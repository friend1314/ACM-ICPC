#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<fstream>
using namespace std;
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,p2,p1,m,s1,s2,b,d,s;
	cin>>n;
	int c[n];
	for(int i=1; i<=n; i++)
		cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	b=0;
	d=0;
	for(int j=1; j<m-1; j++)
		b=b+c[j];
	for(s=m+1; s<=n; s++)
		d=d+c[s];
	if(p1<m)
		b=b+s1;
	if(p1>m)
		d=d+s1;
	if(d>b&&d-b>s2+b-d) p2=m+1;
	else if(b>d&&b-d>s2+d-b) p2=1;
	else p2=m;
	cout<<p2<<"\n";
	return 0;
}
