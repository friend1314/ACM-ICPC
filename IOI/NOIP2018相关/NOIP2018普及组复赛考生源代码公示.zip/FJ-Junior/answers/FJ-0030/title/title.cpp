#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string.h>
#include<string>
#include<fstream>
#include<algorithm>
#define INS 1000001
using namespace std;
int main()
{
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    char a;  
    long long ans; 
    scanf("%s",&a);   
    if(a>-INS&&a<INS)
    {
    if(a<10) ans=1;
    else if(a<100&&a>=10) ans=2;
    else if(a<1000&&a>=100) ans=3;
    else if(a<10000&&a>=1+999) ans=4;
    else if(a<100000&&a>=1+9999) ans=5;
    }
    cout<<ans;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
