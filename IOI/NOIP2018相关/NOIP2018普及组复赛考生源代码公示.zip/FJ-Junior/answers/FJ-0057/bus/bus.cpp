#include<iostream>
#include<stdio.h>
using namespace std;
int a[100000];
int s(int &a,int &b)
{
int t=a; a=b; b=t;	
}
int q(int r)
{
for(int i=r;i>0;i--)
	for(int j=0;j<i-1;j++)
	if(a[j]>a[j+1]) s(a[j],a[j+1]);
	return 0;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	bool v=0;
	int i,j,n,m,k,t=1,l=0,ans=0;
	cin>>n>>m;
	for(i=0;i<n;i++)
	cin>>a[i];
	q(n);
	k=0;
	for(i=a[0];i<a[n-1];i++)
	{
		k=0;
		t--;
		if(t==0) v=0;
		for(j=0;j<n;j++)
		if(a[j]==i) k++;
		l+=k;
		if(v==0)
		{
			l-=k;
			v=1;
			t=m;
		}
		else 
		ans+=l;	
	}
	cout<<ans<<'\n';
	return 0;
}
