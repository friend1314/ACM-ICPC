#include<iostream>
#include<stdio.h>
using namespace std;
int a[1000000],l[1000000],r[1000000];
int main()
{	
freopen("tree.in","r",stdin);
freopen("tree.out","w",stdout);
	int i,j,n;
	cin>>n;
	for(i=0;i<n;i++)
	cin>>a[i];
	for(i=0;i<n;i++)
	cin>>l[i]>>r[i];
	j=1;
	cout<<j<<'\n';
	return 0;
}
