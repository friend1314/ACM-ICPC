#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	char c;
	int i,ans=0;
	while(cin>>c&&c!=' '&&c!='\n')
	ans++;
	cout<<ans<<'\n';
	return 0;
}
