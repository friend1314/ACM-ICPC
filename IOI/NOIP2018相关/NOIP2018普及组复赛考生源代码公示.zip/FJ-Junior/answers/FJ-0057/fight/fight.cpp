#include<iostream>
#include<cmath>
using namespace std;
int a[100010];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int i,j,k,l,n,ans1=0,ans2=0,w,q=0;
	long long minn=999999999999999999;
	int m,p1,p2,s1,s2;
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	for(i=1;i<=n;i++)
	{
	a[i]*=abs(m-i);
	if(m>i) ans1+=a[i];
	else ans2+=a[i];
	}
	w=abs(ans1-ans2);
	for(i=1;i<=n;i++)
		if(abs(w-s2*abs(m-i))<minn)
		{
			minn=abs(w-s2*(m-i));
			q=i;
		}
cout<<q<<endl;
return 0;
}
	
