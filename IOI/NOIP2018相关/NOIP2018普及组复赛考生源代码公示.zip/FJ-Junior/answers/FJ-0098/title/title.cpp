#include<cstdio>
/* Temp   */char TmpA;
/* Count  */ int CountC=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(!feof(stdin))
	{
		TmpA=getchar();
		if(TmpA!=' '&&TmpA!='\n'&&TmpA!=-1)CountC++;
	}
	printf("%d",CountC);
	return 0;
}
