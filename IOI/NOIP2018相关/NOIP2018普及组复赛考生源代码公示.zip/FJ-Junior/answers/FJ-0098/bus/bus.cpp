#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
/* Input  */ int InpM,InpN,InpV[100001];
/* Loop   */ int LoopI,LoopJ;
/* Count  */ int CountC=0,CountN=0;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>InpN>>InpM;
	if(InpM==1)
	{
		cout<<0;
		return 0;
	}
	else
	{
		for(LoopI=1;LoopI<=InpN;LoopI++)cin>>InpV[LoopI];
		sort(InpV+1,InpV+InpM);
		for(LoopI=1;LoopI<=InpN;LoopI++)
		{
			if(InpV[LoopI+1]-InpV[CountN]>=InpM)
			{
				for(LoopJ=CountN;LoopJ<=LoopI;LoopJ++)
				{
					CountC+=InpV[LoopI]-InpV[CountN];
				}
				CountN=LoopI+1;
			}
		}
		cout<<CountC;
		return 0;
	}
}
