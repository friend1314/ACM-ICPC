#include<iostream>
#include<cstdio>
using namespace std;
/* Input  */ int InpN,InpV[100001][3];
/* Temp   */ int TmpA;
/* Loop   */ int LoopI,LoopJ;
/* Maxnum */ int MaxM;

/* Temp Of Function */ int TmpTrav[50000],TmpRTrav[50000],TmpSize,now=1;
void FnTrav(int start,bool switc_h)//Front Travel
{
	if(start==-1)return;
	if(switc_h)
	{
		TmpTrav[now++]=InpV[start][0];
		FnTrav(InpV[start][1],1);
		FnTrav(InpV[start][2],1);
		TmpSize=now;
	}
	else
	{
		TmpRTrav[now++]=InpV[start][0];
		FnTrav(InpV[start][1],0);
		FnTrav(InpV[start][2],0);
		TmpSize=now;
	}
}

/* Temp Of Function */ int TmpRecursion[100001];
bool FnIs(int num)
{
	if(TmpRecursion[num])return TmpRecursion[num];
	FnTrav(num,0);
	now=1;
	FnTrav(num,1);
	for(LoopJ=1;LoopJ<=InpN;LoopJ++)if(TmpTrav[LoopJ]!=TmpRTrav[LoopJ])return false;
	return (FnIs(InpV[num][1])&&FnIs(InpV[num][2]));
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>InpN;
	for(LoopI=1;LoopI<=InpN;LoopI++)cin>>InpV[LoopI][0];
	for(LoopI=1;LoopI<=InpN;LoopI++)cin>>InpV[LoopI][1]>>InpV[LoopI][2];
	for(LoopI=1;LoopI<=InpN;LoopI++)
	{
		if(FnIs(LoopI))
		{
			if(MaxM<TmpSize)MaxM=TmpSize;
		}
	}
	cout<<MaxM;
}
