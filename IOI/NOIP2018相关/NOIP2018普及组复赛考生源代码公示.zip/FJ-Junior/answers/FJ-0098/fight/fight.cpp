#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
/* Input  */ int InpN,InpV[10001],InpM,InpS,InpP,InpR;
/* Loop   */ int LoopI,LoopJ;
/* Temp   */long long TmpD=0,TmpT=0; //Dragon and Tiger
/* Temp   */long long TmpC;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>InpN;
	for(LoopI=1;LoopI<=InpN;LoopI++)cin>>InpV[LoopI];
	cin>>InpM>>InpP>>InpS>>InpR;
	for(LoopI=1;LoopI<=InpN;LoopI++)
	{
		if(LoopI==InpM)continue;
		if(LoopI<InpM)
		{
			TmpD+=InpV[LoopI]*abs(LoopI-InpM);
			if(LoopI==InpP)TmpD+=InpS*abs(LoopI-InpM);
		}
		else
		{
			TmpT+=InpV[LoopI]*abs(LoopI-InpM);
			if(LoopI==InpP)TmpT+=InpS*abs(LoopI-InpM);
		}
	}
	TmpC=ceil((TmpD-TmpT)*1.0/InpR);
	cout<<TmpC;
	return 0;
}
