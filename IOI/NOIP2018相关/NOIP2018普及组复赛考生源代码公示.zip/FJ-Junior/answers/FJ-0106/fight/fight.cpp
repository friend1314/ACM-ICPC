#include<iostream>
#include<stdio.h>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#include<cstdio>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	int n;
	int c[1000];
	int t1=0,t2=0;
	int m,p1,s1,s2;
	int p2;
	int x[1000];
	
	scanf("%d",&n);
	for(int i=1; i<=n; i++){
		scanf("%d",&c[i]);
	}
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	x[n+1]=100000;
	for(int i=1; i<=m-1; i++){
		t1+=c[i]*(m-i);
		if(p1==i) t1+=s1*(m-i);
	}
	for(int j=n; j>=m+1; j--){
		t2+=c[j]*(j-m);
		if(p1==j) t2+=s1*(j-m);
	}
	
	if(t1<t2){
		for(int i=1; i<=m-1; i++){
			x[i]=abs(t2-(t1+s2*(m-i)));
		}
		for(int i=1; i<m-1; i++){
			for(int j=i+1; j<=m-1; j++){
				if(x[i]>x[j]){
					p2=j;
				 printf("%d",p2);
				 return 0;
			}else {
		p2=i;
			printf("%d",p2);
			return 0;}
			}
		}
	}
	if(t2<t1){
		for(int j=n; j>=m+1; j--){
			x[j]=abs(t1-(t2+s2*(j-m)));
		}	
			for(int i=1; i<m-1; i++){
			for(int j=i+1; j<=m-1; j++){
				if(x[i]>x[j]){
					p2=j;
				 printf("%d",p2);
				 return 0;
			}else {
		p2=i;
			printf("%d",p2);
			return 0;}
			}
		}
	}
	

	fclose(stdin);
	fclose(stdout);
	return 0;
}
