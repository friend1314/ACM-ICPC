#include<iostream>
#include<stdio.h>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#include<cstdio>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	int n,i,t[1000],m,tot=0;
	int q=0,j;
	
	scanf("%d%d",&n,&m);
	for(i=1; i<=n; i++){
		scanf("%d",&t[i]);
	}
//	int g=t[n];
//	sort(t[1],t[n]);
	for(i=1; i<=n-1; i++){
		for(j=i+1; j<=n; j++){
			if(t[i]>t[j]){
				q=t[i];
				t[i]=t[j];
				t[j]=q;
			}
		}
	}
	for(i=1; i<=n-1; i++){
		for(j=i+1; j<=n; j++){
			if(t[i]==t[j]) t[j]=0;
		}
	}

	for(i=2; i<=n; i++){
		if(t[i]>t[1]){
			if((t[i-1]+m)>t[i]) tot+=t[i-1]+m-t[i];
		} 
	}
	printf("%d",tot);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
