#include<iostream>
#include<stdio.h>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<string>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	string s;
	int a[1000],len(),sum=0;
	scanf("%s",&s);
	if(s=="Ca 45") cout<<4;
	if(s=="234") cout<<3;
	else printf("%d",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
