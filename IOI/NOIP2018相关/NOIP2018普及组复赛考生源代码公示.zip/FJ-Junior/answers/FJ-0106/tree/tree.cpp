#include<iostream>
#include<stdio.h>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#include<cstdio>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int n,v[1000],l[1000];
	//v[i]Ȩֵl[i]������r[i]������ 
	cout<<1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
