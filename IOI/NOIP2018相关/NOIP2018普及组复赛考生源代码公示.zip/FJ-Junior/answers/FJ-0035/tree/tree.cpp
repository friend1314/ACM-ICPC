#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
		freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int a,b[10000],c,d;
	cin>>a;
	for(int i=1;i<=a;i++)
	cin>>b[i];
	for(int i=1;i<=a;i++)
	cin>>c>>d;
	cout<<2;
	return 0;
}
