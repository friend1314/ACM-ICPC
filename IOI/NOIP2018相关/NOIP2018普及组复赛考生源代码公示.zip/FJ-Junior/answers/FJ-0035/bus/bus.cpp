#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int a,b,c[100000],d[10000],r,k[10000][100],ans,ans2,m,z;
int main()
{
		freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=a;i++)
	{
		cin>>a;
		if(c[a]==0)
		{
			r++;
			c[r]=a;
		}
		d[a]++;
}
sort(c+1,c+r);
m+=b;
for(int i=2;i<=r;i++)
{
	if(c[i]>=m&&!c[i])
	{
		for(int j=i+1;j<=r;j++)
		{
			if(c[j]-c[i]<c[i]+b-c[j])
			{
				cout<<1;
				ans+=c[j]-c[i];
				c[j]=1;
				break;
			}
			else{
				z++;
				ans2=c[i+z]-c[i];
				c[i]=1;
				c[i+z]=1;
			}
		}
	}
	m+=b;
	ans+=ans2;
}
cout<<ans;
return 0;
}
