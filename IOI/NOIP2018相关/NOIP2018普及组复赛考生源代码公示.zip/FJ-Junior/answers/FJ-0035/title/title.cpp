#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char a[100000];
long int b,c;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	b=strlen(a);
	for(int i=0;i<b;i++)
	{
	if(a[i]!=' '&&a[i]!='\n')c++;	
	}
	cout<<c;
	return 0;
 } 
