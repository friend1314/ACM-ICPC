#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long int n,b[100000],m,p1,s1,s2,c[100000],ans,ans2,k=999999,z=999999,v,u,x=999999;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>b[i];
	cin>>m>>p1>>s1>>s2;
	b[p1]+=s1;
	for(int i=1;i<m;i++)
	{
	c[i]=b[i]*(m-i);
	ans+=c[i];
}
	for(int i=n;i>=m;i--)
	{
	c[i]=b[i]*(i-m);
	ans2+=c[i];
}
if(ans<ans2)
{
	for(int i=1;i<m;i++)
	{
		v=s2*(m-i)+ans;
		if(v==ans2)
		{
			 cout<<i;
			 return 0;
		}
		else{
			if(abs(v-ans2)<k)
		{
			k=abs(v-ans2);
			 if(i<z)z=i;
		}
		}
	}
	cout<<z;
	return 0;
}
else if(ans>ans2){
	for(int i=n;i>m;i--)
	{
		u=s2*(i-m)+ans2;
			if(u==ans)
		{
			 cout<<i;
			 return 0;
		}
		else{
			if(abs(u-ans2)<x)
		{
			x=abs(u-ans2);
			 if(i<z)z=i;
		}
		}
	}
	cout<<z;
	return 0;
}
else{
	cout<<m;
	return 0;
}
}
