#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cmath>
#include <algorithm>
using namespace std;
char a[100001];
int ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	ans=0;
	for(int i=0;i<strlen(a);i++)
	{
		if(a[i]>='a'&&a[i]<='z' || a[i]>='A'&&a[i]<='Z' || a[i]>='0'&&a[i]<='9')	ans++;
	}
	cout<<ans<<endl;
	return 0;
}
