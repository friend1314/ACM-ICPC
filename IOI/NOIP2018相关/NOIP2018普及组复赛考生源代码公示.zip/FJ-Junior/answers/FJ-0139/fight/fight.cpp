#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cmath>
#include <algorithm>
using namespace std;
int c[100001];
int n,cha,ans=1;
int m,p,s1,s2;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int a=1;a<=n;a++) cin>>c[a];
	cin>>m>>p>>s1>>s2;
	c[p]=c[p]+s1;
	int h=0,l=0;
	
	for(int i=m+1;i<=n;i++)
		h+=c[i]*(i-m);
	for(int i=1;i<m;i++)
		l+=c[i]*(m-i);
		
	int cha=abs(h-l);
	if(l<h)
	{
		for(int i=1;i<m;i++)
			if(abs(((m-i)*s2+l)-h)<cha)
			{
				cha=abs((l+s2*(m-i))-h);
				ans=i;
			}
	}
	if(l>h)
	{
		for(int i=m+1;i<n;i++)
			if(abs(((i-m)*s2+h)-l)<cha ) 
			{
				cha=abs((h+s2*(i-m))-h);
				ans=i;
			}
	}
	if(l==h&&s2!=0) ans=m;
	cout<<ans<<endl;
	return 0;
}
