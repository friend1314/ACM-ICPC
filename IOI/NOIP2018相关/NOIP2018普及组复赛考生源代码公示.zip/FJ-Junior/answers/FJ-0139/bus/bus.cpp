#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <cmath>
#include <algorithm>
using namespace std;
int n,m,t[501],f[501];
int ans=0;

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++) { cin>>t[i]; f[i]=t[i];}
	sort(t+1,t+n+1);
	sort(f+1,f+n+1);
	if(m!=1)
	{
		int i=1;
		while(i<=n)
		{
			if(t[i]==t[i+1])
			{
				int gs=0;
				int x=t[i];
				while(t[i]==x)
				{
					f[i]=0;
					i++; gs++;
				}
				if(t[i+1]-t[i]>gs*(t[i]-t[i-1]))
				{
					ans+=gs*(t[i]-t[i-1]);
				}
				i--;
			}
			else if(t[i+1]-t[i]>=m)
			{
				for(int c=i;f[c]!=0;c--)
				{
					ans+=t[i]-t[c];
					f[c]=0;
				}
			}
			else if(t[i]-t[i-1]<=t[i+1]-t[i])
			{
				for(int c=i;f[c]!=0;c--)
				{
					ans+=t[i]-t[c];
					f[c]=0;
				}
			}
			i++;
		}
	}
	cout<<ans<<endl;
	return 0;
}
