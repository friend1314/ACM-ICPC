#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<string>
#include<cmath>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int sum=0;
	getline(cin,s);
	for(int i=0; i<s.length(); i++)
	{
		if(s[i]!=' '&&s[i]!='\n')
		{
			sum++;
		}
	}
	cout<<sum;
	return 0;
}
