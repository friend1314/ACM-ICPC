#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<string>
#include<cmath>
using namespace std;
long long s[200000],result=2147483646,resnum,suma=0,sumb=0;
long long countpower(long long a,long long m)
{
	suma=0;
	sumb=0;
	for(long long i=1; i<m; i++)
	{
		suma+=s[i]*(m-i);
	}
	for(long long i=m+1; i<=a; i++)
	{
		sumb+=s[i]*(i-m);
	}
	return abs(suma-sumb);
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long a,m,p1,s1,s2;
	cin>>a;
	for(long long i=1; i<=a; i++)
	{
		scanf("%lld",&s[i]);
	}
	cin>>m>>p1>>s1>>s2;
	s[p1]+=s1;
	for(long long i=1; i<=a; i++)
	{
		s[i]+=s2;
		if(countpower(a,m)<result)
		{
			result=countpower(a,m);
			resnum=i;
		}
		s[i]-=s2;
	}
	cout<<resnum;
	return 0;
}
