#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<string>
using namespace std;
int a[100001],n,ci,m,p1,s1,s2,c[100001],q[100001],l,h;
int d,ans,sum=0x7fffffff,b1;
void csl(int x)
{
	if(l==h) ans=m;
	if(l>h) 
	{
		for(int i=n;i>n-m;i--)
		{
			d=h+x*c[i];
			if(l>d) b1=l-d;
			if(l<d) b1=d-l;
			if(d==l) ans=i;
			if(d!=l&&b1<sum) {	ans=i;sum=b1;}
			d-=x*c[i];b1=0;
		}
	}
	if(h>l) 
	{
		for(int i=1;i<=m;i++)
		{
			d=l+x*c[i];
			if(d==h) ans=i;
			if(d>h) b1=d-h;
			if(d<h) b1=h-d;
			if(d!=h&&b1<sum) { ans=i;sum=b1;}
			d-=x*c[i];b1=0;
		}
		
		
	}
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>ci;a[i]=ci;
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=n;i++)
		{
			if(m>=i) c[i]=m-i;
			else
			c[i]=i-m;
		}
		for(int i=1;i<=n;i++)
		{
			q[i]=a[i]*c[i];	
		}
		for(int i=1;i<=n;i++)
		{
			if(i<m) l+=q[i];
			else
			h+=q[i];
		}
		if(p1>m) h+=c[p1]*s1; else l+=c[p1]*s1;
	
		csl(s2);
	cout<<ans;

	fclose(stdin);
	fclose(stdout);
	
	
	return 0 ;
}
