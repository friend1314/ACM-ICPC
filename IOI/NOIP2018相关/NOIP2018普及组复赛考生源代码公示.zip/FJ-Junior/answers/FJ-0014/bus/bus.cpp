#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<string>
using namespace std;
int n,m,a[5001],c[4000001],b[501];
int ans,t,x=1;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		int b;cin>>b;a[i]=b;
	}	
	sort(a,a+n);
	b[1]=a[1];
	for(int i=1;i<=n;i++) 
	{
		if(b[x]!=a[i]) {b[x+1]=a[i];x++;} 
		
		}	

	for(int i=1;i<=n;i++)
	{
		t=b[i]+m;
		if(t==b[i+1]) ans+=0;
			if(t!=b[i+1])
			{
				if((b[i+2]-b[i+1])>m) ans=ans+b[i+2]-t-b[i+1]; 
				if((b[i+1]-b[i])<m) ans=ans+b[i+1]-b[i];
				if(t>b[i+1]) ans=ans+t-b[i+1];		
			}
		
	}
	

	
cout<<ans;

	fclose(stdin);
	fclose(stdout);
	
	
	return 0 ;
}
