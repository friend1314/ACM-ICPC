#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<string>
using namespace std;
string a;
char s[10];
int b;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin>>a;
	for(int i=0;i<10;i++)
	{
		s[i]=a[i];
	}
	for(int i=0;i<10;i++)
	{
	if((s[i]>=65&&s[i]<=90)||(s[i]>=97&&s[i]<=122))b++;
	if(s[i]>=49&&s[i]<=57) b++;
	}
	cout<<b;
	fclose(stdin);
	fclose(stdout);
	
	
	return 0 ;
}
