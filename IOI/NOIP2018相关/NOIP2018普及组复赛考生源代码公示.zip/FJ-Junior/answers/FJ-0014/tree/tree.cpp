#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<string>
using namespace std;
int n,m,a[5001],c[4000001],b[501];
int ans,t,x=1;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
for(int i=1;i<=n;i++)
{
	cin>>m;a[i]=m;
}
for(int i=1;i<=n;i++)
{
	cin>>ans>>t;
}

cout<<n/2;

	fclose(stdin);
	fclose(stdout);
	
	
	return 0 ;
}
