#include<iostream>
#include<cstdio>
using namespace std;
int n,m,s1,s2,p1,dr,ti,big;
int ans=1e9+2,ans0,answer,a[100005];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	for(int i=1;i<=n;i++)
	{
	  a[i]*=max(i,m)-min(i,m);
	  if(i<m) dr+=a[i];
	  if(i>m) ti+=a[i];
	}
	if(dr==ti)
	{
	  cout<<m<<endl;
	  return 0;
	}
	if(dr>ti)
	  for(int i=m+1;i<=n;i++)
	  {
	  	big=ti+s2*(i-m);
	  	ans0=ans;
	  	ans=min(ans,max(big,dr)-min(big,dr));
	  	if(ans0!=ans) answer=i;
	  }
	else
	  for(int i=1;i<m;i++)
	  {
	  	big=dr+s2*(m-i);
	  	ans0=ans;
	  	ans=min(ans,max(big,ti)-min(big,ti));
	  	if(ans0!=ans) answer=i;
	  }
	cout<<answer<<endl;
	return 0;
}
