#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char str[15];
int ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(str);
	for(int i=0;;i++)
	{
	  if((str[i]>='a'&&str[i]<='z')||(str[i]>='A'&&str[i]<='Z')||(str[i]>='0'&&str[i]<='9')) ans++;
	  else if(str[i]!=' ') break;
	}
	cout<<ans<<endl;
	return 0;
}
