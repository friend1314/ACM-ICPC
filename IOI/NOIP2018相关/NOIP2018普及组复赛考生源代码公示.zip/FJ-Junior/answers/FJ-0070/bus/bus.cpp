#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,ans=4000005;
int a[505],t[505],tt;
void bus(int ti,int an,int go,int lev,int k,int l)
{
	k+=t[ti];
	if(lev>0) lev--;
	if(lev>0) l++;
	if(l>m) return;
	if(ti==tt)
	{
	  ans=min(ans,an);
	  return;
	}
	if(go==1) bus(ti+1,an,0,m,0,0);
	else if(t[ti+1]==0||lev>0) bus(ti+1,an+k,0,lev,k,l);
	else
	{
	  bus(ti+1,an+k,0,lev,k,l);
	  bus(ti+1,an+k,1,lev,k,l);
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>a[i],t[a[i]]++,tt=max(tt,a[i]);
	if(m==1){cout<<"0"<<endl;return 0;}
	sort(a,a+n);
	bus(0,0,0,0,0,0);
	cout<<ans<<endl;
	return 0;
}
