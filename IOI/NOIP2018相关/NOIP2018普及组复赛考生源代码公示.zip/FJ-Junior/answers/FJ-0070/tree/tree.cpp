#include<iostream>
#include<cstdio>
using namespace std;
int n,ans=1;
int a[1000005],le[1000005],ri[1000005];
int main()
{
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=1;i<=n;i++) cin>>le[i]>>ri[i];
    int i=1,j=1;
    if(a[le[i]]==a[ri[j]&&a[le[i]]!=-1]) ans++;
    i=le[i],j=ri[j];
    if(a[le[i]]==a[ri[j]]&&a[le[i]]!=-1) ans++;
	cout<<ans<<endl;
	return 0;
}
