#include <iostream>
#include <cstdio>
#include <string.h>
using namespace std;
char c;
int w;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    while (c=getchar())
    {
    	if (c=='\n') break;
    	if (c==' ') w--;
    	w++;
	}
	cout<<w;
	return 0;
}
