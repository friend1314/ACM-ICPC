#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n,m,a[505],f[505];
int sum1,sum2,lt[4000005],rt[4000005],ans,t;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	//cout<<m;
	for (int i=1;i<=n;i++) cin>>a[i];
	//for (int i=1;i<=n;i++) cout<<a[i]<<" ";
	sort(a+1,a+1+n);
	int k=0;
	for (int i=1;i<=4e6+5;i++)
	{
		while (a[k]<i) k++;
		lt[i]=k-1,rt[i]=k;
		if (a[k]==i) lt[i]=k,rt[i]=k;
	}
//	for (int i=1;i<=13;i++) printf("%d %d\n",lt[i],rt[i]);
	for (int i=1;i<=n;i++)
	{
		//printf("%d ",t);
		sum1=0,sum2=0;
		if (a[i]==t) {continue;}
		if (a[i]>=t+m) {t=a[i];continue;}
		sum1=t+m-a[i];
		for (int j=rt[t]+1;j<=i-1;j++) sum2+=a[i]-t-m;
		for (int j=lt[t];j>=1;j--)
		{
		    if (t-a[j]>=m) break;
		    sum2+=a[i]-t;
		    //if (i==5) cout<<rt[t];
		}
		if (sum1<sum2) f[i]=sum1;	
		else
		{
			for (int j=lt[t];j>=1;j--)
			{
				if (t-a[j]>=m) break;
				f[j]=a[i]-a[j];
			}
			for (int j=rt[t]+1;j<=i-1;j++) f[j]=a[i]-a[j];
			t=a[i];
		}
		
	    //printf("%d %d\n",sum1,sum2);
	}
	for (int i=1;i<=n;i++) ans+=f[i];
	printf("%d",ans);
	return 0;
}
/*5 5
11 13 1 5 5*/ 
