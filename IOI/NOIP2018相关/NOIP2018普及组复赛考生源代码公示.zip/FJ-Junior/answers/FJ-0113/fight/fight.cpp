#include <iostream>
#include <cstdio>
#include <algorithm>
#include <stdlib.h>
#include <cmath>
using namespace std;
long long n,a[100005];
long long m,p1,s1,s2,ans;
long long sum,cnt1,cnt2,Min;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
    scanf("%lld",&n);
    for (int i=1;i<=n;i++) scanf("%lld",&a[i]);
    scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
    a[p1]+=s1;
    for (int i=1;i<=n;i++)
    {
    	if (i<m) cnt1+=(m-i)*a[i];
    	else cnt2+=(i-m)*a[i];
	}
	
	Min=1e18;
	for (int i=1;i<=n;i++)
	{
		sum=abs(i-m)*s2;
		if (i<m&&abs(cnt1+sum-cnt2)<Min) {ans=i;Min=abs(cnt1+sum-cnt2);}
		if (i>m&&abs(cnt2+sum-cnt1)<Min) {ans=i;Min=abs(cnt2+sum-cnt1);}
	}
	printf("%lld",ans);
//cout<<abs(-1);
	return 0;
}
