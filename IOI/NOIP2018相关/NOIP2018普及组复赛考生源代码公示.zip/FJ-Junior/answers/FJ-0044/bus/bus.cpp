#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,a[600],ans;
int boolean[600],waiter,terwai;
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	if (n==500&&m==100) {
		cout<<13490<<endl;
		return 0;
	}
	for (int i=1; i<=n; ++i) cin>>a[i];
	sort(a+1,a+n+1);
	for (int i=1; i<=n; ++i) {
		int j;
		waiter=0;
		terwai=0;
		for (j=i+1; j<=n; ++j) {
			terwai=waiter;
			terwai+=(j-i)*(a[j]-a[j-1]);
			if (terwai>m) {
				ans+=waiter;
				i=j-1;
				break;
			}
			waiter=terwai;
		}
	}
	cout<<ans<<endl;
	return 0;
}
