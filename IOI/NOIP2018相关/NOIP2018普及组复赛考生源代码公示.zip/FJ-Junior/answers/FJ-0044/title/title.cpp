#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int ans;
string str;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,str);
	int len=str.size();
	for (int i=0; i<len; ++i)
		if (str[i]!=' ') ans++;
	cout<<ans<<endl;
	return 0;
}
