#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,p1,s1,p2,s2;
int c[100005],air[100005];
long long dg,tg,minn=100000000000005,minm;
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for (int i=1; i<=n; ++i) scanf("%d",&c[i]);
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for (int i=1; i<=n; ++i)
		if (i!=m) air[i]=c[i]*abs(m-i);
	for (int i=1; i<m; ++i) dg+=air[i];
	for (int i=m+1; i<=n; ++i) tg+=air[i];
	if (dg==tg) {
		cout<<m<<endl;
		return 0;
	}
	if (dg<tg) {
		for (int i=1; i<=m; ++i) {
			if (abs(tg-(dg+s2*abs(m-i)))<minn) {
				minn=abs(tg-(dg+s2*abs(m-i)));
				minm=i;
			}
		}
	} else {
		for (int i=m; i<=n; ++i) {
			if (abs(dg-(tg+s2*abs(m-i)))<minn) {
				minn=abs(dg-(tg+s2*abs(m-i)));
				minm=i;
			}
		}
	}
	cout<<minm<<endl;
	return 0;
}
