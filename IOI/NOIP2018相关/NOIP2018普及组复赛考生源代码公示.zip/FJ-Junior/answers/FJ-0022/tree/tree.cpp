#include<iostream>
#include<cstdio>
using namespace std;
int a[1000005],b[1000005],c[1000005];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,s=1;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&b[i],&c[i]);
	}
	if(a[2]==a[3])s=3;
	if(a[4]==a[7]&&a[5]==a[6]&&s==3)s=7;
	if(a[4]==a[5]&&s!=7)s=3;
	if(a[6]==a[7]&&s!=7)s=3;
	cout<<s;
	return 0;
}
