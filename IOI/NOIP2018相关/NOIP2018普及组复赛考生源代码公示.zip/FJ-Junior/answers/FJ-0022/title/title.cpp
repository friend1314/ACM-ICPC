#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int s=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char n;
	while(scanf("&s",&n)!=EOF)
	{
		n=getchar();
		if(n!=' '&&n!='\n')
		{
			s++;
		}
	}
	cout<<s;
	return 0;
}
