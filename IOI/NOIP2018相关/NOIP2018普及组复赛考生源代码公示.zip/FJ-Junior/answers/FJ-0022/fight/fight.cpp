#include<iostream>
#include<cstdio>
using namespace std;
long long a[100005],b[100005];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,m,x,y,z,q=0,w=0,p,j,l,u,jj,ll,s;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	cin>>m>>x>>y>>z;
	for(int i=1;i<m;i++)
	{
		q+=a[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		w+=a[i]*(i-m);
	}
	if(x>m)w+=y*(x-m);
	if(x<m)q+=y*(m-x);
	if(q>w)
	{
		p=q-w;
		j=m+1;l=n;
	while(j-l>1)
	{u=(j+l)/2;
		if(z*(u-m)>=p)
		{
				l=u;
				continue;
		}
		if(z*(u-m)<p)
		{
				j=u;
				continue;
		}
	}
	jj=(j-m)*z;
	ll=(l-m)*z;
	}
	if(w>q)
	{
		p=w-q;
		j=m-1;l=1;
	while(j-l>1)
	{u=(j+l)/2;
		if(z*(m-u)>=p)
		{
				l=u;
				continue;
		}
		if(z*(m-u)<p)
		{
				j=u;
				continue;
		}
	}
	jj=(m-j)*z;
	ll=(m-l)*z;
	}
	if(w==q)
	{
		cout<<m;
		return 0;
	}		
	jj=p-jj;
	ll=ll-p;
	if(jj>ll)s=l;
	else s=j;
	if(p<jj&&p<ll)s=m;
	cout<<s;
	return 0;
}
