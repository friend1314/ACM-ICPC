#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[505];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,x=1,s=0,l=0,v=1000000,p,q,w=0,e=0,g=0,t=0,ans=0,y;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+1+n);
	while(ans<n)
	{
		l=0;
		if(x>n)
		{
			for(int i=ans+1;i<=n;i++)
			{
				s+=a[ans]+m-a[i];
			}
			break;
		}
	    for(int i=x;i<=n;i++)
	    {
	    	l=0;
	    	for(int j=x;j<i;j++)
	    	{
	    		l+=a[i]-a[j];
	    		
			}
		
				for(int j=i+1;a[j]<a[i]+m&&j<=n;j++)
			{
				l+=a[i]+m-a[j];q=j-i;
			}
			l+=w*(a[i]-e);
			
			if(l<=v)
			{
				y=i;
				g=a[i]+m;
				v=l;
				p=q;
				t=0;
			}
        }
	    s+=v;
	     w=p;
	    ans=y;
	    e=g;
	    l=0;
	    v=1000000;
		if(t==0)x=x+w+1;
	    q=0;
		for(int u=x;a[u]<e+m&&u<=n;u++)
		{
			l+=e+m-a[u];q=u-(x);
		}
		
				g=e+m;
				v=l;
				p=q;
				y=x-1;
				t=1;
		
}
	cout<<s;
	return 0;
}
