#include<cstdio>
using namespace std;
char c; int i,s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	while(1)
	{
		scanf("%c",&c);
		if(c=='\n')
			break;
		if(c!=' ')
			s++;
	}
	printf("%d\n",s);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
