#include<cstdio>
#include<cmath>
using namespace std;
unsigned long long n,m,p,s,q,t,x,y,i,j,min=99999999,mini=99999999,a[100010]; bool f=1;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		scanf("%d",&a[i]);
	scanf("%d%d%d%d",&m,&p,&s,&t);
	a[p]+=s;
	for(i=1;i<=m-1;i++)
		x=x+a[i]*(m-i);
	for(i=m+1;i<=n;i++)
		y=y+a[i]*(i-m);

//------------------------------------------------------------

	if(x==y)
	{
		printf("%d\n",m); f=0;
	}
	else
	{
		if(x<y)
			for(i=1;i<=m-1;i++)
				if(x+t*(m-i)==y)
				{
					printf("%d\n",i);
					f=0; break;
				}
				else if(abs(x+t*(m-i)-y)<min)
				{
					min=abs(x+t*(m-i)-y);
					if(mini>i)
						mini=i;
				}
		else
			for(i=m+1;i<=n;i++)
				if(x+t*(m-i)==y)
				{
					printf("%d\n",i);
					f=0; break;
				}
				else if(abs(y+t*(i-m)-x)<min)
				{
					min=abs(x+t*(m-i)-y);
					if(mini>i)
						mini=i;
				}
	}
	if(f)
		printf("%d\n",mini);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
