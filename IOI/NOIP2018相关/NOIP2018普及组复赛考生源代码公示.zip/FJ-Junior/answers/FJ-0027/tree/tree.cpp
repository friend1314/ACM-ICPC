#include<iostream>
#include<cstdio>

using namespace std;

struct student
{
	int value;
	int left;
	int right;
	int root;
	int s;
};

student tree[1000001];
int ans=1;

bool dg(int i)
{
	if(i==-1)return 0;
	tree[i].s=1;
	if(tree[i].left==-1 && tree[i].right==-1)
	{
		tree[tree[i].root].s++;
		return 1;
	}
	bool lflag=dg(tree[i].left);
	bool rflag=dg(tree[i].right);
	tree[tree[i].root].s+=tree[i].s;
	if(lflag && rflag && tree[tree[i].left].value==tree[tree[i].right].value && tree[tree[i].left].s==tree[tree[i].right].s)
	{
		ans=max(tree[i].s,ans);
		return 1;
	}
	return 0;
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&tree[i].value);
	for(int i=1;i<=n;i++)
	{
		scanf("%d %d",&tree[i].left,&tree[i].right);
		tree[tree[i].left].root=tree[tree[i].right].root=i;
	}
	dg(1);
	printf("%d",ans);
}
