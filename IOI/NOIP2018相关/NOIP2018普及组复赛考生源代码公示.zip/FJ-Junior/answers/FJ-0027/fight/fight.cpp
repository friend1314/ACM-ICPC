#include<algorithm>
#include<iostream>
#include<cstdio>
#include<cmath>

using namespace std;
long long a[100001];
long long d,t;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	long long m,p1,s1,s2;
	scanf("%lld %lld %lld %lld",&m,&p1,&s1,&s2);
	a[p1]+=s1;
	for(int i=1;m-i>0;i++)
		d+=a[m-i]*i;
	for(int i=1;i+m<=n;i++)
	    t+=a[m+i]*i;
	int ans=m;
	long long tmp,sum=abs(d-t);
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			tmp=(m-i)*s2+d;
			if(abs(tmp-t)<sum)
			{
				ans=i;
				sum=abs(tmp-t);
			}
		}
		else if(i>m)
		{
			tmp=(i-m)*s2+t;
			if(abs(tmp-d)<sum)
			{
				ans=i;
				sum=abs(tmp-d);
			}
		}
	}
	printf("%d",ans);
}
