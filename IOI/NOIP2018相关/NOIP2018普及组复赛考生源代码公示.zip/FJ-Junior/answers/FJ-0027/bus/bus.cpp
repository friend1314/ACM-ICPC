#include<algorithm>
#include<iostream>
#include<cstdio>

using namespace std;

int f[4000101];
int a[4000001];

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,p,tt=0;
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p);
		a[p]++;
		tt=max(tt,p);
	}
	for(int i=1;i<tt+m;i++)
	{
		f[i]=f[i-m];
		for(int j=1;j<m;j++)
		{
			f[i]+=a[i-m+j]*(m-j);
		}
	}
	int ans=1999999999;
	for(int i=0;i<m;i++)
	    ans=min(f[tt+i],ans);
	printf("%d",ans);
}
