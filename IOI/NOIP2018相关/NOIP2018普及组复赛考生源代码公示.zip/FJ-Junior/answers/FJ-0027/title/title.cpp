#include<iostream>
#include<cstdio>

using namespace std;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans=0;
	char c;
	while(cin>>c)
	{
		if((c>='0' && c<='9') || (c>='a' && c<='z') || (c>='A' && c<='Z'))ans++;
	}
	printf("%d",ans);
}
