#include<bits/stdc++.h>
using namespace std;
long long a[100001];
int main(){
	srand(time(0));
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,m,p,q,r,x;
	long long ans=10000000000000000;
	long long dra=0;
	long long tig=0;
	//cout<<"ans="<<ans<<endl;
	cin>>n;
    for(int i=1;i<=n;i++){
		//a[i]=rand()%10+1;
		//cout<<a[i]<<" ";
		cin>>a[i];
	}
	cin>>m>>p>>q>>r;
	//p=rand()%4+1;cout<<p<<" ";
	//q=rand()%10+1;cout<<q<<" ";
	//r=rand()%10+1;cout<<r<<" ";
	//cout<<endl;
	for(int i=1;i<=n;i++){
        if(i<m){
        	if(i!=p){
        		dra=dra+a[i]*(m-i);
        		//cout<<"dra="<<dra<<"tig="<<tig<<"qs="<<a[i]*(m-i)<<"i="<<i<<"m="<<m<<"a[i]="<<a[i]<<endl;
			}
			else{
				dra=dra+(a[i]+q)*(m-i);
				//cout<<"dra="<<dra<<"tig="<<tig<<endl;
			}
		}
		if(i==m) continue;
		if(i>m){
				if(i!=p){
        		tig=tig+a[i]*(i-m);
        		//cout<<"dra="<<dra<<"tig="<<tig<<endl;
			}
			else{
				tig=tig+(a[i]+q)*(i-m);
				//cout<<"dra="<<dra<<"tig="<<tig<<endl;
			}
		}
	}
	//cout<<"dra="<<dra<<"tig="<<tig<<endl;
	if(dra==tig){
		cout<<m<<endl;
		return 0;
	}
	if(dra>tig){
		for(int i=m;i<=n;i++){
			if(abs(dra-tig-(long long)((i-m)*r))<ans){
				ans=abs(dra-tig-(long long)((i-m)*r));
				x=i;
				//cout<<"ans="<<ans<<"i="<<i<<endl;
			}
	}
		//cout<<"ans="<<ans<<endl;
		cout<<x<<endl;
		return 0;
	}
	if(dra<tig){
		for(int i=1;i<=m;i++){
			if(abs(tig-dra-(long long)((m-i)*r))<ans){
				ans=abs(tig-dra-(long long)((m-i)*r));
				x=i;
			}
		}
		//c//out<<"ans="<<ans<<endl;
		cout<<x<<endl;
		return 0;
	}
	return 0;
}
