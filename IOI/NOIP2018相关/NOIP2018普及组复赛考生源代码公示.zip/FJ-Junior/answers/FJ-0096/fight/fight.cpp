#include<cstdio>
using namespace std;
#define INF 0x7fffffff
#define MIN(a,b) ((a)<(b)?(a):(b))
#define afs(a) (a)>0?(a):(-(a))

int n;
int c[100000+1];
long long a,b;
long long check[100000+1];

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	int m,s1,s2,p1;
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	scanf("%d %d %d %d",&m,&p1,&s1,&s2);
	
	for(int i=m-1;i>=1;i--)
		a+=(long long)c[i]*(m-i);
	for(int i=m+1;i<=n;i++)
		b+=(long long)c[i]*(i-m);
	
	if(p1<m) a+=(long long)s1*(m-p1);
	if(p1>m) b+=(long long)s1*(p1-m);
	
	for(int i=1;i<=n;i++)
	{
		if(i==m) check[i]=(long long)afs(a-b);
		else if(i<m)
		{
			long long temp_a=a;
			temp_a+=(long long)(m-i)*s2;
			check[i]=(long long)afs(temp_a-b);
		}
		else if(i>m)
		{
			long long temp_b=b;
			temp_b+=(long long)(i-m)*s2;
			check[i]=(long long)afs(a-temp_b);
		}
	}
	
	//printf("a=%d b=%d\n",a,b);
	//for(int i=1;i<=n;i++) printf("check[%d]=%d\n",i,check[i]);
	
	long long ans=INF;
	int ans_p=0;
	for(int i=1;i<=n;i++)
	{
		if(check[i]<ans) ans=check[i],ans_p=i;
	}
	
	printf("%d",ans_p);
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
