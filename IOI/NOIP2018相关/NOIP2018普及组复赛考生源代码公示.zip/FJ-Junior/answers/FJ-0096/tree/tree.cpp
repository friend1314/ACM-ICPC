#include<cstdio>
using namespace std;
#define MAX(a,b) ((a)>(b)?(a):(b))

int n;
int a[1000000+1];
int b[1000000+1];
int c[1000000+1];

bool check(int,int);
int num(int);

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d %d",&b[i],&c[i]);
	
	int ans=-1;
	for(int i=1;i<=n;i++)
		if(check(b[i],c[i])) ans=MAX(ans,num(i));
	
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
bool check(int e,int f)
{
	if(e==-1&&f==-1) return true;
	if(e==-1||f==-1) return false;
	if(a[e]!=a[f]) return false;
	return check(b[e],c[f])&&check(c[e],b[f]);
}
int num(int x)
{
	int ans=0;
	if(b[x]!=-1) ans+=num(b[x]);
	if(c[x]!=-1) ans+=num(c[x]);
	ans++;
	return ans;
}
