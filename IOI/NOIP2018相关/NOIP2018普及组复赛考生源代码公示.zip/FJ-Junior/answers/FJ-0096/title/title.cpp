#include<cstdio>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	int count=0;
	char str[10];
	gets(str);
	
	int i=0;
	while(str[i]!='\0')
	{
		if(str[i]!=' ') count++;
		i++;
	}
	printf("%d",count);
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
