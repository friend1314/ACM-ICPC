#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,i[10001],j[10001],m,p1,p2,s1;
	cin>>n;
	for(int q=0;q<=n;q++)
	{
		scanf("%d",&i[q]);
		if(m-i[q]>0)
		{
			j[q]=m-i[q];
		}
		else
		{
			j[q]=i[q]-m;
		}
	}
	int k[10001],plus1,plus2;
	for(int r=0;r<m;r++)
	{
	    k[r]=i[r]*j[r];
	    plus1+=k[r];
	}
	for(int t=0;t<n;t++)
	{
	    k[t]=i[t]*j[t];
	    plus2+=k[t];
	}
	if(m-p2>0)
		{
			p2=m-p2;
		}
		else
		{
			p2=p2-m;
		}
	plus1+=p1*p2;
    printf("%.f",(plus1-plus2)/s1);
	return 0;
}
