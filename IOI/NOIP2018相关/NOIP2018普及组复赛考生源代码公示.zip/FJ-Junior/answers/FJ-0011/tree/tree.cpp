#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.out","w",stdout);
	cout<<"Null!"<<endl;
	cout<<"Sorry,I don't know how to do it."<<endl;
	return 0;
}
