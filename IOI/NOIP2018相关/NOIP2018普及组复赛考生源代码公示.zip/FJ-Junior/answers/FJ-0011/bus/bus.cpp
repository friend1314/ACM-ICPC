#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,i[10001],temp,sum;
	cin>>n;
	for(int q=0;q<=n;q++)
	{
		scanf("%d",&i[q]);
	}

	for(int r=0;r<n;r++)
	{
	    for(int t=0;t<=n;t++)
	    {
	        if(i[t]>i[t+1])
	        {
	        	temp=i[t];
	        	i[t]=i[t+1];
	        	i[t+1]=temp;
			}
		}
	}
    for(int y=0;y<=n;y++)
    {
    	if(i[y]%m!=0)
    	{
    		sum+=m-i[y];
		}
	}
	cout<<sum<<endl;
	return 0;
}
