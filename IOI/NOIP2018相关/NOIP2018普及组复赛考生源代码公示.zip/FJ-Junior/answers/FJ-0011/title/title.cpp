#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char x,input[10001],sum;
	cin>>x;
    for(int b=0;b<=10001;b++)
	{
	    input[b]=x;
	}
	for(int a=0;a<=10001;a++)
	{
		if(input[a]=1)
		{
			sum++;
		}
	}
	cout<<sum<<endl;
	return 0;
}
