#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
int n,m,p1,ans;
ll c[2333333],sum1,sum2,s1,s2,minn=1e18;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%lld",&c[i]);
	scanf("%d%d%lld%lld",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	for(int i=1;i<m;++i)
		sum1+=(m-i)*c[i];
	for(int i=m+1;i<=n;++i)
		sum2+=(i-m)*c[i];
	for(int i=1;i<=n;++i)
	{
		ll x;
		x=(m-i)*s2;
		x=abs(sum1+x-sum2);
		if(x<minn)
		{
			minn=x;
			ans=i;
		}
	}
	printf("%d",ans);
	return 0;
}
