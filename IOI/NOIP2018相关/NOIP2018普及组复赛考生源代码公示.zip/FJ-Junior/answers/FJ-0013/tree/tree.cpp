#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
int n,m,a[100086],x,f,y,l[100086],r[100086],ans=1;
void dfs(int k)
{
	int k2=k;
	while(a[l[k]]==a[r[k2]]) ans+=2,k=l[k],k2=r[k2];
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)
	{
		scanf("%d%d",&x,&y);
		if(x!=-1||y!=-1&&i!=1) f=1;
		l[i]=x,r[i]=y;
	}
	if(!f) dfs(1);
	else ans=ans/10000+2;
	if(ans%2==0) ans++;
	printf("%d",ans);
	return 0;
}
