#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
char s[500];
int ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(scanf("%s",s)!=EOF) ans+=strlen(s);
	printf("%d",ans);
	return 0;
}
