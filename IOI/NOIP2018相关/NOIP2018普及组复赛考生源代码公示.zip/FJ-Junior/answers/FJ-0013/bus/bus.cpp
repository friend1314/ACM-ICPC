#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#define ll long long
using namespace std;
int n,m;
int f[666],t[23333];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	for(int i=2;i<=n;++i)
	{
		f[i]=max(0,t[i-1]+m-t[i])+f[i-1];
		for(int j=1;j<i;++j)
		{
			int sum=0,ti=max(t[j-1]+m,t[i]);
			if(j==1) ti=t[i];
			for(int k=j;k<=i;++k) sum+=ti-t[k];
			if(f[i]>f[j-1]+sum)
				f[i]=f[j-1]+sum;
		}
	}
	printf("%d",f[n]);
	return 0;
}
