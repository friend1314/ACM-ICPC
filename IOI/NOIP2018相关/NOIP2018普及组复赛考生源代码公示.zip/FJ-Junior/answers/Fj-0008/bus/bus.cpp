#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	int a,x=0;
	int q=((n-1)/(n+1));
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	cin>>a;
	{
		x-=a;
	}
	int p=abs(x);
	if((p=n*m-1)||(p=0))
	cout<<"0";
	return 0;
}
