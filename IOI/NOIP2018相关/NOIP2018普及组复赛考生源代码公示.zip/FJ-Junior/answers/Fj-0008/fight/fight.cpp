#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long a;
	long  max_x,max_y,min_x,min_y,k=0;
	int b[1000];
	cin>>a;
	for(int i=1;i<=a;i++)
	cin>>b[i];
	cin>>max_x>>max_y>>min_x>>min_y;
	for(int i=1;i<=a;i++)
	if(b[k]+min_y<b[max_y]*b[i]+min_x){
		k+=b[max_y]+min_x;
	}
	k++;
	cout<<k+1;
	return 0;
}
