#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	cin>>s;
	cout<<s.length();
}
