#include<bits/stdc++.h>
using namespace std;
int n,m,ans;
int t[1001];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>ans;
	for(int i=1;i<=n;i++)
	 for(int j=0;j<=t[i];j++)
	{
		for(ans=0;ans<t[m];ans++);
		ans+=t[m];
	}
	cout<<ans<<endl;
	return 0;
}
