#include<stdio.h>
#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	char a[6]={};
	int tot=0;
	freopen("title.in","r",stdin);
	freopen("title.out","t",stdout);
    for(int i=1;i<=5;i++)
    {
    	a[i]=getchar();
    	if((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')||(a[i]>='0'&&a[i]<='9'))
    	  tot++;
	}
	cout<<tot;
	fclose(stdin);fclose(stdout);
	return 0;
 } 
