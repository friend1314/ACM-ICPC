#include<iostream>
#include<stdio.h>
using namespace std;
long long int a[10001]={},p1,p2,n,m,m1,m2,pa,pb,mi=10001,t;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	   cin>>a[i];
	cin>>m>>p1>>m1>>m2;
	a[p1]+=m1;
	for(int i=1;i<=m-1;i++)
	  pa+=(m-i)*a[i];
	for(int i=m+1;i<=n;i++)
	  pb+=(i-m)*a[i];
	if(pa==pb)
	{
		cout<<m;
	}
	if(pa<pb)
	{
		for(int i=1;i<=m-1;i++)
		{
			pa+=m2*(m-i);
			t=pa-pb;
			if(t<0)
			  t=-t;
			if(t<mi)
			{
				mi=t;
				p2=i;
			}
			pa-=m2*(m-i);
		}
		cout<<p2;
		
	}
	if(pa>pb)
	{
		for(int i=m+1;i<=n;i++)
		{
			pb+=m2*(i-m);
			t=pa-pb;
			if(t<0)
			  t=-t;
			if(t<mi)
			{
				mi=t;
				p2=i;
			}
			pb-=m2*(i-m);
		}
		cout<<p2;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
