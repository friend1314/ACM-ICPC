#include<iostream>
#include<stdio.h>
using namespace std;
int main()
{
	int a,b,s[501][2],d[501];
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>a;
	for(int i=1;i<=a;i++)
	{
		cin>>d[i];
	}
	for(int i=1;i<=a;i++)
	{
		cin>>s[i][0]>>s[i][1];
	}
	cout<<"3";
	fclose(stdin);fclose(stdout);
	return 0;
}
