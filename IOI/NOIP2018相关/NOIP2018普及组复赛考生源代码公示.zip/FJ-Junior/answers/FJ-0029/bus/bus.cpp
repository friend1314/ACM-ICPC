#include<iostream>
#include<cstdio>
using namespace std;
int b[4000004],c[4000004],e[4000004],a[4000004];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,i,ans=0,x=0,j,d=1,f;
	cin>>n>>m;
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	for(i=1;i<=n;i++){
		if(x<a[i])x=a[i];
	}
	for(i=1;i<=n;i++){
		b[a[i]]++;
	}
	for(i=1;i<=n;i+=m){
		x=0;
		for(j=i;j<=i+m;j++){
			if(b[j]>x){
				x=b[j];
				c[d]=j;
				d++;
				e[j]=1;
			}
		}
	}
	d=1;
	for(i=1;i<=n;i+=m){
		for(j=i;j<=i+m;j++){
			if(e[j]==0){
				f=c[d]-j;
				ans+=f*b[j];
			}
			else d++;
		}
	}
	cout<<ans;
	return 0;
}
