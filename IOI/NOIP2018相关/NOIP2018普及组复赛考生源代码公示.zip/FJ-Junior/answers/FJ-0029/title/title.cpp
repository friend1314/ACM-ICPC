#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int a=0,i,b=0;
	while(b<5){
		cin>>s;
		a+=s.size();
		b+=s.size();
		b+=1;
	}
	cout<<a;
	return 0;
}
