#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,i;
	cin>>n;
	int a[n+2],b[n+2][3];
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	for(i=1;i<=n;i++){
		cin>>b[i][1]>>b[i][2];
	}
	cout<<'1';
	return 0;
}
