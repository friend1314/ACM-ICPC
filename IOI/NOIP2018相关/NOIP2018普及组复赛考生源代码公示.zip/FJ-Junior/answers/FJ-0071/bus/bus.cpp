#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
using namespace std;
int n,m,sum1=0,sum2=0,f1,f2,ans;
int a[510],b[510];
int main() {
	freopen("bus .in","r",stdin);
	freopen("bus .out","w",stdout);
	scanf("%d %d\n",&n,&m);
	for(int i=0; i<n; i++)
		scanf("%d ",a[i]);
	sort(a+1,a+n+1);
	for(int i=0; i<n; i++) {
		if(a[i]==a[f1])
			continue;
		if(a[i]>=a[f1]+m) {
			f1=i;
			f2=i;
			continue;
		}
	}
	printf("%d\n",f1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
