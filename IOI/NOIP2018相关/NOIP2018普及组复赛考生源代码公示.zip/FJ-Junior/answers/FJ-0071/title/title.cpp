#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
using namespace std;
char s[55];
int z;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(s=getchar()!=) {
		if(s=='\n')
			break;
		if(s==' ')
			z--;
		z++;
	}
	printf("%d\n",z);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
