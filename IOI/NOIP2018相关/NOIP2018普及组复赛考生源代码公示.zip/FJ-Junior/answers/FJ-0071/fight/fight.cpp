#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string>
#include <string.h>
#include <cstring>
using namespace std;
int n,a[233333];
int m,p1,s1,s2,ans;
long long sum,b1,b2,mymin;
int main() {
	freopen("fight .in","r",stdin);
	freopen("fight .out","w",stdout);
	scanf("%d\n",&n);
	for(int i=0; i<n; i++)
		scanf("%d\n",&a[i]);
	scanf("%d %d %d %d\n",&m,&p1,&s1,&s2);
	scanf("%lld %lld",&b1,&b2);
	a[p1]=a[p1]+s1;
	for(int i=0; i<n; i++) {
		if(i<m)
			b1=b1+(m-i)*a[i];
		else
			b2=b2+(i-m)*a[i];
	}
	mymin=abs(b2-b1);
	for(int i=0; i<n; i++) {
		sum=abs(i-m)*s2;
		if(i<m&&abs(b1+sum-b2)<mymin) {
			ans=i;
			mymin=abs(b1+sum-b2);
		}
		if(i>m&&abs(b2+sum-b1)<mymin) {
			ans=i;
			mymin=abs(b2+sum-b1);
		}
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
