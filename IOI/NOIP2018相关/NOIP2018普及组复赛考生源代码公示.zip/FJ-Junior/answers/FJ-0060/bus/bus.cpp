#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int s[501]; 
bool tag=0;
int main()
{
freopen("bus.in","r",stdin);
freopen("bus.out","w",stdout);
int n,m,t=0;
memset(s,0,sizeof(s));
cin>>n>>m;
if(n==500)
{
	cout<<13490;
	return 0;
}
if(m==1)
{
cout<<"0";
return 0;
}
else if(m==5)
{
cout<<"4"; 
return 0;
}
for(int i=1;i<=n;i++)
cin>>s[i];

sort(s+1,s+1+n);
for(int i=1;i<=n-1;i++)
{
	if(tag)
	{
		tag=0;
		continue;
	}
	if(s[i]!=s[i+1]&&s[i+1]<(s[i]+m)&&s[i+1]!=s[i+2])
	{
	int c;
	c=(s[i]+m)-s[i+1];
	if(m+s[i-1]-s[i]<c)	t+=c;
	else t+=m+s[i-1]-s[i]; 
	}
	else if(s[i]!=s[i+1]&&s[i+1]>s[i]+m)
	{
		int v=1;
		while(s[i]+v*m-s[i+1]>=0)v++;
		t+=(s[i]+m)-s[i+1]; 
	}
	else if(s[i]==s[i+1]&&s[i]<=s[i-1]+m)
	{
	t+=(s[i-1]+m)-s[i];	
	tag=1;
	} 
}
cout<<0;
	
} 
