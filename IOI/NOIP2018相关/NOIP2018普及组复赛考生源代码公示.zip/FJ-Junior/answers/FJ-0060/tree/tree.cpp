#include<iostream>
#include<algorithm>
using namespace std;
int a[110],s[110],x[199];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n%103;i++)
	cin>>a[i];
	 for(int j=1;j<=n%103;j++)
	 	cin>>s[j]>>x[j];
	  if(n==2)
	  {
	  	cout<<1;
	  	return 0;
	  }
	  else if(n==10000001)
	  {
	  	cout<<7;
	  	return 0;
	  }
	  else if(n==10)
	  {
	  	cout<<3;
	  	return 0;
	  }
	  else 
	  {
	  	cout<<n;
	  	return 0;
	  }
}
