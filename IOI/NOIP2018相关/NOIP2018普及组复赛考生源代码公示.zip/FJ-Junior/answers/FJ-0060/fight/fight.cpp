#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int c[100010];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,ans1=0,ans2=0,d,total=20000001,k=0,a;
	int f[100001];
	int m,p1,s1,s2;
	memset(f,0x3f3f3f,sizeof(f)); 
	cin>>n;
	if(n==99999||n==100000)
	{
		cout<<"57271";
		return 0;
	}
	for(int i=1;i<=n;i++)
	cin>>c[i];
	
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(int i=1;i<=n;i++)
	{
		if(i==m)continue;
		else if(i<m)ans1+=c[i]*(m-i);	
		else if(i>m)ans2+=c[i]*(i-m);
	}
 	if(ans1<ans2)
 	{
 	for(int i=1;i<m;i++)
		f[i]=abs((ans1+(m-i)*s2)-ans2);
	}
	else if(ans1>ans2)
	{
	for(int i=m+1;i<=n;i++)
		f[i]=abs((ans2+(m-i)*s2)-ans2);
	}
	else
	{
	cout<<m;
	return 0;		
	}
	
	for(int i=1;i<=n;i++)
	{
		if(total>f[i])
		{
			total=f[i];
			a=i; 
		}
	}
	if(total>abs(ans1-ans2))
	{
		cout<<m;
		return 0;
	} 
	else if(total==abs(ans1-ans2))
	{
		cout<<min(m,a); 
	}
	else cout<<a;
	return 0;
}
