#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string a;
	int ans=0;
	getline(cin,a);
	for(int i=0;i<=a.size()-1;i++)
	{
		if(a[i]!=' '&&a[i]!='\n')ans++;
	}
	cout<<ans;
	return 0;
}
