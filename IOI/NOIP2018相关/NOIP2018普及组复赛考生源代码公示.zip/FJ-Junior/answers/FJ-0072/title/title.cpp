#include <iostream>
#include <cstdio>
#include <string>
using namespace std;
int s;
string c;
int main()
{
	freopen("title.in","r",stdin);freopen("title.out","w",stdout);
//	freopen("title2.in","r",stdin);freopen("title2.out","w",stdout);
	getline(cin,c);
	for(int i=0;i<c.size();i++)
	{
		if(c[i]!=' ')s++;
	}
	cout<<s;
	return 0;
}
