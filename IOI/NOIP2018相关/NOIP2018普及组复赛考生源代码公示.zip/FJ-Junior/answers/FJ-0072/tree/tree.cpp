#include <iostream>
#include <cstdio>
#include <stack>
#include <queue>
using namespace std;
int n,a[1000001],type1=0;
struct tree{
	int son[2],size,val,dad,van;
}t[1000001];
stack<tree>st1,st2;
queue<tree>q;
int work(int x)
{
	int ans=a[x];
	t[x].size=1;
	if(t[x].son[0])ans+=work(t[x].son[0]),t[x].size+=t[t[x].son[0]].size,t[t[x].son[0]].dad=x,t[t[x].son[0]].van=t[t[x].son[0]].van<<1;
	if(t[x].son[1])ans+=work(t[x].son[1]),t[x].size+=t[t[x].son[1]].size,t[t[x].son[1]].dad=x;
	t[x].val=ans;
	if(t[t[x].son[0]].size==t[t[x].son[1]].size)type1++;
	return ans;
}
bool check(int x)//���x�������Ƿ�Գ� 
{
	tree doby1,doby2,make;
	while(!st1.empty())st1.pop();
	while(!st2.empty())st2.pop();
	st1.push(t[t[x].son[0]]),st2.push(t[t[x].son[1]]);
	while(!st1.empty()&&!st2.empty())
	{
		doby1=st1.top();doby2=st2.top();st1.pop();st2.pop();
//													 		cout<<doby1.val<<' '<<doby2.val<<endl;
		if(doby1.val!=doby2.val||doby1.size!=doby2.size)
		{
			return 0;
		}
		if(doby1.son[1])
		{
			make=t[doby1.son[1]];
			st1.push(make);
		}
		if(doby1.son[0])
		{
			make=t[doby1.son[0]];
			st1.push(make);
		}
		if(doby2.son[0])
		{
			make=t[doby2.son[0]];
			st1.push(make);
		}
		if(doby2.son[1])
		{
			make=t[doby2.son[1]];
			st1.push(make);
		}
	}
	if(!st1.empty()||!st2.empty())return 0;
	return 1;
}
int main()
{
	freopen("tree.in","r",stdin);freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)
	{
		cin>>t[i].son[0]>>t[i].son[1];
		if(t[i].son[0]==-1)t[i].son[0]=0;
		if(t[i].son[1]==-1)t[i].son[1]=0;
	}
	t[1].val=work(1);
//										for(int i=1;i<=n;i++)cout<<'#'<<i<<' '<<t[i].size<<' '<<t[i].val<<endl;
	if(n<=10)
	{
		int s=0;
		for(int i=1;i<=n;i++)
		{
			if(check(i))s=max(t[i].size,s);
		}
		cout<<s<<endl;
		return 0;
	}
	if(type1==n)
	{
		q.push(t[1]);
		tree head;
		while(!q.empty())
		{
			head=q.front();q.pop();
			if(t[head.son[0]].val==t[head.son[1]].val)
			{
				cout<<head.size<<endl;
				return 0;
			}
			q.push(t[head.son[0]]);
			q.push(t[head.son[1]]);
		}
		return 0;
	}
	return 0;
}
/*
15
1 2 1 1 1 1 1 1 1 1 1 1 1 1 1
2 3
4 5
6 7
8 9
10 11
12 13
14 15
0 0
0 0
0 0
0 0
0 0
0 0
0 0
0 0
*/
