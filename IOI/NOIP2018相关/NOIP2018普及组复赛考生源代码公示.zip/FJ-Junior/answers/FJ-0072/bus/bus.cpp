#include <iostream>
#include <cstdio>
#include <queue>
#include <algorithm>
#include <vector>
using namespace std;
int n,a[501],X,b[501],num[501],cnt;
struct doby{
	int x;
//	vector peo;
};
int f[501][2];//f[i][1]��������i��ͬѧ�������ѵ���ʱ�䣬f[i][0] ��ʾ��i��ͬѧ�ȳ� 
queue<int>q;
/*int dfs(int last,int x,vector<int>wait,int ans)//last��ʾ��һ�η�����ʱ�� 
{
	if(x>n)
	{
		last+=X;
		for(int i=0;i<wait.size();i++)if(a[wait[i]]<last)ans+=(last-a[wait[i]])*num[wait[i]];
	}
}*/
int main()
{
	freopen("bus.in","r",stdin);freopen("bus.out","w",stdout);
	cin>>n>>X;
	for(int i=1;i<=n;i++)cin>>b[i];
	sort(b+1,b+n+1);
	b[0]=-1;
	for(int i=1;i<=n;i++)
	{
		if(b[i]!=b[i-1])cnt++,a[cnt]=b[i];
		num[cnt]++;
	}
	n=cnt;
//							for(int i=1;i<=n;i++)cout<<a[i]<<' '<<num[i]<<endl;
	doby u,v;
	a[0]=-1926081764;
	if(X==1)
	{
		cout<<'0'<<endl;
		return 0;
	}
	if(X==2)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
		{
			if(a[i-1]+X<=a[i])continue;
			sum+=(a[i-1]+X-a[i])*num[i];
		}
		cout<<sum<<endl;
		return 0;
	}
	for(int i=1,sum;i<=n;i++)
	{
		sum=0;
		if(a[i-1]+X>a[i])f[i][1]=1926081764;
		else {f[i][1]=0;continue;}
		for(int j=i;j>1;j--)
		{
			sum=0;
			for(int k=j;k<=i;k++)
			{
				if(a[j-1]+X<=a[k])continue;//����ڵ�j-1��ͬѧ�ִ�ʱ���������ӻ�����kͬѧ��û�ִ�Ͳ���Ҫ�ȴ� 
				sum+=(a[j-1]+X-a[k])*num[k];
			}
			if(sum==0)continue;
			if(f[i][1]>sum+f[j-1][1])f[i][1]=sum+f[j-1][1]/*,cout<<sum+f[j-1][1]<<endl*/;
//			f[i][1]=min(f[i][1],sum+a[j-1]);
		}
		
//		if(f[i]==1926081764)f[i]=0;
	}
//													for(int i=1;i<=n;i++)cout<<f[i][1]<<' ';cout<<endl;
//	cout<<f[n][1]<<endl;
	int ans=0;
													for(int i=1;i<=n;i++)ans+=f[i][1];
	cout<<ans<<endl;
	return 0;
}
