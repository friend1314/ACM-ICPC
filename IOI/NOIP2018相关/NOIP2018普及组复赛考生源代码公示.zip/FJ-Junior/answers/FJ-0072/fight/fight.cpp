#include <iostream>
#include <cstdio>
using namespace std;
int n,m,sno,p1;
long long a[100001],s1,s2,sum1=0,sum2=0,s;
inline long long abss(long long x)
{
	return x<0?(-x):x;
}
inline long long minn(long long aa,long long bb)
{
	return aa<bb?aa:bb;
}
inline long long maxx(long long aa,long long bb)
{
	return aa>bb?aa:bb;
}
inline long long check(long long dis)
{
	if(dis<m)return abss(abss(m-dis)*s2+sum1-sum2);
	if(dis>m)return abss(abss(m-dis)*s2+sum2-sum1);
	return abss(sum1-sum2);
}
int main()
{
	freopen("fight.in","r",stdin);freopen("fight.out","w",stdout);
//	freopen("fight3.in","r",stdin);freopen("fight3.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	for(int i=1;i<m;i++)
	{
		sum1+=a[i]*(long long)(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		sum2+=a[i]*(long long)(i-m);
	}
	int l,r,mid,midd;
//											cout<<sum1<<' '<<sum2<<endl;
/*	if(sum1<sum2)l=1,r=m-1;
	else if(sum1>sum2)l=m+1,r=n;
	else
	{
		cout<<m<<endl;
		return 0;
	}
	while(l<r)
	{
		mid=(l+r+1)>>1;
		midd=(mid+r+1)>>1;
											cout<<l<<'~'<<r<<"  "<<mid<<':'<<check(mid)<<"  "<<midd<<':'<<check(midd)<<endl;
		if(check(mid)==0){l=mid;break;}
		if(check(midd)==0){l=midd;break;}
		if(check(midd)<check(mid))l=mid;
		if(check(mid)<=check(midd))r=midd-1;
	}
	for(int i=max(l-2,1);i<=min(l+1,(sum1<sum2?m-1:n));i++)if(check(i)<check(l)||check(i)==check(l)&&)
	if(check(l)<abss(sum1-sum2)||check(l)==abss(sum1-sum2)&&l<m)cout<<l<<endl;
	else cout<<m;*/
	s=check(1),sno=1;
	for(int i=2;i<=n;i++)
	{
		if(check(i)<s)s=check(i),sno=i;
	}
	cout<<sno;
//	cout<<s;
	return 0;
}
/*
9
1 0 0 0 0 0 0 5 0
6 1 0 3

9
0 5 0 0 0 0 0 0 1
4 1 0 3
*/
