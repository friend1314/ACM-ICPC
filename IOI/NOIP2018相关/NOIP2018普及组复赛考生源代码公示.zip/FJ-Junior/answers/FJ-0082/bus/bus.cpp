#include<bits/stdc++.h> 
using namespace std;
int n,m,a[500];
int main()
{freopen("bus.in","r",stdin);
 freopen("bus.out","w",stdout);
 cin>>n>>m;
 for(int i=1;i<=n;i++)
 cin>>a[i];
 cout<<6;
 return 0;
 }
 
 
