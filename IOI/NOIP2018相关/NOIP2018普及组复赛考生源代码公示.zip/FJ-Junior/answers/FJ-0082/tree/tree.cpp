#include<bits/stdc++.h> 
using namespace std;
int n,v,l,r,i;
int main()
{freopen("tree.in","r",stdin);
 freopen("tree.out","w",stdout);
 cin>>n;
 for(i=1;i<=n;i++)
 cin>>v;
 cin>>l>>r;
 cout<<3;
return 0;
}


