#include<bits/stdc++.h> 
using namespace std;
int n,m,p1,x,y,s,MIN=9999;
int tot1,tot2,l, i,h,j,k;;
long c[100000],s1,s2,p2;
int main()
{freopen("fight.in","r",stdin);
 freopen("fight.out","w",stdout);
 
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 scanf("%d",&c[i]);
 scanf("%d%d%d%d",&m,&p1,&s1,&s2);
 
for(i=1;i<=n;i++)

for(j=1;j<=m-1;j++)
for( k=m+1;k<=n;k++)
 if(p1<m)  {l=c[j]*(m-j);l+=((m-p1)*s1);}
    else    l=c[j]*(m-j);
if(p1>m)   {h=c[k]*(k-m);l+=((p1-m)*s1);}
    else    h=c[k]*(k-m);
if(p1=m) 
   {
   l=c[j]*(m-j);
   h=c[k]*(k-m);
   }
 
 
 if(l<h)
  {x=h-l;
   p2=x/s2;
   if(p2*s2==x) 
    {s+=1;
     if(s==1) cout<<p2;
      else 
	     if(p2<MIN)
	  {
	   MIN=p2;
	   cout<<MIN;
	}
  }
}
 if(l>h)
  {x=l-h;
   p2=x/s2;
   if(p2*s2==x)
    {s+=1;
     if(s==1) cout<<p2;
      else 
	   if(p2<MIN)
	{
	 MIN=p2;
	 cout<<MIN;
    }
  }
}
  else
   cout<<0;

return 0;
}
 
 

