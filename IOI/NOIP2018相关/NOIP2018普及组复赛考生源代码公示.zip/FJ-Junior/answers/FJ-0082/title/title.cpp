#include<bits/stdc++.h> 
using namespace std;
char s[5];
int  s1,s2;
int main()
{freopen("title.in","r",stdin);
 freopen("title.out","w",stdout);
 gets(s);
 s1=strlen(s);
 for(int i=0;i<s1;i++)
 {
 if((s[i]>=48&&s[i]<=57)||(s[i]>=65&&s[i]<=90)||(s[i]>=97&&s[i]<=122))
  s1=s1;
  else s1-=1;
 }
 cout<<s1;
 fclose(stdin);fclose(stdout);
 return 0;
}
