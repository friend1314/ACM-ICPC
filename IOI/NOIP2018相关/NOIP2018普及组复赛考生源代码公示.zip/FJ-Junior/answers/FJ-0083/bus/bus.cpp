#include<bits/stdc++.h>
using namespace std;
int a[100001];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,ans=0,t=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+1+n);
	if(m==1)
	{
		cout<<"0"; return 0;
	}
	if(m==2)
	{
		for(int i=1;i<n;i++)
		{
			for(int j=i+m;j<=n;j++)
				if(a[j]-a[i]>1)
				{
					ans++;
				}
		}
		cout<<ans;
		return 0;
	}
	for(int i=1;i<n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			t+=m;
			if(t<a[j])
			{
				ans+=a[j]-t;
			}
		}
	}
	cout<<ans;
	return 0;
 } 
