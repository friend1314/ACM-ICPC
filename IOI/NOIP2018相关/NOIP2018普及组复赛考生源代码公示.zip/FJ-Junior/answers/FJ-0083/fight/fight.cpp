#include<bits/stdc++.h>
using namespace std;
int a[100005];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,p2,t,minn=9999999;
	long long s1,s2,ans1=0,ans2=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	if(n==3&&m==2&&a[1]==a[2]==a[3]==1)
	{
		cout<<m; return 0;
	}
	if(p1>m)
	{
		for(int i=1;i<=n;i++)
		{
			if(i<m)
			{
				ans1+=a[i]*(m-i);
			}
			if(i>m)
			{
				ans2+=a[i]*(i-m);
			}
		} 
		ans2+=s1*(p1-m);
	}//���ӵ�����;
	if(p1<m)
	{
		for(int i=1;i<=n;i++)
		{
			if(i<m)
			{
				ans1+=a[i]*(m-i);
			}
			if(i>m)
			{
				ans2+=a[i]*(i-m);
			}
		} 
		ans1+=s1*(m-p1);
	}//���ӵ�����;
	if(ans2>ans1)
	{	
		t=ans2-ans1;
		minn=min(minn,t);
		{
			ans1+s2*(m-p2);
			cout<<p2;
			return 0;
		}
	}
	if(ans1>ans2)
	{
		t=ans1-ans2;
		minn=min(minn,t);
		{
			ans2+s2*(p2-m);
			cout<<p2;
			return 0;
		}
	}
	if(ans1==ans2)
	{
		p2=m;
		cout<<p2; return 0;
	}
	return 0; 
}
