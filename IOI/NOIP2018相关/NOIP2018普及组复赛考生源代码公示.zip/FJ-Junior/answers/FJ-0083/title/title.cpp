#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans=0;
	string s;
	cin>>s;
	for(int i=1;i<=s.size();i++)
	{
		ans++;
	}
	cout<<ans;
	return 0;
 } 
