#include<cstdio>
using namespace std;
int a[10001];
int n,m,s1,p1,s2,s,tdra,ttie,dra,tie,tc;
int l,r,mid;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	l=1;r=n;
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for(int i=1;i<=n;i++)
	{
		if(i<m)dra+=a[i]*(m-i);
		else tie-=a[i]*(m-i);
	}
	a[p1]+=s1;
	s=s1*(m-p1);
	if(p1<m)dra+=s;
	else tie-=s;
	if(dra==tie)
	{
		printf("%d\n",&m);
		return 0;
	}
	if(dra<tie)
	{
		r=m;
		while(l<=r)
		{
			mid=(l+r)/2;
			tdra=dra+s2*(m-mid);
			if(tie==tdra)
			{
				printf("%d",mid);
				return 0;
			}
			if(tie>tdra)r=mid-1;
			else l=mid+1;
		}
	}
	if(dra>tie)
	{
		l=m;
		while(l<=r)
		{
			mid=(l+r)/2;
			ttie=tie+s2*(mid-m);
			if(ttie==dra)
			{
				printf("%d",mid);
				return 0;
			}
			if(ttie>dra)r=mid-1;
			else l=mid+1;
		}
	}
	printf("%d\n",mid);
	return 0;
}
