#include<cstdio>
#include<iostream>
using namespace std;
char c;int sum;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(cin>>c)
	{
		if(c>32)sum++;
	}
	printf("%d\n",sum);
	return 0;
}
