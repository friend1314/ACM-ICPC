#include<cstdio>
using namespace std;
struct tree
{
	int d,l,r;
}a[1000001];
int n,ans;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&a[i].d);
	for(int i=1;i<=n;i++)scanf("%d%d",&a[i].l,&a[i].r);
	int p=0;
	if(n%2==1)printf("%d\n",n);
	else printf("1\n");
	return 0;
}
