#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int a[501],n,m,ans=2143658709,tmp;
void dfs(int t,int x)
{
	if(x>=n)
	{
		if(abs(tmp)<ans)ans=abs(tmp);
		return;
	}
	for(int i=a[x];i<=a[n];++i)
		if(i>=t)
		{
			int q=x,s=0;
			while(a[q]<i&&q<=n)
			{
				tmp+=a[++q]-t;
				s+=a[q]-t;
			}
			dfs(i+m,q);
			tmp-=s;
		}
	return;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	if(m==1)
	{
		printf("0\n");
		return 0;
	}
	if(m%2==1)
	{
		printf("%d\n",m-(m/n));
		return 0;
	}
	dfs(1,1);
	if(ans>0)printf("%d\n",ans);
	if(ans==0)printf("%d\n",n);
	if(ans<0)printf("%d\n",-ans);
	return 0;
}
