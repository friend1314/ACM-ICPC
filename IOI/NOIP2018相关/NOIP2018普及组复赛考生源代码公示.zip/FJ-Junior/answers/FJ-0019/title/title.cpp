#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<ctime>
#include<cstdlib>
using namespace std;
char s[1000];
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	int i = 1,ans = 0;
	while(1){
		scanf("%c",&s[i]);
		if(s[i] == '\n') break;
		if(s[i] != ' ') ++ ans;
		++i;
	}
	printf("%d",ans);
	return 0;
}
