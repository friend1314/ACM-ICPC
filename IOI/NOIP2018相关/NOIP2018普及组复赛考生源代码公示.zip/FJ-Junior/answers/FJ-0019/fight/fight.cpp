#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<ctime>
const int MAXX = 1e6 + 5;
long long a[MAXX];
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	int n;
	scanf("%d",&n);
	for(register int i = 1;i <= n ; ++i){
		scanf("%lld",&a[i]);
	}
	long long m,p1,s1,s2;
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	a[p1] += s1;
	int l = m - 1,r = m + 1,t = 1;
	long long num = 0,ans,tx;
	while(1){
		num += (a[l] - a[r]) * t;
		l = max(l - 1,0);
		r = min(r + 1 , n);
		if(l == 0 && r == n) break;
		t++;
	}
	if(num > 0){
		ans = num;
		r = m + 1;
		while(r <= n){
			if(ans > abs(s2 * (r - m) - num)) ans = abs(s2 * (r - m) - num), tx = r;
			r++;
		}
	}
	else{
		l = m - 1;
		num *= -1;
		ans = num ;
		while(l >= 1){
			if(ans > abs(s2 * (m - l) - num)) ans = abs(s2 * (m - l) - num), tx = l;
			l--;
		}
	}
	printf("%lld",tx);
	return 0;
}
