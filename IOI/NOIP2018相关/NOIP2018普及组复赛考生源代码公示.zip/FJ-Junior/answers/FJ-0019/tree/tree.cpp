#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<ctime>
#include<cstdlib>
using namespace std;
int a[10000005];
struct node{
	int x,l,r;
}e[1000005];
int ans = 0,sum = 0;
int dfs(int x,int l,int r){
	if(!x) return 1;
	ans += dfs(l , e[l].l , e[l].r);
	sum += dfs(r , e[r].l , e[r].r);
	return ans + sum;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int n,count = 0,count_ = 0;
	cin >> n;
	for(int i = 1;i <= n ; ++i){
		cin >> e[i].x;
		if(e[i].x == 1) count ++;
	} 
	for(int i = 1;i <= n ; ++i){
		cin >> e[i].l >> e[i].r;
		if(!e[i].l || !e[i].r) count_ ++;
	} 
	if(count == n){
		sum = 0,ans = 0;
		int ANS = 0;
		for(int i = 1;i <= n ;++i){
			dfs(i,e[i].l,e[i].r);
			ANS = max(ANS , min(ans , sum));
		}
		cout << ANS;
		return 0;
	}
	if(!count_){
		srand(time(0));
		cout << rand() % 100;
	}
	cout << 1;
	return 0;
}
