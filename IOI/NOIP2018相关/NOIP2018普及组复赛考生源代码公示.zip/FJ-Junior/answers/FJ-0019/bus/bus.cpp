#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<ctime>
using namespace std;
int b[4444444],a[505],f[5005];
int n,m, ans = 1e9 + 7;
void dfs(int x ,int sum){
	if(sum > ans) return ;
	if(x == n) {
		ans = min(ans , sum);
		return ;
	}
	long long num = sum,count = 0;
	for(register int i = x + 1;i <= n;++i){
		if(a[i] == a[i - 1]) continue;
		if(!count ) num += abs(b[a[i]] * (a[i] - a[i - 1] - m));
		else num += count * abs (a[i - count] - a[i - count - 1] - m);
		// num -= sum + abs(b[a[i]] * (a[i] - a[i - 1] - m));
		dfs(i ,num);
		for(int j = x + 1;j <= i ; ++j)
			if(a[j] != a[j - 1])
				count += b[a[j]];
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	if(n <= 10){
	for(register int i = 1;i <= n ; ++i){
		scanf("%d",&a[i]);
		b[a[i]] ++;
	}
	sort(a + 1, a + n + 1);
		dfs(1 , 0);
		cout << ans;
	}
	else{
	int p = n;
	for(register int i = 1;i <= n ; ++i){
		scanf("%d",&a[i]);
		b[a[i]] ++;
		if(b[a[i]] > 1) a[i] = 1e9 ,p--;
	}
	sort(a + 1,a + n + 1);
	for(int i = 2;i <= p; ++i) f[i] = 1e9;
	for(int i = 1;i <= p; ++i){
		f[i] = f[i - 1] + b[a[i]] * abs(min(a[i] - a[i - 1] - m,0));
		for(int j = 1;j < i; ++j){
			int sum = 0,num = 0;
			for(int k = j;k > i - j; --k){
				num += b[a[k]];
				sum += num * abs(min(a[k] - a[k - 1] - m,0));
				f[i] = min(f[i] , f[k] + sum);
			}
		}
	}
	cout << f[p];
	}
	return 0;
}
