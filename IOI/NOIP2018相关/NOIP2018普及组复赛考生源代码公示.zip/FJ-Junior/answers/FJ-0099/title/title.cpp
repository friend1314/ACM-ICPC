#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
char a[30000000];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s=0,i=0;
	while(scanf("%c",&a[i])!=-1)
	{
		if((a[i]>=97 && a[i]<=122) || (a[i]>=48 && a[i]<=57) || (a[i]>=65 && a[i]<=90)) s++;
		i++;
	}
	cout<<s;
	return 0;	
}
