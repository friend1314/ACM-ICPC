#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,p1,x=0,y=0,p2,ans=10000000,t;
long long a[100005],s1,s2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int i;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(i=1;i<=m-1;i++)
	{
		x=x+a[i]*(m-i);
	}
	for(i=m+1;i<=n;i++)
	{
		y=y+a[i]*(i-m);
	}
	if(p1<m) x=x+s1*(m-p1);
	if(p1>m) y=y+s1*(p1-m);
	for(i=1;i<=n;i++)
	{
		if(i<m)
		{
		    t=x+s2*(m-i);
		    if(abs(t-y)<ans)
		    {
		   	    ans=abs(t-y);
		   	    p2=i;
		    }
	    }
	    if(i==m)
	    {
	    	if(abs(x-y)<ans)
	    	{
	    		ans=abs(x-y);
		   	    p2=i;
	    	}
	    }
	    if(i>m)
		{
		    t=y+s2*(i-m);
		    if(abs(t-x)<ans)
		    {
		   	    ans=abs(t-x);
		   	    p2=i;
		    }
	    }
	}
	cout<<p2;
	return 0;
}
