#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,a[505];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int i,s,t=0;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	s=a[1];
	while(s+2*m<a[n])
	{
		for(i=1;i<=n;i++)
		{
			if(a[i]>s) break;
		}
		if(a[i]>=s+m) s=a[i];
		else
		{
			for(i=1;i<=n;i++)
			{
				if(a[i]>s && a[i]<s+m) t=t+s+m-a[i];
			}
			s=s+m;
		}
	}
	if(a[i+1]>=s+m) s=a[i];
	else
	{
	    for(i=1;i<=n;i++)
	    {
		    if(a[i]>s && a[i]<a[n]) t=t+a[n]-a[i];
	    }
	}
	cout<<t;
	return 0;
}
