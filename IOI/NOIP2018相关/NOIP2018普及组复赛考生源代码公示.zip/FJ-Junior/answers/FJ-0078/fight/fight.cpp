#include <cstdio>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
using namespace std;

int a[100005];
int n,m,p1,s1,s2;

long long cmp(int p2)
{
	a[p2]+=s2;
	long long x=0,y=0;
	for(int i=1;i<m;i++)
		x=x+(long long)((m-i)*a[i]);
	for(int i=n;i>m;i--)
		y=y+(long long)((i-m)*a[i]);
	a[p2]-=s2;
	return x-y;
}

long long cmp2()
{
	long long x=0,y=0;
	for(int i=1;i<m;i++)
		x=x+(long long)((m-i)*a[i]);
	for(int i=n;i>m;i--)
		y=y+(long long)((i-m)*a[i]);
	return x-y;
}

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int l,r,mid,ans1,ans2,l1;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	fclose(stdin);
	a[p1]+=s1;
	if(cmp2()==0) {
		cout<<m;
		fclose(stdout);
		return 0;
	}
	if(cmp2()>0) {
		l=m+1;r=n;
		while(l!=r) {
			mid=(l+r)/2;
			if(cmp(mid)<=(long long)0)r=mid;
			else l=mid+1;
		}
		cout<<l;
		fclose(stdout);
		return 0;
	}
	if(cmp2()<0) {
		l=1;r=m-1;
		while(l!=r) {
			mid=(l+r)/2;
			if(cmp(mid)<=(long long)0)r=mid;
			else l=mid+1;
		}
		cout<<l;
		fclose(stdout);
		return 0;
	}
}
