#include <cstdio>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
using namespace std;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a;
	int ans=0;
	string s;
	getline(cin,s);
	for(int i=0;i<s.size();i++) {
		if((s[i]>='a' && s[i]<='z') || (s[i]>='A' && s[i]<='Z') || (s[i]>='0' && s[i]<='9'))ans++;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
