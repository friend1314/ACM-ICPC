#include <cstdio>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
using namespace std;
struct tree{
	int vi;
	int *left;
	int *right;
}a[1000003];
bool b[1000003]={0};
int no=-1;
int findsth(tree *m,int lv,int mlv)
{
	if(lv==mlv)return m->vi;
	return findsth(b[lv]?&(m->left):&(m->right),lv+1);
}
int findans(tree m,int lv)
{
	int a,b;
	a=findsth(&a[0],1,lv);
	for(int i=0;i<lv;i++)b[i]=!b[i];
	b=findsth(&a[0],1,lv);
	if(a!=b)findans()
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,num,num2,sum=-1;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i].vi;
	for(int i=1;i<=n;i++) {
		cin>>num>>num2;
		
		if(num!=-1)a[i].left=&a[num];
		else a[i].left=&no;
		if(num2!=-1)a[i].right=&a[num2];
		else a[i].right=&no;
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
