#include <cstdio>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
using namespace std;
int a[505];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,num,x,tm=0,ans=0;
	cin>>n>>m;
	for(int i=0;i<n;i++) {
		cin>>a[i];
	}
	sort(a,a+n);
	tm=a[0];
	for(int i=0;i<n;i++) {
		num=0;x=a[i];
		for(i=i;a[i]==x && i<n;i++) {
			num++;
		}
		ans+=(tm-x)*num;
		tm+=m;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
