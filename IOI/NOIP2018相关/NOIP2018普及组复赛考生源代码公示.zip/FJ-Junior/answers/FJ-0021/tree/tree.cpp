#include<iostream>
#include<cstring>
#include<algorithm>
#define N 510
using namespace std;
int main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    cout<<"8";
	return 0;
}
