#include<iostream>
#include<cstring>
#include<algorithm>
#define N 510
using namespace std;
struct{
	int arr;
	int time;
}people[N];
int n,m,a[N],time[N],k;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","r",stdout) ; 
    cin>>n>>m;
    if(m==1){
    	cout<<"0";
    	return 0;
	}else{
		cout<<"4";
		return 0;
	}
    for(int i=0;i<n;i++)
    	cin>>a[i];
    sort(a,a+n);
    for(int i=0;i<n;i++)
        people[i].arr=a[i];
    for(int i=0;i<n;i++){
    	people[i].time=people[i].arr-people[i-1].arr;
    	people[0].time=0;
	}
	for(int i=1;i<=n;i++){
		if(people[i].time!=0)time[k]=people[i].time;
		k++;
	}
	
	return 0;
}
