#include<iostream>
#include<cstring>
using namespace std;
char a[6];
int sum=0;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    cin.getline(a,6);
    for(int i=0;i<=5;i++){
    	if(a[i]>='0'&&a[i]<='9')sum++;
    	if(a[i]>='a'&&a[i]<='z')sum++;
    	if(a[i]>='A'&&a[i]<='Z')sum++;
	}
	cout<<sum;
	return 0;
}
