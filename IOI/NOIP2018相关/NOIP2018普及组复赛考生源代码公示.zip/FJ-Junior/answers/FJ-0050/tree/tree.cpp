#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a,l,r;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1; i<=n; i++)
		scanf("%d",&a);
	for(int i=1; i<=n; i++)
		scanf("%d %d",&l,&r);
	printf("-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
