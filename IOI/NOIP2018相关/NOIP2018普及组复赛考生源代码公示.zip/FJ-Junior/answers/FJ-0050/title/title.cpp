#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
char a[101];
int sum;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	for(int i=0; i<strlen(a); i++)
		if(a[i]>='0'&&a[i]<='9'||a[i]>='a'&&a[i]<='z'||a[i]>='A'&&a[i]<='Z')
			sum++;
	cout<<sum<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
