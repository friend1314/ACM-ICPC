#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int a[5001],n,m,l,sum,ioi;
int s(int x,int y) {
	return x<y;
}
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1; i<=n; i++)
		scanf("%d",&a[i]);
	if(m==1) {
		fclose(stdin);
		fclose(stdout);
		cout<<'0';
		return 0;
	}
	sort(a+1,a+1+n,s);
	a[0]=a[1];
	ioi=1;
	while(a[ioi]==a[ioi-1])
		ioi++;
	l=a[ioi];
	while(l<=a[n]) {
		l+=m;
		for(int i=ioi; l>a[i]; i++)
			sum+=l-a[i];
	}
	cout<<sum;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
