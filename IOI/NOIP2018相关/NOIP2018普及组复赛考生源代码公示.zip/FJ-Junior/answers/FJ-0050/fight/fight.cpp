#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int c[100001];
int n,p1,s1,s2,m,xcz=999999,danp1,danp2,zb;
void nb() {
	for(int i=1; i<=m-1; i++)
		danp1+=c[i]*(m-i);
	for(int i=m+1; i<=n; i++)
		danp2+=c[i]*(i-m);
}
int nb1() {
	int a=0,b=0;
	for(int i=1; i<m; i++)
		a+=c[i]*(m-i);
	for(int i=m+1; i<=n; i++)
		b+=c[i]*(i-m);
	return max(a,b)-min(a,b);
}
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++)
		scanf("%d",&c[i]);
	scanf("%d %d %d %d",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	nb();
	for(int i=n; i>=1; i--) {
		c[i]+=s2;
		if(nb1()<=xcz) {
			zb=i;
			xcz=nb1();
		}
		c[i]-=s2;
	}
	printf("%d",zb);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
