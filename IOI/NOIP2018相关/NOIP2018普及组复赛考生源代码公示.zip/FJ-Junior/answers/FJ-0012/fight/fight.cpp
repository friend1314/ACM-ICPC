#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("bus.in","r",instd)
	freopen("bus.out","w",outstd)
	cout<<2;
	return 0;
}
