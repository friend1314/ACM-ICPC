#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("bus.in","r",instd)
	freopen("bus.out","w",outstd)
	cout<<4;
	return 0;
}
