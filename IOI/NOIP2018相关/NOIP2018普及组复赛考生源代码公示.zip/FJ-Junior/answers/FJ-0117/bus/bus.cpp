#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int a[510];
int main(){
    
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    
    int n,m;
    int i,j,t,w=0,nj;
    
    scanf("%d%d",&n,&m);
    
    for(i=1;i<=n;i++){
        
        scanf("%d",&a[i]);
        
    }
    
    for(i=1;i<n;i++){
        
        for(j=i;j<n;j++){
            
            if(a[i]>a[i+1]){
            
                t=a[i];
                a[i]=a[i+1];
                a[i+1]=t;
                
            }
            
        }
        
    }
   
//    for(i=1;i<=n;i++){
//        
//        printf("%d",a[i]);
//        
//    }

    for(i=1;i<=n;i+=nj){
        
        for(j=1;j<=n;j++){
        
            if(a[j]>a[i]){
                
                w=w+m-(a[j]-a[i]);
                
                nj=j;
                
                break;
                
            }
            
        }
        
    }
    
    printf("%d",w);
    
    fclose(stdin);
    fclose(stdout);
    
    return 0;
    
}
