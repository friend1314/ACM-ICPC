#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int c[100020];
int main(){
    
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    
    int n,m,minf,minn,mn;
    int i,j,s1,s2,p1,p2,ft,fd,k;
    
    scanf("%d",&n);
    
    for(i=1;i<=n;i++){
        
        scanf("%d",&c[i]);
        
    }
    
    scanf("%d%d%d%d",&m,&p1,&s1,&s2);
    
    c[p1]+=s1;
    
    ft=fd=0;
    
    for(i=1;i<m;i++){
        
        fd+=c[i]*(m-i);
        
    }
    
    for(j=m+1;j<=n;j++){
        
        ft+=c[j]*(j-m);
        
    }
    
    minf=abs(ft-fd);
    
    ft=fd=0;
    
    //printf("%d",minf);
    
    for(k=1;k<=n;k++){
        
        c[k]+=s2;
        
        for(i=1;i<m;i++){
        
            fd+=c[i]*(m-i);
            
        }
        
        for(j=m+1;j<=n;j++){
            
            ft+=c[j]*(j-m);
            
        }
        
        minn=abs(ft-fd);
        
        //printf("k=%d %d %d fd:%d ft:%d\n",k,minn,minf,fd,ft);
        
        if(minn<minf){
            
            minf=minn;
            
            mn=k;
            
        }
        
        ft=fd=0;
        
        c[k]=c[k]-s2;
        
    }
    
    printf("%d",mn);
    
    fclose(stdin);
    fclose(stdout);
    
    return 0;
    
}
