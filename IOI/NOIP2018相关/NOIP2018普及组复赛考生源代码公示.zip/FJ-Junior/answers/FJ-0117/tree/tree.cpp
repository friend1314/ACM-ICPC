#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int a[510];
int main(){
    
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    
    int i,j;

    
    
    fclose(stdin);
    fclose(stdout);
    
    return 0;
    
}
