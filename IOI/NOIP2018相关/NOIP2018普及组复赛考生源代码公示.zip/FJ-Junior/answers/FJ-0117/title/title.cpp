#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
    
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    
    int t=0;
    int i;
    char s[1000];
    
    gets(s);
    
    for(i=0;i<strlen(s);i++){
        
        if(s[i]>32){
            
            t++;
            
        }
        
    }
    
    printf("%d",t);
    
    fclose(stdin);
    fclose(stdout);
    
    return 0;
    
}
