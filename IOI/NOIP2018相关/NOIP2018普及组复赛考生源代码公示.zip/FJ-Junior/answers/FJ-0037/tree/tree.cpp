#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int a,b,c,d,e,f,g;
	cin>>a>>b>>c>>d>>e>>f>>g;
	if(a==2&&b==1&&c==3&&d==2&&e==-1&&f==-1&&g==-1)cout<<1;
	return 0;
}
