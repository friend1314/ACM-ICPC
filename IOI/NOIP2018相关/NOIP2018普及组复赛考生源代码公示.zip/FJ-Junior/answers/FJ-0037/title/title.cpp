#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[5];
	int t=-1;
	gets(a);
	for(int i=0;i<=10;i++){
		if(a[i]>0&&a[i]!=' ')t++;
	}
	cout<<t;
}
