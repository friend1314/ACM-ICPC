#include<iostream>
#include<cstdio>
using namespace std;
long long n,c[100100],p,pp,s,ss,a[100100]={0},ans=21732194213,b=0;
int m,f;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	cin>>m>>p>>s>>ss;
	c[p]+=s;
	for(int i=1;i<=n;i++){
			b+=(m-i)*c[i];	
	}
	for(int j=1;j<=n;j++){
		a[j]=b+(m-j)*ss;
	}
	for(int j=1;j<=n;j++){
		if(a[j]<0)a[j]=0-a[j];
		if(a[j]<ans){ans=a[j];
		f=j;
		}
	}
	cout<<f;
	return 0;
}
