#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int t[600]={0};
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,a=0,mm[200]={0};
	long long b=0,c=721486869;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>t[i];
	}
	if(m==1){
		cout<<0;
		return 0;
	}
	else if(m==2){
		for(int i=1;i<=n;i++){
			if(t[i]%2==1)a++;
			else b++;
		}
		if(a>b)cout<<b;
		else cout<<a;
		return 0;
	}
	else{
		for(int j=1;j<=m;j++){
			for(int i=1;i<=n;i++){
				mm[j]+=(m-(j+t[i])%m);		
			}
		}
		for(int j=1;j<=m;j++){
			if(mm[j]<=c)c=mm[j];
		}
		cout<<c;
		return 0;
	}
}
