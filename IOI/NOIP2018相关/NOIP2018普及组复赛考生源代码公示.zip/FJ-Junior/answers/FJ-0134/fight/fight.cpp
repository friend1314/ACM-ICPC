#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,c[100],m,p1,s1,s2,x=0,y=0,oo,a[100],b;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>c[i]; 
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(int i=1;i<m;i++){
		x+=(m-i)*c[i];
	}
	for(int i=m+1;i<=n;i++){
		y+=(i-m)*c[i];
	}
	if(x>y)oo=x-y;
	else oo=y-x;
	if(x>y){
		for(int i=m+1;i<=n;i++){
			if(c[i]*(i-m)-oo>0)a[i]=c[i]*(i-m)-oo;
			else a[i]=oo-c[i]*(i-m);
		}
	}
	if(y>=x){
		for(int i=1;i<m;i++){
			if(c[i]*(m-i)-oo>0)a[i]=c[i]*(m-i)-oo;
			else a[i]=oo-c[i]*(m-i);
		}
	}
	if(x>y){
		for(int i=m+1;i<=n;i++){
			for(int i=m+1;i<=n;i++){
			if(a[i]>a[i+1]){b=a[i];a[i]=a[i+1];a[i+1]=b;}
		}
		}
		if(a[m+1]==0){cout<<"1";return 0;}
		cout<<a[m+1];
	}
	if(y>=x){
		for(int i=1;i<m;i++){
			for(int i=1;i<m;i++){
			if(a[i]>a[i+1]){b=a[i];a[i]=a[i+1];a[i+1]=b;}
		}
		}
		if(a[1]==0){cout<<"1";return 0;}
		cout<<a[1];
	}
	return 0;
}
