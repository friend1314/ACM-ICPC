#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int a,b,c[100];
	cin>>a>>b;
	for(int i=1;i<=a;i++)cin>>c[i];
	if(b==1){cout<<"0";return 0;}
	cout<<"4";
	return 0;
}
