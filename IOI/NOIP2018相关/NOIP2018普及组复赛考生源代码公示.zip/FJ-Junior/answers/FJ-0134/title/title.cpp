#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[100];
	int x=0;
	cin>>a;
	for(int i=0;a[i];i++)x++;
	cout<<x;
	return 0;
} 
