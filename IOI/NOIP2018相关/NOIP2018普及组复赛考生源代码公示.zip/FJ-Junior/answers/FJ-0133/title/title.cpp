#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <stack>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[1001];
	gets(s);
	int as=0,len=strlen(s);
	for(int i=0;i<len;i++)
		if(s[i]!=' ')
			as++;
	printf("%d",as);
	fclose(stdin);fclose(stdout);
	return 0;
}
