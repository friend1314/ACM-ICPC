#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <stack>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	int num[101]={0};
	scanf("%d%d",&n,&m);
	if(m==1)cout<<0;
	else if(m==2)
	{
		int wting,linshi;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&linshi);
			num[linshi]++;
		}
		wting=0;
		long long as=0;
		for(int i=0;i<=100;i++)
		{
			wting+=num[i];
			if(wting>=num[i+1])
			{
				wting=num[i+1];
				as+=num[i+1];
				i++;
			}
			else as+=wting;
		}
		printf("%lld",as);
	}
	else cout<<5;
	fclose(stdin);fclose(stdout);
	return 0;
}
