#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <stack>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m;
	long long s1,s2,p1;
	long long num[100010];
	long long shil=0,shir=0,as=1;
	unsigned long long Min=-1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lld",&num[i]);
	scanf("%d%lld%lld%lld",&m,&p1,&s1,&s2);
	num[p1]+=s1;
	for(int i=1;i<m;i++)
		shil+=num[i]*(m-i);
	for(int i=m+1;i<=n;i++)
		shir+=num[i]*(i-m);
	long long linshi=shil-shir;
	for(int i=1;i<=n;i++)
		if(abs(linshi+s2*(m-i))<Min)
		{
			Min=abs(linshi+s2*(m-i));
			as=i;
		}
	printf("%lld",as);
	fclose(stdin);fclose(stdout);
	return 0;
}
