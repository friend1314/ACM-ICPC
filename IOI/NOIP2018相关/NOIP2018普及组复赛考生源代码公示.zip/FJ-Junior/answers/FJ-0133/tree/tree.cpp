#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <queue>
#include <stack>
#include <cstring>
#include <cmath>
using namespace std;
int nn;
struct node
{
	int q,l,r;
}n[11];
inline bool work()
{
	int a=0,b=0,l=1,r=1;
	while(n[l].l!=-1&&n[r].r!=-1)
	{
		l=n[l].l;r=n[r].r;
		if(n[l].q!=n[r].q)return 0;
	}
	return n[l].l==n[r].r;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&nn);
	for(int i=1;i<=nn;i++)
		scanf("%d",&n[i].q);
	for(int i=1;i<=nn;i++)
		scanf("%d %d",&n[i].l,&n[i].r);
	bool a=work();
	if(a)printf("%d",nn);
	else printf("1");
	fclose(stdin);fclose(stdout);
	return 0;
}
