#include <bits/stdc++.h>
using namespace std;
long t[501]={0},sum=0,now,future;
int n,m,num[501]={0},step=1;
int dfs()
{
	if(step>n)
	{
		return 0;
	}
	if(step==n)
	{
		sum+=(now-t[step])*num[step];
		return 0;
	}
	int left,right;
	future=now;
	while(future<t[step+1])
	{
		future+=m;
	}
	left=(now-t[step])*num[step];
	right=(t[step+1]-t[step])*num[step];
	
	if(left+(future-t[step+1])*num[step+1]<right)
	{
		sum+=left;
		step++;
		now=future;
		dfs();
		return 0;
	}
	else
	{
		sum+=right;
		now=t[step+1];
		step=step+2;
		while(now<t[step])
		{
			now+=m;
		}
		dfs();
		return 0;
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int j=1;j<=n;j++)
	{
		cin>>t[j];
	}
	sort(t,t+(n+1));
	now=t[1];
	for(int j=1;j<=n;j++)
	{
		if(t[j]==t[j-1])
		{
			num[j-1]++;
			n--;
			for(int i=j;i<=n;i++)
			{
				t[i]=t[i+1];
			}
			j--;
		}
		else
		num[j]++;
	}
	dfs();
	cout<<sum;
	return 0;
}
