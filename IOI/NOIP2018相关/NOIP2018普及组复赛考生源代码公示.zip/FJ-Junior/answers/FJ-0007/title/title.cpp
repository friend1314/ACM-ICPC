#include <bits/stdc++.h>
using namespace std;
int main()
{
	int ans=0;
	char s[101];
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	for(int j=0;j<=100;j++)
	{
		s[j]=' ';
	}
	gets(s);
	for(int j=0;j<=100;j++)
	{
		if(s[j]!=' ')
		{
			ans++;
		}
	}
	cout<<ans-1;
	return 0;
}
