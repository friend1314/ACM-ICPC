#include <bits/stdc++.h>
using namespace std;
long long n,camp[100001]={0},m,s1,s2,p1,PD=0,PT=0,p2=1,M,FD,FT;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int j=1;j<=n;j++)
	{
		cin>>camp[j];
	}
	cin>>m>>p1>>s1>>s2;
	camp[p1]+=s1;
	for(int j=1;j<m;j++)
	{
		PD+=camp[j]*(m-j);
	}
	for(int j=n;j>m;j--)
	{
		PT+=camp[j]*(j-m);
	}
	M=abs(PD+s2*(m-1)-PT);
	for(int j=1;j<=n;j++)
	{
		if(j<m)
		{
			FD=PD;
			FD+=s2*(m-j);
			
			if(abs(FD-PT)<M)
			{
				M=abs(FD-PT);
				p2=j;
			}
		}
		if(j>m)
		{
			FT=PT;
			FT+=s2*(j-m);
			
			if(abs(PD-FT)<M)
			{
				M=abs(PD-FT);
				p2=j;
			}
		}
	}
	cout<<p2;
	return 0;
}
