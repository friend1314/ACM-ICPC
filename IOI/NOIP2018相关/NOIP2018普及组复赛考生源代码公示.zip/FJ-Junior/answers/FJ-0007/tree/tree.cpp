#include <bits/stdc++.h>
using namespace std;
long n,a[100001];
int b[100001][2];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int j=1;j<=n;j++)
	{
		cin>>a[j];
	}
	for(int j=1;j<=n;j++)
	{
		cin>>b[j][1]>>b[j][2];
	}
	cout<<"1";
	return 0;
}
