#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long long n,m,t[505],z;
long long i,g,w,k,ans;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	scanf("%lld%lld",&n,&m);
	for(i=1;i<=n;i++)
		scanf("%lld",&t[i]);
	sort(t+1,t+n+1);
	i=1;k=0ll;w=0ll;g=(long long)-1;
	while(i<=n)
	{
		if(k==0)
		{
			z=t[i];i++;k++;
			while(t[i]==z) {i++;k++;}
			if(g>=z) w=(g-z)*k;
			else g=z;
			continue;
		}
		if(w+k*(t[i]-g)<=(g+m)-t[i])
		{
			w+=k*(t[i]-g);k++;g=t[i];
			i++;
		}
		else
		{
			ans+=w;w=0ll;k=0ll;g+=m;
		}
	}
	if(w!=0ll) ans+=w;
	printf("%lld",ans);
	return 0;
}
