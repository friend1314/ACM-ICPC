#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
char a;
int ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	while(scanf("%c",&a)!=EOF)
	{
		if(a!=' '&&a!='\n') ans++;
	}
	printf("%d",ans);
	return 0;
}
