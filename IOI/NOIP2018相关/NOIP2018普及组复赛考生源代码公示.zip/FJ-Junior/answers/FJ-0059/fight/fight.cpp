#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;
long long n,m,p1,s1,s2;
long long c[200005],t1=0ll,t2=0ll,ans,minn=1e18,k1,k2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	scanf("%lld",&n);
	for(long long i=1;i<=n;i++)
		scanf("%lld",&c[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	for(long long i=1;i<=m-1;i++)
		t1+=(c[i]*(m-i));
	for(long long i=m+1;i<=n;i++)
		t2+=(c[i]*(i-m));
	for(long long i=1;i<=n;i++)
	{
		k1=t1;k2=t2;
		if(i<m) k1+=s2*(m-i);
		if(i>m) k2+=s2*(i-m);
		if(abs(k1-k2)<minn) {minn=abs(k1-k2);ans=i;}
	}
	printf("%lld",ans);
	return 0;
}
