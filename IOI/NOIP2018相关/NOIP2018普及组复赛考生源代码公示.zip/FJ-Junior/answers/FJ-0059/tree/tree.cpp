#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,v[1100006],l[1100006],r[1100006],dfn;
int k[1100006],g,tot,res,ans;
struct note
{
	int x,dfn;
}q[1100006];
void hp(int x,int dfn)
{
	if(l[x]==-1&&r[x]==-1) {k[x]=1;return;}
	if(l[x]!=-1)
	{
		q[++tot].x=l[x];q[tot].dfn=dfn+1;
		hp(l[x],dfn+1);
	}
	if(r[x]!=-1)
	{
		q[++tot].x=r[x];q[tot].dfn=dfn+1;
		hp(r[x],dfn+1);
	}
	if(l[x]!=-1&&k[l[x]]==1&&r[x]!=-1&&k[r[x]]==1) {k[x]=1;return;}
}
void ff(int x)
{
	if(l[x]!=-1)
	{
		res++;ff(l[x]);
	}
	if(r[x]!=-1)
	{
		res++;ff(r[x]);
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&l[i],&r[i]);
		//if(l[x]!=-1&&r[x]!=-1&&v[l[x]]==v[r[x]]) k[x]=1;
	}
	q[++tot].x=1;q[tot].dfn=1;
	hp(1,1);
	for(int i=1;i<=n;i++)
	{
		//printf("%d\n",k[i]);
		if(k[i]==1) 
		{
			res=1;ff(i);
			//printf("%d %d\n",i,res);
			ans=max(ans,res);
		}
	}
	printf("%d",ans);
	return 0;
}
