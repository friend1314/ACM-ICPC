#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int a[510],f[510];
int n,m,ans,aa;
int zjw(int z) {
	int a1=0;
	for(int j=z+1;j<=n;j++) {
		if(a[j]<a[z]+m) {
			a1+=a[z]+m-a[j];
		} else {
			break;
		}
	}
	return a1;
}
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		scanf("%d",&a[i]);
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n-1;i++) {
		int k=zjw(i);
		if(f[i-1]+k<f[i-1]+(a[i+1]-a[i])*(aa+1)) {
			f[i]=f[i-1]+k;aa=0;
		} else {
			aa++;f[i]=f[i-1]+(a[i+1]-a[i])*aa;
		}
	}
	cout<<f[n-1]; 
}
