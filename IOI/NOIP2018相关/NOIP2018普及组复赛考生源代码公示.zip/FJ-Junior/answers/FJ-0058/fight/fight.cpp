#include<iostream>
#include<cstdio>
using namespace std;
long long a[100010],m,s1,p1,s2,p2,ans1,ans2,Min=0x7fffffff;
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
		scanf("%lld",&a[i]);
	}
	scanf("%lld %lld %lld %lld",&m,&p1,&s1,&s2);
	a[p1]+=s1;p2=m;
	for(int i=m+1;i<=n;i++) {
		ans2+=(i-m)*a[i];
	}
	for(int i=m-1;i>=1;i--) {
		ans1+=(m-i)*a[i];
	}
	if(ans1>ans2) {
		for(int i=m;i<=n;i++)
			if(ans1>(ans2+s2*(i-m))) {
				if(ans1-(ans2+s2*(i-m))<ans1-ans2&&Min>ans1-(ans2+s2*(i-m))) {
					p2=i;Min=ans1-(ans2+s2*(i-m));
				}
			} else {
				if((ans2+s2*(i-m))-ans1<ans1-ans2&&Min>(ans2+s2*(i-m))-ans1) {
					p2=i;Min=(ans2+s2*(i-m))-ans1;
				}
			}
	} else {
		for(int i=m;i>=1;i--) {
			if(ans2>(ans1+s2*(m-i))) {
				if(ans2-(ans1+s2*(m-i))<ans2-ans1&&Min>ans2-(ans1+s2*(m-i))) {
					p2=i;Min=ans2-(ans1+s2*(m-i));
				}
			}			
			else
				if((ans1+s2*(m-i))-ans2<ans2-ans1&&Min>(ans1+s2*(m-i))-ans2) {
					p2=i;Min=(ans1+s2*(m-i))-ans2;
				}
		}
	}
	cout<<p2;
	return 0;
}

