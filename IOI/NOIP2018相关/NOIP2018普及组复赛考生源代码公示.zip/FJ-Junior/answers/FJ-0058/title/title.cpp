#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[64];int ans=0; 
	gets(s);
	for(int i=1;i<=strlen(s);i++) {
		if(s[i]!=' ') ans++;
	}
	printf("%d",ans);
	return 0;
}

