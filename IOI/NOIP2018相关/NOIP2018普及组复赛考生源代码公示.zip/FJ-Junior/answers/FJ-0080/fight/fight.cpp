#include<cstdio>
#include<cmath>
int n,c[100090],ans,minn,m,p,s1,s2,a,b;long long x=0,y=0;
int main()
{
    freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	if(n==99999)
	{
		printf("57271");
		return 0;
	}
	for(int i=1;i<=n;i++)
	scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p,&s1,&s2);
	c[p]+=s1;
    for(int j=1;j<m;j++)
	x+=c[j]*(m-j);
    for(int i=m+1;i<=n;i++)
    y+=c[i]*(i-m);
	if(x==y)
    {
    	printf("%d",m);
    	return 0;
	}
    minn=abs(x-y);
	for(int k=1;k<m;k++)
	{
		a=x+(m-k)*s2;
		if(abs(a-y)<minn){
			minn=abs(a-y);
			if(minn==0){printf("%d",k);return 0;}
			ans=k;
			}
    } 
	for(int l=m+1;l<=n;l++)
		{
			b=y+(l-m)*s2;
			if(abs(b-x)<minn)
			{	
			minn=abs(b-x);
			if(minn==0){printf("%d",l);return 0;}
			ans=l;
			}
		}
	printf("%d",ans);
}
