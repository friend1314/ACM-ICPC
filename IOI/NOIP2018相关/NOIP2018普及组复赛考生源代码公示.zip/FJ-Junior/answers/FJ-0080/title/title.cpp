#include<cstdio>
char c;int ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(c!=EOF)
	{
		c=getchar();
		if(c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9')
		ans++;
	}
	printf("%d",ans);
}
