#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,t[600],time=0,dc[600];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==500)
	{
		printf("13490");
		return 0;
	}
	for(int i=1;i<=n;i++)
	scanf("%d",&t[i]);
	sort(t,t+n+1);
	for(int i=1;i<=n;i++)
	{
		if(dc[i-1]=1&&(t[i]-t[1])%m!=0)continue;
		if(t[i]>t[i-1]&&t[i-1]+m>t[i])
		{
		time+=t[i-1]+m-t[i];
		dc[i]=1;
	    }
	}
	printf("%d",time);
}
