#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int m,n,t[1000],time=0,wait=0,together=1,a;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>t[i];
	sort(t+1,t+n+1);
	time=t[1]+m;
	a=time;
	for(int i=2;i<=n;i++){
		
		if(time>t[i]){
			if(t[i]==t[i-1]){
				wait+=a;
			}
			else{
				a=time-t[i];
				wait+=a;
				time+=m;
			}
		}
		else
		{
			time+=m;
		}
		//cout<<time<<" "<<a<<" "<<wait<<" "<<t[i]<<" "<<i<<endl;
	}
	cout<<wait;
	fclose(stdin);fclose(stdout);
	return 0;
}
