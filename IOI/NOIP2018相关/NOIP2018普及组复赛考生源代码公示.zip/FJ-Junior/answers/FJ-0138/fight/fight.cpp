#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,p1,p2;
long long Min=11111111111,c[100011],s1,s2,longq=0,huq=0,cj;
int put(int);
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<m;i++){
		longq+=c[i]*(abs(m-i));
	}
	for(int i=m+1;i<=n;i++){
		huq+=c[i]*(abs(i-m));
	}
	if(p1>m)huq+=s1*(abs(p1-m));
	if(p1<m)longq+=s1*(abs(m-p1));
	//cout<<longq<<" "<<huq<<endl;
	for(int i=1;i<=n;i++)
		put(i);
	cout<<p2;
	fclose(stdin);fclose(stdout);
	return 0;
}
int put(int a){
	if(a>m)huq+=s2*(abs(a-m));
	if(a<m)longq+=s2*(abs(m-a));
	cj=abs(huq-longq);
	//cout<<cj<<endl;
	if(cj<Min){
		Min=cj;
		p2=a;
	}
	if(a>m)huq-=s2*(abs(a-m));
	if(a<m)longq-=s2*(abs(m-a));
	//cout<<longq<<" "<<huq<<endl;
}
