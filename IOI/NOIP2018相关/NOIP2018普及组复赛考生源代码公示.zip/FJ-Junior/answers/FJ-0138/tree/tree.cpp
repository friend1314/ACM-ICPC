#include<iostream>
#include<cstdio>
using namespace std;
int n,a[1000011],l[1000011],r[1000011],f;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>l[i]>>r[i];
		
	}
	int j=n/2;
	do{
		f=1;
		for(int i=1;i<=j;i++){
			f=f*2;
		}
		j--;
	}while(f>n);
	cout<<f-1;
	
	fclose(stdin);fclose(stdout);
	return 0;
}

