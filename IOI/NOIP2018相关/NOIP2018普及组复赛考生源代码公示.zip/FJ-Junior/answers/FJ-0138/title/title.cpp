#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int a=0;
	char s[100];
	gets(s);
	for(int i=0;i<strlen(s);i++){
		if(s[i]>='0'&&s[i]<='9')
			a++;
		if(s[i]>='A'&&s[i]<='Z')
			a++;
		if(s[i]>='a'&&s[i]<='z')
			a++;
	}
	cout<<a;
	
	fclose(stdin);fclose(stdout);
	return 0;
}
