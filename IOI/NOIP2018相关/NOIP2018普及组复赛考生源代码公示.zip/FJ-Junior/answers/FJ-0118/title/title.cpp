#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
char s[100];
int len,ans;
bool a[1000];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	len=strlen(s);
	for(int i=0;i<len;i++)
	{
		if(s[i]!=' '&&s[i]!='\n'&&a[s[i]]==0)
		{
			a[s[i]]=1;
			ans++;
		}
	}
	printf("%d",ans);
	return 0;
}
