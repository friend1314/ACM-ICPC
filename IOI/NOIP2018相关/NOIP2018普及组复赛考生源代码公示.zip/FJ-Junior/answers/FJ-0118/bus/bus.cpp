#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,a[1000],t[1000][3],s=-1,w;
int ans=999999999;
void dfs(int d,int wa,int to)
{
	if(d==w)
	{
		//cout<<ans<<' ';
		ans=min(ans,wa);
		return;
	}
	for(int j=d+1;j<=w;j++)
		{
			if(t[j][1]<=to+m)
			{
				wa+=(to+m-t[j][1])*t[j][2];
				d=j;
			}
			else break;
		}
	if(d==w)
		{
			//cout<<ans<<' ';
			ans=min(ans,wa);
			return;
		}
	for(int i=d;i<=w;i++)
		{
			int wait=wa;
			for(int k=i;k>=d;k--)
			wait+=(t[i][1]-t[k][1])*t[k][2];
			dfs(i,wait,to+m);
		}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
	{
		if(s!=a[i])
		{
			s=a[i];
			t[++w][1]=a[i];
			t[w][2]=1;
		}else
		{
			t[w][2]++;
		}
	}
    int ac;
	for(int i=1;i<=w;i++)
	{
		ac=0;
		for(int j=i-1;j>=1;j--)
		ac+=(t[i][1]-t[j][1])*t[j][2];
		dfs(i,ac,t[i][1]);
	}
	printf("%d",ans);
	return 0;
}
