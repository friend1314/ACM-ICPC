#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
int n,a[100000001],m,p1,s1,p2,s2;
int ong1,ong2;
int t=99999999,on;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	a[p1]+=s1;
	for(int i=1;i<m;i++)
	ong1+=a[i]*(m-i);
	for(int i=m+1;i<=n;i++)
	ong2+=a[i]*(i-m);
	if(ong1<ong2)
	{
		for(int k=1;k<m;k++)
		{
			on=ong1+s2*(m-k);
			if(t>abs(ong2-on))
			{
				t=abs(ong2-on);
				p2=k;
			}
		}
	}else
	if(ong1>ong2)
	{
		for(int k=m+1;k<=n;k++)
		{
			on=ong2+s2*(k-m);
			if(t>abs(ong1-on))
			{
				t=abs(ong2-on);
				p2=k;
			}
		}
	}
	else p2=m;
	printf("%d",p2);
	return 0;
}
