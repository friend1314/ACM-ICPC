#include<iostream>
using namespace std;
int main()
{
	//freopen("title.in","r"stdin);
	//freopen("title.out","w"stiout);
	int b,c=0;
	int a;
	cin>>a;
	if(a<1000&&a>99) c+=3;
	if(a<100&&a>9) c+=2;
	if(a<10) c+=1;
	cout<<c;
	
    return 0;
}
