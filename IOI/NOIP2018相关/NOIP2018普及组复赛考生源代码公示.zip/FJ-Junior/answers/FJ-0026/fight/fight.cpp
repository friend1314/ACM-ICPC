#include<iostream>
#include<cmath> 
using namespace std;
int main()
{
	int x,y,b,n,m,s1,s2,p1,p2,i,e=0,f=0,c1,c2,min=(10,8),g,h;
	int a[10005];
	cin>>n;
    cin>>a[10005]>>m>>p1>>s1>>s2;//����Ӫ��ʼֵ 
    x+=a[m-1];//����Ӫ�� 
    y+=a[n-m];//����Ӫ�� 
    for(i=1;i<m;i++)
    {
    e+=i;	
	}
	c1=e*x;
	for(int j=m;j<n;i++)
	{
		f+=j;
	}
    c2=f*y;//��ʼ���� 
    if(p1>m) c2=c2+s1*(p1-m);
    if(p1<m) c1=c1+s1*(m-p1);//�ս����֮��
    if(c1=c2) cout<<m;
	if(c1<c2)
	{
	for(i=1;i<m;i++)
    {
    	c1+=i*s2;
      g=c2-c1;
      if(min>g) min=g;
      cout<<g;
	}	
	} 
	if(c1>c2)
	{
			for(int j=m;j<n;i++)
	{
		c2+=j*s2;
		h=c1-c2;
      if(min>h) min=h ;
      cout<<h;
	}
	}
	return 0;
    
	
	
	
	
	
	
}
