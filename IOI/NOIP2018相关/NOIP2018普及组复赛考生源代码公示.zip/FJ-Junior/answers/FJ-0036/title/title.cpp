#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int anS=0;
	string a;
	cin>>a;
	for(int i=0;i<a.size();i++)
		if((a[i]>='0'&&a[i]<='9')||(a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')) anS++;
	cout<<anS;
	return 0;
}
