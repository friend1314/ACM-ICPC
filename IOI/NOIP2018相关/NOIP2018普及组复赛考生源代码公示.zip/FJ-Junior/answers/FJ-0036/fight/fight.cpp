#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p,bs[100001];
	int tb,rb;
	int lq=0,hq=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>bs[i];
	cin>>m>>p>>tb>>rb;
	bs[p]+=tb;
	for(int i=1;i<m;i++)
		lq+=bs[i]*(m-i);
	for(int i=m+1;i<=n;i++)
		hq+=bs[i]*(i-m);
	if(lq==hq) cout<<m<<endl;
	else 
		if(lq>hq)
		{
			if(lq-hq<abs(lq-hq-rb))
			{
				cout<<m;
				return 0;
			}
			for(int i=m+1;i<=n;i++)
				if(hq+rb*(i-m)>=lq)
				{
					cout<<i;
					return 0;
				} 	
			cout<<n<<endl;
		}
		else 
		{
			if(hq-lq<abs(hq-lq-rb))
			{
				cout<<m;
				return 0;
			}
			for(int i=m-1;i>=1;i--)
				if(lq+rb*(m-i)>=hq)
				{
					cout<<i;
					return 0;
				}	
			cout<<1<<endl;
		}
	return 0;
}
