#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,t[501],an=1,su=0;
	bool qc[40001];
	int dy[40001];
	cin>>n>>m;
	for(int i=1;i<=40001;i++)
	{
		qc[i]=0;
		dy[i]=0;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>t[i];
		if(qc[t[i]]=true)
		{
			t[i]=0;
			an++;
			dy[t[i]]++;
		} 
		else qc[t[i]]=true;
	}
	for(int i=n;i>=1;i++)
		for(int j=1;j<i;j++)
			if(t[j]>t[i])
			{
				swap(t[j],t[i]);
				swap(dy[j],dy[i]);
			}
	for(int i=an;i<n;i++)
	{
		if((m-t[i+1]+t[i])*(dy[t[i+1]]+1)<=t[i+1]-t[i]) su+=m;
		else su+=(t[i+1]-t[i])*(dy[t[i+1]]+1);
	}
	cout<<su;
	return 0;
}
