#include<bits/stdc++.h>
using namespace std;
int n,w[100050],ls[100050],rs[100050],ss[100050],h[100050],f[100050],ans=1;
bool n1[100050]={0};
void tt(int i){
	h[i]=h[f[i]]+1;
	f[ls[i]]=f[rs[i]]=i;
	if (ls[i]>0){tt(ls[i]);ss[i]+=ss[ls[i]];}
	if (rs[i]>0){tt(rs[i]);ss[i]+=ss[rs[i]];}
	if (ls[i]==-1||rs[i]==-1) {
		if (ls[i]!=rs[i]) n1[i]=1;
		return;
	}
	if (ss[ls[i]]!=ss[rs[i]]||((ss[i]^1)&1)) {
		n1[i]=1;
		return;
	}
	ans=max(ans,ss[i]);
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++) {scanf("%d",&w[i]);ss[i]=1;}
	for (int i=1;i<=n;i++) scanf("%d%d",&ls[i],&rs[i]);
	h[0]=f[0]=0;
	tt(1);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
