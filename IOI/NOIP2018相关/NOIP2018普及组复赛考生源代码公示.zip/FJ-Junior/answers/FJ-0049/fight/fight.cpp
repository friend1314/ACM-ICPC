#include<bits/stdc++.h>
#define ULL unsigned long long
using namespace std;
unsigned long long s2,sum1=0,sum2=0,sum0,xx;
int m,s1,n,p,c[100050];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int mk,l=1,r;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%d",&c[i]);		
	}
	
	scanf("%d%d%d%llu",&m,&p,&s1,&s2);
	c[p]+=s1;
	for (int i=1;i<m;i++) sum1+=(ULL)(m-i)*c[i];
	for (int i=m+1;i<=n;i++) sum2+=(ULL)(i-m)*c[i];
	if (s2==0) {
		printf("1\n");
		return 0;
	}
	if (sum1==sum2) {
		printf("%d\n",m);
		return 0;
	}
	if (sum1<sum2) {
		mk=0;r=m-1;sum0=sum2-sum1;
	} else {
		mk=1;r=n-m;sum0=sum1-sum2;
	}
	unsigned long long mn=sum0;
	int ans=0;
	while (l<=r){
		int mid=(r+l)>>1;
		if (s2*mid==sum0) {
			ans=mid;
			l=r+1;
		}
		if (s2*mid>sum0) {
			xx=s2*mid-sum0;
			r=mid-1;
		}
		if (s2*mid<sum0) {
			xx=sum0-s2*mid;
			l=mid+1;
		}
		if (xx<mn) {
			mn=xx;
			ans=mid;
		}
	}
	if (mk) printf("%d\n",ans+m);
	else printf("%d\n",m-ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
