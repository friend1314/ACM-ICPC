#include<bits/stdc++.h>
using namespace std;
int n,t[4000550],m,gt[4000550],mxt=-1,sum[4000550];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	int j;
	if (m==1) {
		printf("1\n");
		return 0;
	}
	for (int i=0;i<n;i++){
		scanf("%d",&j);
		t[j]++;
		mxt=max(mxt,j);
	}
	sum[0]=t[0];
	for (int i=1;i<mxt+m;i++) {
		t[i]+=t[i-1];
		sum[i]=sum[i-1]+t[i];
	}
	gt[0]=0;
	for (int i=1;i<mxt+m;i++) {
		int ll=(i>m?sum[i-1]-sum[i-m]-(m-1)*t[i-m]:sum[i-1]),kk=0;
		//printf("%d\n",ll);
		gt[i]=(i>m?gt[i-m]:0);
		for (j=1;j<=m-1&&i-j-m>0;j++) {
			kk+=(t[i-j-m+1]-t[i-j-m])*(j+m);
			gt[i]=min(gt[i],gt[i-j-m]+kk);
		}
		if (i>=2*m-1) {
			kk+=t[i-2*m+1]*((m<<1)-1);
			gt[i]=min(gt[i],gt[i-j-m]+kk);
		}
		gt[i]+=ll;
	}
	int mn=gt[mxt];
	for (int i=1;i<m;i++) mn=min(gt[mxt+i],mn);
	printf("%d",mn);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
