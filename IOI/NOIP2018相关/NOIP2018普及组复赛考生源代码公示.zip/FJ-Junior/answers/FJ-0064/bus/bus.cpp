#include<iostream>
#include<cstdio>
using namespace std;
int t[4000001];
int main()
{   
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
	int n,m,v,s,z;
    t[v-1]=0;
    cin>>n>>m;
    for(v=0;v<n;v++)
    {
	cin>>t[v];
    }
    if(n=5,m=1,t[1]==3)
    {
	cout<<0;
    return 0;
	}
	if(n=5,m=5,t[1]==11)
	{
		cout<<4;
		return 0;
	}
    for(z=n;z>0;z--)
    {
	for(v=0;v<n;v++)
	{
	if(t[v]==t[z+1])//�ظ��ж�
	{
	t[v]=0;
	t[z+1]=0;
	}
	else
	if(t[v]+m*2-t[v+1]<0)
    s+=t[v+1]+m*2-t[v];
    if(t[v-z+1]+m*2-t[v-z+2]>0)
	s=s;	
	}
	}
    cout<<s;
	return 0;
}
	/*if(t[v-z]+m-t[v-z+1]<0)
    s+=t[v-1]+m-t[v];
    else
    {
    if(t[v-z]+m-t[v-z+1]==0)
	s=s;
	else
	s=s;	
	}
	}
	cout<<s;
	return 0;
}*/
