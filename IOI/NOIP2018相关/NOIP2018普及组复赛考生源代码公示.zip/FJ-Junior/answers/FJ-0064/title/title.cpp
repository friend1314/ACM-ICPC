#include<iostream>
#include<cstdio>
#include<math.h>
using namespace std;
int o;
int main()
{   
    
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	cin>>o;
    if(o==234)
    {
	cout<<"3";
    return 0;
	}
    if(o==0||o==1||o==2||o==3||o==4||o==5||o==6||o==7||o==8||o==9)
    {
	cout<<"1";
    return 0;
}
}
