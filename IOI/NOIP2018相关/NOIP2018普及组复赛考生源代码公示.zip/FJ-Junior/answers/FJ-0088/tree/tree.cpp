#include<iostream>
using namespace std;
int main()
{
	int n,m,i,sj=0;
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n;
	int a[n],b[n],c[n];
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cout<<1;
	return 0;
}
