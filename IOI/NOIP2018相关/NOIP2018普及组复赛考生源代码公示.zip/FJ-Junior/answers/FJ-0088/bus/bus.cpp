#include<iostream>
using namespace std;
int main()
{
	int n,m,i,sj=0;
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	int a[m];
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cout<<0;
	return 0;
}
