#include<iostream>
using namespace std;
int main()
{
	char s[6];
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int i,sum=0;
	for(i=1;i<=5;i++)
	{
		cin>>s[i];
		if(s[i]<='z'&&s[i]>='a'&&s[i]!=' ')
		sum++;
		else if(s[i]<='Z'&&s[i]>='A'&&s[i]!=' ')
		sum++;
		else if(s[i]<='9'&&s[i]>='0'&&s[i]!=' ')
		sum++;
	}
	cout<<sum;
	return 0;
}
