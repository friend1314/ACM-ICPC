#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,m,p1,p2,s1,s2,a[100005],dra,tig,t,temp;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	for(int i=1;i<m;i++) dra+=a[i]*(m-i);
	for(int i=m+1;i<=n;i++) tig+=a[i]*(i-m);
	if(p1<m) dra+=s1*(m-p1);
	if(p1>m) tig+=s1*(p1-m);
	if(dra==tig) p2=m;
	else if(dra<tig)
	{
		t=tig-dra;
		if(t%s2==0) t/=s2;
		else 
		{
		    temp=t*10/s2;
		    temp%=10;
		    if(temp>=5) t=t/s2+1;
		    else t/=s2;
		}
		p2=m-t;
		if(p2<1) p2=1;
	}
	else
	{
		t=dra-tig;
		if(t%s2==0) t/=s2;
		else
		{
			temp=t*10/s2;
			temp%=10;
			if(temp>=5) t=t/s2+1;
			else t/=s2;
		}
		p2=m+t;
		if(p2>n) p2=n;
	}
	printf("%lld\n",p2);
	return 0;
}

