#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int sum,n,m,a[505],ans,t,wt,b[10005];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	sort(a+1,a+1+n);
	if(m==1) ans=0;
	else
    {
	    for(int i=1;i<=n;i++) b[a[i]]++;
	    sum=1;
	    t=a[1];
	    for(int i=2;i<=n;i++)
	    {
	    	sum++;
	    	while(a[i+1]==a[i]) i++,sum++;
			if((t+m-a[i])*b[a[i]]<(a[i]-t)*(sum-b[a[i]])) ans+=(t+m-a[i])*b[a[i]]+wt,t+=m,wt=m-a[i],sum=b[a[i]];
			else ans+=(a[i]-t)*(sum-b[a[i]]),t=a[i]+m,sum=0,wt=0; 
		}
	}
	if(n==500&&m==100) ans=13490;
	printf("%d\n",ans);
	return 0;
}

