#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int s,ans;
char a[15];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin.getline(a,1005);
	s=strlen(a);
	for(int i=0;i<s;i++) if(a[i]!=32) ans++;
	printf("%d\n",ans);
	return 0;
}
