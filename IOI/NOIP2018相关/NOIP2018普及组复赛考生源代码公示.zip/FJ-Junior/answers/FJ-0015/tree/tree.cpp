#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[10],z[10][2],t[10][10],i,x,y;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(i=0;i<n;i++)
	  cin>>a[i];
	z[0][0]=z[0][1]=1;
	for(i=0;i<n;i++)
	 {t[z[i][0]][z[i][1]]=a[i];
	  cin>>x>>y;
	  if(x>0)
	    z[x][0]=z[i][0]+1,z[x][1]=z[i][1]*2;
	  if(y>0)
	    z[y][0]=z[i][0]+1,z[y][1]=z[i][1]*2+1;
	 }
	cout<<1<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
