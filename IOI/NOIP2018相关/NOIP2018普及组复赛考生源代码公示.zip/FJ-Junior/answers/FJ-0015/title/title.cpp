#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char a[5];
int i,l;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	l=strlen(a);
	for(i=0;i<l;i++)
	  if(a[i]==' ')
	    l--;
	cout<<l<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
