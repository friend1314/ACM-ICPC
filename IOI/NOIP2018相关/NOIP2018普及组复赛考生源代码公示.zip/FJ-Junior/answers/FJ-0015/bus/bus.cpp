#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,m,i,t[100],f,g;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>t[1];
	for(i=2;i<=n;i++)
	 {cin>>t[i];
	  if(t[i]%2!=t[1]%2)
	    f=1;
	 }
	if(m<2||(m<3&&f<1))
	 {cout<<'0'<<endl;
	  return 0;}
	sort(t+1,t+n+1);
	for(i=1;i<n;i++)
	  if(t[i]+1==t[i+1])
	    g++,i++;
	if(f>0)
	  cout<<g<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
