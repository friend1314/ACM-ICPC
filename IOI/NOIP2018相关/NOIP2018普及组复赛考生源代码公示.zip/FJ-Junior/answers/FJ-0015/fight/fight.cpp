#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int x,n,m,h,l,t,b,w,i,d,c[100000];
int jd(int a)
{if(a<0)return -a;
 return a;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	x=0x7fff;
	cin>>n;
	for(i=1;i<=n;i++)
	  cin>>c[i];
	cin>>m>>t>>b>>w;
	c[t]+=b;
	for(i=1;i<m;i++)
	  l+=(m-i)*c[i];
	for(i=m+1;i<=n;i++)
	  h+=(i-m)*c[i];
	if(l<h)
	 {for(i=1;i<m;i++)
	    if(x>jd(h-(l+w*(m-i))))
	      x=jd(h-(l+w*(m-i))),d=i;
	 }
	if(l>h)
	 {for(i=m+1;i<=n;i++)
	    if(x>jd(l-(h+w*(i-m))))
	      x=jd(l-(h+w*(i-m))),d=i;
	 }
	if(x>jd(h-l))
	  d=m;
	cout<<d<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
