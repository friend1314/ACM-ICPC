#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int len,ans;
char a[100001];
int main()
{
	freopen("title.in","t",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	len=strlen(a);
	for(int i=0;i<len;i++)
	{
	    if(a[i]!=' '&&a[i]!='\n')
	    ans++;
	}
	cout<<ans;
	return 0;
}
