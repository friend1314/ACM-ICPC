#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
long long c[100100],m,p1,s1,s2,zuo,you,chahao,n;
int main()
{
	freopen("fight.in","t",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(long long i=1;i<=n;i++)
	  cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(long long i=1;i<m;i++)
	  zuo+=c[i]*(m-i);
	for(long long i=m+1;i<=n;i++)
	  you+=c[i]*(i-m);
	if(zuo==you)
	{
		cout<<m<<endl;
		return 0;
	}
	else if(zuo<you)
	{
		chahao=(you-zuo)/s2;
		if(chahao>=m-1)
		{
			cout<<1<<endl;
			return 0;
		}
		if((you-zuo)%s2>0)
		{
			if((you-zuo)-(chahao-1)*s2>(chahao)*s2-(you-zuo))
			cout<<m-chahao<<endl;
			else
			cout<<m-chahao+1<<endl;
			return 0;
		}
		else
		cout<<m-chahao<<endl;
		return 0;
	}
	else
	{
		chahao=(zuo-you)/s2;
		if(chahao>=n-m)
		{
			cout<<n<<endl;
			return 0;
		}
		if((zuo-you)%s2>0)
		{
			if((zuo-you)-(chahao-1)*s2>(chahao)*s2-(zuo-you))
			cout<<m+chahao<<endl;
			else
			cout<<m+chahao-1<<endl;
			return 0;
		}
		else
		cout<<m+chahao<<endl;
		return 0;
	}
}
