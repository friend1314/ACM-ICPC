#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int n,x;
int main()
{
	freopen("tree.in","t",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>x;
	for(int i=1;i<=n;i++)
	cin>>x>>x;
	cout<<3<<endl;
	return 0;
}
