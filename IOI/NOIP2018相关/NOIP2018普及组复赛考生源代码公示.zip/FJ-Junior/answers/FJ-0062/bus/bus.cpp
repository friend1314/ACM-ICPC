#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int a[100001],v[100001],c[100001],x,n,m,k,ans,Time=-1;
int main()
{
	freopen("bus.in","t",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
	    cin>>x;
	    v[x]++;
	    if(v[x]==1)
	    c[++k]=x;
	}
	cout<<0<<endl;
	return 0;
}
