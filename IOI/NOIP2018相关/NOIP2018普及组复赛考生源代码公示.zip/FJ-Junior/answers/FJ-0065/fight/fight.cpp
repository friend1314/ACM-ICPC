#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("fight1.in","r",stdin);
	freopen("fight1.out","w",stdout);
	int n=3,m=2,a1,a2,a3,p1,s1,s2,i,j,a,b;
	cin>>n;
	cin>>a1>>a2>>a3;
	cin>>m>>p1>>s1>>s2;
	i=(s1+1)*1;
	j=(1+s2)*1; 
	if(i=j)cout<<"2";
	else if(i>j)cout<<"3";
	     else cout<<"1";
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
