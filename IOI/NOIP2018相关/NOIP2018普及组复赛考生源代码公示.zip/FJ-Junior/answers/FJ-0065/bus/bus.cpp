#include <iostream> 
using namespace std 
int main() 
{ 
cout<<"fuck you world"<<endl;
return 0; 
}
