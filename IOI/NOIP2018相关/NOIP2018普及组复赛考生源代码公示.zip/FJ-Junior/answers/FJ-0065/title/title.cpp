#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int n;
	cin>>n;
	if(n/10000>=1)cout<<5;
	else if(n/1000>=1&&n/10000<1)cout<<4;
	     else if(n/100>=1&&n/1000<1)cout<<3;
	          else if(n/10>=1&&n/100<1)cout<<2;
	               else cout<<1;
	               fclose(stdin);
	               fclose(stdout);
	               return 0;
	
}
