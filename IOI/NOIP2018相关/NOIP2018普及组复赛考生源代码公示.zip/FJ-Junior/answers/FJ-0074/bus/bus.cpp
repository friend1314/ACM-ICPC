#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,a[505],f[4000105]={0},st=1,st1=1,en=0,l=0,ans=0x7fffffff;
int sum(int k,int t,int tim)
{
	int cnt=0;
	for(int i=k;i<=t;i++)
	{
		cnt+=tim-a[i];
	}
	return cnt;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	if(m==1) {printf("0");return 0;}
	sort(a+1,a+n+1);if(a[1]==0) en=1;
	for(int i=1;i<m;i++)
	{
		f[i]=f[i-1]+en;
		if(a[en+1]==i) en++;
	}
	for(int i=m;i<a[n]+m;i++)
	{
		while(a[st1]<=i-m) st1++;
		int sum1=sum(st,en,i);
		int sum2=sum(st1,en,i);
		if(f[l]+sum1<f[i-m]+sum2)
		{
			f[i]=f[l]+sum1;
		}
		else
		{
			f[i]=f[i-m]+sum2;
			st=st1;l=i-m;
		}
		while(a[en+1]==i) en++;
	}
	for(int i=0;i<m;i++) ans=min(ans,f[i+a[n]]);
	printf("%d",ans);
	return 0;
}
