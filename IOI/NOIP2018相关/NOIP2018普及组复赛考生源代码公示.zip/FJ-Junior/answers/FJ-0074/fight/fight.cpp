#include<cstdio>
#include<iostream>
using namespace std;
const int maxn=100005;
long long n,m,p1,s1,s2,ans;
long long a[maxn],minn,x=0,y=0,x1,y1;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	a[p1]+=s1;ans=m;
	for(long long i=1;i<m;i++) x+=(m-i)*a[i];
	for(long long i=m+1;i<=n;i++) y+=(i-m)*a[i];
	minn=x>y? x-y:y-x;
	if(x==y) {printf("%lld",m);return 0;}
	if(x<y)
	{
		for(long long i=1;i<m;i++)
		{
			x1=x+(m-i)*s2;
			y1=x1>y? x1-y:y-x1;
			if(y1<minn) {ans=i;minn=y1;}
		}
		printf("%lld",ans);
		return 0;
	}
	for(long long i=m+1;i<=n;i++)
	{
		y1=y+(i-m)*s2;
		x1=y1>x? y1-x:x-y1;
		if(x1<minn) {ans=i;minn=x1;}
	}
	printf("%lld",ans);
	return 0;
	
}
