#include<cctype>
#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
string s;
int l,ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(cin>>s)
	{
		l=s.size();
		for(int i=0;i<l;i++) if(isalnum(s[i])) ans++;
	}
	printf("%d",ans);
	return 0;
}
