#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
const int maxn=1000005;
int size[maxn],sum[maxn],a[maxn],root,ans=0,l[maxn],r[maxn],n,de[maxn];
bool bl[maxn];
int find(int k,int t)
{
	if((de[k]==1&&de[t]==2)||(de[k]==2&&de[t]==1)) return 2;
	if(size[k]==size[t]&&sum[k]==sum[t]&&a[k]==a[t])
	{
		if(size[k]==1) return 1;
		int fi=find(l[k],r[t]);
		if(fi==2) return 2;
		fi=find(r[k],l[t]);
		return fi;
	}
	return 2;
}
void dfs(int u)
{
	size[u]=1;sum[u]=a[u];int f=1;
	if(l[u]!=-1) {dfs(l[u]);size[u]+=size[l[u]];sum[u]+=sum[l[u]];f=-f;}
	if(r[u]!=-1) {dfs(r[u]);size[u]+=size[r[u]];sum[u]+=sum[r[u]];f=-f;}
	if(l[u]==-1&&r[u]==-1) {de[u]=1;ans=max(ans,size[u]);return;}
	if(f==-1||a[l[u]]!=a[r[u]]||size[l[u]]!=size[r[u]]||sum[l[u]]!=sum[r[u]]) {de[u]=2;return;}
	if((de[l[u]]==1&&de[r[u]]==2)||(de[l[u]]==2&&de[r[u]]==1)) {de[u]=2;return;}
	de[u]=find(l[u],r[u]);
	if(de[u]==1) ans=max(ans,size[u]);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	memset(bl,true,sizeof(bl));
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&l[i],&r[i]);
		if(l[i]!=-1) bl[l[i]]=false;
		if(r[i]!=-1) bl[r[i]]=false;
	}
	for(int i=1;i<=n;i++)
	  if(bl[i]==true) {root=i;break;}
	dfs(root);
	printf("%d",ans);
	return 0;
}
