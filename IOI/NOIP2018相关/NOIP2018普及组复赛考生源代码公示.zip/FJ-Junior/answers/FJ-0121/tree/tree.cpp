#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	if(n==2) cout<<1;
	else cout<<3;
}
