#include<bits/stdc++.h>
using namespace std;
int n,m;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	if(n==5&&m==1) cout<<0;
	else cout<<4;
	return 0;
}
