#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	if(n==6) cout<<2;
	else cout<<1;
	return 0;
}
