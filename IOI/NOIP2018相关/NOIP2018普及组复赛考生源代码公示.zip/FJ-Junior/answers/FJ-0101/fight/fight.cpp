#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    int i,n,m,p,s,s2;
                        //���壻���ٸ���Ӫ�� 
    cin>>n;                             //���� 
    int a[n+1],b=0,h=0,h2=0,sh=0,j[n+2],s3=0;                 //���� 
    for(int i=1;i<=n;i++)
    {   
    cin>>a[i];   
    }
    
    cin>>m>>p>>s>>s2;
    for(int i=1;i<=n;i++) 
    {
      
        if(i==p)a[i]=a[i]+s;
        if(a[i]<m){
        h=a[i]*(m-i)+h;
        
       } 
        else{
        h2=a[i]*(i-m)+h2;
        }
    
    }
    b=abs(h-h2);//cout<<b<<" ";
    
     for(int i=1;i<n;i++)
     {   sh=abs(s2*(m-i));
         if(sh==b)cout<<i;
         else{
         j[i]=abs(sh-b);
         }
         
     }
    //�Ƚϡ����У�ѡ����С������p2�� 
      
     
     
    return 0;    
}
