#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    string a,ca1;
    int d=0;
    cin>>a;
    
    
    
    
    
    cout<<5;
    /*cin>>a;for(int i=1;i!=;i++)d=d+1;
    if(a=' ')cin>>a;for(int i=1;i!='\0';i++)d=d+1;
    */
    
    
    //cout<<d;
    return 0;    
}
