#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int t=0,n,m,s=0,cf=0;
    cin>>n>>m;
    int a[n+1];
    for(int i=1;i<=n;i++){
    cin>>a[i];
    }
    for(int i=1;i<=n;i++)
    for(int i=1;i<=n;i++){
    if(a[i]>a[i+1]&&i<=n-1){
    t=a[i];
    a[i]=a[i+1];
    a[i+1]=t;}
    
    }
    
    for(int i=1;i<=n-1;i++)
    {
    //s=s+a[i]+m-a[i+1];cout<<i<<" "<<s<<endl;
    if(a[i]!=a[i+1]&&a[i+1]-a[i]<=m)
    s=abs(a[i+1]-a[i]-m)+s;
    }
    
    cout<<s;
    
    
    return 0;    
}
