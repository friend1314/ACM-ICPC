#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	int a,b;
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<"0";
	
	return 0;
}
