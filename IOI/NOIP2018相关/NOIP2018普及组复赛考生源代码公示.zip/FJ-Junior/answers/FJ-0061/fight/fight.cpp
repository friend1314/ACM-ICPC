#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	int n,a[1000],i;
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cout<<"2";
	
	return 0;
}
