#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	int a,ans=0,i,b[5];
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	for(i=1;i<=5;i++)
	{
		cin>>b[i];
		if(b[i]!=' ')
		{
			ans++;
		}
		if(b[i]=' ')
		{
			ans=ans+0;
		}
		else
		{
			break;
		}
	}
	
	cout<<ans;
	
	return 0;
}
