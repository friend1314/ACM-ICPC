#include<iostream>
#include<stdio.h>
#include<cmath>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int n;
	cin>>n;
	if(n==2)
	cout<<1;
	if(n==10)
	cout<<3;
	return 0;
}
	
