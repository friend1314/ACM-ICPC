#include<iostream>
#include<stdio.h>
#include<cmath>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int a,b;
	cin>>a>>b;
	if(a==5&&b==1)
	cout<<0;
	if(a==5&&b==5)
	cout<<4;
	return 0;
}
	
