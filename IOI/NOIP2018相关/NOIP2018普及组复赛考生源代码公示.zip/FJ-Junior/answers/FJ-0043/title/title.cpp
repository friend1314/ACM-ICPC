#include<iostream>
#include<stdio.h>
#include<cmath>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    cout<<3;
	return 0;
}
