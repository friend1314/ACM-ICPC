#include<bits/stdc++.h>
using namespace std;
int a[100005],tans,uansa,uansbz,ans1,ans2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,s1,s2,p2,max=0Xfffffff;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);

	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			ans1+=a[i]*abs(i-m);
		
		}
		if(i>m)
		{
			ans2+=a[i]*abs(i-m);
		}
	}
	if(p1>m)
	{
	ans2+=abs(p1-m)*s1;
	}
	if(p1<m)
	{
	    ans1+=abs(p1-m)*s1;
	}
	if(ans1<ans2)
	{
		uansa=1;
		uansbz=m-1;
	}
	if(ans1>ans2)
	{
		uansa=m+1;
		uansbz=n;
	}
	for(int j=uansa;j<=uansbz;j++)
	{
		if(abs((ans1+abs(j-m)*s2)-ans2)<max)
		{
		max=abs((ans1+abs(j-m)*s2)-ans2);
		p2=j;
		}
		if(abs((ans2+abs(j-m)*s2)-ans1)<max)
	    {
	    	max=abs((ans2+abs(j-m)*s2)-ans1);
	    	p2=j;
	    }
	}
		    printf("%d",p2);
	return 0;
}
