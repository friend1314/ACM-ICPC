#include<bits/stdc++.h>
using namespace std;
bool cmp(int x,int y)
{
	return x<y;
}
int a[505],b[505],ans;
int n,m,h;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=a[i-1])
		{
			h++;
			b[h]=a[i];
		}
	}
	int i=2;
	int h1=b[1];
	while(i<=h)
	{
		if(2*(b[i]-b[i-1])<m)
		{
			ans=ans+(b[i]-h1);
			i++;
			h1=h1+(b[i]-h1);
		}
		else
		{
			ans=ans+(b[i]-(b[i-1]+m));
			i++;
			h1=h1+(b[i]-(b[i-1]+m));
			
		}
		
	}
	printf("%d",ans);
	return 0;
}
