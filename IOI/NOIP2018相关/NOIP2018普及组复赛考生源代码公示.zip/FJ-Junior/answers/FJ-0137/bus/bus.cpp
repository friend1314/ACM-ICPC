#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
long long a[2000],b[2000]={0};
int main()
{   freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    long long n,m,t=0,t1=-1,t2,l1,l2,p;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    cin>>a[i];
    sort(a+1,a+n+1);
    for(long long i=1;i<=n;i++)
      if(b[i]==0)
        {  l1=i;l2=i;           
		   for(long long j=i+1;j<=n;j++)
		   if(a[j]<a[i]+m)
		   {  b[j]=1;
		   l2++;}
		     else break;
		     t1=-1;t2=0;					
		for(long long j=l1;j<=l2;j++)
		  {  t2=0;
		  p=a[j];
		  for(long long k=l1;k<=l2;k++)
		  if(p>=a[k])t2=t2+p-a[k];
		    else t2=t2+p+m-a[k];
		  if(t1==-1)t1=t2;
		    else t1=min(t1,t2);
		}
		t+=t1;
		 b[i]=1;
	}
	else continue;
	 
	  cout<<t<<endl;
	  return 0;
}
