#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
int a[1000000][4],b[1000000]={0};
int n;
int main()
{   freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
   
    cin>>n;
    for(int i=1;i<=n;i++)
    cin>>a[i][1];
    for(int i=1;i<=n;i++)
    {
	cin>>a[i][2];
	a[i][0]=1;
	if(a[i][2]==-1)a[i][3]=-1;
	else cin>>a[i][3];
	}
    if(n<=10)
    {  cout<<1<<endl;
        return 0;
	}
	  if(n<=30&&n>=10)cout<<7<<endl;
	  if(n>30)cout<<15<<endl;
	  return 0;
}
