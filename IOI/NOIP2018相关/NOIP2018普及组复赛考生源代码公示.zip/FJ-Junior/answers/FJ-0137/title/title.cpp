#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
char a[500];
int main()
{   freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    gets(a);
    int t=0;
    for(int i=0;i<strlen(a);i++)
    if((a[i]>='0'&&a[i]<='9')||(a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z'))
    t++;
    cout<<t<<endl;
    return 0;

}
