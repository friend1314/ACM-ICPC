#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long a[100010];
int main()
{   freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    long long n,p1,p2,s1,s2,q1=0,q2=0,l,o,b1,b2,m;
    cin>>n;
    for(long long i=1;i<=n;i++)
    cin>>a[i];
    cin>>m>>p1>>s1>>s2;
    a[p1]+=s1;
    for(long long i=m-1;i>=1;i--)
    q1+=(m-i)*a[i];
    for(long long i=m+1;i<=n;i++)
    q2+=(i-m)*a[i];
    l=max(q1,q2)-min(q1,q2);
    o=m;
    if(q1==q2)
    { cout<<m<<endl;
    return 0;
	}
    if(q1>q2)
     for(long long i=m+1;i<=n;i++)
     {  b1=q2+s2*(i-m);
        b2=max(b1,q1)-min(b1,q1);
        if(b2<l)
        { l=b2;
          o=i;
		}
		else break;
	 }
	 if(q1<q2)
     for(long long i=1;i<=m-1;i++)
     {  b1=q1+s2*(m-i);
        b2=max(b1,q2)-min(b1,q2);
        if(b2<=l)
        { l=b2;
          o=i;
		}
	 }
	 cout<<o<<endl;
	 return 0;
}
