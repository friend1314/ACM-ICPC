#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a;
	unsigned long long ans=0;
	while(cin>>a){
		ans++;
	}
	cout<<ans;
	return 0;
}
