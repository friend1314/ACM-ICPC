#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	if(n%2==0){
		cout<<1;
		return 0;
	}
	cout<<n;
	return 0;
}
