#include<bits/stdc++.h>
using namespace std;
int n;
long long c[100001],m,p1,s1,s2;
long long a[100001];
int main(){
	ios::sync_with_stdio(false);
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	long long left=0,right=0;
	for(int i=1;i<=n;i++){
		if(i<m){
			left+=c[i]*(m-i);
			continue ;
		}
		if(i>m){
			right+=c[i]*(i-m);
			continue ;
		}
	}
	long long p2,qsc,s;
	for(int i=1;i<=n;i++){
		if(i<m){
			s=abs(left+s2*(m-i)-right);
			if(i==1){
				p2=1;qsc=s;
				continue ;
			}
			if(qsc>s){
				p2=i;qsc=s;
				continue ;
			}
			continue ;
		}
		if(i>m){
			s=abs(left-right-s2*(i-m));
			if(i==1){
				p2=1;qsc=s;
				continue ;
			}
			if(qsc>s){
				p2=i;qsc=s;
				continue ;
			}
		}
	}
	cout<<p2;
	return 0;
}
