#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<cstring>
#include<string>
int n,m,p1,p2,s1,s2,c[100005],d[100005],ql,qh;
using namespace std;
void work (int a,int b)
{
	ql=0;
	qh=0;
	int i,d[100005];
	for (i=1;i<=n;i++)
		d[i]=c[i];
	d[a]+=b;
	for (i=1;i<m;i++)
		ql+=d[i]*(m-i);
	for (i=m+1;i<=n;i++)
	{
		qh+=d[i]*(i-m);
			
	}
}
int main ()
{
	freopen ("fight.in","r",stdin);
	freopen ("fight.out","w",stdout);
	cin>>n;
	int i,x=100000010,y=0;
	for (i=1;i<=n;i++)
		cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	work (0,0);
//	x=ql,y=qh;
	if (ql<qh)
	{
		for (i=1;i<m;i++)
		{
			work (i,s2);
			if (abs(qh-ql)<abs(y-x))
			{
				x=ql;
				y=qh;
				p2=i;
			}
		}
	}
	else
	{
		for (i=m+1;i<=n;i++)
		{
			work (i,s2);
			if (abs(ql-qh)<abs(x-y))
			{
				x=ql;
				y=qh;
				p2=i;
			}
		}
	}
	cout<<p2;
	return 0;
}
/*
6
2 3 2 3 2 3
4 6 5 2


6
1 1 1 1 1 16
5 4 1 1

*/
