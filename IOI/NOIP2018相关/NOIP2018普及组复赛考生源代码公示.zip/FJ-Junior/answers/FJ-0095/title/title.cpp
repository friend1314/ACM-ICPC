#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<cstring>
#include<string>
using namespace std;
char a[10000000];
int main ()
{
	freopen ("title.in","r",stdin);
	freopen ("title.out","w",stdout);
	gets (a);
	int sum=0;
	int len=strlen(a);
	for (int i=0;i<len;i++)
	{
		if (('0'<=a[i]<='9' || 'a'<=a[i]<='z' || 'A'<=a[i]<='Z') && a[i]!=' ')
			sum++;
	}
	cout<<sum;
	return 0;
}

