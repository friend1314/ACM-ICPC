#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<cstring>
#include<string>
using namespace std;
#define MAXN 12345678
int sum1,sum2=MAXN,n,m,t[505],bz[505];
int main ()
{
	freopen ("bus.in","r",stdin);
	freopen ("bus.out","w",stdout);
	int i,j=0,k,x,a;
	cin>>n>>m;
	for (i=0;i<n;i++)
	{
		cin>>x;
		if (bz[x]==0)
		{
			bz[x]=1;
			t[j]=x;
			j++;
		}
	}
	a=j;
	sort (t,t+a);
	for (i=1;i<m+t[a-1];i++)
	{
		for (j=0;j<a;j++)
		{
			if (t[j]>i)
			{
				for (k=0;k*m+i<t[j];k++);
				sum1+=k*m+i-t[j];
			}
			else
				sum1+=i-t[j];
		}
		if (sum2>sum1)
			sum2=sum1;
	}
	cout<<sum2;
	return 0;
}

/*
5 1
3 4 4 3 5

5 5 
11 13 1 5 5

*/
