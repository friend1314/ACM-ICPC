#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int tree[1000];
	int i;
	cin>>tree[1000];
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
}
