#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int kaikai=0,xuanxuan=0,xuanxuan1=0,kaikai1=0;
	int n,m,p,i,x=1,y=1,z=0;
	int p1,p2,s1,s2;
	int a[100],b[100];
	int ans,sum;
	int cunfang,jishu=10000;
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	for(i=1;i<m;i++)
	{
	xuanxuan=xuanxuan+(a[i]*(m-i));
	}
	for(i=1;i<n-m+1;i++)
	{
	kaikai=kaikai+(a[i+m]*y);
	y++;
    }
    if(p1>m)
    {
	ans=s1*(p1-m);
	kaikai+=ans;
	}
    else
    {ans=s1*(m-p1);
	xuanxuan+=ans;
	}
    xuanxuan1=xuanxuan;
    kaikai1=kaikai;
    if(xuanxuan<=kaikai)
    {
        for(i=1;i<m;i++)
        {
            sum=s2*(m-i);
            xuanxuan=xuanxuan+sum;
            cunfang=kaikai-xuanxuan;
            if(cunfang<0)
            cunfang=cunfang*(-1);
            if(cunfang<=jishu)
            {
			jishu=cunfang;
			p2=i;
			}
			xuanxuan=xuanxuan1;
        }
    }
    else
    {
        for(i=n-m;i<m;z++)
        {
        	i++;
            sum=s2*z;
            kaikai=kaikai+sum;
            cunfang=xuanxuan-kaikai;
            if(cunfang<0)
            cunfang=cunfang*(-1);
            if(cunfang<=jishu)
            {
			jishu=cunfang;
			p2=i;
			}
			kaikai=kaikai1;
        }
    }
    cout<<p2;
}
