#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int n,m,ans=0,sum=0;
	int i,j;
	int student[100],bus[100];
    cin>>n>>m;
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	for(i=1;i<=n;i++)
	cin>>student[i];
	for(i=1;i<=n;i++)
	{
	 for(j=i+1;j<=n;j++)
	 {
	  if(student[i]==student[j])
	   bus[i]=student[i];
     }
	}
    for(i=1;i<=n;i++)
    {
	sum=bus[i]-bus[i+1];
    if(sum<0)
    sum=sum*(-1);
    ans+=sum;
    sum=0;
	}
    cout<<ans;
}
