#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int main()
{
	bool s[5];
	int ans=1,i,p;
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    for(i=1;i<=5;i++)
    {
	    cin>>s[i];
    	if((s[i]>=0)&&(s[i]<=9))
		ans++;
    	else
    	{
		  if((s[i]>='a')&&(s[i]<='z'))
		  ans++;
		  else
		  {
		    if((s[i]>='A')&&(s[i]<='Z'))
		    ans++;
		  }
		}
	}
	cout<<ans;
}
