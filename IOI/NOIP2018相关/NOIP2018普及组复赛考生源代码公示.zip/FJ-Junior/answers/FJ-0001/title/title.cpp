#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    string s;
    int n,m;
    getline(cin,s);
    n=s.size();
    m=n;
    for(int i=0;i<m;i++)
    {
    	if(s[i]==' ')
    	n--;
	}
	cout<<n;
	fclose(stdin);fclose(stdout);
	return 0;
}
