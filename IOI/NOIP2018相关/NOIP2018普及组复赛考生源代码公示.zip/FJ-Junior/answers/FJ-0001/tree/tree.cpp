#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
    int n,v[15],l[15],r[15],sum[15]={0};
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    	cin>>v[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>l[i]>>r[i];
	}
	for(int  j=1;j<=n;j++)
	for(int i=1;i<=n;i++)
	{
		if((l[j]==l[i]&&l[j]==r[i])||(r[j]==r[i]&&r[j]==l[i]))
		sum[j]++;
		else
		if(sum[j]>0)
		break;
	}
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		if(sum[i]>ans)
		ans=sum[i];
	}
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}
