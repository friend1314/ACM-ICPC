#include<bits/stdc++.h>
using namespace std;
int n,m,a[505],sum=99999999,ans,c=0,b,xx=0;
int pd(int q)
{
	ans=0;
	b=0;
	c=q;
	for(int i=1;i<=n;i++)
	{
		
		for(int j=1;j<=n;j++)
		{
			if(a[j]<=c&&a[j]>b)
			{
				if(a[j]-b>c-a[j])
				ans=ans+c-a[j];
				else
				ans=ans-b+a[j];
			}
		}
		b=c;
		c=c+m;
	}
	if(ans<sum)
	sum=ans;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
	cin>>a[i];
	if(a[i]>xx)
	xx=a[i];
    }
    for(int i=0;i<=xx;i++)
    pd(i);
    cout<<sum;
	fclose(stdin);fclose(stdout);
	return 0;
}
