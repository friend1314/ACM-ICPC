#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
    int n,m,a[100005],c,s1,s2,p1,p2,sum,sl1=0,sl2=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
    	cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	p2=m;
	a[p1]=a[p1]+s1;
	for(int i=1;i<m;i++)
	sl1=sl1+a[i]*(m-i);
	for(int i=m+1;i<=n;i++)
	sl2=sl2+a[i]*(i-m);
	if(sl2==sl1)
	{
		cout<<m;
		exit(0);
	}
	if(sl2<sl1)
	{
	sum=sl1-sl2;
	for(int i=m+1;i<=n;i++)
	{
		if(sl2+s2*(i-m)==sl1)
		{
			cout<<i;
			exit(0);
		}
		if((sl2+s2*(i-m))-sl1<sum&&(sl2+s2*(i-m))-sl1>0)
		{
			sum=(sl2+s2*(i-m))-sl1;
			p2=i;
		}
		if(sl1-(sl2+s2*(i-m))<sum&&sl1-(sl2+s2*(i-m))>0)
		{
			sum=sl1-(sl2+s2*(i-m));
			p2=i;
		}
	}
    }
	if(sl2>sl1)
    {
	sum=sl2-sl1;
	for(int i=1;i<m;i++)
	{
		if(sl1+s2*(m-i)==sl2)
		{
			cout<<i;
			exit(0);
		}
		if((sl1+s2*(m-i))-sl2<sum&&(sl1+s2*(m-i))-sl2>0)
		{
			sum=(sl1+s2*(m-i))-sl2;
			p2=i;
		}
		if(sl2-(sl1+s2*(m-i))<sum&&sl2-(sl1+s2*(m-i))>0)
		{
			sum=sl2-(sl1+s2*(m-i));
			p2=i;
		}
	}
    }
    cout<<p2;
    fclose(stdin);fclose(stdout);
	return 0;
}
