#include<bits/stdc++.h>
#include<iostream>
using namespace std;
long long a[100010]={0};
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int h;
		scanf("%d",&h);
		a[i]=h;
	}
	long long m,px,py,sx,sy;
	cin>>m>>px>>sx>>sy;
	a[px]+=sx;
	long long x=0,y=0;
	for(int i=1;i<m;i++)
	{
		x+=a[i]*(m-i);
	}
	for(int i=n;i>m;i--)
	{
		y+=a[i]*(i-m);
	}
	if(x==y)
	{
		cout<<m;
		exit(0);
	}
	long long s=abs(x-y);
	if(x>y)
	{
		for(int i=n;i>m;i--)
		{
			if(abs(y+sy*(i-m)-x)<s)
			{
				s=abs(y+sy*(i-m)-x);
				py=i;
			}
		}
	}
	if(x<y)
	{
		for(int i=1;i<m;i++)
		{
			if(abs(x+sy*(m-i)-y)<s)
			{
				s=abs(x+sy*(m-i)-y);
				py=i;
			}
		}
	}
	cout<<py;
}
