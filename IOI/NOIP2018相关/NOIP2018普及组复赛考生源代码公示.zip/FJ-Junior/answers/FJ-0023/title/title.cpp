#include<bits/stdc++.h>
#include<iostream>
using namespace std;
char a[100000];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	int s=0;
	int x=strlen(a);
	for(int i=0;i<=x-1;i++)
	{
		if(a[i]!=' ')
		{
			s++;
		}
	}
	cout<<s;
	return 0;
}
