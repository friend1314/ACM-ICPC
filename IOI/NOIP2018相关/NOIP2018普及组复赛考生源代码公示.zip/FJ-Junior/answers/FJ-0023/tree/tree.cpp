#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int a[1000]={0},b[1000]={0},c[1000]={0},d[1000]={0},e[1000]={0};
int cai(int x,int h)
{
	int s=0;
	if(b[x]!=-1)
	{
		d[h]=b[x];
		s++;
		cai(a[b[x]],h+1);
	}
	if(c[x]!=-1)
	{
		s++;
		e[h]=c[x];
		cai(a[b[x]],h+1);
	}
	if(s==0)
	{
		return 0;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int h;
		scanf("%d",&h);
		a[i]=h;
	}
	for(int i=1;i<=n;i++)
	{
		int x,y;
		cin>>x>>y;
		b[i]=x;
		c[i]=y;
	}
	cai(1,1);
	int s=1,y=1;
	for(int i=1;i<=n;i++)
	{
		if(d[i]==e[i])
		{
			s++;
		}
		else
		{
			break;
		}
	}
	cout<<s;
}
