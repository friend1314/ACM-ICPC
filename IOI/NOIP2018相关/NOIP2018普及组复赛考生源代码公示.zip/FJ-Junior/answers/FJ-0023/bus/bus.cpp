#include<bits/stdc++.h>
#include<iostream>
using namespace std;
int a[1000]={0},b[1000]={0},c[1000]={0},d[1000]={0};
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		int h;
		scanf("%d",&h);
		a[i]=h;
	}
	sort(a+1,a+n+1);
	int l=1,s=1;
	b[1]=a[1]+5;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<a[1]+5&&i!=1&&a[i]!=a[1])
		{
			c[1]+=a[1]+5-a[i];	
		}
		if(a[i]>a[1]+5)
		{
			break;
		}
	}
	for(int i=2;i<=n;i++)
	{		
		int k=0;
		for(int j=1;j<=i;j++)
		{
			k+=a[i]-a[j];
		}
		for(int j=i+1;j<=n;j++)
		{
			if(a[j]<a[i]+5&&j!=i&&a[j]!=a[i])
			{
				k+=a[i]+5-a[j];
			}
			if(a[j]>a[i]+5)
			break;
		}
		if((a[i]<b[s]||(k<c[s]&&k!=0))&&a[i]!=a[i-1])
		{
			b[i]=a[i]+m;		
			c[i]=k;
			d[i]=1;
		}
		if(a[i]==a[i-1])
		{
			b[i]=b[i-1];
			c[i]=c[i-1];
			d[i]=1;
		}
		if(a[i]>b[i-1])
		{
			d[i]=d[i-1]+5;
			for(int j=i+1;j<=n;j++)
			{
				if(a[j]<b[i-1]+5)
				{
					c[i]+=a[j];
				}
			}
		}
	}	
	int j=0;
	for(int i=2;i<=n;i++)
	{
		if(a[i]-a[i-1]>1)
		{
			j++;
		}
	}
	if(m==1)
	{
		cout<<"0";
		exit(0);		
	}
	else
	{
		cout<<j;
	}

}















