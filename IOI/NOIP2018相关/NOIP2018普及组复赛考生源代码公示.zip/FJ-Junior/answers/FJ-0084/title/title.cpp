#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
char s[10000000];
int sum,i,l;
int main()
{
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout); 
	gets(s);
	l=strlen(s);
	for(i=1;i<=l;i++)
	  {
	  	if(s[i]!=' ')
	  	  sum++;
	  }
	cout<<sum<<endl;
	fclose(stdin);
    fclose(stdout);
	return 0;
}
