#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	//freopen("title.in","r",stdin);
	//freopen("title.out","w",stdout);
	int a,t=0,i;
	char s;
	cin>>s;
	for(i=1;i<=s;i++)
	{
		t++;
    }
    t=t-47;
	cout<<t<<endl;
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
