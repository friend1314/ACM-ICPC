#include<iostream>
#include<cstdio>
int c[10];
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int x,y,a=0,b=0,j,i,n,c[n],m,p1,p2,s1,s2,t;
	cin>>n;
	for(int k;k<=n-1;k++)
	cin>>c[n];
	cin>>m>>p1>>s1>>s2;
	for(i=1;i<=m-1;i++)
	{
		x=c[i]*(m-i);
		a+=x;
	}
	for(j=m+1;j<=n-m;j++)
	{
		y=c[j]*(j-m);
		b+=y;
	}
	b+=s1*(p1-m);
	for(p2=1;p2<=m-1;p2++)
	{
		a+=s2*(p2-m);
		p2++;
		if(a==b)
		t=p2;
    }
    p2=t;
    cout<<p2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
