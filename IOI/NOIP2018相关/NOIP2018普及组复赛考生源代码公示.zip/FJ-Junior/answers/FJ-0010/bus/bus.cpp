#include<iostream>
using namespace std;
int main()
{
	//freopen("bus.in","r",stdin);
	//freopen("bus.out","w",stdout);
	int m,n,a[n],i,ti,x;
	cin>>n>>m;
	for(int o;o<=n-1;o++)
	cin>>a[n];
	cout<<x<<endl;
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
