#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int n,m,i,a;
    cin>>n>>m;
    for(i=0;i<=n-1;i++)
    {
        cin>>a;
    }
    cout<<0<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
