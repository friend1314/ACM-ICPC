#include<iostream>
#include<cstdio>
#include<string>
#include<cmath>
using namespace std;
int main()
{
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    string a;  
    int i,s=0;
    for(i<=a.size();i>=0;i--)
    {
        cin>>a;
        if(a[i]>='a'&&a[i]<='z') s++;
        if(a[i]>='A'&&a[i]<='Z') s++;
        if(a[i]%1==0||a[i]%(-1)==0) s++;
    }
    cout<<s<<endl;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
