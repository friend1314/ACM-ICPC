#include<cstdio>
#include<cmath>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int n,i,j,v[100010],l[100010],r[100010];
int father[100010],in[100010];
int tp[100010],ans;
int ingive(int x)
{
	if(father[x]==x)
	{
		in[x]++;
		return 0;
	}
	else
	{
		in[x]++;
		ingive(father[x]);
	}
	return 0;
}
int ksm(int a,int b)
{
	int an=1;
	while(b>0)
	{
		if(b%2==1)
			an*=a;
		b/=2;
		a*=a;
	}
	return an;
}
int jg(int w)
{
	w--;
	if(w%2==1)
		return 0;
	for(j=1;;j++)
	{
		if(w<ksm(2,j))
			break;
		w-=ksm(2,j);
	}
	if(w==0)
		return 1;
	else
		return 0; 
}
int son(int x)
{
	if(l[x]==-1&&r[x]==-1)
		return 1;
	if(v[l[x]]==v[r[x]]&&son(r[x])&&son(l[x]))
		return 1;
	else
		return 0;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	cin>>n;
	for(i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for(i=1;i<=n;i++)
		father[i]=i;
	for(i=1;i<=n;i++)
	{
		scanf("%d %d",&l[i],&r[i]);
		if(l[i]!=-1)
			father[l[i]]=i;
		if(r[i]!=-1)
			father[r[i]]=i;
	}
	for(i=1;i<=n;i++)
	{
		in[i]++;
		if(i!=1)
			ingive(father[i]);
	}
	for(i=1;i<=n;i++)
		if(!jg(in[i]))
			tp[i]=1;
	for(i=1;i<=n;i++)
	{
		if(tp[i])
			continue;
		if(son(i))
			ans=max(ans,in[i]);
	}
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
