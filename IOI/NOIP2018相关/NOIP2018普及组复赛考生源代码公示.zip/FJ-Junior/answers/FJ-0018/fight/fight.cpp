#include<cstdio>
#include<cmath>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
long long n,i,j,c[100010],m,p1,s1,s2;
long long ls,hs;
long long minn,ans;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	cin>>n;
	for(i=1;i<=n;i++)
		scanf("%lld",&c[i]);
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(i=1;i<m;i++)
		ls+=c[i]*(m-i);
	for(i=m+1;i<=n;i++)
		hs+=c[i]*(i-m);
	minn=9999999999;
	for(i=1;i<=n;i++)
	{
		if(i<m&&abs(ls+(m-i)*s2-hs)<minn)
		{
			minn=abs(ls+(m-i)*s2-hs);
			ans=i;
		}
		else
			if(i==m&&abs(ls-hs)<minn)
			{
				minn=abs(ls-hs);
				ans=i;
			}
			else
				if(i>m&&abs(ls-(hs+(i-m)*s2))<minn)
				{
					minn=abs(ls-(hs+(i-m)*s2));
					ans=i;
				}
	}
	cout<<ans;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
