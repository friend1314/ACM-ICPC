#include<cstdio>
#include<cmath>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int n,i,t[510],m,peo[4000010];
int tp[4000010],ti,ck,ans;
void dfs(int x,int y)
{
	bool flag=false;
	int p[510],k=0;
	if(ck==n)
	{
		ans=min(ans,ti);
		return;
	}
	if(y==m)
		y=0;
	else
	{
		dfs(x+1,y+1);
		return;
	}
	memset(p,0,sizeof(p));
	for(int i=1;i<=x;i++)
		if(peo[i]&&!tp[i])
		{
			flag=true;
			p[++k]=i;
			ti+=(x-i)*peo[i];
			tp[i]++;
			ck+=peo[i];
		}
	if(flag)
	{
		dfs(x+1,1);
		for(int i=1;i<=k;i++)
		{
			ti-=(x-p[i])*peo[p[i]];
			tp[p[i]]--;
			ck-=peo[p[i]];
		}
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
		peo[t[i]]++;
	}
	ans=1<<30;
	dfs(1,m);
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
