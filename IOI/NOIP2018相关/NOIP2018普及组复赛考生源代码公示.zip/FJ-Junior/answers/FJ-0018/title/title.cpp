#include<cstdio>
#include<cmath>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int i,n,ans;
char s[110];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	fgets(s,110,stdin);
	n=strlen(s);
	for(i=0;i<n-1;i++)
	{
		if(s[i]==' ')
			continue;
		ans++;
	}
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
