#include<bits/stdc++.h>
#include<cstdio>
#include<iostream>
#include<string>
#include<string.h>
#include<cstring>
using namespace std;
int l,i,j,m,s1,s2=0,p1,p2,n,c[501],a1=0,a2=0,f[501],f1=0,a3,p3,t=0,g,q[501],p=1;
int main(){
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    cin>>n>>m;
    s1=n;
    for(i=1;i<=n;i++)
    cin>>c[i];
    for(i=1;i<n;i++)
    for(j=i+1;j<=n;j++)
    if(c[i]==c[j]&&c[i]!=0&&c[j]!=0){
    c[j]=0;
    s1--;}
    for(i=1;i<=n;i++){
    if(c[i]!=0){
    f[p]=c[i];
    p++;}}
    
    for(i=1;i<n;i++)
    for(j=i+1;j<=n;j++)
    if(f[i]>f[j]&&f[j]!=0){
    l=f[i];
    f[i]=f[j];
    f[j]=l;}
    for(i=1;i<s1;i++){
        g=f[i]+m-f[i+1];
        if(g>0){
        t+=g;
        f[i+1]+=g;} }
    cout<<t;
    
    fclose(stdin);
    fclose(stdout);
    return 0;}
