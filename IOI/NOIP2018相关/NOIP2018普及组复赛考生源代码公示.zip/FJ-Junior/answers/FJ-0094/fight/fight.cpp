#include<bits/stdc++.h>
#include<cstdio>
#include<iostream>
#include<string>
#include<string.h>
#include<cstring>
using namespace std;
int l,i,j,m,s1,s2,p1,p2,n=0,c[100001],a1=0,a2=0,f[100001],f1=0,a3,p3;
int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    cin>>n;
    for(i=1;i<=n;i++)
    cin>>c[i];
    cin>>m>>p1>>s1>>s2;
    c[p1]+=s1;
    
    for(i=1;i<m;i++)
    a1+=(m-i)*c[i];
    for(i=m+1;i<=n;i++){
    a2+=(i-m)*c[i];}
    a3=a1-a2;
    
    if(a3<0)
    for(p2=1;p2<m;p2++){
    f[p2]=-a3-s2*(m-p2);
    if(f[p2]<0) f[p2]=-f[p2];
    if(f[p2]==0) {cout<<p2; return 0;}
    if(p2==1) {f[1]=f[p2]; p3=p2;}
    else if(f[p2]<f[1]){ f[1]=f[p2];p3=p2;}}
    
    if(a3>=0)
    for(p2=m+1;p2<=n;p2++){
    f[p2]=a3-s2*(p2-m);
    if(f[p2]<0) f[p2]=-f[p2];
    if(f[p2]==0) { cout<<p2; return 0;}
    if(p2==m+1) {f[m+1]=f[p2]; p3=p2;}
    if(f[p2]<f[m+1]){ f[1]=f[p2];p3=p2;}
    }
    
    p2=p3;
    cout<<p2;
    fclose(stdin);
    fclose(stdout);
    return 0;}
