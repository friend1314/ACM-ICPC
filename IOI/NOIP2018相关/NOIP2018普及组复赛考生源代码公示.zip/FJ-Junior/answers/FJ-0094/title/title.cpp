#include<bits/stdc++.h>
#include<cstdio>
#include<iostream>
#include<string>
#include<string.h>
#include<cstring>
using namespace std;
string s;int l,i,j,m=0,n=0;
int main(){
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    getline(cin,s);
    l=s.length();
    for(i=0;i<l;i++){
    if(s[i]!=' '&&s[i]!='\n')
    m++;}
    cout<<m;
    fclose(stdin);
    fclose(stdout);
    return 0;}
