#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,a[100005],m,p1,p2,s1,s2,x[100005],y,s,t,w,jl;
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	a[p1]=a[p1]+s1;
	for(int k=1;k<=m-1;k++)
	{
		s=(m-k)*a[k];
		t=t+s;
	}
	for(int j=m+1;j<=n;j++)
	{
		s=(j-m)*a[j];
		w=w+s;
	}
	if(t<w)
	{
	    y=w-t;
	    if(t+s2*(m-1)>w) jl=m-(y/s2); cout<<jl<<endl;
		if(t+s2*(m-1)<=w) cout<<"1"<<endl;
	}
	if(t>w)
	{
	    y=t-w;
	    if(w+s2*(n-m)>t) jl=m+(y/s2); cout<<jl<<endl;
	}
	return 0;
}
