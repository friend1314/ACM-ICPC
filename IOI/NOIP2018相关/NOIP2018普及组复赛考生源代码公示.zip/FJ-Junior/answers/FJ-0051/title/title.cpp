#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[10];
	gets(a);
	int x=strlen(a),k;
	for(int i=0;i<x;i++)
	{
		if(a[i]==' ') k++;
	}
	x=x-k;
	cout<<x<<endl;
	return 0;
}
