#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,a,s[505],t,w=1,x[505],y=1;
	cin>>n>>a;
	for(int i=1;i<=n;i++) cin>>s[i];
	if(a==1) cout<<"0"<<endl;
	return 0;
}
