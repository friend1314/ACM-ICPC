#include<cstdio>
int main()
{
    freopen("tree.in","r",stdin);
    freopen("tree,out","w",stdout);
    int n;
    if(n==1||n==2)
    {
        printf("1");
        return 0;
    }
    printf("%d",n);
    return 0;
}
