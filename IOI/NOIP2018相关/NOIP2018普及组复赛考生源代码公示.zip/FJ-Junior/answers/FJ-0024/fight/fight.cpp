#include<cstdio>
long long a[100010];
int main()
{
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    long long m,n,i,s1,s2,p1,p2,sum1=0,sum2=0,x,ans1;
    scanf("%lld",&n);
    for(i=1;i<=n;i++)
        scanf("%lld",&a[i]);
    scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
    a[p1]+=s1;
    for(i=1;i<=n;i++)
    {
        if(i==m) continue;
        if(i<m) sum1+=a[i]*(m-i);
        else sum2+=a[i]*(i-m);
    }
    if(sum1==sum2)
    {
        printf("%lld",m);
        return 0;
    }
    p2=m;
    if(sum1<sum2)
    {
        ans1=sum2-sum1;
        for(i=m-1;i>0;i--)
        {
            x=sum1+s2*(m-i)-sum2;
            if(x<0) x=-x;
            if(x<=ans1)
            {
                ans1=x;
                p2=i;
            } 
        }
    }
    else
    {
        ans1=sum1-sum2;
        for(i=m+1;i<=n;i++)
        {
            x=sum2+s2*(i-m)-sum1;
            if(x<0) x=-x;
            if(x<ans1)
            {
                ans1=x;
                p2=i;
            } 
        }
    }
    printf("%lld",p2);
    return 0;
}
