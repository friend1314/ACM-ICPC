#include<cstdio>
int b[110];
using namespace std;
int main()
{
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int n,m,i,j,t=0,x;
    scanf("%d%d",&n,&m);
    for(i=1;i<=n;i++)
    {
        scanf("%d",&x);
        b[x]++;
    }
    if(m==1)
    {
        printf("0");
        return 0;
    }
    for(i=2;i<=110;i+=2)
    {
        if(b[i-1]==0&&b[i]==0&&b[i+1]==0) continue;    
        if(b[i]>b[i-1]+b[i+1]) t+=b[i-1];
        else t+=b[i];
    }
    printf("%d",t);
    return 0;
}
