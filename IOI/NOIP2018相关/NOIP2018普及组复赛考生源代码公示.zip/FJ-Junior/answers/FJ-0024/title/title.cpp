#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    int i,sum=0;
    char a[5];
    for(i=0;i<5;i++)
    {
        scanf("%c",&a[i]);
        if(a[i]=='\n') break;
        if(a[i]==' ') continue;
        if(a[i]>='A'&&a[i]<='z'||a[i]>='a'&&a[i]<='z'||a[i]>='0'&&a[i]<='9') sum++;
    }
    printf("%d",sum);
    return 0;
}
