#include<bits/stdc++.h>
using namespace std;
long long s[10000000];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>s[i];
	printf("9"); 
	return 0;
}
