#include<bits/stdc++.h>
using namespace std;
long long g[1000000005];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,p2,shlix,shlax=0,shhix,shhax=0;
	long long s1,s2;
	bool u,v;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>g[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=m-1;i++){
		shlax+=g[i]*(m-i);
	}
	for(int j=m+1;j<=n;j++){
		shhix=g[j]*(j-m);
		shhax+=shhix;
	}
	if(p1>m)shhax+=(p1-m)*s1;
	else if(p1<m)shlax+=(m-p1)*s1;
	else
		u=1;
	int qi;
	if(shlax<shhax){
		qi=shhax-shlax;
		p2=m+qi/s2;
	}
	else if(shhax<shlax){
		qi=shlax-shhax;
		p2=m-qi/s2;
	}
	else
		v=1;
	if(u==1||v==1)cout<<m;
	else 
		cout<<p2;
	return 0;
}
