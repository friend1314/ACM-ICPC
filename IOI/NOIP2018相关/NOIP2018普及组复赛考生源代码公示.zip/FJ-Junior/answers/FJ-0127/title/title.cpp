#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s,u=0,k=0,i=0;
	string a;
	getline(cin,a);
	while(i<=a.length()){
		if(a[i]==' ')u++;
		if(a[i]=='\n')k++;
		i++;
	}
	s=a.length()-u-k;
	cout<<s;
	return 0;
}
