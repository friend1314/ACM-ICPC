#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	long long a,b,c;
	cin>>a>>b>>c;
	printf("3"); 
	return 0;
}
