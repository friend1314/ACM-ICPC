#include <cstdio>


int main()
{
	freopen("title.in", "r", stdin);
	freopen("title.out", "w", stdout);
	int num = 0;
	char ch;
	ch = getchar();
	while (ch != '\n' && ch != -1)
	{
		if (ch != ' ' && ch != '\n')
		{
			++num;
		}
		ch = getchar();
	}
	printf("%d", num);
	return 0;
}

