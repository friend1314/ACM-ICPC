#include <cstdio>
#include <queue>
using namespace std;
struct _nood
{
	int val;
	int l_id;
	int r_id;
}nood[110];
int nood_num;
int line_val[110] = {0};
int line_len = 0;


bool check_line(void)
{
	for (int i = 1; i <= (line_len >> 1); ++i)
	{
		if (line_val[i] != line_val[line_len - i + 1])
		{
			return false;
		}
	}
	return true;
}


inline bool line_dead(int id)
{
	if (id == 1)
	{
		return false;
	}
	for (int i = 1; i <= line_len; ++i)
	{
		if (line_val[i] != -1)
		{
			return false;
		}
	}
	return true;
}


int check_tree(int index)
{
	queue <int> id;
	id.push(1);
	int base_num = 2;
	int temp = 1;
	int tree_nood_num = 1;
	while (!line_dead(temp))
	{
		line_len = 0;
		for (int i = 1; i <= base_num; ++i)
		{
			temp = id.front();
			id.pop();
			id.push(nood[temp].l_id);
			id.push(nood[temp].r_id);
			line_val[line_len + 1] = nood[ nood[temp].l_id ].val;
			line_val[line_len + 2] = nood[ nood[temp].r_id ].val;
			line_len += 2;
		}
		//
		for (int i = 1; i <= line_len; ++i)printf("%d ", line_val[i]);putchar('\n');
		//
		if (!check_line())
		{
			return 0;
		}
		base_num <<= 1;
		tree_nood_num += base_num;
	}
	return tree_nood_num;
}


int get_max_num(int id)
{
	printf("id:%d ", id);
	if (nood[id].l_id == -1 && nood[id].r_id == -1)
	{
		printf("leaf\n");
		return 1;
	}
	if (nood[id].l_id == -1)
	{
		printf("right: %d\n", nood[id].r_id);
		return get_max_num(nood[id].r_id);
	}
	if (nood[id].r_id == -1)
	{
		printf("left: %d\n", nood[id].l_id);
		return get_max_num(nood[id].l_id);
	}
	printf("normal %d %d\n", nood[id].l_id, nood[id].r_id);
	int l_max = get_max_num(nood[id].l_id);
	int r_max = get_max_num(nood[id].r_id);
	return l_max > r_max? l_max: r_max;
}


int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &nood_num);
	for (int i = 1; i <= nood_num; ++i)
	{
		scanf("%d", &(nood[i].val));
	}
	for (int i = 1; i <= nood_num; ++i)
	{
		scanf("%d %d", &(nood[i].l_id), &(nood[i].r_id));
	}
	
	
	bool I_quit = true;
	if (I_quit)
	{
		puts("1");
		return 0;
	}
	if (nood_num <= 10)
	{
		for (int i = 1; i <= nood_num; ++i)
		{
			printf("%d %d\n", i, check_tree(i));
		}
	}
	else
	{
		
	}
	return 0;
}

