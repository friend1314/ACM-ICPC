#include <cstdio>
#include <cstring>
#include <cmath>
int chess[100010];


int main()
{
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	memset(chess, 0, sizeof(chess));
	
	int len, mid, p1, s1, s2;
	int l_power = 0, r_power = 0;
	scanf("%d", &len);
	for (int i = 1; i <= len; ++i)
	{
		scanf("%d", chess + i);
	}
	scanf("%d %d %d %d", &mid, &p1, &s1, &s2);
	chess[p1] += s1;
	for (int i = 1; i < mid; ++i)
	{
		l_power += (mid - i)*chess[i];
	}
	for (int i = mid + 1; i <= len; ++i)
	{
		r_power += (i - mid)*chess[i];
	}
	
	int min_val = 2147483647, min_index = 0;
	int new_power;
	for (int i = 1; i <= len; ++i)
	{
		if (i == mid)
		{
			continue;
		}
		new_power = i < mid
			? abs( l_power + (mid - i)*s2 - r_power )
			: abs( r_power + (i - mid)*s2 - l_power );
		if (new_power < min_val)
		{
			min_val = new_power;
			min_index = i;
		}
	}
	printf("%d", min_index);
	return 0;
}

