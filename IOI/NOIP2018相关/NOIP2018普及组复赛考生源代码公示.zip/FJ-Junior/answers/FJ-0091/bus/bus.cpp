#include <cstdio>
#include <algorithm>
int people_num, time_once;
int time[510];
int min_wait_time = 2147483647;


void dfs(int wait_time, int start_time, int people_arrived)
{
	if (start_time >= time[people_num])
	{
		wait_time += start_time - time[people_num];
		if (wait_time < min_wait_time)
		{
			min_wait_time = wait_time;
		}
		return ;
	}
	int new_wait_time, new_people_num;
	for (int next_time = start_time + time_once; next_time <= time[people_num]; ++next_time)
	{
		new_wait_time = 0;
		new_people_num = 0;
		for (int i = people_arrived + 1; i <= people_num; ++i)
		{
			if (time[i] <= next_time)
			{
				new_wait_time += next_time - time[i];
				++new_people_num;
			}
			else
			{
				break;
			}
		}
		if (new_people_num == 0 || wait_time + new_wait_time > min_wait_time)
		{
			continue;
		}
		dfs(wait_time + new_wait_time, next_time, people_arrived + new_people_num);
	}
}


int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	scanf("%d %d", &people_num, &time_once);
	for (int i = 1; i <= people_num; ++i)
	{
		scanf("%d", time + i);
	}
	std::sort(time + 1, time + people_num + 1);
	
	dfs(0, -time_once, 0);
	printf("%d", min_wait_time);
	return 0;
}

