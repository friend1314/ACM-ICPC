#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#define R register
#define ll long long
using namespace std;
const int N=100010;
ll n,m,p1,s1,s2,ans=0;
ll c[N]= {};
ll add1=0,tot=0x7fffffffffff;
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(R int i=1; i<=n; ++i) {
		scanf("%lld",&c[i]);
	}
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	for(R int i=1; i<=n; ++i) {
		add1+=c[i]*(m-i);
	}
	add1+=s1*(m-p1);
	for(R int i=1; i<=n; ++i) {
		ll add;
		add=s2*(m-i);
		if(abs(add1+add)<tot) {
			tot=abs(add1+add);
			ans=i;
		}
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
