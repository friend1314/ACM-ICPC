#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans=0;
	string a;
	getline(cin,a);
	int len=a.length()-1;
	for(int i=0;i<=len;++i){
	    if(a[i]>='0'&&a[i]<='9')ans++;
	    if(a[i]>='A'&&a[i]<='Z')ans++;
	    if(a[i]>='a'&&a[i]<='z')ans++;
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
