#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#define R register
#define ll long long
using namespace std;
const int N=510,M=4000110;
int n,m;
int t[N]= {};
int ans=0;
int f[M]= {};
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=M; ++i)f[i]=0x3f3f3f3f;
	for(int i=1; i<=n; ++i)scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	int tt=t[n];
	f[1]=0;
//	for(int i=1;i<=n;++i)printf("%d ",t[i]);
//	printf("\n%d\n%d",tt,v);
	for(R int i=1; i<=m; i++) {
		int l=1,r=n,cost=0;
		while(i<t[r])r--;//j<t[p]<=i
		for(int k=l; k<=r; ++k) {
			cost+=i-t[k];
		}
		f[i]=min(f[i],cost);
	}
	for(R int i=1; i<=tt; i++) {
		for(R int j=1; j<=i-m; j++) {
			int l=1,r=n,cost=0;
			while(j>=t[l])l++;
			while(i<t[r])r--;//j<t[p]<=i
		//	printf("i:%d j:%d l:%d r:%d ",i,j,l,r);
			for(int k=l; k<=r; ++k) {
				cost+=i-t[k];
			}
		//	printf("%d\n",cost);
			f[i]=min(f[i],f[j]+cost);
		}
	}
//  for(int i=1; i<=tt; ++i)printf("i=%d:%d\n",i,f[i]);
	printf("%d",f[tt]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
