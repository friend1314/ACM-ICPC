#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
using namespace std;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	scanf("%d",&n);
	int a;
	for(int i=1; i<=n*3; i++)scanf("%d",&a);
	printf("1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
