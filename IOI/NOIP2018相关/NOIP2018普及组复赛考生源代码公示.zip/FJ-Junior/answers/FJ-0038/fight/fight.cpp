#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,m,p1,s1,s2,c[100005],lt,rt,k,ans,sum;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(int i=1;i<=n;i++)
	{
		if(i<m)lt+=abs(i-m)*c[i];
		if(i>m)rt+=abs(i-m)*c[i];
	}
	ans=abs(lt-rt);sum=m;
	for(int i=n;i>=1;i--)
	{
		k=abs(i-m)*s2;
		if(i<m)
		{
			if(abs(lt+k-rt)<=ans)ans=abs(lt+k-rt),sum=i;
		}
		if(i>m)
		{
			if(abs(lt-rt-k)<=ans)ans=abs(lt-rt-k),sum=i;
		}
	}
	cout<<sum<<endl;
	return 0;
}

