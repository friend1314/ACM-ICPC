#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,m,t[505],sum,ans1,ans,tt,k,kkk,kk;
bool v[505];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>t[i];
	sort(t+1,t+n+1);
	while(kkk!=n)
	{
		ans=1e14;tt=0;
	    for(int i=1;i<=n;i++)
	    {
	    	if(!v[i])
	    	{
		    k=i;ans1=0;kk=i;
		    while(t[k]<t[i]+m&&k<=n)k++;
		    k--;
		    while(!v[kk]&&kk!=0)kk--;
			kk++;
			for(int j=kk;j<=k;j++)
			{
				if(t[j]<t[i])ans1+=t[i]-t[j];
				if(t[j]>t[i])ans1+=t[i]+m-t[j];
			}
			if(ans1<ans){ans=ans1;tt=k;}
		    }
	    }
	    for(int i=1;i<=tt;i++)v[i]=true;
	    kkk=tt;
	    sum+=ans;
    }
    cout<<sum<<endl;
	return 0;
}

