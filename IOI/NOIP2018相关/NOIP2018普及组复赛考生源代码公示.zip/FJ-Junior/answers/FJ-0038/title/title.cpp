#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
char s[15];
int len,sum;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	len=strlen(s);
	for(int i=0;i<len;i++)
	{
		if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')||(s[i]>='0'&&s[i]<='9'))sum++;
	}
	cout<<sum<<endl;
	return 0;
}

