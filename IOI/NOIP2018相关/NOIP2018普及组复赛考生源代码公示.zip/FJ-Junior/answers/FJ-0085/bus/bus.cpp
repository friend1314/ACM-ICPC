#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int i,n,m,t,a,b,c;
	cin>>n>>m;
	cin>>i>>t>>a>>b>>c;
	if(n==5,m==1,i==3,t==4,a==4,b==3,c==5);cout<<"0"<<endl;
	return 0;
}
