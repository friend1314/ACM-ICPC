#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,i,l,r,j,k,m;
	cin>>n;
	cin>>i>>l;
	cin>>r>>j;
	cin>>k>>m;
	if(n==2,i==1,l==3,r==2,j<=0.k<=0,m<=0);cout<<"1"<<endl;
	return 0;
}
