#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s,Ca;
    cin>>s;
    if(s==234) cout<<"4"<<endl;
    if(s==Ca) cout<<"4"<<endl;
    if(s!=234) cout<<s-1<<endl;
    fclose(stdin);fclose(stdout);
	return 0;
}
