#include<bits/stdc++.h>
using namespace std;
int n,m,t[520],ans;
int dengdai(int x,int y,int st)
{
	for(int i=1;i<n;i++)
	{
		if(t[i]==t[i+1]) continue;
		else
		{
			st+=m;
			if((t[i+1]-st)<m&&(t[i+1]-st>0)) ans+=t[i+1]-st;
			else if((st-t[i+1])<m&&(st-t[i+1]>0)) ans+=st-t[i+1];
		}
	}
	return ans;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","W",stdout);
    scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	printf("%d",dengdai(n,m,t[1]));
	fclose(stdin);fclose(stdout);
	return 0;
}
