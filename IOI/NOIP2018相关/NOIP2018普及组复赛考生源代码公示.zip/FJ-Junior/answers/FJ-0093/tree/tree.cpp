#include<bits/stdc++.h>
using namespace std;
int n,ans=1;
struct node
{
	int l,r,c;
}a[10000010];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) a[i].c=-1;
	for(int i=1;i<=n;i++)
	 scanf("%d",&a[i].c);
	for(int i=1;i<=n;i++)
	 scanf("%d%d",&a[i].l,&a[i].r);
	for(int i=1;i<=n;i++)
	{
		int x=a[i].l,y=a[i].r;
		if((a[x].c==a[y].c)&&(x!=-1)&&(y!=-1)) ans+=2;
	}
	printf("%d",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
