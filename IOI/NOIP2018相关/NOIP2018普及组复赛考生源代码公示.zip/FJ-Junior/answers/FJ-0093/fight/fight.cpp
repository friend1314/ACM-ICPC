#include<bits/stdc++.h>
using namespace std;
int n,c[100100],m,p,s1,s2;long long l,h;
int fight(int x,int y)
{
	int min=100000000,k;long long t;
	if(x==l)
	{
		for(int i=1;i<=m-1;i++)
	    {
		   t=x+s2*(m-i);
		   if(abs(t-y)<min) min=abs(t-y),k=i;
	    }
	}
	else
	{
		for(int i=m+1;i<=n;i++)
	    {
		   t=x+s2*(i-m);
		   if(abs(t-y)<min) min=abs(t-y),k=i;
	    }
	}
	return k;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p,&s1,&s2);
	for(int i=1;i<=m-1;i++)
	{
		if(i==p)
		  l+=(c[i]+s1)*(m-i);
		else l+=c[i]*(m-i);
	}
    for(int i=m+1;i<=n;i++)
	{
		if(i==p)
		  h+=(c[i]+s1)*(i-m);
		else h+=c[i]*(i-m);
	}
    if(h<l) printf("%d",fight(h,l));
	else if(l<h) printf("%d",fight(l,h));
	else if(l==h) printf("%d",m);
	fclose(stdin);fclose(stdout);
	return 0;
}
