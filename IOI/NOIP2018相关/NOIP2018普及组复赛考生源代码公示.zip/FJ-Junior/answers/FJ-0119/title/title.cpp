#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
char a[100];
int i,ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);	
	gets(a);
	for(i=0;i<strlen(a);i++){
		if((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='z')||(a[i]>='0'&&a[i]<='9')) ans++;
	}
	cout<<ans;
    return 0;
}
