#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
long long int n,m,a[509],t[40000],h,i,time=1,ans;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(i=1;i<=n;i++){
		cin>>a[i];
		t[a[i]]=1;
		if(h<a[i]) h=a[i];
	}
	for(i=1;i<=h;i++){
		if(t[i]==1){
			if(time>i)
			ans=ans+time-i;
			time=time+m;
		}
	}
	cout<<ans;
	return 0;
}
