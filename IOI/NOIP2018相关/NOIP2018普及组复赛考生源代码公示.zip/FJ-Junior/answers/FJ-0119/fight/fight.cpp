#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
long long int n,a[100009],m,p1,s1,s2,i,j;
long long int lo,hu,minn,ans=1;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	a[p1]=a[p1]+s1;
	for(i=1;i<m;i++){
		lo=a[i]*(m-i)+lo;
	}
	for(i=m+1;i<=n;i++){
		hu=a[i]*(i-m)+hu;
	}
    minn=abs(lo-hu);
    for(i=1;i<m;i++){
    	if(minn>abs(lo+s2*(m-i)-hu)){
    		minn=abs(lo+s2*(m-i)-hu);
    		ans=i;
		}
	}
	for(i=m+1;i<=n;i++){
		if(minn>abs(hu+s2*(i-m)-lo)){
			minn=abs(hu+s2*(i-m)-lo);
			ans=i;
		}
	}
	cout<<ans;
	return 0;
}
