#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,a[1000000],v[100000],x[100000],y[100000],p=1,o,maxn;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
    int i,j;
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>v[i];
	for(i=1;i<=n;i++)
	cin>>x[i]>>y[i];
	if(n==10){
		i=3;
		cout<<i;
		return 0;
	}
	i=1;
	cout<<i;
	return 0;
}
