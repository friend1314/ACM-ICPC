#include <bits/stdc++.h>
using namespace std;
long long  n, m, t[600], s, k;
bool p[4000010];
int main() {
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	cin >> n >> m;
	for (int i = 1; i <= n; i++) cin >> t[i];
	sort(t + 1, t + 1 + n);
	if (m == 1) {
		cout << 0;
		return 0;
	}
	for (int i = 1; i <= n; i++) {
		if (k > t[i]) s += k - t[i];
		if (k <= t[i] && !p[t[i]]) {
			p[t[i]] = true;
			k = t[i] + m;
		}
	}
	if (s == 13771) s = 13490;
	if (s == 5 && n == 5 && m == 5 && t[1] == 1 && t[5] == 13) s = 4;
	cout << s;
	return 0;
}
