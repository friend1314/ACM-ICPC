#include <bits/stdc++.h>
using namespace std;
long long n, c[100010], m, p1, p2, s1, s2, q1, q2;
int main() {
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	cin >> n;
	for (int i = 1; i <= n; i++) cin >> c[i];
	cin >> m >> p1 >> s1 >> s2;
	c[p1] += s1;
	for (int i = 1; i < m; i++) q1 += c[i] * (m - i);
	for (int i = m + 1; i <= n; i++) q2 += c[i] * (i - m);
	if (q1 == q2) p2 = m;
	else {
		long long cmin = abs(q1 - q2);
		for (int i = 1; i <= n; i++) {
			if (i > m) q2 += s2 * (i - m);
			else q1 += s2 * (m - i);
			if (abs(q1 - q2) < cmin) {
				cmin = abs(q1 - q2);
				p2 = i;
			}
			if (i > m) q2 -= s2 * (i - m);
			else q1 -= s2 * (m - i);
		}
	}
	cout << p2;
	return 0;
}
