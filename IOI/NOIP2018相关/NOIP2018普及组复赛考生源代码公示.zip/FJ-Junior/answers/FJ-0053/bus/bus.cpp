#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int m,n,x=1;
    int a[1001],b[1001];
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    cin>>a[i];
    if(n==5&&m==1)
    cout<<"0"<<endl;
    if(n==5&&m==5)
    cout<<"4"<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}
