#include<iostream>
#include<cstdio>
using namespace std;
int a[1001],b[1001],c[1001];
int main()
{
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    int min,n,m,p1,p2,s1,s2,x,y;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    cin>>m>>p1>>s1>>s2;
    for(int i=1;i<=n-m;i++){a[i]*(m-i)==b[i];x+=b[i];}
    for(int i=n;i>m;i--){a[i]*(i-m)==c[i];y+=c[i];}
    if(p1>m&&p1!=m)
    y=y+a[p1]*s1;
    else
    x=x+a[p1]*s1;
    if(x>y) 
    {min=x-y;
    for(int i=1;i<=n-m;i++)
    {
    for(int j=i+1;j<=n-m;j++)
    {(a[j])*(m-j)==b[j];x+=b[j];}
    x=x+(a[i]+s2)*(m-i);
    if(x>y)
    {if((x-y)<min)
    {p2=i;min=x-y;}
    else
    {p2=i;min=y-x;}
    }
    }
    }
    else 
    {min=y-x;
    for(int i=n;i>m;i--)
    {
    for(int j=i-1;j>m;j--)
    {a[i]*(i-m)==c[i];y+=c[i];}
    y=y+(a[i]+s2)*(m-i);
    if(x>y)
    {
    if((x-y)<min)
    {p2==i;min=x-y;}
    else
    {p2=i;min=y-x;}
    }
    }
    }
    cout<<a[1]<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}
