#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    char s[1001];
    string a;
    int ans=0;
    gets(s);
    a=s;
    for(int i=0;i<a.size();i++)
    if(a[i]!=' ')
    ans++;
    cout<<ans<<endl;
    fclose(stdin);fclose(stdout);
    return 0;
}

