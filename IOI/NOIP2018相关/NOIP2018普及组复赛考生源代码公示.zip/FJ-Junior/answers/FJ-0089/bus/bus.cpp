#include <iostream>
#include <algorithm>
using namespace std;
int n,m,quanju;
long long ans=0,t[510],lins[510],diguil[510];
long long tanxin[510],guihua,digui,cengshu,linshi;
long long quling(long long a)
{
	if(a<0)
		return 0;
	else
		return a;
}
void doing(int hao)
{
	digui+=t[hao]-t[hao-1];
	hao++;
	cengshu++;
	diguil[hao]=t[hao-1]+m;
	if((hao<n)&&(t[hao]-t[hao-1]<quling(diguil[hao]-t[hao])))
	{
		doing(hao);
	}
	else
	{
		hao--;
		cengshu--;
	}
	if(hao>quanju)
		quanju=hao;
	return;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<n;i++)
		cin>>t[i];
	sort(t,t+n);
	for(quanju=1;quanju<n;quanju++)
	{
		lins[quanju]=t[quanju-1]+m;
		tanxin[quanju]=quling(lins[quanju]-t[quanju]);
		if(tanxin[quanju]>t[quanju]-t[quanju-1])
		{
			digui=0;
			linshi=tanxin[quanju-1];
			cengshu=2;
			doing(quanju);
			ans+=digui+(cengshu-1)*linshi;
		}
		else
			ans+=tanxin[quanju];//m-(t[i]-t[i-1]);
	}
	cout<<ans;
	return 0;
}
//By:Kkkrran
//ORZ YC
/*for(int i=1;i<n;i++)
		if(t[i]!=t[i-1])
		{
			lins[i]=t[i-1]+m;
			tanxin=quling(lins[i]-t[i]);
			if(tanxin>(t[i]-t[i-1]))
				ans+=t[i]-t[i-1];
			else
				ans+=tanxin;//m-(t[i]-t[i-1]);
		}
*/
