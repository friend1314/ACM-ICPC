#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
long long n,c[100005],p1,s1,s2;
long long m,lshiqi=0,rshiqi=0,jie1,tui1,lins[100005],best_hao,best_zhi=7386721425538678783;
long long juedui(long long a)
{
	if(a<0)
		return -a;
	else
		return a;
}
int main()
{
	//cout<<best_zhi;
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(long long i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(long long i=1;i<m;i++)
		lshiqi+=(m-i)*(c[i]);
	for(long long i=m+1;i<=n;i++)
		rshiqi+=(i-m)*(c[i]);
	//cout<<lshiqi<<' '<<rshiqi;
	if(lshiqi==rshiqi)
		cout<<m;
	else if(lshiqi>rshiqi)
	{
		jie1=m+1;
		tui1=lshiqi-rshiqi;
		for(long long i=jie1;i<=n;i++)
		{
			lins[i]=juedui(tui1-((i-m)*s2));
			if(lins[i]<best_zhi)
			{
				best_zhi=lins[i];
				best_hao=i;
			}
		}
		cout<<best_hao;
	}
	else if(lshiqi<rshiqi)
	{
		jie1=m-1;
		tui1=rshiqi-lshiqi;
		for(long long i=1;i<=m-1;i++)
		{
			lins[i]=juedui(tui1-((m-i)*s2));
			if(lins[i]<best_zhi)
			{
				best_zhi=lins[i];
				best_hao=i;
			}	
		}
		cout<<best_hao;
	}
	return 0;
}
