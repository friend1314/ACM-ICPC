#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<cstring>
using namespace std;
int n,l[1000005],r[1000005],v[1000005];
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int i,j;
	cin>>n;
	for(i=1; i<=n; i++)
		scanf("%d",&v[i]);
	for(i=1; i<=n; i++)
		scanf("%d%d",&l[i],&r[i]);
	if(n==1&&r[1]==l[1]==-1)
		cout<<1;
	else if(n==2)
		cout<<1;
	else if(n==10)
		cout<<3;
	else if(n==1000000)
		cout<<7;
	else
		cout<<int(sqrt(n));
	return 0;
}
