#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<cstring>
using namespace std;
string s;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int len,i,ans=0;
	getline(cin,s);
	len=s.size();
	for(i=0; i<len; i++)
		if(s[i]!=' ')
			ans++;
	cout<<ans;
	return 0;
}
