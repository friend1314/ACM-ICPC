#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<cstring>
using namespace std;
int n,m,p1,s1,s2,c[100005];
long long ans[100005];
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int i,j,s;
	long long l=0,h=0,l1,h1,minn;
	cin>>n;
	for(i=1; i<=n; i++)
		scanf("%d",&c[i]);
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(j=1; j<=n; j++) {
		if(j<m)
			l+=c[j]*abs(m-j);
		if(j>m)
			h+=c[j]*abs(m-j);
	}
	for(i=1; i<=n; i++) {
		l1=l,h1=h;
		if(i<m)
			l1+=s2*abs(m-i);
		if(i>m)
			h1+=s2*abs(m-i);
		ans[i]=abs(l1-h1);
	}
	minn=ans[n];
	for(i=m; i>=1; i--)
		if(ans[i]<=minn)
			minn=ans[i],s=i;
	cout<<s;
	return 0;
}
