#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
#include<string>
#include<cstring>
using namespace std;
int n,m,c[505];
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int i,j=1,k;
	int s,ans=0,t;
	cin>>n>>m;
	for(i=1; i<=n; i++)
		scanf("%d",&c[i]);
	sort(c+1,c+n+1);
	t=c[1];
	for(i=1; i<=n;) {
		s=0,k=0,j=i;
		while(c[j]-c[i]<sqrt(m)&&j<=n)
			s+=c[j],k++,j++;
		j--;
		ans+=abs(t*k-s);
		t+=m;
		i=j+1;
	}
	cout<<ans;
	return 0;
}
