#include<bits/stdc++.h>
using namespace std;
int n,m,a1,a2,s,a[100001],ans=0,num=0;
int nm=0,lj,op=0,no,mmp=0;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	  cin>>a[i];
	cin>>m>>s>>a1>>a2;
	a[s]=a[s]+a1;
	for(int i=1;i<=m-1;i++)
		ans=ans+(a[i]*(m-i));
	for(int i=m+1;i<=n;i++)
		num=num+(a[i]*(i-m));
	if(ans>num)
	{
		mmp=ans-num;
	}
	if(ans<num)
	{
		mmp=num-ans;
	}
	if(ans==num)
	{
		mmp=0;
	}
	
	
	
	
	if(ans<num)
	{
		no=1;
		nm=num-(a2*(m-1)+ans);
		if(nm>0)
		{
			op=nm;
		}
		if(nm<0)
		{
			op=(a2*(m-1)+ans)-num;
		}
		if(nm==0)
		{
			cout<<no;
			return 0;
		}
		for(int i=2;i<m;i++)
		{
			lj=num-(a2*(m-i)+ans);
			if(lj>0)
			{
				if(op>lj)
				{
					op=lj;
					no=i;
				}
			}
			if(lj<0)
			{
				if(op>(a2*(m-i)+ans)-num)
				{
					lj=(a2*(m-i)+ans)-num;
					no=i;
				}
			}
			if(lj==0)
			{
				cout<<i;
				return 0;
			}
		}
		if(lj>mmp)
		{
			cout<<m;
			return 0;
		}
		cout<<no;
		return 0;
	}
	
	
	
	
	if(ans>num)
	{
		no=m+1;
		nm=ans-(a2*1+num);
		if(nm>0)
		{
			op=nm;
		}
		if(nm<0)
		{
			op=(a2*1+num)-ans;
		}
		if(nm==0)
		{
			cout<<no;
			return 0;
		}
		for(int i=m+1;i<n;i++)
		{
			lj=ans-(a2*(i-m)+num);
			if(lj>0)
			{
				if(op>lj)
				{
					op=lj;
					no=i;
				}
			}
			if(lj<0)
			{
				if(op>(a2*(i-m)+num)-ans)
				{
					lj=(a2*(i-m)+num)-ans;
					no=i;
				}
			}
			if(lj==0)
			{
				cout<<i;
				return 0;
			}
		}
		if(lj>mmp)
		{
			cout<<m;
			return 0;
		}
		cout<<no;
		return 0;
	}
	return 0;
}
