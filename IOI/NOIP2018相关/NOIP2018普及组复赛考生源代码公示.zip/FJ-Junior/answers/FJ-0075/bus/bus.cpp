#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
using namespace std;
int n,m,ans=0;
int t[505];
int b[1000101];
int mod[101];
int maxtime=-1;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	memset(b,0,sizeof(b));
	memset(t,0,sizeof(t));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
		b[t[i]]++;
		maxtime=max(maxtime,t[i]);
	}
	if(m==1)
	{
		printf("0\n");
		return 0;
	}
	else if(m==2)
	{
		for(int i=0;i<=maxtime;i++)
		{
			if(b[i]==0) continue;
			int temp=i;
			int ji=0,ou=0;
			while(b[temp]!=0)
			{
				if((temp-i)%2==0) ji+=b[temp];
				else ou+=b[temp];	
				temp++;
			}
			ans+=min(ji,ou);
			i=temp;
		}
		cout<<ans<<endl;
		return 0;
	}
	/*====================================================*/
	else
	{
		for(int i=1;i<=maxtime;i++)
		{
			int tt=-1,s=0;
			bool flag=1;  //�Ƿ������m��ȫ��0 
			for(int j=i;j<i+m;j++) if(b[j]!=0) flag=0;
			if(flag==1) continue; 
			int temp=i;
			while(flag==0)
			{
				/*if((temp-i)%2==0) ji+=b[temp];
				else ou+=b[temp];*/
				mod[(temp-i)&m]+=b[temp];
				temp++;
				flag=1;  //�Ƿ������m��ȫ��0 
				for(int j=temp;j<temp+m;j++) if(b[j]!=0) flag=0;
			}
			for(int j=0;j<m;j++)
			{
				tt=max(tt,mod[j]);
				s+=mod[j];
			}
			ans+=(s-tt);
			i=temp;
		}
		cout<<ans<<endl;
		return 0;
	}
	/*======================================================*/
	fclose(stdin);fclose(stdout);
	return 0;
}
