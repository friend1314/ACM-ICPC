#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
using namespace std;
char str[11];
int ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(str);
	for(int i=0;i<strlen(str);i++)
	{
		char c=str[i];
		if((c<='Z'&&c>='A')||(c>='a'&&c<='z')||(c>='0'&&c<='9')) ans++;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
