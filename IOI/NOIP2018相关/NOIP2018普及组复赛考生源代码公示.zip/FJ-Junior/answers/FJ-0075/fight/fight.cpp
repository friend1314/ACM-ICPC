#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
using namespace std;
int n,m,p1,s1,s2;
int qi1,qi2,minn=2147483647,ans;
int t1,t2;
int c[100001];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	for(int i=1;i<m;i++) qi1+=c[i]*(m-i);
	for(int i=m+1;i<=n;i++) qi2+=c[i]*(i-m);
	//cout<<qi1<<" "<<qi2<<endl;
	for(int i=1;i<=n;i++)
	{
		t1=qi1;t2=qi2;
		if(i<m)  t1+=(m-i)*s2;
		if(i>m)  t2+=(i-m)*s2;
		int t3=abs(t1-t2);
		if(t3<minn)
		{
			minn=t3;
			ans=i;
		}
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
