#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdlib>
using namespace std;
int n,w[100001];
int root;
int lc[100001],rc[100001];
int l[100001],r[100001];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	memset(lc,-1,sizeof(lc));
	memset(rc,-1,sizeof(rc));
	memset(l,-1,sizeof(l));
	memset(r,-1,sizeof(r));
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]);
	for(int i=1;i<=n;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		if(a!=-1&&b!=-1) root=i;
		lc[i]=a;rc[i]=b;
	}
	
	/*cout<<root<<endl;
	for(int i=1;i<=n;i++) cout<<lc[i]<<" "<<rc[i]<<endl;
	cout<<endl;*/
	
	int a,b;
	a=lc[root];b=rc[root];
	int i=1;
	l[i]=w[root];r[i]=w[root];
	
	/*cout<<endl<<endl<<w[root]<<endl<<endl;
	
	cout<<l[i]<<" ";*/
	
	while(a!=-1)
	{
		
		
		l[++i]=w[a];
		a=lc[a];
		
		/*cout<<l[i]<<" ";*/
	}
	
	/*cout<<endl;
	
	
	
	cout<<r[root]<<" ";*/
	i=1;
	
	while(b!=-1)
	{
		
		r[++i]=w[b];
		b=rc[b];
		
		/*cout<<r[i]<<" ";*/
	}
	
	/*cout<<endl;*/
	
	bool f=1;
	for(int i=1;i<=n;i++)
	{
		if(l[i]!=r[i]) f=0;
		
		/*cout<<l[i]<<" "<<r[i]<<endl;
		cout<<endl;
		**/
	}
	if(f) cout<<n<<endl;
	else cout<<1<<endl;
	fclose(stdin);fclose(stdout);
	return 0;
}
