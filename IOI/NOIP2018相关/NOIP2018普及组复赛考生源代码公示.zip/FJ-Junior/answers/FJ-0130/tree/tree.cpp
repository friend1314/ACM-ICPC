#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
long long n,a,b;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a;
	}
	for(int i=1;i<=n;i++){
		cin>>a>>b;
	}
	cout<<1;
	return 0;
}
