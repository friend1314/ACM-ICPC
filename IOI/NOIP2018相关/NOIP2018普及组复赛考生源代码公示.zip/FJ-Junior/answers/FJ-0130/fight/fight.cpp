#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
long long n,a[100001],mc,p1c,p2c,s1c,s2c;
long long ldqs=0,hdqs=0,ans,f;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>mc>>p1c>>s1c>>s2c;
	a[p1c]+=s1c;
	for(int i=1;i<mc;i++){
		ldqs+=(mc-i)*a[i];
	}
	for(int i=mc+1;i<=n;i++){
		hdqs+=(i-mc)*a[i];
	}
	ans=abs(ldqs-hdqs);
	f=mc;
	for(int i=1;i<mc;i++){
		if(abs(ldqs+s2c*(mc-i)-hdqs)<ans){
			ans=abs(ldqs+s2c*(mc-i)-hdqs);
			f=i;
		}
	}
	for(int i=mc+1;i<=n;i++){
		if(abs(hdqs+s2c*(i-mc)-ldqs)<ans){
			ans=abs(hdqs+s2c*(i-mc)-ldqs);
			f=i;
		}
	}
	cout<<f<<endl;
	return 0;
}
