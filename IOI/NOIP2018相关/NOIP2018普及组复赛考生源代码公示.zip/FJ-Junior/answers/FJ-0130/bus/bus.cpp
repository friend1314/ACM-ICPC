#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,m,a[501],ans,sj=1,l=1,s=0;
bool aflag[501];
/*void gg(int t){
	
	gg(t+m);
	t-=m;
	gg(t+1);
	t--;
}*/
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++){
		ans+=a[n]-a[i];
	}
	if(m==1){
		cout<<0<<endl;
		return 0;
	}
	else{
    	//gg(0);
    	//cout<<ans;
    	//return 0;
		while(l<=n){
			int ddrs=0;
			int i=l;
			if(a[i]>sj){
				sj=a[i];
			}
			while(a[i]<=sj){
				ddrs++;
				i++;
			}
			if(sj+m<=a[i]){
				sj+=m;
				l=i;
			}
			else{
				int airs=0;
				int i2=i;
				while(a[i]==a[i2]){
					airs++;
					i2++;
				}
				int yssj=airs*(sj+m-a[i]);
				int tt=1;
				while(aflag[tt]==1){
					tt++;
				}
				int wwrs=0;
				while(a[tt]<=sj){
					wwrs++;
					tt++;
				}
				int bssj=wwrs*(a[i]-sj);
				//int bssj=(i-l)*(a[i]-sj);
				if(yssj<bssj){
			    	for(int j=1;j<=i+airs-1;j++){
			    		aflag[j]=1;
					}
			    	sj+=m;
			    	l=i;
			    	s+=yssj;
				}
				else{
					sj=a[l];
					l=i2;
					s+=bssj;
				}
			}
		}
		cout<<s<<endl;
		return 0;
	}
}/*
7 5
5 7 4 1 3 9 8*/
