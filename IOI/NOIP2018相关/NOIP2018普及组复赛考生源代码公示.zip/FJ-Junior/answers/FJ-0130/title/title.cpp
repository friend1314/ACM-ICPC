#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
char a[10];
int l,ans=0;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	l=strlen(a);
	for(int i=0;i<l;i++){
		if((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')||(a[i]>='0'&&a[i]<='9')){
			ans++;
		}
	}
	cout<<ans;
	return 0;
}
