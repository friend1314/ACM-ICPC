#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int main()
{   
    freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    int n;
	cin>>n;
	int a[100];
	cin>>a[100];
	int li,ri;
	cin>>li>>ri;
	cout<<2<<endl;
    freopen("title.out","w",stdout);
}
