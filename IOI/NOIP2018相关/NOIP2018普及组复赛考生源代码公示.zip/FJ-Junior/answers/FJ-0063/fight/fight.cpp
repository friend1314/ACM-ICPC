#include<iostream>
#include<cstdio>
using namespace std;
int mian()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin>>n;
	cin>>n[100];
	int m,p1,s1,s2,p2;
	cin>>m>>p1>>s1>>s2;
	int a=0,b=0;
	for(int i=1;i<m;i++)
	{
	  for(int j=m-1;j>0;j--)
	{
		a=n[i]*j;
		a++;
    }
    for(int i=n;i>m;i--)
    {
    	for(int f=n-m;f>0;f--)
    {
    	b=n[i]*f;
    	b++;
    }
    if(p1<m)
    {a=(m-p1)*s1+a;
    int q=0,c;
    q=a-b;
    c=q/s2;
    p2=m-c;
    cout<<p2<<endl;
    }
    if(p1>m)
    { b=(p1-m)*s1+a;
    int r=0,l;
    r=b-a;
    l=r/s2;
    p2=m+l;
    cout<<p2<<endl;
    }
    fclose(stdin),fclose(stdout);
    return 0;
}
