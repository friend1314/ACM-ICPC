#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int mian()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s;
	cin>>s;
	cout<<"3";
    fclose(stdin),fclose(stdout);
    return 0;
}
