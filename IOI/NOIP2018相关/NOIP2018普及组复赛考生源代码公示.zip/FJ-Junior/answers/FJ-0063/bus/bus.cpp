#include<iostream>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a[100];
	for(int i=1;i<=n;i++)
	cin>>a[i];
	cout<<0<<endl;
	fclose(stdin),fclose(stdout);
	return 0;

	
}
