#include<cstdio>
#include<cstring>
#include<cctype>
const int MAXN=10;

int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans=0;    
	char ch=getchar();
	while(ch!=EOF){
		ans+=(isdigit(ch)||isalpha(ch));
		ch=getchar();
	}
	printf("%d\n",ans);
	return 0;
}
/*
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
*/
