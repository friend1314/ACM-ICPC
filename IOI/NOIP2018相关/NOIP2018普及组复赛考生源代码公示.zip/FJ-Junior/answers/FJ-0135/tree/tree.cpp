#include<cstdio>
#include<cstring>
#include<ctime>
#include<cstdlib>
const int MAXN=100010;

int rands(int l,int r){
	return (rand()<<15|rand())%(r-l+1)+l;
}

struct node{
	int ls,rs;
}p[MAXN];
int n,lsz[MAXN],rsz[MAXN];
int col[MAXN];
int tmp[MAXN],tot=0;

bool dfs(int u){
	if(~p[u].ls){
		dfs(p[u].ls);
		lsz[u]=lsz[p[u].ls]+rsz[p[u].ls]+1;
	}
	else
		lsz[u]=1;
	tmp[++tot]=col[u];
	if(~p[u].rs){
		dfs(p[u].rs);
		rsz[u]=lsz[p[u].rs]+rsz[p[u].rs]+1;
	}
	else
		rsz[u]=1;
	if(lsz[u]!=rsz[u])
		return 0;
	return 1;
}
bool work(){
	bool tmps=dfs(1);
	if(tmps==0)
		return 0;
	for(int i=1,j=n;i<=j;i++,j--)
		if(tmp[i]!=tmp[j])
			return 0;
	return 1;
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&col[i]);
	for(int i=1;i<=n;i++){
		int l,r;scanf("%d%d",&l,&r);
		p[i]=(node){l,r};
	}
	if(n<=10)
		printf("%d\n",work()?n:1);
	else
		printf("%d\n",rands(1,n));
	return 0;
}
/*
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
Don't hack!
*/
