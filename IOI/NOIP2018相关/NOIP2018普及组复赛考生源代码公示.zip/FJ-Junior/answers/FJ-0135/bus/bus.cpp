#include<cstdio>
#include<cstring>
#include<algorithm>
#define reg register
const int MAXN=510;

int n,m,a[MAXN];
long long f[MAXN][110];

inline int max(reg int x,reg int y){
	return x>y?x:y;
}
inline long long min(reg long long x,reg long long y){
	return x<y?x:y;
}

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m); 
	for(reg int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	std::sort(a+1,a+n+1);
	for(reg int i=1;i<=n;i++){
		for(int g=0;g<m;g++){
			reg long long wt=0;
			for(reg int k=1;k<=i;k++)
				wt+=a[i]+g-a[k];
			f[i][g]=wt;
		}
		for(reg int j=1;j<i;j++)
			for(reg int g=0;g<m;g++){
				int t=max(a[j]+m+g,a[i]);
				int lst=t-a[i];
				reg long long wt=0;
				for(reg int k=j+1;k<=i;k++)
					wt+=t-a[k];
				f[i][lst]=min(f[i][lst],f[j][g]+wt);
			}
	}
	reg long long _ans=(1ll<<60);
	for(reg int i=0;i<m;i++)
		_ans=min(_ans,f[n][i]);
	printf("%lld\n",_ans);
	return 0;
}
/*
Don't hack me!
*/
