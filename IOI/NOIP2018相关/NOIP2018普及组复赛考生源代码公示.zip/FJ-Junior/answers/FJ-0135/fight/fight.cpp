#include<cstdio>
#include<cstring>
const int MAXN=100010;

int n,m,p1;
long long s1,s2;
long long c[MAXN];

inline long long my_abs(long long x){
	return x>0?x:-x;
}
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lld",&c[i]);
	scanf("%d%d%lld%lld",&m,&p1,&s1,&s2);
	long long sum=0; 
	for(int i=1;i<=n;i++)
		sum+=c[i]*(long long)(m-i);
	sum+=s1*(m-p1); 
	long long ans=(1ll<<60),ans_pos=0;
	for(int i=1;i<=n;i++){ 
		if(ans>my_abs(sum+s2*(long long)(m-i))){
			ans=my_abs(sum+s2*(long long)(m-i));
			ans_pos=i;
		}
	}
	printf("%lld\n",ans_pos);
	return 0;
}
/*
Don't hack me,please!
Don't hack me,please!
Don't hack me,please!
*/
