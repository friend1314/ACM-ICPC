#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char c[10];
	int i,n,ans;
	for(i='a';i<='z';i++)
	for(i='A';i<='Z';i++)
	for(i='0';i<='9';i++)
	//for(i=1;i<=sizeof(i);i++)
	{
		cin>>c[i];
	    ans+=c[i];
	}
    cout<<ans;
	return 0;
}
