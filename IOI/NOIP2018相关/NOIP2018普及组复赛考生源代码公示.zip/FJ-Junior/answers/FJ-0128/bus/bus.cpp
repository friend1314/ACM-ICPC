#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int f[1005],b[1005][1005],n,ans,a[1005][1005];
int search(int k)
{
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=k;j++)
	{
		if(f[i]+=b[i][j]-2*a[i][j])
		return b[i][j];
	else f[i]=max(a[i][j+1],b[i+1][j]+2*a[i][j]);
}
	return k;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	cin>>n>>m;
	search(1);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		scanf("%d",&a[i][j]);		
		if(m>n) ans++;
		return search(1);
	}
	cout<<ans<<endl;
	return 0;
}
