#include<iostream>
#include<cstdio>
#include<algorithm>
int f[1005];
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,len,ans1,ans2,num,sum,a,b,c,d;
	cin>>n;
	for(int i=1;i<=n;i++)
	scanf("%d",&f[i]);
	scanf("%d %d %d %d ",&a,&b,&c,&d);
	for(int i=1;i<=n;i++)
	{
		
	}
	for(int i=1;i<=n;i++)
	{
		if(len>n)
		{
			sum=f[i]*(len-n);
			ans1+=sum;
	    }
		if(n>len)
		{
			num=f[i]*(n-len);
			ans2+=num;
		
	    }
	}
	return 0;
}
	
