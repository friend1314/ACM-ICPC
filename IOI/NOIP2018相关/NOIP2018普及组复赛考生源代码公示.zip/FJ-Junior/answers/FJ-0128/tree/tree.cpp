#include<iostream>
#include<cstdio>
#include<algorithm>
int f[1005],b[1005];
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cout<<"3";
	return 0;
}
