#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
long long a,b[100050],m,p1,s1,s2;
long long sum1,sum2,sum3;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	sum1=0; sum2=0; sum3=0;
	for(int i=1;i<=100050;i++)
	b[i]=0;
	cin>>a;
	for(int i=1;i<=a;i++)
	cin>>b[i];
	cin>>m>>p1>>s1>>s2;
	b[m]=0;
	for(int i=1;i<m;i++)
		sum1+=b[i]*(m-i);
	for(int i=a;i>m;i--)
		sum2+=b[i]*(i-m);
	if(p1>m)
	{
		sum3=s1*(p1-m);
		sum2+=sum3;
	}
	if(p1<m)
	{
		sum3=s1*(m-p1);
		sum1+=sum3;
	}
	if(p1==m)  
	sum3=0;
	if(sum2==sum1)
	{
		cout<<m;
		return 0;
	}
	if(sum2>sum1)
	{
		if(m-(sum2-sum1)/s2>0)
		cout<<m-(sum2-sum1)/s2;
		else
		cout<<"1";
		return 0;
	}
	if(sum1>sum2)
	{
		if(m+(sum1-sum2)/s2<a)
		cout<<m+(sum1-sum2)/s2;
		else
		cout<<a;
		return 0;
	}
	return 0;
}
