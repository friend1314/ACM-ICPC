#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
char a[6];
int s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	s=0;
	for(int i=0;i<5;i++)
	{
		if(a[i]!=' ')
		if((a[i]<='Z'&&a[i]>='A')||(a[i]<='z'&&a[i]>='a')||(a[i]<='9'&&a[i]>='0'))
		s++;
	}
	cout<<s;
	return 0;
}
