#include<iostream> 
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,s=1;
struct p
{
	int sum;
	int left;
	int right;
}p[10000];
void go(int x)
{
	if(p[x].sum==p[x].sum)
	{
		s*=2;
		go(p[x].left);
		go(p[x].right);
	}
	else
	{
		s=0;
		return ;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	if(n==1)
	{
		cout<<"1";
		return 0;
	}
	for(int i=1;i<=n;i++)
	cin>>p[i].sum;
	for(int i=1;i<=n;i++)
	{
		cin>>p[i].left;
		cin>>p[i].right;
	}
	for(int i=n;i>=1;i--)
		go(i);
	cout<<s;
	return 0;
}
