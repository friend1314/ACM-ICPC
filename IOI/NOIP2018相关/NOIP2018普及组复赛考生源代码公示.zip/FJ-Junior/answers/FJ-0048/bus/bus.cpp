#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,p,t,ss=0,fc=1;
long long a[1000],s[5000];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	t=0;
	for(int i=0;i<=5000;i++)
	s[i]=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	if(m==1)
	{
		cout<<"0";
		return 0;
	}
	if(m==2)
	{
		for(int i=1;i<=n;i++)
		{
			if(a[i]%2!=1)
			t++;
		}
		cout<<t;
		return 0;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
	{
		int p=1,pp=0,ppp=0,p1=1;
		for(int k=i+1;k<=n;k++)
		{
			if(a[k]>a[i]+m)
			break;
			p++;
		}
		for(int j=i+1;j<i+p;j++)
			pp+=a[i]+p-a[j];
		int l=i;
		while(a[i]==a[l])
		{
			p1++;
			l++;
		}
		if(p1*m<pp)
		ss+=pp;
		else
		ss+=p1*m;
	}
	cout<<ss;
	return 0;
}
		
