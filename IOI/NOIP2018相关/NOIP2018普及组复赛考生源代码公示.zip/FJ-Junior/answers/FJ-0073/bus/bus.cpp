#include<bits/stdc++.h>
#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,t[1000],s[1000],x=1,y=0,z=n,a=0,b=1,c=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
	}
	for(int i=2;i<=z;i++)
	{
		if(t[i]<t[i-1])
		{
			y=t[i-1];
			t[i-1]=t[i];
			t[i]=y;
		}
		if(i==z)
		{
			i=2;z--;
		}
	}
	for(int i=2;i<=b;i++)
	{
		if((s[i]-s[i-1])>1)
		{
			c+=(s[i]-s[i-1]-1);
		}
	}
	printf("%d",c);
	return 0;
}
