#include<bits/stdc++.h>
#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,c[10000],m,p1,p2=10000,s1,s2;
	cin>>n;
	int a=0,b=0,x[10000],s=0;
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=m-1;i++)
	{
		if(i==p1)
		{
			x[i]=((c[i]+s1)*(m-i));
			a+=x[i];
		}
		else
		{
			x[i]=(c[i]*(m-i));
			a+=x[i];
		}
	}
	for(int i=m+1;i<=n;i++)
	{
		if(i==p1)
		{
			x[i]=((c[i]+s1)*(i-m));
			b+=x[i];
		}
		else
		{
			x[i]=(c[i]*(i-m));
			b+=x[i];
		}
	}
	if(a==b)
	{
		p2=m;
		cout<<p2;
	}
	else
	{
		if(a<b)
	{
		s=(b-a);
		for(int i=1;i<=m-1;i++)
		{
			
			if(s2*(m-i)>=s)
			{
				if((s2*(m-i)-s)<p2)
				{
					p2=i;
				}
			}
			else
			{
				if((s-s2*(m-i))<p2)
				{
					p2=i;
				}
			}
		}
		cout<<p2;
	}
	else
	{
		s=(a-b);
		for(int i=m+1;i<=n;i++)
		{
			if((s2*(i-m))>=s)
			{
				if((s2*(i-m)-s)<p2)
				{
					p2=i;
				}
			}
			else
			{
				if((s-s2*(i-m))<p2)
				{
					p2=i;
				}
			}
		}
		cout<<p2;
	}
	}
	return 0;
}
