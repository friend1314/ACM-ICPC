#include<bits/stdc++.h>
using namespace std;
int nn,xz,xj,wj,zl,xuan=0,kai=0,zxz=1000000001,pd,klk,klx;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>nn;
	int a[nn+1];
	for(int i=1;i<=nn;i++)
		cin>>a[i];
	cin>>zl>>xz>>xj>>wj;
	a[xz]+=xj;
	for(int i=1;i<zl;i++)
		xuan+=a[i]*(zl-i);
	for(int i=zl+1;i<=nn;i++)
		kai+=a[i]*(i-zl);
	a[xz]-=xj;
	for(int i=1;i<=nn;i++)
	{
		klk=kai;
		klx=xuan;
		if(i<zl) klx+=wj*(zl-i); 
		if(i>zl) klk+=wj*(i-zl);
		pd=klx-klk;
		if(pd<0) pd*=-1;
		if(pd<zxz) zxz=i;
	}
	cout<<zxz;
	return 0;
}
