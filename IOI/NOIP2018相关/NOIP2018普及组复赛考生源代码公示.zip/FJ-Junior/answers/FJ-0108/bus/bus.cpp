#include<bits/stdc++.h>
using namespace std;
int rs,cs,asd,dsc=0,zxz=4000001,bc;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>rs>>cs;
	int sc[rs+2];
	sc[rs+1]=-1;
	for(int i=1;i<=rs;i++)
	{
		cin>>sc[i];
	}
	sort(sc+1,sc+(rs+1));
	bc=sc[1];
	for(int i=1;i<=rs;i++)
	{
		if(bc>sc[i]&&sc[i]!=sc[i-1])
			dsc+=bc-sc[i];
		if(sc[i]!=sc[i+1])
			bc+=cs;
	}
	cout<<dsc;
	return 0;
}
