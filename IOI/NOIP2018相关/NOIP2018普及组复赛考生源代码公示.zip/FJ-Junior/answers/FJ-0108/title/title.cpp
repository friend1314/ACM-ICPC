#include<bits/stdc++.h>
using namespace std;
string wz;
int ans=0,c=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,wz);
	c=wz.size();
	for(int i=0;i<c;i++)
	{
		if(wz[i]!=' ') ans++;
	}
	cout<<ans;
	return 0;
}
