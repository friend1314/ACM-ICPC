#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,a[501],i,j,k,minn,maxx,ans=0;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	if(m==1)
	{
		cout<<0;
		return 0;
	}
	else if(m==2)
	{
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=n-i;j++)
			{
				if(a[j]>a[j+1])
				{
					swap(a[j],a[j+1]);
				}
			}
		}
		int shuliang[10001];
		int shu[10001];
//		int shuzi[10001];
		shu[minn-1]=0;
		for(int t=minn;t<=maxx;t++)
		{
			shu[t]=0;
			shuliang[t]=0;
			bool frog=true;//
			for(i=1;i<=n;i++)
			{
				if(a[i]==t)
				{
					frog=false;//
					shuliang[t]++;
					a[i]=0;
				}
			}
			if(frog==true)
				continue;
			for(i=t;i<=t+m;i++)
			{
				shu[t]+=shuliang[i];
			}
			if(shu[t]<shu[t-1])
			{
				ans+=shuliang[t];
			}
			if(shu[t]>=shu[t-1])
			{
				if(t!=minn)
				{
					ans+=shuliang[t-1];
				}
			}
		}
		cout<<ans;
		return 0;
	}
	else cout<<5;
	return 0;
}
