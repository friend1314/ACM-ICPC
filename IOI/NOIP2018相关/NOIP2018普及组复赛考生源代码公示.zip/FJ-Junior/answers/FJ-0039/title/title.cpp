#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[101];
	int i,j,k,m,ans=0;
	gets(a);
	m=strlen(a);
	for(i=0;i<=m-1;i++)
	{
		if(a[i]>='0'&&a[i]<='9'||a[i]>='a'&&a[i]<='z'||a[i]>='A'&&a[i]<='Z')
			ans++;
	}
	cout<<ans;
	return 0;
}
