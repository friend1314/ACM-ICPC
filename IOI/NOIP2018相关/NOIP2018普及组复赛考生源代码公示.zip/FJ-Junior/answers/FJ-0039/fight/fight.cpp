#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int ans1=0,ans2=0,min1,min2;
	long long n,i,a[100001],m,p1,s1,s2,b[100001];
	int qi;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(i=1;i<=n;i++)
	{
		b[i]=abs(m-i)*a[i];
	}
	b[p1]=(a[p1]+s1)*abs(m-p1);
	for(i=1;i<=m-1;i++)
	{
		ans1+=b[i];
	}
	for(i=m+1;i<=n;i++)
	{
		ans2+=b[i];
	}
	if(ans1==ans2)
	{
		cout<<m-1;
		return 0;
	}
	else if(ans1>ans2)
	{
		min2=m-1;
		for(i=m+1;i<=n;i++)
		{
			qi=s2*abs(i-m);
			if(i==m+1)
			{
				min1=abs(ans1-ans2-qi);
				min2=i;
			}
			if(abs(ans1-ans2-qi)<min1)
			{
				min1=ans1-ans2-qi;
				min2=i;
			}
		}
	}
	else {
		min2=m+1;
		for(i=1;i<=m-1;i++)
		{
			qi=s2*abs(i-m);
			if(i==1)
			{
				min1=abs(ans2-ans1-qi);
				min2=i;
			}
			if(abs(ans2-ans1-qi)<min1)
			{
				min1=ans2-ans1-qi;
				min2=i;
			}
		}
	}
	cout<<min2;
	return 0;
}
