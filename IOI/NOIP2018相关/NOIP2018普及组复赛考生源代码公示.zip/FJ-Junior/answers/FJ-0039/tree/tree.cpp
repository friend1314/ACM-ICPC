#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,l[101],r[101],i,j,k=1,m,quan[101];
	int quanzhi[101];
	int shuyi=0,shuer=0;
	cin>>n;
	if(n<=10)
	{
		for(i=4;i<=10;i++)
		{
			quanzhi[i]=0;
		}
		for(i=1;i<=n;i++)
		{
			cin>>quan[i];
		}
		quanzhi[1]=quan[1];
		for(i=1;i<=n;i++)
		{
			cin>>l[i]>>r[i];
			if(l[i]==-1)
				shuyi++;
			if(r[i]==-1)
				shuer++;
			if(l[i]!=-1)
			{
				k++;
				quanzhi[k]=quan[l[i]];
			}
			if(r[i]!=-1)
			{
				k++;	
				quanzhi[k]=quan[r[i]];
			}
		}
		if(shuyi!=shuer)
		{
			cout<<1;
			return 0;
		}
		for(i=2;i<=n;i+=2)
		{
			if(quanzhi[i]!=quanzhi[i+1])
			{
				cout<<1;
				return 0;
			}
		}
		cout<<n;
	}
	else cout<<7;
	return 0;
}
