#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
int ans=0;
string s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.length();i++)
		if(s[i]!=' ')
			ans++;
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
