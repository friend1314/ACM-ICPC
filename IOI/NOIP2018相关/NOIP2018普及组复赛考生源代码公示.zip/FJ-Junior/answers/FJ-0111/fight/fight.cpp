#include<iostream>
#include<cstdio>
#include<cmath>
#define R register
using namespace std;
int n,m,x,p1,s1,s2;
long long s,p2;
long long c[100010];
long long pd(long long a)
{
	if(a<1)
		return 1;
	if(a>n)
		return n;
	return a;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(R int i=1;i<=n;i++)
		scanf("%lld",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	if(s2==0)
	{
		printf("1");
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	c[p1]+=s1;
	for(R int i=1;i<=n/2;i++)
	{
		s+=(m-i)*c[i];
		s+=(m-n+i-1)*c[n-i+1];
	}
	if(n%2==1)
		s+=(m-(n+1)/2)*c[(n+1)/2];
	x=2*abs(s-(s/s2*s2));
	if(x<=s2)
		p2=pd(m+s/s2);
	else
		if(s/s2>0)
			p2=pd(m+s/s2+1);
		else
			p2=pd(m+s/s2-1);
	printf("%lld",p2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
