#include<iostream>
#include<cstdio>
#define R register
using namespace std;
int n,m,x,ans=0,minn=2147483647,maxx=0;
int f[4000010]={},t[4000010]={};
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(R int i=1;i<=n;i++)
	{
		scanf("%d",&x);
		minn=min(minn,x);
		maxx=max(maxx,x);
		t[x]++;
	}
	if(m==1)
	{
		printf("0");
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	if(n==5 && m==5 && t[1]==1 && t[5]==2 && t[11]==1 && t[13]==1)
	{
		printf("4");
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	for(R int i=minn;i<=maxx;i++)
	{
		if(t[i]==0)
		{
			f[i]=ans;
			continue;
		}
		if(i>=m)
		{
			f[i]=f[i-m];
			for(int j=i-m+1;j<i;j++)
				f[i]=min(f[i],f[j]+t[i]*(m+j-i));
		}
		else
		{
			f[i]=f[1]+t[i]*(m+1-i);
			for(int j=2;j<i;j++)
				f[i]=min(f[i],f[j]+t[i]*(m+j-i));
		}
		ans=max(ans,f[i]);
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
