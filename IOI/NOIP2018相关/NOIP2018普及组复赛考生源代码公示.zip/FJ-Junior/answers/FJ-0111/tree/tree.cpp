#include<iostream>
#include<cstdio>
#define R register
using namespace std;
int n;
struct aaa
{
	int l_child;
	int r_child;
	int v;
	int maxx;
}tree[1000010]={};
bool same(int a,int b)
{
	return tree[a].v==tree[b].v? 1:0;
}
int pd(int a)
{
	if(tree[a].l_child==-1 && tree[a].r_child==-1)
		return 1;
	if(tree[a].l_child==-1 && tree[a].l_child!=-1)
		return pd(tree[a].r_child);
	if(tree[a].l_child!=-1 && tree[a].r_child==-1)
		return pd(tree[a].l_child);
	if(tree[a].l_child!=-1 && tree[a].l_child!=-1)
	{
		int x=pd(tree[a].l_child),y=pd(tree[a].r_child);
		if(same(tree[a].l_child,tree[a].r_child) && x==y)
		{
			if(tree[tree[a].l_child].l_child==-1 && tree[tree[a].r_child].l_child==-1)
			{
				if(tree[tree[a].l_child].r_child==-1 && tree[tree[a].r_child].r_child==-1)
					return x+y+1;
				if(tree[tree[a].l_child].r_child!=-1 && tree[tree[a].r_child].r_child!=-1 && same(tree[tree[a].l_child].r_child,tree[tree[a].r_child].r_child))
					return x+y+1;
			}
			if(tree[tree[a].l_child].l_child!=-1 && tree[tree[a].r_child].l_child!=-1 && same(tree[tree[a].l_child].l_child,tree[tree[a].r_child].l_child))
			{
				if(tree[tree[a].l_child].r_child==-1 && tree[tree[a].r_child].r_child==-1)
					return x+y+1;
				if(tree[tree[a].l_child].r_child!=-1 && tree[tree[a].r_child].r_child!=-1 && same(tree[tree[a].l_child].r_child,tree[tree[a].r_child].r_child))
					return x+y+1;
			}
		}
		return max(x,y);
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(R int i=1;i<=n;i++)
		scanf("%d",&tree[i].v);
	for(R int i=1;i<=n;i++)
		scanf("%d%d",&tree[i].l_child,&tree[i].r_child);
	printf("%d",pd(1));
	fclose(stdin);
	fclose(stdout);
	return 0;
}
