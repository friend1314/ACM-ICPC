#include<stdio.h>
using namespace std;
#define LL long long
LL n,a[100001],m,p1,s1,s2;
LL sum1=0,sum2=0;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	LL i,min1,ans=m,temp;
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	//��˫�������� 
	a[p1]+=s1;
	for(i=1;i<m;i++)
		sum1+=(m-i)*a[i];
	for(i=m+1;i<=n;i++)
		sum2+=(i-m)*a[i];
	min1=sum1>sum2?sum1-sum2:sum2-sum1;
	
	for(i=1;i<m;i++)
	{
		sum1+=(m-i)*s2;
		temp=sum1>sum2?sum1-sum2:sum2-sum1;
		if(temp<min1)
		{
			min1=temp;
			ans=i;
		}
		sum1-=(m-i)*s2;
	}
	for(i=m+1;i<=n;i++)
	{
		sum2+=(i-m)*s2;
		temp=sum1>sum2?sum1-sum2:sum2-sum1;
		if(temp<min1)
		{
			min1=temp;
			ans=i;
		}
		sum2-=(i-m)*s2;
	}
	printf("%lld\n",ans);
	return 0;
}
