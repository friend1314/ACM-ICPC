#include<stdio.h>
using namespace std;
struct Tree
{
	int x,left_child,right_child;
}a[1000001];
int n;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int i,max1=1,sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		scanf("%d",&a[i].x);
	for(i=1;i<=n;i++)
		scanf("%d%d",&a[i].left_child,&a[i].right_child);
	printf("1\n");
	return 0;
}
