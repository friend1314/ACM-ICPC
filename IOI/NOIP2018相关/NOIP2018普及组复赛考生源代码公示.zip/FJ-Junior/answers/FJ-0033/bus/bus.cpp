#include<stdio.h>
using namespace std;
int n,m,a[501],f[501];
int ton[4000001],top=0;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int i,t,Time;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&t);
		ton[t]++;
	}
	for(i=0;i<=4000000;i++)
		if(ton[i]) a[++top]=i;
	f[1]=0;
	Time=a[1];
	for(i=2;i<=top;i++)
	{
		if(a[i]-Time>m)
		{
			Time=a[i];
			f[i]=f[i-1];
			continue;
		}
		if(a[i]-Time>Time+m-a[i])
		{
			Time+=m;
			f[i]=f[i-1]+ton[a[i]]*(Time-a[i]);
		}
		else
		{
			f[i]=f[i-1]+ton[a[i-1]]*(a[i]-Time);
		}
	}
	printf("%d\n",f[top]);
	return 0;
}
