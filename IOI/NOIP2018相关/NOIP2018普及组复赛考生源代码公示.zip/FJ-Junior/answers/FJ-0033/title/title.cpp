#include<stdio.h>
#include<iostream>
#include<string>
using namespace std;
string s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int i,sum=0,temp;
	getline(cin,s);
	temp=s.length();
	for(i=0;i<temp;i++)
		if(s[i]!=' ') sum++;
	printf("%d\n",sum); 
	return 0;
}
