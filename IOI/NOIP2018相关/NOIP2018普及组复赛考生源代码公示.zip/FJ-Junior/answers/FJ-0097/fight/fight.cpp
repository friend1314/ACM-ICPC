#include <bits/stdc++.h>
using namespace std;
int n;
long long ci[1001];
int f[1001];
long long dra,tig;
int i,j,q;
int m,p1;
long long s1,s2;
int ans;
int main()
{
	freopen ("fight.in","r",stdin);
	freopen ("fight.out","w",stdout);
	scanf ("%d",&n);
	for (i=1;i<=n;i++)
	{
		cin>>ci[i];
	}
	cin>>m>>p1>>s1>>s2;
	for (i=1;i<=n;i++)
	{
		f[i]=i;
	}
	i--;
	for (j=1,dra=0;j<=m-1;j++)
	{
		dra+=abs(f[j]-m)*ci[j];
	}
	for (q=i,tig=0;q>m;q--)
	{
		tig+=(f[q]-m)*ci[q];
	}
	if (p1<m) dra+=(m-p1)*s1;
	if (p1>m) tig+=(p1-m)*s1; 
	if (dra>tig)
	{
		long a;
		a=(dra-tig)/s2;
		ans=m+a;
		if (ans>f[i]) ans=f[i];
	}
	else
	{
		if (dra<tig)
		{
			long a;
			a=(tig-dra)/s2;
			ans=m-a;
			if (ans<1) ans=1;
		}
		else ans=m;
	}
	cout<<ans;
	fclose (stdin);
	fclose (stdout);
	return 0;
}
