#include <bits/stdc++.h>
using namespace std;
int a;
int i;
int ans=0;
int main()
{
	freopen ("title.in","r",stdin);
	freopen ("title.out","w",stdout);
	cin>>a;
	while (1)
	{
		a/=10;
		ans++;
		if (a==0) break;
	}
	cout<<ans;
	fclose (stdin);
	fclose (stdout);
	return 0;
}
