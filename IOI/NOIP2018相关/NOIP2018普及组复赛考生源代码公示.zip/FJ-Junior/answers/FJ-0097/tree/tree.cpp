#include <bits/stdc++.h>
using namezpace std;
int main()
{
	freopen ("tree.in","r",stdin);
	freopen ("tree.out","w",stdout);
	cout<<1;
	flose (stdin);
	flose (stdout);
	return 0;
}
