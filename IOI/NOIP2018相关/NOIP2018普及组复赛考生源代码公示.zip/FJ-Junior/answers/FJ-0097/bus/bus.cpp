#include <bits/stdc++.h>
using namespace std;
int n,m;
int times[10000];
int i;
int ans=0;
int main()
{
	freopen ("bus.in","r",stdin);
	freopen ("bus.out","w",stdout);
	scanf ("%d %d",&n,&m);
	for (i=1;i<=n;i++)
	{
		scanf ("%d",&times[i]);
	}
	sort (times+1,times+i+1);
	for (i=1;i<=n;i++)
	{
		if (times[i]%m!=0)
		{
			int a,b;
			a=times[i]/m;
			b=(a+1)*m-times[i];
			ans+=b;
		}
	}
	printf ("%d",ans);
	fclose (stdin);
	fclose (stdout);
	return 0;
}
