#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string a;
	cin>>a;
	int cntt=0;
	for(int i=0;i<=a.size()-1;i++)
	{
		if(a[i]>='0'&&a[i]<='9'||a[i]>='a'&&a[i]<='z'||a[i]>='A'&&a[i]<='Z'){cntt++;
		}
	}
	cout<<cntt;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
