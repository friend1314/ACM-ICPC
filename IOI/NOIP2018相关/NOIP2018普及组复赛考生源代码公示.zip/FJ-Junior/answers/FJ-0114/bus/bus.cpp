#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int m,n,i,cntt=0,z,j;
	cin>>m>>n;
	int t[m+10];
	for(i=1;i<=m;i++)
	{
		cin>>t[i];
	}
	for(i=1;i<=m-1;i++)
	{
		for(j=i+1;j<=m;j++)
		{
			if(t[i]>t[j]) {z=t[i];t[i]=t[j];t[j]=z;}
		z=1;
	}
	z=1;
	for(i=t[1];i<=t[m];i=i+n)
	{
		for(j=z;j<=m;j++)
		{
			if(t[j]<=i) cntt=cntt+(i-t[j]);z++;j=z;
		}
	}
	}
	cntt=cntt+(i-t[m]);
	cout<<cntt;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
