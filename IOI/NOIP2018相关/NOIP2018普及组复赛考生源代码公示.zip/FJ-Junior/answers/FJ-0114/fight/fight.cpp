#include<iostream>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	unsigned long long m,n,sa,sc,pa,lo=0,hu=0;
	cin>>n;
	unsigned long long c[n+10],i;
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	cin>>m>>pa>>sa>>sc;
	c[pa]=c[pa]+sa;
	for(i=1;i<=m-1;i++)
	{
		lo=lo+c[i]*(m-i);
	}
	for(i=n;i>m;i--)
	{
		hu=hu+c[i]*(i-m);
	}
	if(lo==hu) {cout<<m;return 0;}
	else if(lo<hu){
	for(i=1;i<=m-1;i++)
	{
		if(lo+(m-i)*sc==hu) {cout<<i;return 0;}
    }
    unsigned long long min=10000000000200000;
    for(i=1;i<m;i++)
    {
    	if(lo+(m-i)*sc>hu&&lo+(m-i)*sc-hu<min) min=lo+(m-i)*sc-hu;
    	else if(lo+(m-i)*sc<hu&&hu-lo-(m-i)*sc<min) min=hu-lo-(m-i)*sc;
	}
	for(i=1;i<m;i++)
	{
		if(lo+(m-i)*sc-hu==min||hu-lo-(m-i)*sc==min) {cout<<i;return 0;}
	}
	}
	else {
	for(i=m+1;i<=n;i++)
	{
		if(hu+(i-m)*sc==lo) {cout<<i;return 0;}
	}
	unsigned long long min=10000000000200000;
    for(i=m+1;i<=n;i++)
    {
    	if(lo>hu+(i-m)*sc&&lo-hu-(i-m)*sc<min) min=lo-hu-(i-m)*sc;
    	else if(lo<hu+(i-m)*sc&&hu+(i-m)*sc-lo<min) min=hu+(i-m)*sc-lo;
	}
	for(i=m+1;i<=n;i++)
	{
		if(lo-hu-(i-m)*sc==min||hu+(i-m)*sc-lo==min) {cout<<i;return 0;}
	}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
