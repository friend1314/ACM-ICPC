#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<string>
#include<cstring>
using namespace std;
char s[100];
int main()
{
freopen("title.in","r",stdin);
freopen("title.out","w",stdout);
int len,a;
gets(s);
len=strlen(s);
a=len;
for(int i=1;i<=a;i++)
  {
  	if(s[i]==' ')len--;
  }
	
	cout<<len;
	
	return 0;
	
}
