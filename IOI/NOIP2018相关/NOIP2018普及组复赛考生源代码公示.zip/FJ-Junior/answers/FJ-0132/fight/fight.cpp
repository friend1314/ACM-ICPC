#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
using namespace std;
long long c[10003];
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int i,j,k=0,z,m,x=0,y=0,a;
	long long sml=1000000009,p1,S1,S2,n;
	cin>>n;
	for(i=1; i<=n; i++)cin>>c[i];
	cin>>m>>p1>>S1>>S2;
	while(k!=p1) {
		k++;
	}
	if(k==p1)c[k]+=S1;
	for(i=1; i<m; i++) {
		x+=c[i]*(m-i);
	}
	for(j=m+1; j<=n; j++) {
		y+=c[j]*(j-m);
	}
	if(x>y) {
		z=x-y;
		for(j=m+1; j<=n; j++) {
			if((c[j]+S2)*(j-m)>z)a=(c[j]+S2)*(j-m)-z;
			if((c[j]+S2)*(j-m)<z)a=z-(c[j]+S2)*(j-m);
			if(sml>a)sml=c[j];
			if((c[j]+S2)*(j-m)==z) {
				sml=c[j];
				break;
			}
		}
	}
	if(x<y) {
		z=y-x;
		for(i=1; i<m; i++) {
			if((c[i]+S2)*(m-i)>z)a=(c[i]+S2)*(m-i)-z;
			if((c[i]+S2)*(m-i)<z)a=z-(c[i]+S2)*(m-i);
			if(sml>a)sml=c[i];
			if((c[i]+S2)*(m-i)==z) {
				sml=c[i];
				break;
			}
		}
	}
	if(x==y)sml=m;
	cout<<sml;
	return 0;
}
