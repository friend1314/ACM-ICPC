#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
long long t[1000];
int main()
{freopen("bus.in","r",stdin);
frepoen("bus.out","w",stdout);
int j,s=0,i,m,n;
cin>>n>>m;
for(i=1;i<=n;i++)cin>>t[i];
for(i=1;i<=n;i++)	  
{if(t[i]%m!=0&&t[i]!=1)s+=t[i]%m;
}
	cout<<s;
	
	return 0;
	
}
