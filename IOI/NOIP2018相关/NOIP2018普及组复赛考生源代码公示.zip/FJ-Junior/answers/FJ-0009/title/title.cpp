#include<cstdio>
#include<iostream>
#include<cmath>
#include<string>
#include<cstring>
#include<map>

using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans=0;
	char c;
	int step=0;
	while(c!='\n')
	{
		
		c=getchar();
		if(c!='\n'&&c!=' ')ans++;
		step++;
	//	if(step==5)break;
	}
	cout<<ans<<endl;
	return 0;
}
