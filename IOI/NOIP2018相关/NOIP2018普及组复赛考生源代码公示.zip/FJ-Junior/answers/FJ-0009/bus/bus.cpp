#include<cstdio>
#include<iostream>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<map>
#include<queue>
#include<ctime>
using namespace std;
int n,m;
long long int s[10000];
const int maxn = 2147483647;
int timeans=maxn; 
void dfs(int timelimit,int last,int ans)
{
	//cout<<timelimit<<endl;
	
	if(ans>timeans)return;
	//baosouchuqiji
	if(last-1==n)
	{
		//cout<<1<<endl;
		timeans=min(timeans,ans);
		return;
	}
	//if(ans>timeans)return;
	int poi=ans;int tmp=last;
	while(s[tmp]<=timelimit&&tmp<=n) 
	ans+=timelimit-s[tmp++];
	if(tmp-1==n)
	{
		timeans=min(timeans,ans);
		return;
	}
	
	dfs(timelimit+m,tmp,ans);
	for(int i=last;i<=n;i++)
	if(s[i]>timelimit)
	dfs(s[i],last,poi);
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);

	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	cin>>s[i];
	sort(s+1,s+n+1);
	dfs(s[1],1,0);
	cout<<timeans<<endl;
}
