#include<cstdio>
#include<cstring>
#include<iostream>

#include<map>
#include<cmath>
#include<string>
using namespace std;
long long int s[1000007];
long long int m,p,s1,s2;
long long int dragon,tiger;
long long int charstep;
long long int ans=0;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;cin>>n;
	for(int i=1;i<=n;i++)cin>>s[i];
	cin>>m>>p>>s1>>s2;
	//��ʱm����
	s[p]+=s1;
	for(int i=1;i<m;i++)
		dragon+=s[i]*(m-i);
	for(int i=n;i>m;i--)
		tiger+=s[i]*(i-m);
	//cout<<dragon<<" "<<tiger;
	charstep=abs(tiger-dragon);
	for(int i=1;i<=n;i++)
	{
		if(i==m)continue;
		int tmp=abs(i-m);
		if(i<m)
		{
			dragon+=s2*tmp;
		}
		else if(i>m)
		{
			tiger+=s2*tmp;
		}
		if(charstep>abs(tiger-dragon))
		{
			ans=i;
			charstep=abs(tiger-dragon);
		}
		if(i<m)dragon-=s2*tmp;
		else tiger-=s2*tmp;
	//	s[i]-=s2;
	}
	cout<<ans<<endl;
	return 0;
}
