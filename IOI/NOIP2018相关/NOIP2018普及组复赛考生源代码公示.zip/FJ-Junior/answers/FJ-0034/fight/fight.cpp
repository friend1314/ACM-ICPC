#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#define ll long long 
using namespace std;
ll n,b[1000001],m,p1,p2,s1,s2,l = 0,h = 0,G,Q;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i = 1;i <= n;i++) cin>>b[i];
	cin>>m>>p1>>s1>>s2;
	b[p1] += s1;
	for(int i = m - 1;i > 0;i--) 
		l += b[i] * (m - i);
	for(int i = m + 1;i <= n;i++) 
		h += b[i] * (i - m);
	G = abs(l - h);
	Q = G/s2;
	if(l > h) if(m + Q >= n) cout<<n; else cout<<m + Q;
	else if(h > l) if(Q >= m) cout<<'1'; else cout<<m - Q;
	else cout <<m;
	return 0;
}
