#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#include <string.h>
using namespace std;
int n,m,to[101],f[10000001],num = 0,now,MAXN,tong[10000001];
int all(int i,int j)
{
	int QWQ = 0;
	for(int x = i;i <= j ;i++)
	QWQ += (j - x) * tong[x];
	return QWQ;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(tong,0,sizeof(tong));
	memset(f,1e9,sizeof(f));
	cin>>n>>m;
	now = 0;
	for(int i = 1;i <= n;i++) 
	{
		cin>>to[i];
		MAXN=max(MAXN,to[i]);
		tong[to[i]]++;
	}
	for(int i = 1;i <= m;i++)
	{
		f[i] = all(1,i);
	}
	for(int i = 1;i <= n;i++)
		for(int j = 1;j <= m && j < i;j++) 
		f[i] = min(f[i],f[i - j] + all(i - j - m,i - j));	
	for(int i = 1; i <= m; i++) cout <<f[i]<<" ";
}
