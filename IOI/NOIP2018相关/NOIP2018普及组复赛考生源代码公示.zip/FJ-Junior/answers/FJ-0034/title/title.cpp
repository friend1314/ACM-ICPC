#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[50001];
	int i = 0;
	while(cin>>a[i]){
		i++;
	}
	int l = strlen (a),num = 0;
	for(int i = 1 ;i <= l;i++) if(a [i] == ' ') num++;
	cout<<l - num;
	return 0;	
}
