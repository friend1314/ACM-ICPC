#include<iostream>
#include<cstdio>
#include<algorithm>
#include<map>
#include<cmath>
#include<cstring>
using namespace std;
long long a[100005],n,m,s1,s2,p,i,lon=0,hu=0,max1=9999999999,maxn;
long long jdz(long long a)
{
	return a>0?a:-a;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)cin>>a[i];
	cin>>m>>p>>s1>>s2;a[p]+=s1;
	for(i=1;i<m;i++)
	lon+=(m-i)*a[i];
	for(i=m+1;i<=n;i++)
	hu+=(i-m)*a[i];
	if(lon==hu){
	cout<<m;return 0;}
	if(lon>hu)
	{
		for(i=m+1;i<=n;i++)
		{
			if(jdz((i-m)*s2+hu-lon)<max1)
			{
				max1=jdz((i-m)*s2+hu-lon);
				maxn=i;
			}
		}
	}
	else{
	for(i=1;i<m;i++)
	{
		if(jdz((m-i)*s2+lon-hu)<max1)
		{
			max1=jdz((m-i)*s2+lon-hu);
			maxn=i;
		}
	}}cout<<maxn;
	return 0;
}

