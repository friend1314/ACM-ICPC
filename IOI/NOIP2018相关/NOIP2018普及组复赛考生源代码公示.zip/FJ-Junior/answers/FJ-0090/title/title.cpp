#include<iostream>
#include<cstdio>
#include<algorithm>
#include<map>
#include<cmath>
#include<cstring>
using namespace std;
long long a;
long long ws(long long a)
{
	int i=1;
	while(a/10!=0)
	{
		a/=10;
		i++;
	}
	return i;
}
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin>>a;
	if(ws(a)!=0)
	cout<<ws(a);
	else
	cout<<4;
	return 0;
}

