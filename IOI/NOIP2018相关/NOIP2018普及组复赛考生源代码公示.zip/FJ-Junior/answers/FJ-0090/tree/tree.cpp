#include<iostream>
#include<cstdio>
#include<algorithm>
#include<map>
#include<cmath>
#include<cstring>
using namespace std;
int n;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;cout<<n;
	return 0;
}
