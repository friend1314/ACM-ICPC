#include<iostream>
#include<cstdio>
#include<algorithm>
#include<map>
#include<cmath>
#include<cstring>
using namespace std;
long long a[509],b[509]={},n,t,i,j,k,sum=0,sun=0;
int dp()
{
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		b[j]+=a[i]%t;
	}
	sort(b+1,b+n+1);
	return b[1];
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>t;
	if(t<2){cout<<0;return 0;}
	for(i=1;i<=n;i++)cin>>a[i];
	sort(a+1,a+n+1);
	cout<<dp();
	return 0;
}
