#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
const long long INF=1000000000000000000ll;
int n,c[100005],m,p1,s1,s2,minn;
long long ans1,ans2,Min;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for (int i=1;i<=n;i++)
	{
		if (i<m)ans1+=(long long)(c[i])*(m-i);
		if (i>m)ans2+=(long long)(c[i])*(i-m);
	}
	if (p1<m)ans1+=(long long)(s1)*(m-p1);
	if (p1>m)ans2+=(long long)(s1)*(p1-m);
	Min=INF;
	for (int i=1;i<=n;i++)
	{
		if (i<m)
		{
			long long hh=ans1+(long long)(s2)*(m-i);
			if (abs(hh-ans2)<Min)
			{
				Min=abs(hh-ans2);minn=i;
			}
		}
		else if (i>m)
		{
			long long hh=ans2+(long long)(s2)*(i-m);
			if (abs(hh-ans1)<Min)
			{
				Min=abs(hh-ans1);minn=i;
			}
		}
		else if (i==m)
		{
			if (abs(ans1-ans2)<Min)
			{
				Min=abs(ans1-ans2);minn=i;
			}
		}
	}
	printf("%d\n",minn);
	return 0;
}
