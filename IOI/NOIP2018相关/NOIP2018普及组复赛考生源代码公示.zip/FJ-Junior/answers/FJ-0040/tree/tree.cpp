#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
const int INF=13131331,INFF=9528901;
int n,l[1000002],r[1000002],zjds[1000002],Max,d[1000002];
bool fl[1000002];
unsigned long long f[1000002][3],cm[1000002],cm2[1000002];
void dfs(int x,bool u){
	if (!x)return;
	zjds[x]=1;
	if (!u)
	{
		dfs(l[x],u);f[x][u]=f[l[x]][u]*cm2[zjds[l[x]]];
		f[x][u]=f[x][u]*INF+d[x];
		dfs(r[x],u);f[x][u]=f[x][u]*cm[zjds[r[x]]]+f[r[x]][u];
	}
	else
	{
		dfs(r[x],u);f[x][u]=f[r[x]][u]*cm2[zjds[r[x]]];
		f[x][u]=f[x][u]*INF+d[x];
		dfs(l[x],u);f[x][u]=f[x][u]*cm[zjds[l[x]]]+f[l[x]][u];
	}
	zjds[x]+=zjds[l[x]]+zjds[r[x]];
}
void dfss(int x,bool u){
	if (!x)return;
    if (!u){dfss(l[x],u);dfss(r[x],u);}
    else {dfss(r[x],u);dfss(l[x],u);}
    printf("%d\n",d[x]);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);cm[0]=1;cm2[0]=1;d[0]=1323;
	for (int i=1;i<=n;i++){cm[i]=cm[i-1]*INF;cm2[i]=cm2[i-1]*INFF;}
	for (int i=1;i<=n;i++)scanf("%d",&d[i]);
	for (int i=1;i<=n;i++)
	{
	    scanf("%d%d",&l[i],&r[i]);
	    if (l[i]==-1)l[i]=0;
	    if (r[i]==-1)r[i]=0;
	}
	dfs(1,0);dfs(1,1);
	for (int i=1;i<=n;i++)if (f[l[i]][0]==f[r[i]][1] && zjds[i]>Max)Max=zjds[i];
	printf("%d\n",Max);
	return 0;
}
