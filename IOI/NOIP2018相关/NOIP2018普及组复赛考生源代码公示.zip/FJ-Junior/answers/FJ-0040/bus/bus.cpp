#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
const int INF=1000000000,Max=200000;
int n,m,t[505];
long long f[200005],Min[200005],sum[505],len;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);sum[0]=0;
	for (int i=1;i<=n;i++){scanf("%d",&t[i]);t[i]++;}
	sort(t+1,t+n+1);t[n+1]=INF;
	for (int i=1;i<=n;i++)
	if (t[i]-t[i-1]>2*m)
	{
		int hh=t[i]-t[i-1]-2*m;
		for (int j=i;j<=n;j++)t[j]-=hh;
	}
	for (int i=0;i<=n;i++)
	{
	    Min[i]=1000000000000000000ll;
	    if (i)sum[i]=sum[i-1]+t[i];
	}
	for (int i=0;i<=Max;i++)
	{
		int a1=0,a2=0;f[i]=1000000000000000000ll;
		for (int j=1;j<=n;j++)
		{
		    if (t[j]<=i-m)a1=j;
		    if (t[j]<=i)a2=j;
		}
		if (a1==n)break;
		if (a2==0)
		{
			f[i]=Min[len]=0;
		}
		else
		{
			if (!a1)f[i]=min(f[i],(long long)i*a2-sum[a2]);
			else for (int j=t[a1];j+m<=i;j++)f[i]=min(f[i],f[j]+(long long)i*(a2-a1)-(sum[a2]-sum[a1]));
			for (int j=a1;j>=0;j--)
			if (t[j]!=t[a1])f[i]=min(f[i],Min[j]+(long long)i*(a2-j)-(sum[a2]-sum[j]));
		}
		if (i!=t[len+1])Min[len]=min(Min[len],f[i]);
		else
		{
			while(i==t[len+1])
			{
				len++;Min[len]=min(Min[len],f[i]);
			}
		}
	}
	cout<<Min[n]<<endl;
	return 0;
}
