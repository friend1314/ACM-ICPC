#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
int n;
char s[100];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(scanf("%s",s)==1)n+=strlen(s);
	printf("%d\n",n);
	return 0;
}
