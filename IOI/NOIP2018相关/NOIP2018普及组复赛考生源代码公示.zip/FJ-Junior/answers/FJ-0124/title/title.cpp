#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>

#include<string>
#include<cstring>
#include<string.h>

using namespace std;

int main(){
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    char a[1000];
    int b,i;
    cin.getline(a,1000);
    b=strlen(a);
    for(i=0;i<b;i++){
        if(a[i]==' '){
            b--;
        }
    }
    cout<<b;
    fclose(stdin);
    fclose(stdout);
    return 0;
}
