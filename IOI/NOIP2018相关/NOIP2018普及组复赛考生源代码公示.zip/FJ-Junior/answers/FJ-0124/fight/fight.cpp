#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>

using namespace std;

int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    
    int n,m,p1,p2,s1,s2,zx=99999999;
    int i,t1=0,t2=0;
    cin>>n;
    int a[n];
    for(i=0;i<n;i++)
        cin>>a[i];
    cin>>m>>p1>>s1>>s2;
    a[p1-1]=a[p1-1]+s1;
    
    for(i=0;i<m-2;i++)
        t1=t1+a[i]*(i+1);
    for(i=m;i<n;i++)
        t2=t2+a[i]*(i+1-m);

    
    if(t1<t2){
        for(i=m-2;i>=0;i--){
            if((a[i]*(i+1))<zx)
                p2=a[i];
        }
    }
    if(t1>t2){
        for(i=n-1;i>m;i--){
            if((a[i]*(i+1))<zx)
                p2=a[i];
        }
    }
    if(t1==t2)
        p2=m;
    
    cout<<p2;
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
