#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>

using namespace std;

int main(){
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    
    int n,m,i;
    cin>>n>>m;
    int a[n],d[n],zd=0;
    for(i=0;i<n;i++)
        cin>>a[i];
    
    for(i=0;i<n;i++){
        if(a[i]==m)
            d[i]=1;
        else
            d[i]=a[i]%m-1;
        zd=d[i]+zd;
    }
    
    cout<<zd;
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}
