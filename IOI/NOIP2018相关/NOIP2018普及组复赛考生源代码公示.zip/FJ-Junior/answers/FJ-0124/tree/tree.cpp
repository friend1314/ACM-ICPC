#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>

using namespace std;

int main(){
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    
    int n,i,zd=1000,zz=0,z[10];
    cin>>n;
    int a[n],b[n][2];
    for(i=0;i<n;i++)
        cin>>a[i];
    for(i=0;i<n;i++)
        cin>>b[0][i]>>b[1][i];
    
    for(i=0;i<n;i++){
        if(b[0][i]!=-1&&b[1][i]!=-1){
            z[zz]=a[i];
            zz++;
        }
    }
    for(i=0;i<zz;i++){
        if(z[i]<zd){
            zd=z[i];
        }
    }
    
    cout<<zd;
        
    fclose(stdin);
    fclose(stdout);
    return 0;
}
