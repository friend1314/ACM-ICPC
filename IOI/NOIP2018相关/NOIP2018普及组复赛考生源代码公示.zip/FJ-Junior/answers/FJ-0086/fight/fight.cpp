#include<bits/stdc++.h>
using namespace std;
int c[100001]={0},l=0,h=0,n,m,p1,p2,s2,s1,t=0;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for(int i=1;i<m;i++)l+=c[i]*(m-i);
	for(int i=m+1;i<=n;i++)h+=c[i]*(i-m);
	if(p1<m)l+=s1*(m-p1);if(p1>m)h+=s1*(p1-m);
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			l+=s2*(m-i);
			if(i==1){t=abs(l-h);p2=i;}
			if(abs(l-h)<t){t=abs(l-h);p2=i;}
		}
		if(i==m&&abs(l-h)<t){t=abs(l-h);p2=i;}
		if(i<m)
		{
			h+=s2*(m-i);
			if(abs(l-h)<t){t=abs(l-h);p2=i;}
		}
	}
	printf("%d",p2);
	return 0;
}
