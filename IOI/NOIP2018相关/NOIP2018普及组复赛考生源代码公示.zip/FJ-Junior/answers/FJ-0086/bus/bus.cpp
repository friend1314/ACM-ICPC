#include<bits/stdc++.h>
using namespace std;
int n,m,t[501],ans=0,k=1,s=0,i;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
    for(i=1;i<=n;i++)scanf("%d",&t[i]);
    sort(t+1,t+1+n);i=1;
	while(i<=n)
	{
		if(s==0&&k>=t[i])
		{s=m;while(k>=t[i]&&i<=n)i++;}
		if(s!=0&&s!=m&&k>=t[i])ans++;
		s--;k++;
	}
	printf("%d",ans);
	return 0;
}
