#include<bits/stdc++.h>
using namespace std;
int ans=0;string s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin>>s;for(int i=0;i<=s.size()-1;i++)
		if(s[i]!=32)ans++;
	printf("%d",ans);
	return 0;
}
