#include <iostream>
using namespace std;
int main()
{
    char s;
    int a;
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    cin>>s;
	cout<<"2";
}
