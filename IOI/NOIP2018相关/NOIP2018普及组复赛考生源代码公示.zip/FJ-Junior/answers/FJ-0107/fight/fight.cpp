#include <iostream>
using namespace std;
int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l;
	freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    cin>>a>>b>>c>>d>>e>>f>>g;
	cin>>h>>i>>j>>k;
	if(a+b+c+d+e+f+g<h+i+j+k)

	cout<<"1";

    else 
    cout<<"2";
    return 0;

}
