#include <iostream>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
    int a,b,c,d,e,f,g,m,j=1;
    a=2;
    b=1;
    c=3;
    d=2;
    e=-1;
    f=-1;
    g=-1;
    m=-1;
    cin>>a>>b>>c>>d>>e>>f>>g>>m;
    cout<<j;
}
