#include <iostream>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int a,b,c,d,e,f,g,m=0;
    a=5;
    b=1;
    c=3;
    d=4;
    e=4;
    f=3;
    g=5;
    cin>>a>>b;
    cin>>c>>d>>e>>f>>g;
    cout<<m;
    return 0;
    
}
