#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,li,son,father;
	cin>>n;
	int a,b;
	for(int i=1;i<=n;i++)
	{
		cin>>li;
	}
	int a,b;
	for(int i=0;i<n;i++)
	{
		cin>>a>>b;
		father=i;
		son=a;
		son=b;
	}
	if(n<=10)
	{
		cout<<'1';
	fclose(stdin);fclose(stdout);
	return 0;
	}
	if(n<=100000)
	{
		cout<<n;
	fclose(stdin);fclose(stdout);
	return 0;
	}
}
