#include<bits/stdc++.h>
using namespace std;
int ma[100001]={0};
int ll(int a)
{
	if(a<0)
	a*=-1;
	return a;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,p2,s1,s2,a;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		ma[i]=a;
	}
	long long lon=0,hu=0;
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<m;i++)
	lon+=ma[i]*(m-i);
	for(int i=m+1;i<=n;i++)
	hu+=ma[i]*(i-m);
	if(p1<m)
	lon+=s1*(m-p1);
	else
	hu+=s1*(p1-m);
	if(lon==hu)
	{
		cout<<m;
		fclose(stdin),fclose(stdout);
		return 0;
	}
	if(lon<hu)
	{
		int l=hu-lon;
		p2=l/s2;
		if(ll(lon+p2*s2-hu)>ll(lon+(p2+1)*s2-hu))
		p2++;
		if(m-p2<1)
		{
			cout<<1;
			fclose(stdin),fclose(stdout);
			return 0;
		}
		cout<<m-p2;
		fclose(stdin),fclose(stdout);
		return 0;
	}
	else  //hu<lon
	{
		int l=lon-hu;
		p2=l/s2;
		if(ll(hu+p2*s2-lon)>ll(hu+(p2+1)*s2-lon))
		p2++;
		if(p2+m>n)
		{
			cout<<n;
			fclose(stdin),fclose(stdout);
			return 0;
		}
		cout<<m+p2;
		fclose(stdin),fclose(stdout);
		return 0;
	}
}
