#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,n;
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>a;
	for(int i=0;i<n;i++)
	scanf("%d",&a);
	cout<<'0';
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
