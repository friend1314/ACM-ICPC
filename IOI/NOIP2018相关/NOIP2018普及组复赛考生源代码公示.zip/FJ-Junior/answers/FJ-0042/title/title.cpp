#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans=0;
	string a;
	while((cin>>a)!=0)
	ans+=a.length();
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
}
