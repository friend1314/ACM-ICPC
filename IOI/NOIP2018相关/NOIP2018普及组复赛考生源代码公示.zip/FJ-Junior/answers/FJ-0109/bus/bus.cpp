#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,a(int i),t,s,e=0;
	int a[i]; 
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		t=a[i]+m;
		break;
	}if(t==a[i-1])
	{
		s=0;
		e+=s;
	}
	if(t!=a[i-1])
	{
		s=a[i]-a[i-1];
		e+=s;
	}cout<<e;
	return 0;
} 
