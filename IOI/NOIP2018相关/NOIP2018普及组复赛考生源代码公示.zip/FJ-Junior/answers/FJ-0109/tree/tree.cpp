#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main() 
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,a,b,c;
	char
}
