#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w".stdout);
	int n,s=0;
	char a,e,h;
	cin>>n>>e>>h;
	for(int i=1;i<=n;i++)
	{
		cin>>a; 
		if(a!=e  &&  a!=h)s++;
	}
	cout<<s<<endl;
	return 0;
}
