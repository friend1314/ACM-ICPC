#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
int a[505],f[4000005],dp[400005];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k=0,x;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		f[x]++;
		if(f[x]==1)a[++k]=x;
	}
	sort(a+1,a+k+1);
	int ans=0;
	for(int i=1;i<=k;i++){
		for(int j=a[i]+1;j<a[i]+m;j++){
			if(f[j]>=1){
				ans+=min((j-a[i])*f[a[i]],(m+a[i]-j)*f[j]);
			}
		}
	}
	printf("%d",ans);
	return 0;
}

