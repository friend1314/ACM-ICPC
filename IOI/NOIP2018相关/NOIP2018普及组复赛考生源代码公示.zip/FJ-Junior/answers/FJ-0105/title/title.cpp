#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
char s[15];
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	int d=strlen(s);
	int ans=0;
	for(int i=0;i<d;i++){
		if((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z'))ans++;
	}printf("%d",ans);
	return 0;
}

