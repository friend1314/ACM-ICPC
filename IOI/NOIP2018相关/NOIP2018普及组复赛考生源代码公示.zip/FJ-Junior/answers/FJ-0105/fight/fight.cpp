#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
long long mum[100005];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,m,p1,s1,s2;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&mum[i]);
	}
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	mum[p1]+=s1;
	long long cz=0;
	for(int i=1;i<m;i++){
		if(i+m<=n)cz+=mum[m-i]*i-mum[m+i]*i;
		else if(i+m>n&&m-i<=n)cz+=mum[m-i]*i;
	}
	if(2*m-1<n){
		for(int i=2*m;i<=n;i++){
			cz-=mum[i]*(i-m);
		}
	}
	long long fa=m;
	if(cz==0)printf("%lld",fa);
	else if(cz>0){
		long long minn=cz;
		for(int i=m+1;i<=n;i++){
			long long u=s2*(i-m);
			u=abs(cz-u);
			if(u<minn){ 	
				fa=i;
				minn=u;
			}
		}
		printf("%lld",fa);
	}else if(cz<0){
		long long minn=abs(cz);
		for(int i=1;i<m;i++){
			long long u=s2*(i-m);
			u=abs(cz-u);
			if(u<minn){
				fa=i;
				minn=u;
			}
		}
		printf("%lld",fa);
	}
	return 0;
}

