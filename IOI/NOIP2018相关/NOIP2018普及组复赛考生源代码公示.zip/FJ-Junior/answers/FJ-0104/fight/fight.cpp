#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,a[10010],m,p1,s1,s2,l,h,x,X,minnn=0x7ffffff,mwei;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=n;i++)
	{
		if(i<m)  l+=a[i]*(m-i);
		if(i>m)  h+=a[i]*(i-m);
	}
	if(p1>m)  h+=s1*(p1-m);
	if(p1<m)  l+=s1*(m-p1);
	if(l>h)
	{
		x=l-h;
		for(int i=n;i>m;i--)
		{
			if(s2*(i-m)>x)  X=s2*(i-m)-x;
			else  X=x-s2*(m-i);
			if(X<minnn)
			{
				minnn=X;
				mwei=i;
			}
		}
	}
	if(h>l)
	{
		x=h-l;
		for(int i=1;i<m;i++)
		{
			if(s2*(m-i)>x)  X=s2*(m-i)-x;
			else  X=x-s2*(m-i);
			if(X<minnn)
			{
				minnn=X;
				mwei=i;
			}
		}
	}
	if(l==h)
	mwei=m;
	cout<<mwei<<endl;
	return 0;
}
