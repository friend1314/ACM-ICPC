#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
char a[11];
int k=1;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin>>a;
	while(a[k])
	{
		k++;
	}
	cout<<k<<endl;
	return 0;
}
