#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,a[501];
long long total=0x7ffffff;
void Search(int peo,int t1,int num,int now)
{
	int i=num+1,p=peo;
	while(i<=n)
	{
		if(a[i]==a[num+1])
		{
			i++;
			p++;
			if(i<n+1)
			continue;
/*			if(i==n+1&&a[i-1]==a[num+1])
			{
				i++;
				p++;
			}*/ 
		}
		else break;
		//i++;
	}
	if(peo&&a[i-1]>=now)//�ȴ������ʱ��ĵȴ���ʱ��� 
	{
		t1+=peo*(a[i-1]-now);
	}
	if(a[i-1]<now)//���ʱ�����ȴ��ġ����� 
	{
		t1+=p*(now-a[i-1]);
	}
	if(i-1<n)
	{
		Search(0,t1,i-1,a[i-1]+m);
		Search(p,t1,i-1,a[i-1]);
	}
	if(i-1==n)
	{
		Search(0,t1,i,a[i-1]+m);
	}
	if(num>=n)
	{
		if(t1<total)  total=t1;
	}
	return ;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;
	for(int i=1;i<=n;i++)  cin>>a[i];
	stable_sort(a+1,a+1+n);
	if(m==1)  total=0;
	else
	{		
		Search(0,0,0,0);
	}
	
	cout<<total<<endl;
	return 0;
}
