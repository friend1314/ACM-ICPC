#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int t[4000005];
int main(){
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int n,m;
    int i;
    int ans=0;
    int dd;//�ȴ�ʱ�� 
    cin>>n>>m;
    for(i=1;i<=n;i++){
        cin>>t[i];
    }
    sort(t+1,t+n+1);
    dd=t[1];
    for(i=1;i<=n;i++){
        if(dd<t[i]){
            dd+=m;
        }
        if(t[i]!=t[i-1])ans+=dd-t[i];
    }
    cout<<ans;
    return 0;
}




















