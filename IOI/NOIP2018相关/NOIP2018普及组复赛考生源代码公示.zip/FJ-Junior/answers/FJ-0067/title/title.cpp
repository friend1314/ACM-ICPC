#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
    int i,len;
    int ans=0;
    string a;
    getline(cin,a);
    len=a.size();
    for(i=0;i<len;i++){
        if(a[i]>=48 && a[i]<=58){ans++;}
        if(a[i]>=64 && a[i]<=90){ans++;}
        if(a[i]>=96 && a[i]<=122){ans++;}
    }
    cout<<ans;
    return 0;
}
