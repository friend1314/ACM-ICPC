#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    int i;
    int n;
    int a[100005];
    int m,p1,s1,s2;
    int p2;
    int cha;//��ֵ 
    cin>>n;
    for(i=1;i<=n;i++){
        cin>>a[i];
    }
    cin>>m>>p1>>s1>>s2;
    int left=0,right=0;
    for(i=1;i<m;i++){
        left+=a[i]*(m-i);
    }
    for(i=m+1;i<=n;i++){
        right+=a[i]*(i-m);
    }
    if(p1>m){
        right+=s1*(p1-m);
        if(right>left) {
            cha=(right-left)/s2;
            if(cha>=m) {cout<<"1";return 0;}
            else {cout<<(m-cha);return 0;}
        }
        if(right=left){cout<<m;return 0;} 
    }
    if(p1==m){
        if(right>left) {
            cha=(right-left)/s2;
            if(cha>=m) {cout<<"1";return 0;}
            else {cout<<(m-cha);return 0;}
        }
        if(right=left){cout<<m;return 0;} 
    }
    if(p1<m){
        left+=s1*(m-p1);
        if(right>left) {
            cha=(right-left)/s2;
            if(cha>=m) {cout<<"1";return 0;}
            else {cout<<(m-cha);return 0;}
        }
        if(right=left){cout<<m;return 0;} 
    }
    return 0;
}











