#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
const int maxn=1e5+10;
long long a[maxn];
int main(){
	#ifndef NOFILE
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	#endif
	int n;cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	int m,p1,s1,s2;cin>>m>>p1>>s1>>s2;a[p1]+=s1;
	long long q=0;
	for(int i=1;i<=n;i++)q+=(long long)(m-i)*a[i];
	int p=q/s2;
	if(q%s2>s2/2)p++;
	p=m+p;p=min(p,n);p=max(p,1);
	cout<<p<<endl;
	return 0;
}
