#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int maxn=505;
int n,m;int a[maxn];
#ifdef DEBUG
int pppp=0;
void tabs(){for(int i=1;i<=pppp;i++)cout<<' ';}
#endif
int time(int p,int lasts,int lastt){//send person *p* ~ n to the goal,start after *lasts*
	if(p>n){
		#ifdef DEBUG
		cout<<"end with time="<<lastt<<".\n";
		#endif
		return 0;
	}
	#ifdef DEBUG
	pppp++;
	tabs();cout<<"In p="<<p<<",l="<<lasts<<".\n";
	#endif
	int t=a[p],wtime=0,waitp=1,ba=2100000000;
	while(t<a[p]+m){
		if(t>=lasts){
			#ifdef DEBUG
			tabs();cout<<"try go at "<<t<<".\n";
			#endif
			int pp=p;
			while(pp<=n&&a[pp]<=t)pp++;
			ba=min(ba,wtime+time(pp,t+m,lastt+wtime));
			if(t+m<a[p+1])break;
		}
		while(p+waitp<=n&&a[p+waitp]<=t)waitp++;
		t++;wtime+=waitp;
		if(wtime>ba)break;
		#ifdef DEBUG
		tabs();cout<<"stay to "<<t<<",waiting "<<waitp<<",time "<<wtime<<".\n";
		#endif
	}
	#ifdef DEBUG
	pppp--;
	#endif
	return ba;
}
int main(){
	#ifndef NOFILE
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	#endif
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>a[i];
	sort(a+1,a+n+1);
	cout<<time(1,0,0)<<endl;
	return 0;
}
