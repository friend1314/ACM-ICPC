#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main(){
	#ifndef NOFILE
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	#endif
	char ch;int ans=0;
	while((ch=getchar())!=EOF)if(!isspace(ch))ans++;
	cout<<ans<<endl;
	return 0;
}
