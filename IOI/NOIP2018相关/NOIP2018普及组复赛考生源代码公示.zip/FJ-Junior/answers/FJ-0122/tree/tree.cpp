#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
//main
const int maxn=1000000+10;
int n;
int v[maxn],l[maxn],r[maxn];
int vis[maxn],leafc=0,leaf[maxn];
//findset
int fa[maxn];
int findfa(int p){return fa[p]==p?p:fa[p]=findfa(fa[p]);}
void merge(int pa,int pb){fa[findfa(pa)]=findfa(pb);}
bool checks(int pa,int pb){return (pa<0||pb<0)?(pa<0&&pb<0):(v[pa]==v[pb]&&findfa(pa)==findfa(pb));}
//func
int trsnum[maxn];
int trsize(int p){
	if(p==-1)return 0;
	if(trsnum[p]!=-1)return trsnum[p];
	return trsnum[p]=trsize(l[p])+trsize(r[p])+1;
}
int main(){
	#ifndef NOFILE
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	#endif
	memset(trsnum,-1,sizeof trsnum);
	cin>>n;
	for(int i=1;i<=n;i++){cin>>v[i];fa[i]=i;}
	for(int i=1;i<=n;i++){cin>>l[i]>>r[i];if(l[i]<0&&r[i]<0)leaf[++leafc]=i;}
	memset(vis,0,sizeof vis);
	for(int i=1;i<=n;i++)if(r[i]!=-1)vis[r[i]]=1;
	for(int i=1;i<=n;i++)if(vis[i])swap(l[i],r[i]);
	
	memset(vis,0,sizeof vis);
	for(int i=1;i<=leafc;i++){
		int li=leaf[i];
		if(vis[v[li]])merge(li,vis[v[li]]);
		else vis[v[li]]=li;
	}
	
	int notfind=0,fp=0;
	while(notfind<=n){
		fp=fp%n+1;notfind++;
		//cout<<fp<<' '<<notfind<<'\n';
		if(checks(l[fp],r[fp]))continue;
		if(l[fp]<0||r[fp]<0)continue;
		if(v[l[fp]]==v[r[fp]]&&checks(l[l[fp]],r[r[fp]])&&checks(r[l[fp]],l[r[fp]])){
			merge(l[fp],r[fp]);notfind=0;
		}
	}
	
	int maxsize=1;
	for(int i=1;i<=n;i++)if(checks(l[i],r[i]))maxsize=max(maxsize,trsize(i));
	cout<<maxsize;
	return 0;
}
