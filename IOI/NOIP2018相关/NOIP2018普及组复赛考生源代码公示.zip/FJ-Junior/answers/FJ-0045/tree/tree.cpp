#include<iostream>
#include<string.h>
#include<cstring>
#include<string>
#include<cmath>
#include<cstdio>
#include<windows.h>
#include<time.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout); 
	srand(unsigned(time(NULL)));
	cout<<rand()%5+1;
	fclose(stdin);//�ǵüӰ�������
	fclose(stdout);//�ǵüӰ�������
	return 0;
}
