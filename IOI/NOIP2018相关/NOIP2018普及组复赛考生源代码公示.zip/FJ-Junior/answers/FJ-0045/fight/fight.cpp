#include<iostream>
#include<string.h>
#include<cstring>
#include<string>
#include<cmath>
#include<cstdio>
using namespace std;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout); 
	int n;
	long long m,p1,s1,s2,disl,dish,totl=0,toth=0,md,dd,ds;
	long long gb[100001];
	int tianjiang;//0����1����2������  
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>gb[i];
	cin>>m>>p1>>s1>>s2;
	//disl=m-1;
	//dish=n-disl-1;
	//if(p1<disl) tianjiang=0;
	//if(p1>m)    tianjiang=1;
	//if(p1==m)   tianjiang=2;
	for(int i=1;i<=m-1;i++)
	{
		if(p1==i) gb[i]+=s1;
		md=gb[i]*(m-i);
		totl+=md;
		//cout<<gb[i]<<" ";//
	}
	//cout<<gb[m]<<" ";//
	for(int i=m+1;i<=n;i++)
	{
		if(p1==i) gb[i]+=s1;
		md=gb[i]*(i-m);
		toth+=md;
		//cout<<gb[i]<<" ";//
	}
	//cout<<endl;//
	//cout<<totl<<" "<<toth;//
	if(totl==toth) cout<<0<<endl;
	else
	{
		/*if(totl>toth)
		{
			dd=totl-toth;
			ds=dd/s2;
			cout<<
		}*/
			dd=toth-totl;
			ds=dd/s2;
			if(dd%s2!=0) cout<<m-ds+1<<endl;
			else cout<<m-ds<<endl;
		
	}
	fclose(stdin);//�ǵüӰ�������
	fclose(stdout);//�ǵüӰ�������
	return 0;
}
/*
6
2 3 2 3 2 3
4 6 5 2
*/
