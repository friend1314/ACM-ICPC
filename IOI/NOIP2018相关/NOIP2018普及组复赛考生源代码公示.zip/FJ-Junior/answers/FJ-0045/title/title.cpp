#include<iostream>
#include<string.h>
#include<cstring>
#include<string>
#include<cmath>
#include<cstdio>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout); 
	char s[6];
	int total=0,i=0;
	cin.getline(s,6);
	for(i=0;i<=strlen(s);i++)
	{
		if((s[i]>='0')&&(s[i]<='z'))
			total++;
	}
	cout<<total<<endl;
	fclose(stdin);//�ǵüӰ�������
	fclose(stdout);//�ǵüӰ�������
	return 0;
}
