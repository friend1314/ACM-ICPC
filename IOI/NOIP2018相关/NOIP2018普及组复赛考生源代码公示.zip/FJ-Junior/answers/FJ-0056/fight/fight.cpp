#include<bits/stdc++.h>
using namespace std;
int a[100001];
int b[1001];
int c[1001];
int n;
int m,p1,s1,s2;
int l=0;
int h=0;
int p2;
int zj;
int ll,hh;
int he;
int main()
{
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout); 
    cin>>n;
    for(int i=1;i<=n;i++){cin>>a[i];}
    cin>>m>>p1>>s1>>s2;
    int lj=m-1;
    zj=1;
    while(lj!=0)
    {
        l=l+a[lj]*zj;
        lj--;
        zj++;
    }
    int hj=m+1;
    zj=1;
    while(hj!=n+1)
    {
        h=h+a[hj]*zj;
        hj++;
        zj++;
    }
    if(p1<m)
    {
        l=l+s1*(m-p1); 
    }
    if(p1>m)
    {
        h=h+s1*(p1-m); 
    }
    //�ж�һ��˫����� 
    if(l==h)
    {
        cout<<m;
        return 0;
    }
    //cout<<l<<" "<<h<<endl;
    //�ж϶��������ڻ� 
    if(l>h)
    {
        he=l-h;
        hh=1;
        while(hh<=n)
        {
            b[hh]=hh*s2;
            if(b[hh]>he)c[hh]=b[hh]-he;
            if(b[hh]<he)c[hh]=he-b[hh];
            if(b[hh]==he){cout<<hh+m<<endl;return 0;}//���� 
            hh++;
        }
        int hh1=c[1];
        for(int i=1;i<=hh;i++)
        {
            if(c[i]<hh1)hh1=c[i];
        }
        for(int i=1;i<=hh;i++)
        {
            if(c[i]==hh1)
            {
                if(i>m){cout<<i-m<<endl;return 0;}
                else
                cout<<i<<endl;
                return 0;
            }
        }
        cout<<he;
        return 0;
    }
    //�ж������������� 
    if(l<h)
    {
        he=h-l;
        ll=1;
        while(ll<=m-1)
        {
            b[ll]=ll*s2;
            if(b[ll]>he)c[ll]=b[ll]-he;
            if(b[ll]<he)c[ll]=he-b[ll];
            if(b[ll]==he){cout<<ll<<endl;return 0;}//���� 
            ll++;
        }
        int ll1=c[1];
        for(int i=1;i<=ll;i++)
        {
            if(c[i]<ll1)ll1=c[i];
        }
        for(int i=1;i<=ll;i++)
        {
            if(c[i]==ll1)
            {
                if(i>m){cout<<i-m<<endl;return 0;}
                else
                cout<<i<<endl;
                return 0;
            }
        }
        cout<<he;
        return 0;
    }
    
    return 0;
}
/*
6
2 3 2 3 2 3
4 6 5 2
*/
/*
6
1 1 1 1 1 16
5 4 1 1
*/
