#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("title.in","r",stdin);
    freopen("title.out","w",stdout); 
    string a;
    int x;
    getline(cin,a);
    x=a.size();
    int sum=0;
    for(int i=0;i<x;i++)
    {
        if(a[i]>='a'&&a[i]<='z')
            sum++;
        if(a[i]>='A'&&a[i]<='Z')
            sum++;
        if(a[i]>='0'&&a[i]<='9')
            sum++;
    }
    cout<<sum<<endl;
    return 0;
}
