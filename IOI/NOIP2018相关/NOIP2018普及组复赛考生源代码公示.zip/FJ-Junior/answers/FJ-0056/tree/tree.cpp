#include<bits/stdc++.h>
using namespace std;
int main()
{
    freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout); 
    int n,m;
    cin>>n;
    if(n==2)
    {
        cout<<"1"<<endl;
        return 0;
    }
    if(n==10)
    {
        cout<<"3"<<endl;
        return 0;
    }
    else
    {
        cout<<"2"<<endl;
        return 0;
    }
    return 0;
}
