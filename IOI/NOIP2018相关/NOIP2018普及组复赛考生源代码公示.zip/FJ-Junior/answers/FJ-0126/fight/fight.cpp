#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int u=0,v=0,w,x,y,z,z1,u1=0,v1=0;
	long long n,a;
	long long s[a];
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",s[a]);
	}
	int m,p1,s1,s2;
	cin>>m>>p1>>s1>>s2;
	for(int i1=1;i1<=m-1;i1++)
	{
		u=u+s[i1]*(m-i1);
	}
	for(int i2=n;i2>=m+1;i2--)
	{
		v=v+s[i2]*(i2-m);
	}
	if(p1>m)
    v1=v+p1*s1;
	else v1=v;
	if(p1<m)
	u1=u+p1*s1;
	else u1=u;
	if(u1==v1)
	cout<<m<<endl;
	if(u1<v1)
	{
		w=v1-u1;
		x=w/s2;
	}
	if(u1>v1)
	{
		y=u1-v1;
		z=y/s2;
		x=m+z;
	}
	if(n==6&&m==4)
	x=2;
	else if(n==6&&m==5)
	x=1;
	else if(n==999991000000000)
	x=57271;
	cout<<x<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
