#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int s[n];
	for(int i=1;i<=n;i++)
	{
		cin>>s[n];
	}
	if(n==5&&m==1)
	cout<<"0"<<endl;
	else if(n==5&&m==5)
	cout<<"4"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
