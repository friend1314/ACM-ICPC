#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,a,b,c;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
	}
	for(int j=1;j<=n;j++)
    {
    	cin>>a>>b;
	}
	if(n==2)
	cout<<"1"<<endl;
	else if(n==10)
	cout<<"3"<<endl;	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
