#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	cin>>s;
	int a,x=1;
	a=s.length();
	for(int i=1;i<=a;i++)
	{
		if(s[i]<='z'&&s[i]>='a'||s[i]<='Z'&&s[i]>='A'||s[i]<='9'&&s[i]>='0')
		x++;
	}
	cout<<x<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
