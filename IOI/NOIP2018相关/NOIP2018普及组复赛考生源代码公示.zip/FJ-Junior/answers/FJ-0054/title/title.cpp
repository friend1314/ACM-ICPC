#include<bits/stdc++.h>
using namespace std;
char s[10086];
int num=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	for(int i=0;i<=strlen(s);i++)
	{	
		if(s[i]>='a'&&s[i]<='z')num++;
		if(s[i]>='A'&&s[i]<='Z')num++;
		if(s[i]>='0'&&s[i]<='9')num++;
	}
	cout<<num;
	return 0;
}
