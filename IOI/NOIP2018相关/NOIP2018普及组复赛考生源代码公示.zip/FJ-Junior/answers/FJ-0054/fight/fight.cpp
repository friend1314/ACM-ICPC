#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,a[10086],m, p1, s1, s2,x,y;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	cout<<"1"<<endl;
	return 0;
}
