#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.in","w",stdout);
	int a;
	int b[10];
	int c[10][2];
	cin>>a;
	for(int i=1;i<=a;i++)cin>>b[i];
	for(int i=1;i<=a;i++)cin>>c[i][0]>>c[i][1];
	cout<<7;
	return 0;
}
