#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans,b[5]={0};
	int ansx=0;
	char s[5];
	gets(s);
	ans=strlen(s);
	for(int i=0;i<ans;i++)
	{
		if(s[i]==32)
		b[i]=1;
	}
	for(int i=0;i<ans;i++)
	{
		if(b[i]!=1)
		ansx++;
	}
	cout<<ansx;
	return 0;
}
