#include<iostream>
#include<cstdio>
using namespace std;
int j=1;
int n,m,p1,s1,s2,ti=0,dr=0,p2,t;
int by[101];
int a,b,c;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(a=1;a<=n;a++)
	{
		cin>>by[a];
	}
	cin>>m>>p1>>s1>>s2;
	by[m]=0;
	by[p1]+=s1;
	for(b=m-1;b>=1;b--)
	{
		dr+=by[b]*j;
		j++;
	}
	j=1;
	for(c=m+1;c<=n;c++)
	{
		ti+=by[c]*j;
		j++;
	}
	
	if(dr>ti)
	{
		if(s2>dr-ti)
		{cout<<m;return 0;}
		t=(dr-ti)/s2;
		p2=m-t;
		if(p2>n)p2=n;
	}
	if(ti>dr)
	{
		if(s2>ti-dr)
		{cout<<m;return 0;}
		t=(ti-dr)/s2;
		p2=m-t;
		if(p2<1)p2=1;
	}
	cout<<p2;
	return 0;
}
