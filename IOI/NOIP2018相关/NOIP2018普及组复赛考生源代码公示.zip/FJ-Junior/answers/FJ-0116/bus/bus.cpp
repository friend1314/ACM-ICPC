#include<iostream>
#include<cstdio>
using namespace std;
int n,m,a[21],b[101]={0};
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int x=0,y=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		b[a[i]]++;
    }
    if(m==1){cout<<0;return 0;}
    for(int i=1;i<=100;i++)
    {
    	if(b[i]!=0)
    	{
    		if(i%2!=0)
    		x+=b[i];
    	}
    }
    for(int i=1;i<=100;i++)
    {
    	if(b[i]!=0)
    	{
    		if(i%2==0)
    		y+=b[i];
    	}
    }
    if(x>y)cout<<y;
    if(x<=y)cout<<x;
	return 0;
}
