#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long n,a[100000],m,p1,p2,s2,s1,tot1,tot2,sum,r,lol;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	scanf("%lld",&a[i]);
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			tot1+=a[i]*(m-i);
		}
		if(i>m)
		{
			tot2+=a[i]*(i-m);
		}
	}	
	if(p1>m)tot2+=s1*(p1-m);
	if(p1<m)tot1+=s1*(m-p1);
	if(tot1>tot2)r=1;
	else r=2;
	if(r==1)
	sum=tot1-tot2;
	else 
	sum=tot2-tot1;
	//cout<<sum/s2;
	if(r==1)
	{
		long long x=s2*lol;
		long long y=s2*(lol+1);
		//cout<<x<<" "<<y;
		if(abs(sum-x)<=abs(sum-y))p2=x;
		else p2=y;
	}
	if(r==2)
	{
		long long x=s2*lol;
		long long y=s2*(lol+1);
		if(abs(sum-x)<abs(sum-y))p2=x;
		else p2=y;
	}
	printf("%lld",p2);
	return 0;
	fclose(stdin);
	fclose(stdout);
	//printf("%lld %lld %lld",tot1,tot2,sum);
}
