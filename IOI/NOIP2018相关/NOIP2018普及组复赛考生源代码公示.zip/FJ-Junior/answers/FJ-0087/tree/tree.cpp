#include<iostream>
#include<cstdio>
#include<ctime>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	srand((int)time(NULL));
	int n,l,r,x;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>x;
	for(int i=1;i<=n;i++)
	cin>>l>>r;
	cout<<rand();
	fclose(stdin);
	fclose(stdout);
}
