#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char s[1000];
int tot;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	int q=strlen(s);
	for(int i=0;i<q;i++)
	{
		if(s[i]!=' ')tot++;
	}
	cout<<tot<<endl;
	return 0;
	fclose(stdin);
	fclose(stdout);
}
