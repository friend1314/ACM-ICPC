#include<iostream>
#include<cstdio>
using namespace std;
int n,a[40000],x,minx=999999,maxx=-1,m,tot,time;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		a[x]++;
		minx=min(x,minx);
		maxx=max(x,maxx);
	}
	if(m==1)
	{
		cout<<"0"<<endl;
		return 0;
	}
	int i;
	tot=0;
	time=0;
	i=minx;
	while(i<=maxx)
	{
		x=i;
		while(x<=maxx&&a[x]==0)x++;
		if(i+m<=x)
		{
		   i=x;
		   continue;
		}
		else
		{
			if(a[i]>a[x])
			time+=a[i];
			else time+=a[x];
			i=x;
		}
	}
}
