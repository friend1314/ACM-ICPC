#include <iostream>
#include <bits/stdc++.h>
using namespace std;
string s;
int ans=0;
int main() {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin>>s;
	for(int i=1; i<=sizeof(s); i++) {
		if(s==" "||s=="\n") {
			ans-=1;
		}
		if(s!=" "||s=="\n") {
			ans++;
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
