#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int t[40000001];
int n,m;
int num;
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0; i<n; i++) {
		scanf("%d",&t[i]);
	}
	sort(t,t+n);
	for(int i=0; i<n; i++) {
		if(t[i]<=n) {
			printf("%d",0);
			break;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
