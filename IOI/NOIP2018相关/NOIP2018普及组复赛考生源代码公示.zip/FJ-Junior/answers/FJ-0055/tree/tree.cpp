#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int v[10001],l[10001],r[10001];
int n;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=0; i<n; i++) {
		scanf("%d",&v[i]);
	}
	for(int i=0; i<n; i++) {
		scanf("%d",&l[i]);
	}
	for(int i=0; i<n; i++) {
		scanf("%d",&r[i]);
	}
	for(int i=0; i<n; i++) {
		if(l[i]==-1&&r[i]==-1) {
			printf("-%d",1);
			break;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
