#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int c[100001],m,p1,s1,s2;
int l,mid,r,v;
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=0; i<n; i++) {
		scanf("%d",c[i]);
	}
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	while(r>l) {
		mid=(r+l)/2;
		if(s2=mid) {
			cout<<mid;
			return 0;
		} else if(s2>m) {
			l=m+1;
		} else
			r=m-1;
	}
	printf("%d",m/2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
