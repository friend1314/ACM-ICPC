#include <iostream>
#include <string>
#include <cstdio>

using namespace std;

int r=0,big_c=0,c=0;
string s;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	getline(cin,s);
	
	for(int i=0;i<s.length();i++)
	{
		if(s[i]>='a'&&s[i]<='z')
		{
			c++;
		}
		else if(s[i]>='A'&&s[i]<='Z')
		{
			big_c++;
		}
		else if(s[i]>='0'&&s[i]<='9')
		{
			r++;
		}
	}
	cout<<c+big_c+r;
	return 0;
}
