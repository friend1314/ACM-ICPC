#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

int n,m;
int time=0;
int t_stu[4000010];

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	std::cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		std::cin>>t_stu[i];
	}
	for(int i=1;i<=n-1;i++)
	{
		for(int j=1;j<=n-i;j++)
		{
			if(t_stu[j]>t_stu[j+1])
			{
				swap(t_stu[j],t_stu[j+1]); 
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(t_stu[i]==t_stu[i+1]||t_stu[i+1]-t_stu[i]==m||t_stu[i+1]-t_stu[i-1]<=m)
		{
			time+=0;
		}
		else
		{
			time+=(t_stu[i+1]-t_stu[i]+m);
		}
	}
	cout<<time;
	return 0;
}
