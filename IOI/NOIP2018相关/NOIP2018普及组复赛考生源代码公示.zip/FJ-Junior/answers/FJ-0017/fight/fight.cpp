#include <iostream>
#include <cstdio>
using namespace std;
unsigned long int n;
unsigned long int product_of_army[10010];
unsigned long int m,p1,s1,s2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
    std::cin>>n;
    for(int i=1;i<=n;i++)
    {
    	std::cin>>product_of_army[i];
	}
	std::cin>>m>>p1>>s1>>s2;
	std::cout<<"2";
	return 0;
}
