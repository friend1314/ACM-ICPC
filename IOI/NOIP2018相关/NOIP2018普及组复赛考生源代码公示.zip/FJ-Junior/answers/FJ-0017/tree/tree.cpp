#include <iostream>
#include <cstdio>
#include <cmath>
#include <cmath>
#include <algorithm>

using namespace std;

int n;
int lanmen[10010010];
int lanmen_2[20020020];

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	std::cin>>n;
	for(int i=1;i<=n;i++)
	{
		std::cin>>lanmen[i];
		std::cin>>lanmen_2[i];
	}
	cout<<"1";
	return 0;
}
