#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,a[10000000];
	cin>>n;
	for(int i=0;i<n*3;i++)
	cin>>a[i];
	cout<<'1';
	return 0;
}
