#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	int n,m;
	int t[4000000];
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++)
	scanf("%d",&t[i]);
	if(m==1) {cout<<"0"; return 0;}
	return 0;
}
