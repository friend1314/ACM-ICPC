#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	string a;
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int i=0;
	int ans=0;
	cin>>a;
	while(a[i]!='\0')
	{
		if(a[i]==' ')
		{
		i++;
		continue;
		}
		ans++;i++;
	}
	cout<<ans;
	return 0;
}
