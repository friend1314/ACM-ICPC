#include<iostream>
#include<cstdio>

using namespace std;
int c[100000],f[100000];
int main()
{
	freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
	int n,m,p1,p2,s1,s2,i,f1=0,f2=0,low;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	
	for(i=1;i<=m-1;i++)
	{
		f1=f1+c[i]*(m-i);
	}
	for(i=m+1;i<=n;i++)
	{
		f2=f2+c[i]*(i-m);
	}
	if(p1<m) f1=f1+(m-p1)*s1;
	else if(p1>m)  f2=f2+(p1-m)*s1;
	if(f1==f2)
	{cout<<m;
	return 0;}
	else if(f1<f2)
	{for(i=1;i<m;i++)
	f[i]=f1+(m-i)*s2;
	low=f2-f1;}
	else
	{for(i=m+1;i<=n;i++)
	f[i]=f2+(i-m)*s2;
	low=f1-f2;
	}
	if(f1<f2)
	{
		for(i=1;i<m;i++)
		{if(f[i]==f2) {cout<<i;return 0;}
		else if(f[i]>f2) {if(f[i]-f2<low) low=f[i]-f2;}
		else{if(f2-f[i]<low) low=f2=-f[i];}
		}
	}
	else if(f2<f1)
	{
		for(i=m+1;i<=n;i++)
		{if(f[i]==f1) {cout<<i;return 0;}
		else if(f[i]>f1) {if(f[i]-f1<low) low=f[i]-f1;}
		else{if(f1-f[i]<low) low=f1=-f[i];}
		}
	}
	if(f1<f2)
	for(i=1;i<m;i++)
	{
		if(f[i]-f1==low||f1-f[i]==low)
		{
			cout<<i;
			return 0;
		}
	}
	else if(f2<f1)
	for(i=m+1;i<=n;i++)
	{
		if(f[i]-f2==low||f2-f[i]==low)
		{
			cout<<i;
			return 0;
		}
	}
	return 0;
}
