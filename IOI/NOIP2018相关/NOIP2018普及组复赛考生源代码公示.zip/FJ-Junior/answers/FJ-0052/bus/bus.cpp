#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int main()
{
   freopen("bus.in","r",stdin);
   freopen("bus.out","w",stdout);
   int n,m,b=2,l=0;
   scanf("%d%d",&n,&m);
   l=m;
   int a[n];
   for(int i=0;i<n;i++)
   scanf("%d",&a[i]);
   sort(a,a+n);

           printf("%d",b);
           fclose(stdin);
           fclose(stdout);
           return 0;
}
