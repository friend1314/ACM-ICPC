#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int main()
{
   freopen("title.in","r",stdin);
   freopen("title.out","w",stdout);
   string a;
   int b,c=0;
   getline(cin,a);
   b=a.length();
   for(int i=0;i<b;i++){
       if(a[i]!=' '&&a[i]!='/n'&&a[i]!='/0')
       c++;
   }
   printf("%d",c);
   fclose(stdin);
   fclose(stdout);
   return 0;
}
