#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int main()
{
    freopen("fight.in","r",stdin);
   freopen("fight.out","w",stdout);
   
   int n;
   int l,k,o;
   int m,p1,s1,s2,p2;
   scanf("%d",&n);
   int a[n+1];
   for(int i=1;i<=n;i++)
   scanf("%d",&a[i]);
   scanf("%d %d %d %d",&m,&p1,&s1,&s2);
    a[p1]=a[p1]+s1;
    for(int i=1;i<=n;i++){
        if(i<m){
        a[i]=a[i]*(m-i);
        l=l+a[i];
    }
        if(i>m)
        {
        a[i]=a[i]*(i-m);
        k=k+a[i];
    }
    }
    if(l=k)
    p2=m;
    if(l>k){
    for(int i=1;;i++){
        o=m+i;
        k=k+(a[o]+s2)*(o-m)-a[o]*(o-m);
        if(k=l){
        p2=o;
        break;
    }
        else
        if(k>l){
        p2=o;
        break;
    }
    }
}
    if(k>l){
    for(int i=1;;i++){
        o=m-i;
        l=l+(a[o]+s2)*(m-o)-a[o]*(m-o);
        if(k==l){
        p2=o;
        break;
    }    
        else
        if(l>k){
        p2=o;
        break;
    }
    }
}
    printf("%d",p2);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
