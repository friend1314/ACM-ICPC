#include<iostream>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
long n,m,s1,s2,p1;
long a[100001];
int ans;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	int dar=0,tri=0;
	for(int i=1;i<=n;i++)
	{
		if(i==m)
		continue;
		if(i<m)
		{
			dar+=(long long)(m-i)*(long long)a[i];
			continue;
		}
		if(i>m)
			tri+=(long long)(i-m)*(long long)a[i];
	}
	long long min=1000000000;
	for(int i=1;i<=n;i++)
	{
		long long mm=tri+(long long)(i-m)*(long long)s2;
		if(min>abs(mm-dar))
		{
			min=abs(mm-dar);
			ans=i;
		}
	}
	cout<<ans;
	return 0;
}
