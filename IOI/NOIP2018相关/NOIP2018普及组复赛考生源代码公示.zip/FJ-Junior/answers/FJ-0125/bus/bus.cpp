#include<iostream>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
int n,m;
int t[501];
int ans=0,time;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	time=t[1];
	for(int k=1;k<=n;k++)
	{
		int mm=time-t[k];
		if(mm>0)
			ans+=mm;
		if(t[k]==t[k+1]&&time>=t[k])
		{
			if(mm>0)
				ans-=mm;
			continue;
		}
		time+=m;
	}
	cout<<ans;
	return 0;
}
