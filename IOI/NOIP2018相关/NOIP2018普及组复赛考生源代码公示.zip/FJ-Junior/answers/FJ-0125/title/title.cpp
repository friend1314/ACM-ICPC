#include<iostream>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans;
	char a[5];
	gets(a);
	for(int i=0;i<5;i++)
		if(a[i]<='9'&&a[i]>='0'||a[i]<='z'&&a[i]>='a'||a[i]<='Z'&&a[i]>='A')
			ans++;
	cout<<ans<<endl;
	return 0;
}
