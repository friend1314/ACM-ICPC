#include<iostream>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
struct noed
{
	int sum;
	int left;
	int right;
	int father;
}a[100001];
int bm[1001]={0};
int am=1;
int b[10001];
int lm=0;
int ans=1;
void mp(int k)
{
	if(a[k].left==-1&&a[k].right==-1)
	{ 
		lm-=1;
		return;
	} 
	if(a[k].left!=-1)
	b[lm]=a[a[k].left].sum;
	if(a[k].right!=-1)
	{lm++;
	b[lm]=a[a[k].right].sum;
	}
	if(a[k].left!=-1)
	{
		++lm;
		mp(a[k].left);
		bm[am]++;
	}
	if(a[k].right!=-1)
	{
		++lm;
		mp(a[k].right);
		bm[am]++;
	}
	am++;
	return;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i].sum);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&a[i].left,&a[i].right);
		a[a[i].left].father=i;
		a[a[i].right].father=i;
	}
	b[0]=a[1].sum;
	mp(1);
	int mn=1;
	int mv=0;
	for(int i=1;i<=am;i++)
	{
		bool bn=true;
		mv+=bm[i];
		int x=1+mv,y=mv+bm[i];
		while(x<y)
		{
			if(b[x]!=b[y])
				bn=false;
				x++;
				y--;
		}
		if(bn==true)
		mn++;
	}
	ans=max(mn,ans);
	cout<<ans;
	return 0;
}
