#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
using namespace std;

int n,m;
long long p1,s1,s2;
long long c[100005];
long long dr,ti;
long long dif=999999999999999;
int ans;
long long t;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout); 
	cin>>n;
	for(int i=1; i<=n; i++) cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	
	for(int i=1; i<m; i++) dr+=c[i]*(m-i);
	for(int i=m+1; i<=n; i++) ti+=c[i]*(i-m);
	
	if(p1<m) dr+=s1*(m-p1);
	if(p1>m) ti+=s1*(p1-m);
	
	for(int i=1; i<=m; i++) 
	{
		t=abs(dr+s2*(m-i)-ti);
	    if(t<dif) dif=t,ans=i;
    }
    for(int i=m+1; i<=n; i++) 
	{
		t=abs(ti+s2*(i-m)-dr);
	    if(t<dif) dif=t,ans=i;
    }
    
    cout<<ans;
	return 0;
}


