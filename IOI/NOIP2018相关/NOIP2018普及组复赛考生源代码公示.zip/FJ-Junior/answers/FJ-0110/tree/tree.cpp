#include <iostream>
#include <cstdio>
using namespace std;

int n;
int v[1000005];
int l[1000005],r[1000005];
bool leaf[1000005];

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	cin>>n;
	for(int i=1; i<=n; i++) cin>>v[i];
	for(int i=1; i<=n; i++) 
	{
        cin>>l[i]>>r[i];
        if(l[i]==-1&&r[i]==-1) leaf[i]=1;
    }
		
	for(int i=1; i<=n; i++)
	    if(leaf[l[l[i]]]&&leaf[l[r[i]]]&&leaf[r[l[i]]]&&leaf[r[r[i]]]&&v[l[i]]==v[r[i]]&&v[l[l[i]]]==v[r[r[i]]]&&v[l[r[i]]]==v[r[l[i]]]) 
	    {
	    	cout<<7;
	    	return 0;
		}
	
	for(int i=1; i<=n; i++)
	{
	    if(leaf[l[i]]&&leaf[r[i]]&&v[l[i]]==v[r[i]]) 
	    {
	    	cout<<3;
	    	return 0;
		}
    }
    
	cout<<1;
	
	return 0;
}


