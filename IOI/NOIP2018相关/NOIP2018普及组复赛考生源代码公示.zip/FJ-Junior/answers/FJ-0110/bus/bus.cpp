#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
using namespace std;
int n,m,t[505],ans=2000000000;

void dfs(int curt, int wait, int person)
{	
	if(wait>=ans) return;
	if(curt>=t[n]) 
	{
	    ans=wait; 
		return;
	}
	
	int tot=0,k=0;
	for(int i=1; i<=n; i++) 
	{
	    if(t[i]>=curt+m) break;
	    if(t[i]>curt) tot+=curt+m-t[i],k++;
	}
	dfs(curt+m,wait+tot,k);
	
	bool flag=0;
	for(int i=1; i<=n; i++) if(t[i]==curt) flag=1;
	if(flag) dfs(curt+1,wait+person+1,person+1);
	else dfs(curt+1,wait+person,person);
}

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=n; i++) cin>>t[i];
	sort(t+1,t+1+n);
	dfs(t[1],0,1);
	cout<<ans;
	return 0;
}
