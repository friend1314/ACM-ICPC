#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <algorithm>
using namespace std;
char a[50];
int n;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	for(int i=0; i<strlen(a); i++) if(!isspace(a[i])) n++;
	cout<<n;
	return 0;
}
