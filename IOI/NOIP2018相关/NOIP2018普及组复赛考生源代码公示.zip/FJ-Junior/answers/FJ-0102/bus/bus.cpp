#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

int n,m;
int t[510];
long long s=0;

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	int i,j,h;
	for(i=1;i<=n;i++){
		cin>>t[i];
	}
	
	sort(t,t+n);
	
	/*for(i=1;i<=n;i++)
	  cout<<t[i]<<" ";*/
	  
	cout<<"0";
		 
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
