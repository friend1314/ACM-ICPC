#include<iostream>
#include<cstdio>
using namespace std;

int n;
int v[1000010];
int l[1000010],r[1000010];

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int i,j,h;
	cin>>n;
	for(i=1;i<=n;i++)
	  cin>>v[i];
	for(i=1;i<=n;i++)
	  cin>>l[i]>>r[i];
	
	cout<<"1";
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
