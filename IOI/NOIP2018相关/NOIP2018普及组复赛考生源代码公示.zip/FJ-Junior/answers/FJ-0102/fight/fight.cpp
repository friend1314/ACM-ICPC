#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

int n,c[100005];
int m;//middle
int s1,s2,p1,p2;//1:they,2:me
long long qs1=0,qs2=0;

int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	int i,j,h;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	  scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	
	int jl[100005];
	jl[m]=0;
	for(i=m-1,j=1;i>=1;i--,j++)
	  jl[i]=j;
	for(i=m+1,j=1;i<=n;i++,j++)
	  jl[i]=j;
	
	c[p1]+=s1;//jiangbing
	//cout<<p1<<":"<<c[p1]<<endl;
	for(i=m-1,j=m+1;i>=1&&j<=n;i--,j++){
		if(c[i]<c[j]){
			c[j]=c[j]-c[i];
			c[i]=0;
		}
		else{
			c[i]=c[i]-c[j];
			c[j]=0;
		}
	}
	/*for(i=1;i<=n;i++)
	  cout<<c[i]<<" ";*/
	
	for(i=m-1,j=m+1;i>=1&&j<=n;i--,j++){
		
		if(c[i]==0)
		  qs2+=jl[j]*c[j];
		else
		  qs1+=jl[i]*c[i];
		
		if(qs1>qs2){
			qs2=0;
			qs1-=qs2;
		}
		else{
			qs1=0;
			qs2-=qs1;
		}
		
		if(i==1){
			if(qs2==0){
				qs2-=qs1;
				qs1=0;
			}
		    for(j++;j<=n;j++)
			  qs2+=c[j]*jl[j];
			break;
		}
		if(j==n){
			if(qs1==0){
				qs1-=qs2;
				qs2=0;
			}
		    for(i--;i>=1;i--)
		        qs1+=c[i]*jl[i];
		    break;
		}
	}
	
	if(qs1<0){
		qs2-=qs1;
		qs1=0;
	}
	//cout<<qs1<<" "<<qs2<<endl;
	
	if(qs1==0){
		p2=1.0*qs2/s2;//jl(p2~m)
		//cout<<p2<<" "<<abs(p2*s2-qs2)<<abs((p2+1)*s2-qs2)<<endl;
		if(abs(p2*s2-qs2)<=
			 abs((p2+1)*s2-qs2))
		  p2=m-p2;
		else
		  p2=m-p2-1;
		
		if(p2<1)
		  p2=1;
	}
	else{
		p2=1.0*qs1/s2;//jl(p2~m)
		//cout<<p2<<endl;
		if(abs(p2*s2-qs1)<=abs((p2+1)*s2-qs1))
		  p2=m+p2;
		else
		  p2=m+p2+1;
		  
		if(p2>n)
		  p2=n;
	}
	
	printf("%d",p2);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
