#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[5];
	cin.getline(s,7);
	int ll=0,i;
	for(i=0;i<5;i++){
		if((s[i]>='a'&&s[i]<='z')||
		   (s[i]>='A'&&s[i]<='Z')||
		   (s[i]-'0'>=0&&s[i]-'0'<=9))
		   ll++;
	//cout<<"i='"<<s[i]<<"'"<<i+1<<":long="<<ll<<endl;
	}
	cout<<ll;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
