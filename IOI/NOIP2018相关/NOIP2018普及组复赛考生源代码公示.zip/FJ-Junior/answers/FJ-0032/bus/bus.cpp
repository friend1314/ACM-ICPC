#include<bits/stdc++.h>
 using namespace std;
 int m,n,a[100001],t1,t2,t[100001],tot,total[100001],ttt;
 int main()
 {
 	//freopen("bus.in","r",stdin);
 	//freopen("bus.out","w",stdout);
 	cin>>n>>m;
		for(int i=1;i<=n;i++)
		{
			cin>>t[i];
			a[t[i]%m]++;
		}
		for(int i=0;i<=m;i++)
		    if(a[i]>=a[tot]) tot=i;//tot:��õĳ���ʱ�� 
		for(int i=1;i<=n;i++)
		{
			int r=tot;
			while((r-t[i])<0) r+=m;
			total[r-t[i]]++;
	    }
	for(int i=1;i<=100000;i++)
	  if(total[i]) ttt+=i;
	cout<<ttt<<endl;
 	return 0;
 }
