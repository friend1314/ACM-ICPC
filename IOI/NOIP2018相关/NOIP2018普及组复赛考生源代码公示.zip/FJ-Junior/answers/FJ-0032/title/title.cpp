#include<bits/stdc++.h>
 using namespace std;
 char s[10];
 int i;
 int main()
 {
 	freopen("title.in","r",stdin);
 	freopen("title.out","w",stdout);
 	while(cin>>s[i]) i++;
 	cout<<i<<endl;
 	return 0;
 }
