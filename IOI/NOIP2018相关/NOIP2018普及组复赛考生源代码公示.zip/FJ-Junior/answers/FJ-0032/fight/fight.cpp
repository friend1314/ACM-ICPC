#include<bits/stdc++.h>
 using namespace std;
 int m,a[100001],b[100001],n,x[100001],sa,sb,c[100001],p1,p2,m1;
 long long int s1,s2;
 int main()
 {
 	freopen("fight.in","r",stdin);
 	freopen("fight.out","w",stdout);
 	cin>>n;
 	for(int i=1;i<=n;i++) cin>>x[i];
 	cin>>m>>p1>>s1>>s2;
 	x[p1]+=s1;
 	for(int i=1;i<=n;i++)
 	{
 		x[i]+=s2;
 		for(int j=1;j<m;j++) {a[j]=x[m-j];sa+=a[j]*j;}
 	    for(int j=1;j<=n-m;j++) {b[j]=x[j+m];sb+=b[j]*j;}
 	    c[i]=sa-sb;
 	    if(c[i]<0) c[i]=-c[i];
 	    x[i]-=s2;
 	    sa=0;
 	    sb=0;
	 }
	 p2=1;
	 for(int i=2;i<=n;i++)
	 	if(c[i]<c[i-1]) p2=i;
	 cout<<p2<<endl;
 	return 0;
 }
