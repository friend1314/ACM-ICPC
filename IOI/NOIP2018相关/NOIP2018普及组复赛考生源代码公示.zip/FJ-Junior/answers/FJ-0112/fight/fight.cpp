#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
using namespace std;
int main ()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long int n[100001],a,b,c,m,p1,p2=0,s1,s2,qishi1=0,qishi2=0,cha;
	long long int min=10000000000000,minum,num;
	bool daxiao;
	cin>>num;
	for(a=1;a<=num;a++)cin>>n[a];
	cin>>m>>p1>>s1>>s2;
	n[p1]+=s1;
	for(a=1;a<=num;a++)
	{
		if(a<m)qishi1+=n[a]*(m-a);
		if(a>m)qishi2+=n[a]*(a-m);
	}
	if(qishi1==qishi2){cout<<m;return 0;}
	if(qishi1>qishi2)daxiao=1;
	else daxiao=0;
	cha=abs(qishi1-qishi2);
	if(cha%s2!=0)p2+=1;
	if((m-1)*s2+qishi1<qishi2||(num-m)*s2+qishi2<qishi1){if((m-1)*s2+qishi1<qishi2)cout<<"1";else cout<<num;return 0;}
	if(daxiao==0)p2=p2+cha/s2;
	if(daxiao==1)p2=p2+cha/s2+m;
	cout<<p2;
	fclose(stdin);fclose(stdout);
	return 0;
}
