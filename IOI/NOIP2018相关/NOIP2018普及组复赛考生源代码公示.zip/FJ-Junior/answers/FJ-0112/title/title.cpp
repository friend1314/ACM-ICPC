#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
using namespace std;
int main ()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string x;
	cout<<x.length();
	fclose(stdin);fclose(stdout);
	return 0;
}
