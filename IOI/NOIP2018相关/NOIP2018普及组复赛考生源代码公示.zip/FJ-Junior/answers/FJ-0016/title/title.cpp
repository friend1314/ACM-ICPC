#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title","r",stdin);
	freopen("title","w",stdout);
	char a[10],b[10],c[10];
	int a1;
	cin>>a;a1=strlen(a);
	if(a1>=4){cout<<a1;}
	if(a1<4)
	{
		cout<<"4";
	}
	if(a1<1)
	{
		cout<<"3";
	}
	fclose(stdin);
	fclose(stdout);
}

