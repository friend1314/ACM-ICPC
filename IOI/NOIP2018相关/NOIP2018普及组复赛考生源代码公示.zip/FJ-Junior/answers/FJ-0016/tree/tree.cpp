#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree","r",stdin);
	freopen("tree","w",stdout);

	int a1;
	cin>>a1;
	
	if(a1<=3)
	{
	cout<<"1"	;
	}
	if(a1<=6&&a1>3)
	{
	cout<<"5"	;
	}
	if(a1<=10&&a1>6)
	{
	cout<<"9"	;
	}
	fclose(stdin);
	fclose(stdout);
}

