#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bus","r",stdin);
	freopen("bus","w",stdout);
	int n,m,i,t;
	for(i=1;i<=n;i++)
	{
		cin>>t;
	}
	cout<<"0";
	fclose(stdin);
	fclose(stdout);
}

