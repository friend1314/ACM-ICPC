#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<string>
#include<string.h>
#include<algorithm>
using namespace std;
string s;
int ans=0;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.length();i++){
		if(s[i]!=' '){
			ans++;
		}
	}
	cout<<ans;
	return 0;
}
