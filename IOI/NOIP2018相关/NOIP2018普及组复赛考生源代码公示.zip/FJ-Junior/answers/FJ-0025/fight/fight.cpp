#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<string.h>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,p1,s1,s2,dragon=0,tiger=0,ans=0,ans1,ans2,ans3,Max;
int c[100001]={};
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=n;i++){
		if(i==p1){
			c[i]=c[i]+s1;
		}
		if(i<m){
			dragon=dragon+c[i]*(m-i);
		}else if(i==m){
			continue;
		}else if(i>m){
			tiger=tiger+c[i]*(i-m);
		}
	}
	if(tiger>=dragon){
		ans1=tiger-dragon;
		ans3=ans1;
		Max=tiger;
	}else{
		ans2=dragon-tiger;
		ans3=ans2;
		Max=dragon;
	}
	if(ans3==ans1){
		for(int i=1;i<m;i++){
			if(dragon+s2*(m-i)-tiger>=0){
				if(dragon+s2*(m-i)-tiger<Max){
					Max=dragon+s2*(m-i)-tiger;
				}
			}else if(dragon+s2*(m-i)-tiger<0){
				if(tiger-dragon-s2*(m-i)<Max){
					Max=tiger-dragon-s2*(m-i);
				}
			}
		}
	}else if(ans3=ans2){
		for(int i=m+1;i<=n;i++){
			if(tiger+s2*(i-m)-dragon>=0){
				if(tiger+s2*(i-m)-dragon<Max){
					Max=tiger+s2*(i-m)-dragon;
				}
			}else{
				if(dragon-tiger-s2*(i-m)<Max){
					Max=dragon-tiger-s2*(i-m);
				}
			}
		}
	}
	if(ans3==ans1){
		for(int i=1;i<m;i++){
		if(dragon+s2*(m-i)-tiger==Max||tiger-dragon-s2*(m-i)==Max){
			cout<<i;
		}
		}
	}else if(ans3==ans2){
		for(int i=m-1;i<=n;i++){
			if(tiger+s2*(i-m)-dragon==Max||dragon-tiger-s2*(i-m)==Max){
				cout<<i;
			}
		}
	}
	return 0;
}
