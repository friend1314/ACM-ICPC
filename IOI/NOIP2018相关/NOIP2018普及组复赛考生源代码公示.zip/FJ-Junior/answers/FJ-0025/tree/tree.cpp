#include<iostream>
#include<string>
#include<cmath>
#include<string.h>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	return 0;
}
