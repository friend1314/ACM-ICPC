#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<string.h>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m,car,ans=0,i=0,start=0,Small,Max[1000001]={},j=0,l,Max2=1000001;
int peo[1000001]={};
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(i=0;i<n;i++){
		cin>>peo[i];
	}
	for(i=0;i<n;i++){
		sort(peo,peo+n);
	}
	i=0;
	car=peo[i];
	for(int i=1;i<n;i++){
		if(car>=peo[n-1]-m){
			break;
		}
		if(peo[i]<=car){
			ans=ans-peo[i]+car;
		}else{
			car=car+m;
			ans=ans-peo[i]+car;
		}		
	}
	for(int i=1;i<n;i++){
		if(peo[i]==car){
			l=i;
			break;
		}
	}
	for(int i=l;i<n;i++){
			if(peo[i-1]==peo[i]){
				Max[j]=Max[j]+peo[i]-car;
			}else{
				j++;
				Max[j]=Max[j]+peo[i]-car;
			}
	}
	for(int j=1;j<n;j++){
		if(Max[j]!=0&&Max[j]<Max2){
			Max2=Max[j];
		}
	}
	cout<<ans+Max2;
	return 0;
}
