#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c,d,e,f,g;
	cin>>a>>b>>c>>d>>e>>f>>g;
	cout<<"1";
	return 0;
}
