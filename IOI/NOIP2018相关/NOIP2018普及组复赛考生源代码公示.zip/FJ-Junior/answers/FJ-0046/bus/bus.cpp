#include<bits/stdc++.h>
using namespace std;
long long n,m,a[1001],b[100001],c[1001],t=1,sum[100001]={},y=1,d[1001];
bool s[1001];
int ss(int x)
{
    if((n-x)>=1)
	{
	for(int i=1;i<=n-x;i++)
	{
	s[x]=1;
	if((m-(c[x]-c[x-1]))>0)
	sum[y]=sum[y]+(m-(c[x]-c[x-1]))*d[x];
	if(x==(n-1)) y++;
	else ss[x+1];
	s[x]=0;	
	}
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	c[0]=0;
	cin>>n>>m;
	
	for(int i=1;i<=n;i++)
	 cin>>a[i];
	 if(m==1) 
	 {
	 	cout<<"0";
	 	return 0;
	 }
	for(int i=1;i<=n;i++)
	  b[a[i]]++; 
	for(int i=1;i<=100001;i++)
	  if(b[i]==1)
	  {
	  	c[t]=i;
	  	d[t]=b[i];
	  	t++;
	   } 
	   for(int i=1;i<=t-1;i++)
         ss(2);
        sort(sum+1,sum+y);
        cout<<sum[1]<<endl;
	return 0;
}
