#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long a[10001],ci,m,s1,p1,p2,s2,n,t1=0,t2=0,t3[10001],d[10001];
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
      {
      	cin>>a[i];
	  }
	cin>>m>>p1>>s1>>s2;
	a[p1]=a[p1]+s1;
	for(int i=1;i<m;i++)
	  {
	  	t1=t1+a[i]*(m-i);
	  }
	for(int i=m+1;i<=n;i++)
	  {
	  	t2=t2+a[i]*(i-m);
	  }
	if(t1==t2)
	{
		cout<<m<<endl;
		return 0;
	 } 
	else if(t1<t2)
	{
	for(int i=1;i<m;i++)
	{
	t3[i]=t1+(s2*(m-i))-t2;	
	if(t3[i]<0) t3[i]*=-1;
	d[i]=i;
	}
	t3[m]=t2-t1;
	d[m]=m;
	for(int i=1;i<=m-1;i++)
	{
		for(int j=1;j<=i;j++)
		{
			if(t3[j]>t3[j+1])
			{
				swap(t3[j],t3[j+1]);
				swap(d[j],d[j+1]);
			}
		}
	}
	cout<<d[1]<<endl;
	return 0;
	  }  
	else if(t2>t1)
	{
	for(int i=m+1;i<m;i++)
	{
		t3[i]=t2+(s2*(m-i))-t1;
		if(t3[i]<0) t3[i]*=-1;
		d[i]=i;
	}
	t3[m]=t1-t2;
	d[m]=m;
	for(int i=1;i<=m-1;i++)
	{
		for(int j=1;j<=i;j++)
		{
			if(t3[j]>t3[j+1])
			{
				swap(t3[j],t3[j+1]);
				swap(d[j],d[j+1]);
			}
		}
	}
	cout<<d[1]<<endl;
	return 0;
	}
	return 0;
}
