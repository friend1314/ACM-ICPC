#include<bits/stdc++.h>
using namespace std;
int main()
{
	char s[9];
	int sum=0,len=0;
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	len=strlen(s);
	for(int i=0;i<len;i++)
	{
	if((s[i]>='0'&&s[i]<='9') || (s[i]>='a'&&s[i]<='z') || (s[i]>='A'&&s[i]<='Z'))
	{
		sum++;
		}	
		
	}
	cout<<sum<<endl;
	
	
	
	return 0;
}
