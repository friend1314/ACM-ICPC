#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
char a[10000008];
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,a;
	cin>>n;
	if(n==1) cout<<1;
	else{
	for(int i=1;i<=3*n;i++){
		cin>>a;
	}
	cout<<-1;}
	return 0;
}
