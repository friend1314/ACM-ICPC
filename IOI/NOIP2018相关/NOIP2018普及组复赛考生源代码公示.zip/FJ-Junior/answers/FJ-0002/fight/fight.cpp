#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int a[1000050];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long b,d,e,f,g,h,k=0,n,z=9223372036854775807;
	int i,j,c,s;
	cin>>n;
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>b>>c>>d>>e;
	for(j=1;j<=n;j++){
		if(j>b){
			k+=((abs(j-b))*a[j]);//cout<<a[j]<<" "<<b<<" "<<k<<endl;
		}
		if(j<b){
			k-=((abs(j-b))*a[j]);//cout<<a[j]<<" "<<b<<" "<<k<<endl;
		}
	}
	//cout<<c<<" "<<b<<endl;
	if(c>b) k+=(abs(c-b)*d);
	else if(c<b) k-=(abs(c-b)*d);
	f=k/e;
	//cout<<k<<endl<<f<<endl;
	for(i=1;i<=n;i++){
		//cout<<i;
		//cout<<(e*(i-b))<<" ";
		if(abs(e*(i-b)+k)<z) {
			z=abs(e*(i-b)+k);
			//cout<<z<<endl;
			//cout<<i<<" "<<z<<endl;
			h=i;
		}
	}
	cout<<h;
	return 0;
}
