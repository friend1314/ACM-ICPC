#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
long long n[100000008];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	long long a,b,c,d,e,f,g,h=9223372036854775807,i,j,k=0;
	cin>>a>>g;
	b=a/g;
	for(i=1;i<=a;i++){
		cin>>n[i];
	} 
	sort(n+1,n+a+1);
	/*for(i=1;i<=a;i++){
		cout<<n[i];
	}*/
	for(i=0;i<=b;i++){
		for(j=0;j<=g;j++){ 
		if(n[i+1]-n[i]<h) h=n[i+1]-n[a]<h;
		} 
	}
	for(i=1;i<=a;i++){
		k+=abs(n[i]-g);
	} 
	cout<<6;
	return 0;
}
