#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[1000];
	gets(a);
	int k=0,s,i;
	int l=strlen(a);
	/*for(i=1;i<=l;i++){
		if((a[i]>='0'&&a[i]<='9')||(a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')) k+=1;
	}*/
    for(i=0;i<l;i++){
		if(a[i]>='0'&&a[i]<='9') k+=1;
		else if(a[i]>='a'&&a[i]<='z') k+=1;
		else if(a[i]>='A'&&a[i]<='Z') k+=1;
	}
	cout<<k;
	return 0;
}
