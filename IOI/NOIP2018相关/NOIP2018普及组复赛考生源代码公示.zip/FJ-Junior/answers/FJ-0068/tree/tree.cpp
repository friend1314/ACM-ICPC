#include<iostream>
#include<cstring>
#include<string>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std; 
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,m,a,i,a1,a2,a3,a4;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a;
	}
	for(i=1;i<=n;i++)
	{
		cin>>a1>>a2;
	}
	cout<<"3";
	fclose(stdin);fclose(stdout);
	return 0;
}
