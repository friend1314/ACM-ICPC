#include<iostream>
#include<cstring>
#include<string>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std; 
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[20001];
    int i,ans=0;
    gets(a);
    for(i=1;i<=strlen(a);i++)
    {
    	if(a[i]!=32) ans++;
	}
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}

