#include<iostream>
#include<cstring>
#include<string>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std; 
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,a,i;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>a;
	}
	cout<<0;
	fclose(stdin);fclose(stdout);
	return 0;
}
