#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
using namespace std;
char s[20];
int ans,i,a;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	a=strlen(s);
	while(i<a){	
	if(s[i]!=' ')ans++;
	i++;
	}
	cout<<ans;
	return 0;
}
