#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
using namespace std;
int n,m,t[1000],ans,ti,k=1,k1,p,k2;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)cin>>t[i];
	sort(t+1,t+n+1);
	k1=1;
	while(k<n){
		p=0,k2=k+1;
		while(t[k1]==t[k1+1])k1++;
		if(ti==0){
			if(t[k1]==0)ti+=t[k1+1],k1++;
			else ti+=t[k1],k1++;
		}
		else{
			if(t[k1]-t[k]<ti+m-t[k1]){
				while(t[k1]-t[k]<ti+m-t[k+1]-p && k1<=n)
					if(k1<n)k1++,p=t[k1]-t[k];
					else p=t[k1]-t[k];
				ans+=p,k=k1;
			}
			else{
			ti+=m;
			if(ti>t[k1])
			ans+=(ti-t[k1])*(k1-k2+1),k=k1,k1++;
			else k=k1,k1++;
			}
		}
	}
	cout<<ans;
	return 0;
}
