#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
using namespace std;
long long n,h,l,a[100010],m,p1,p2,s1,s2,ans,k,p,l1,h1;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<m;i++){
		if(i==p1)l+=(a[i]+s1)*(m-i);
		else l+=a[i]*(m-i);
	}
	for(int i=n;i>m;i--){
		if(i==p1)h+=(a[i]+s1)*(i-m);
		else h+=a[i]*(i-m);
	}
	k=abs(l-h);
	for(int i=1;i<=n;i++){
		l1=l;h1=h;
		if(i<m)l1+=s2*(m-i);
		if(i>m)h1+=s2*(i-m);
		p=abs(l1-h1);
		if(p<k)k=p,ans=i;
	//cout<<l1<<" "<<h1<<endl;
	}
	if(ans==0)cout<<m;
	else cout<<ans;
	return 0;
}
