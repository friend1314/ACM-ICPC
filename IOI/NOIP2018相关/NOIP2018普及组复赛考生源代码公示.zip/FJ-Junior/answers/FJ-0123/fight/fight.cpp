#include<iostream>
#include<cstdio>
using namespace std;
int n,m,p1,s1,s2;
long long ans=999999999,ans1;
struct node
{
	int n,val;
}a[100010];
long long jdz(long long x)
{
	if(x<0)
	{
		return -x;
	}
	else
	{
		return x;
	}
}
long long dr=0,ti=0;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i].n);
	}
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	a[p1].n+=s1;
	for(int i=1;i<=n;++i)
	{
		a[i].val=a[i].n*jdz(i-m);
		if(i<m)
		{
			dr+=a[i].val;
		}
		if(i>m)
		{
			ti+=a[i].val;
		} 
	}
	long long tmp=jdz(ti-dr);
	for(int i=1;i<=n;++i)
	{
		if(i<m)
		{
			if(jdz(tmp-s2*jdz(i-m))<ans)
			{
				ans=jdz(tmp-s2*jdz(i-m));
				ans1=i;
			}
		}
		if(i>m)
		{
			if(jdz(tmp+s2*jdz(i-m))<ans)
			{
				ans=jdz(tmp+s2*jdz(i-m));
				ans1=i;
			}
		}
	}
	printf("%lld",ans1);
}
