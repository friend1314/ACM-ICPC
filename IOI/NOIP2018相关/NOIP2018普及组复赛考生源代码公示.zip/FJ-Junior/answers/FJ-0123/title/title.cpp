#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
using namespace std;
char a[15];
int ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	int len=strlen(a);
	for(int i=0;i<=len;++i)
	{
		if(a[i]>='1'&&a[i]<='9')
		{
			ans++;
			continue;			
		}
		if(a[i]>='a'&&a[i]<='z')
		{
			ans++;
			continue;
		}
		if(a[i]>='A'&&a[i]<='Z')
		{
			ans++;
			continue;
		}
	}
	printf("%d",ans);
	return 0;
}
