#include<algorithm>
#include<iostream>
#include<cstdio>
using namespace std;
int a[510],n,m,minn=999999999,ans[510]={0};
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&a[i]);
	}
	sort(a+1,a+n+1);
	for(int i=2;i<=n;++i)
	{
		if(a[i]!=a[i-1]&&a[i]-a[i-1]<minn) minn=a[i]-a[i-1];
	}
	if(m<=minn)
	{
		printf("0");
	}
	else
	{
		minn=99999999;
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<i;++j)
			{
				ans[i]+=a[i]-a[j]+m;
			}
			for(int j=i+1;j<=n;++j)
			{
				int btime=a[i];
				while(a[j]>btime)
				{
					btime+=m;
				}
				ans[i]+=btime-a[j];
			}
		}
		for(int i=1;i<=n;++i)
		{
			if(ans[i]<minn)
			{
				minn=ans[i];
			}
		}
		printf("%d",minn);
	}
	return 0;
}
