#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
const int MAXN=5005;
bool vis[MAXN][MAXN],viss[MAXN];
int n,m,u,v;//,last=0x3f3f3f3f;

int read(){
	int an=0,k=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') k=-1;c=getchar();}
	while(c>='0'&&c<='9') {an=an*10+c-'0';c=getchar();}
	return an*k;
}

void work(int s,int sum){
	int a[MAXN];
	int tot=0;
	if(viss[s]) return;
	else {
		printf("%d ",s);
		viss[s]=1;
		sum++;
	}
	if(sum==n) exit(0);
	memset(a,0,sizeof(a));
	for(int j=1;j<=n;j++){
		if(s==j) continue;
		if(!vis[s][j]) continue;
		a[++tot]=j;
	}
	if(tot==0) return;
	sort(a+1,a+1+tot);
	//if(tot>=2) last=a[2];
	//if(vis[last]) last=0x3f3f3f3f;
	for(int j=1;j<=tot;j++){
		/*if(a[j]>last) {
			int p=last;
			last=a[j];
			work(p,sum);
		}*/
		work(a[j],sum);
	}
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read();m=read();
	memset(vis,0,sizeof(vis));
	memset(viss,0,sizeof(viss));
	for(int i=1;i<=m;i++){
		u=read();v=read();
		vis[u][v]=1;vis[v][u]=1;
	}
	//cout<<1;
	work(1,0);
	return 0;
}
