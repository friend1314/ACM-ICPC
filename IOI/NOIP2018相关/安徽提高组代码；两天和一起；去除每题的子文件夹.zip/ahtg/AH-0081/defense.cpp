#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
const int MAXN=2005;
int vis[MAXN],val[MAXN];
int n,m,u,v,x,y,a,b;
char s[10];

int read(){
	int an=0,k=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') k=-1;c=getchar();}
	while(c>='0'&&c<='9') {an=an*10+c-'0';c=getchar();}
	return an*k;
}

int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	n=read();m=read();cin>>s;
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++) val[i]=read();
	for(int i=1;i<=n-1;i++) {
		u=read();v=read();
	}
	for(int i=1;i<=n;i++){
		memset(vis,2,sizeof(vis));
		x=read();a=read();y=read();b=read();
		vis[x]=a;vis[y]=b;
		if(abs(x-y)<=1&&a==0&&b==0) {cout<<-1<<endl;continue;}
		if(x>y) swap(x,y);
		ll sum=0;
		if(a==1) sum+=val[x];
		if(b==1) sum+=val[y];
		for(int j=x+1;j<=y-1;j++){
			if(vis[j-1]==0||vis[j+1]==0) {
				vis[j]=1;
				sum+=val[j];
				continue;
			}
			else vis[j]=0;
		}
		for(int j=x-1;j>=1;j--){
			if(vis[j-1]==0||vis[j+1]==0) {
				vis[j]=1;
				sum+=val[j];
				continue;
			}
			else vis[j]=0;
		}
		for(int j=y+1;j<=n;j++){
			if(vis[j-1]==0||vis[j+1]==0) {
				vis[j]=1;
				sum+=val[j];
				continue;
			}
			else vis[j]=0;
		}
		cout<<sum<<endl;
	}
	return 0;
}
