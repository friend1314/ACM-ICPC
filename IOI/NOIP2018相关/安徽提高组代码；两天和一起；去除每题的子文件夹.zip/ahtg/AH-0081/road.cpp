#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
const int MAXN=100005;
int n;
int a[MAXN],d[MAXN];
ll ans=0;

int read(){
	int an=0,k=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') k=-1;c=getchar();}
	while(c>='0'&&c<='9') {an=an*10+c-'0';c=getchar();}
	return an*k;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	int last=0;
	for(int i=1;i<=n;i++){
		a[i]=read();
		d[i]=a[i]-last;
		last=a[i];
	}
	for(int i=1;i<=n;i++){
		if(d[i]<0) continue;
		else ans+=d[i];
	}
	printf("%lld\n",ans);
	return 0;
}
