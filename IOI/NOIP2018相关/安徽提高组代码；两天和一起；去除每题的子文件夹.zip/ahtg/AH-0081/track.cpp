#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
const int MAXN=50005;
int n,m,minn=0x3f3f3f3f;
int fa[MAXN],head[MAXN];

struct node{
	int u,v,w,next;
}e[MAXN<<1];

int read(){
	int an=0,k=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') k=-1;c=getchar();}
	while(c>='0'&&c<='9') {an=an*10+c-'0';c=getchar();}
	return an*k;
}

int cnt=1;
void add(int u,int v,int w){
	e[cnt].u=u;e[cnt].v=v;
	e[cnt].w=w;
	e[cnt].next=head[u];
	head[u]=cnt++;
}

bool cmp(node a,node b){
	return a.w<b.w;
}

int find(int x){
	return fa[x]==x?x:fa[x]=find(fa[x]);
}

int x,y,z;
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,0,sizeof(head));
	n=read();m=read();
	for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=n-1;i++) {
		x=read();y=read();z=read();
		minn=min(minn,z);
		add(x,y,z);add(y,x,z);
	}
	ll sum=0;
	sort(e,e+cnt,cmp);
	if(m==n-1) {printf("%d\n",minn);return 0;}
	if(m==n-2) {
		int a=e[1].w;
		int b=e[3].w;
		int c=e[5].w;
		if(a+b>c) printf("%d\n",c);
		else printf("%d\n",a+b);
		return 0;
	}
	for(int i=1;i<=cnt;i++){
		int x=e[i].u;int y=e[i].v;
		if(find(x)==find(y)) continue;
		sum+=e[i].w;
		fa[y]=x;
	}
	printf("%lld\n",sum);
	return 0;
}
