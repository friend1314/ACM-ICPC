#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
const int MAXN=150;
int n,minn,t,f,j;
int a[MAXN];

int read(){
	int an=0,k=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') k=-1;c=getchar();}
	while(c>='0'&&c<='9') {an=an*10+c-'0';c=getchar();}
	return an*k;
}

bool work(int x,int id){
	//cout<<x<<' '<<id<<endl;
	if(x<minn) return false;
	for(int i=j;i>=0;i--){
		if(f==1) break;
		if(x<a[i]||a[i]==0) continue;
		else if(x%a[i]==0) {f=1;return true;}
		else	work(x%a[i],id);
	}
	if(f) return true;
	return false;
}

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	while(t--){
		n=read();
	    for(int i=1;i<=n;i++){
			a[i]=read();
		}
	    sort(a+1,a+1+n);
		minn=a[1];
	    int ans=n;
	    for(int i=2;i<=n;i++){
			for(j=i-1;j>=0;j--){
				if(a[j]==0) continue;
				f=0;
				if(work(a[i],i)) {ans--;a[i]=0;break;}
			}
	    }
		//for(int i=1;i<=ans;i++) cout<<a[i]<<' ';
		printf("%d\n",ans);
	}
	return 0;
}
