#include<bits/stdc++.h>
#define mn 1111111
using namespace std;
struct node{int x,y;}a[mn];
int n,m,c,i=1,x,y,h[mn];
//inline int cmp(node a,node b) {return a.y<b.y;}
inline void add(int x,int y) {a[++c].x=h[x]; a[c].y=y; h[x]=c;}
inline void dfs1(int x,int fa)
{
	int i=h[x],t=0; priority_queue<int,vector<int>,greater<int> >q; printf("%d ",x);
	for (;i;i=a[i].x) if (a[i].y!=fa) q.push(a[i].y);
	for (;q.size();q.pop()) dfs1(q.top(),x);
}
int main()
{
	freopen("travel.in","r",stdin); freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m); for (;i<=m;i++) scanf("%d%d",&x,&y),add(x,y),add(y,x);
	if (m<n) dfs1(1,0); //else doit2();
	return  0;
}