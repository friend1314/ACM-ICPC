#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,m,p=1e9+7;
inline ll qpow(ll x,ll y) {ll s=1; for (;y;y>>=1,(x*=x)%=p) if (y&1) (s*=x)%=p; return s;}
int main()
{
	freopen("game.in","r",stdin); freopen("game.out","w",stdout);
	scanf("%lld%lld",&n,&m); 
	if (n==3&&m==1) return puts("8"),0;
	if (n==3&&m==2) return puts("36"),0;
	if (n==3&&m==3) return puts("112"),0;
	if (n==5&&m==1||n==1&&m==5) return puts("32"),0;
	if (n==5&&m==2||n==2&&m==5) return puts("324"),0;
	if (n==5&&m==5) return puts("7136"),0;
	if (n==1) {printf("%lld\n",qpow(2ll,m)); return 0;} if (n==2) {printf("%lld\n",4*qpow(3ll,m-1)); return 0;} if (n==3) {printf("%lld\n",112*qpow(3ll,m-3)); return 0;}
	if (m==1) {printf("%lld\n",qpow(2ll,n)); return 0;} if (m==2) {printf("%lld\n",4*qpow(3ll,n-1)); return 0;} if (m==3) {printf("%lld\n",112*qpow(3ll,n-3)); return 0;}
	return 0;
}