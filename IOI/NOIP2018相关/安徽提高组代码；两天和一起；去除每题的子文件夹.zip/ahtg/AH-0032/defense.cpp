#include<bits/stdc++.h>
#define mn 1111111
#define gc getchar
#define ll long long
using namespace std;
struct edge{int x,y;}a[mn];
int n,T,x,y,c,i,p,q,flag,inf=2e9,s,ch[mn],vis[mn],v[mn],h[mn],A[11],B[11],f[mn][2]; char cha;
inline void add(int x,int y) {a[++c].x=h[x]; a[c].y=y; h[x]=c;}
inline int check()
{
	memset(vis,0,sizeof(vis)); int i,j,t=0;
	for (i=1;i<=n;i++) if (ch[i]) {for (j=h[i];j;j=a[j].x) vis[a[j].y]=1; vis[i]=1; t+=v[i];}
	for (i=1;i<=n;i++) if (!vis[i]) return inf;
	return t;
}
inline void dfs(int x,int fa)
{
	if (A[1]==x||A[2]==x) f[x][0]=inf; if (B[1]==x||B[2]==x) f[x][1]=inf;
}
//inline void doit2() 
inline void doit(int x,int t) {if (x>n) {s=min(s,check()); return;} if (A[1]==x||A[2]==x) ch[x]=1; else if (B[1]==x||B[2]==x) ch[x]=0; else ch[x]=t; for (int i=0;i<2;i++) doit(x+1,i);}
int main()
{
	freopen("defense.in","r",stdin); freopen("defense.out","w",stdout);
	scanf("%d%d",&n,&T); cha=gc(); cha=gc(); if (cha!='A') flag=1; cha=gc(); if (cha!='2') flag=1;
	for (i=1;i<=n;i++) scanf("%d",v+i); for (i=1;i<n;i++) scanf("%d%d",&x,&y),add(x,y),add(y,x);
	while (T--)
	{
		A[1]=A[2]=B[1]=B[2]=0; scanf("%d%d%d%d",&x,&p,&y,&q); if (p) A[1]=x; else B[1]=x; if (q) A[2]=y; else B[2]=y;
		if (n<11) s=2e9,doit(0,1),printf("%d\n",s==2e9?-1:s);
		//if (!flag) doit2();
	}
	return 0;
}