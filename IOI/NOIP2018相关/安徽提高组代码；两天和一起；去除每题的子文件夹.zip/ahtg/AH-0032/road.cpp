#include<bits/stdc++.h>
#define mn 1111111
using namespace std;
long long n,i=1,s,a[mn];
int main() 
{
	freopen("road.in","r",stdin); freopen("road.out","w",stdout); 
	scanf("%lld",&n); for (;i<=n;i++) {scanf("%lld",a+i); if (a[i]>a[i-1]) s+=a[i]-a[i-1];} 
	printf("%lld\n",s); return 0;
}