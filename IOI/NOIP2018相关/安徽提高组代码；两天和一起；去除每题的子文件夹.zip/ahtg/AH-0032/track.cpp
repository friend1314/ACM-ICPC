#include<bits/stdc++.h>
#define mn 1111111
using namespace std;
struct node{int x,y,z;}a[mn];
int n,m,i=1,c,x,y,z,p,q,t,h[mn],l[mn];
inline void add(int x,int y,int z) {a[++c].x=h[x]; a[c].y=y; a[c].z=z; h[x]=c;}
inline int cmp1(node a,node b) {return a.z>b.z;}
inline int cmp2(node a,node b) {return a.x<b.x;}
inline int check(int x)
{
	int i=1,s=0,t=0;
	for (;i<=n;i++) {t+=a[i].z; if (t>=x) t=0,s++;}
	return s>=m;
}
inline int dfs(int x,int fa)
{
	int i=h[x],y,z,s=0;
	for (;i;i=a[i].x) {y=a[i].y; z=a[i].z; if (y!=fa) s=max(s,dfs(y,x)+z);}
	return s;
}
inline void doit1()
{
	sort(a+1,a+n,cmp1);
	int p=1,q=m<<1,s=2e9;
	while (p<=q) s=min(s,a[p++].z+a[q--].z);
	printf("%d\n",s);
}
inline void doit2()
{
	int l=0,r=2e9,s,mid; sort(a+1,a+n,cmp2);
	while (l<=r) {mid=l+r>>1; if (check(mid)) s=mid,l=mid+1; else r=mid-1;}
	printf("%d\n",s);
}
inline void doit3()
{
	int i=1,x,y,z,s=0;
	for (;i<n;i++) {scanf("%d%d%d",&x,&y,&z); add(x,y,z); add(y,x,z);}
	for (i=1;i<=n;i++) s=max(s,dfs(i,0));
	printf("%d\n",s);
}
int main()
{
	freopen("track.in","r",stdin); freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m); if (n<6) {doit3(); return 0;} for (;i<n;i++) {scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].z); if (a[i].x>a[i].y) t=a[i].x,a[i].x=a[i].y,a[i].y=t; if (a[i].x!=1) p=1; if ((a[i].y-a[i].x)!=1) q=1;}
	if (!p) {doit1(); return 0;} 
	if (!q) {doit2(); return 0;}
	return 0;
}