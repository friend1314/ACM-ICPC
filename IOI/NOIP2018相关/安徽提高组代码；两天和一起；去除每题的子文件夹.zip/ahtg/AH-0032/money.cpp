#include<bits/stdc++.h>
#define mn 1111111
using namespace std;
int T,n,i,j,z,s,f[mn],a[mn];
int main()
{
	freopen("money.in","r",stdin); freopen("money.out","w",stdout);
	for (scanf("%d",&T);T--;)
	{
		memset(f,0,sizeof(f)); s=0; f[0]=1;
		scanf("%d",&n); for (i=1;i<=n;i++) scanf("%d",a+i); sort(a+1,a+1+n);
		for (i=1;i<=n;i++) if (!f[a[i]]) {for (j=a[i];j<=25000;j++) f[j]|=f[j-a[i]]; s++;}
		printf("%d\n",s);
	}
	return 0;
}
