#include<stdio.h>
#include<iostream>
using namespace std;
int n,m;
int ans=0;
int f[25][1000005];
const int mod=1000000007;

long long  power(int n)
{
	long long  tmp=1;
	for(int i=1;i<=n;i++){
		tmp*=2;
		tmp%=mod;
	}
	return tmp;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
    if(n==1)
		printf("0\n");
if(n==2)
{long long ans=0;
    ans=(power(m)%mod+power(m+1)%mod)%mod;
	printf("%lld\n",ans);
}
	if(n==3&&m==3)printf("112\n");
	if(n==3&&m==2)printf("24\n");
}