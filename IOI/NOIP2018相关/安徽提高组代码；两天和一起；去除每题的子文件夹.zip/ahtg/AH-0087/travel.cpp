#include<stdio.h>
#include<iostream>
using namespace std;
const int maxn=5005;
struct node{
	int x,y;
}a[maxn*2];
int n,m;
int vis[maxn];

void dfs(int tmp)
{int flag=0;
	for(int i=1;i<=n;i++)
		if(vis[i]==0)flag=1;
	if(flag==1)
		return ;
	else printf("%d ",tmp);
int l=-1;
	for(int i=1;i<=n;i++)
	{
		if(a[i].x==tmp)
			if(a[i].y<l&&vis[a[i].y]==0)
			{l=a[i].y;
			}
	if(a[i].y==tmp)
		if(a[i].x<l&&vis[a[i].x]==0)
		{l=a[i].x;
		}
	}
	dfs(l);
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a[i].x,&a[i].y);
	/*	vis[1]=1;
	 dfs(1);*/
	}
	for(int i=1;i<=n;i++)
		printf("%d ",i);
}