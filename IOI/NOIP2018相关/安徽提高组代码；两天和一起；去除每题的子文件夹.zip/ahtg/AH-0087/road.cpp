#include<stdio.h>
#include<iostream>
using namespace std;
int n;
const int maxn=100005;
int a[maxn];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	int tmp1=a[1],tmp;
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<a[i+1])
		{
			tmp=a[i];
			ans-=tmp;
			tmp1=a[i+1];
			ans+=tmp1;
		//	printf("%d\n%d\n",tmp,tmp1);
		}
	}
	printf("%d\n",ans+a[1]);
	return 0;
}