#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
int n,m;
int a[105];
int gcd(int n,int m)
{
	if(n==0)return m;
	return gcd(m%n,n);
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	scanf("%d",&t);
while(t--)
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	if(n==2)
	{
		if(gcd(a[1],a[2])==min(a[1],a[2]))printf("1\n");
			else printf("2\n");
	}
	if(n==3)
	{
		sort(a+1,a+1+n);
		if(a[1]+a[2]==a[3]){
			if(gcd(a[1],a[2])==a[1])
			printf("1\n");
			if(gcd(a[1],a[2])!=a[1])
				printf("2\n");
	}
	else{
		if(gcd(a[1],a[2])==a[1]||gcd(a[1],a[3])==a[1])
			printf("2\n");
		else printf("3\n");
	}
}
if(n==4)
{
	sort(a+1,a+1+n);
	if(a[1]==1)
		printf("1\n");
		else{
	if(a[1]+a[2]+a[3]==a[4])
		n--;
		if(a[1]+a[2]==a[3])
			n--;
		if(a[1]+a[3]==a[4])
			n--;
		if(a[1]+a[2]==a[4])
		n--;
	if(gcd(a[1],a[2])==a[1])n--;
		if(gcd(a[1],a[3])==a[1])n--;
			if(gcd(a[1],a[4])==a[1])n--;
				if(gcd(a[2],a[3])==a[2])n--;
					if(gcd(a[3],a[4])==a[3])n--;
						if(gcd(a[2],a[4])==a[2])n--;
					}
	/*
	if(a[1]+a[2]+a[3]==a[4])
	{
			if(a[1]+a[2]==a[3]){
			if(gcd(a[1],a[2])==a[1])
			printf("1\n");
			if(gcd(a[1],a[2])!=a[1])
				printf("2\n");
	}
		if(a[1]+a[2]!=a[3]){
		if(gcd(a[1],a[2])==a[1]||gcd(a[1],a[3])==a[1])
			printf("2\n");
		else printf("3\n");
	}
	}*/
}
}
	return 0;
}