#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=100005;
int vis[maxn]={0};
int p[maxn];
int n,m;
int a,b,d,e,x,y;
char c;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%c",&c);
	scanf("%d",&d);
for(int i=1;i<=n;i++)
	scanf("%d",&p[i]);
	for(int i=1;i<=n;i++)
	{
		
		scanf("%d%d",&d,&e);
}
for(int i=1;i<=m;i++)
{
	scanf("%d%d%d%d",&a,&x,&b,&y);
		vis[a]=1;
	vis[b]=1;	
	int ans=0,ans1=0;
	int tmp=0;
	if(x==1){
		if(a%2==0)
	ans+=p[a];
	else ans1+=p[a];
	}
	else tmp++;
	if(x==1){
		if(b%2==0)
	ans+=p[b];
	else ans1+=p[b];
	}
	
	if(tmp==0||tmp==1)
	{
		for(int j=1;j<=n;j++)
		{
			if(j%2==0&&vis[i]==0)
				ans+=p [j];
				if(j%2==0&&vis[i]==0) ans1+=p[j];
		}
		printf("%d\n",min(ans,ans1));
	}
	else{
		printf("-1\n");
	}
}
return 0;
}
		