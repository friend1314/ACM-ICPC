#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<string.h>
#include<queue>
using namespace std;
int n,m;
const int maxn=500005;
int head[maxn],dis[maxn],vis[maxn];
struct edge
{
	int next,dis,to;
}e[maxn*2];
int cnt=0;
int cmp(int a,int b)
{
	return a>b;
}
void add(int from,int to,int dis)
{
	++cnt;
	e[cnt].next=head[from];
	e[cnt].to=to;
	e[cnt].dis=dis;
	head[from]=cnt;
}
const int inf=2147483647;
void spfa(int s)
{
	queue<int >q;
	for(int i=1;i<=n;i++)
	{
		dis[i]=inf;
		vis[i]=0;
	}
	dis[s]=0;
	q.push(s);
	vis[s]=1;
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		for(int i=head[u];i;i=e[i].next)
		{
			int v=e[i].to;
			if(dis[v]>dis[u]+e[i].dis)
			dis[v]=dis[u]+e[i].dis;
			if(vis[v]==0)
			{
				vis[v]=1;
				q.push(v);
			}
		}
	}
}
int f[maxn];
int x[maxn],y[maxn],z[maxn];
int l[maxn];
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
scanf("%d%d",&n,&m);
	memset(f,0,sizeof(f));
	int flag=0;
	for(int i=1;i<=n-1;i++){
	scanf("%d%d%d",&x[i],&y[i],&z[i]);
		add(x[i],y[i],z[i]);
		add(y[i],x[i],z[i]);
		//f[x[i]]++;
	if(x[i]!=1)flag=1;
	}
	if(flag==0||m==n-1){
 sort(z+1,z+1+n,cmp);
		printf("%d\n",z[m]);
	}
else{
	for(int i=1;i<=n;i++)
	{spfa(i);
		sort(dis+1,dis+1+n,cmp);
		l[i]=dis[1];
		//printf("%d\n",l[i]);
	}
	sort(l+1,l+1+n,cmp);
	printf("%d\n",l[1]);
}
//printf("1\n");
	return 0;
}