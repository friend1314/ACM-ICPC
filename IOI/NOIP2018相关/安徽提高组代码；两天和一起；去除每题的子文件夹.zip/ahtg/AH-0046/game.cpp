#include <iostream>
#include <cstdio>
#include <map>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <stack>
#include <queue>
using namespace std;
long long n,m;
void read()
{
	cin>>n>>m;
	long long ans=1;
	long long i;
	if (n==2)
	{
		ans*=4;
		for (i=3;i<=m+n-1;i++)
		{
			ans*=3;
			ans%=1000000007;
		}
		cout<<ans<<endl;
	}
	else if (n==3)
	{
		if (m==1)
		{
			cout<<8<<endl;
		}
		else if (m==2)
		{
			cout<<36<<endl;
		}
		else if (m==3)
		{
			cout<<112<<endl;
		}
	}
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read();
	fclose(stdin);
	fclose(stdout);
	return 0;
}