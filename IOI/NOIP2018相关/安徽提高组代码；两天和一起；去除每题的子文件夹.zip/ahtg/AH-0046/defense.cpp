#include <iostream>
#include <cstdio>
#include <map>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <stack>
#include <queue>
using namespace std;
int n,m;
int p[100001];
char type1,type2;
int dp(int x,int y)
{
	int i;
	int f[100005];
	f[x]=p[x];
	f[x+1]=f[x]+p[x+1];
	for (i=x+2;i<=y;i++)
	{
		f[i]=min(f[i-1],f[i-2])+p[i];
	}
	return f[y];
}
void read()
{
	int a,b,x,y,i;
	cin>>n>>m>>type1>>type2;
	if (type1=='A')
	{
		for (i=1;i<=n;i++)
		{
			cin>>p[i];
		}
		for (i=1;i<=n-1;i++)
		{
			cin>>x>>y;
		}
		for (i=1;i<=m;i++)
		{
			cin>>a>>x>>b>>y;
			if (a>b)
			{
				swap(a,b);
				swap(x,y);
			}
			if (b==a+1 && x+y==0)
			{
				cout<<-1<<endl;
				continue;
			}
			long long ans=0;
			if (x*2+y==0)
			{
				ans+=dp(0,a-1);
				//cout<<ans<<endl;
				ans+=dp(a+1,b-1);
				//cout<<ans<<endl;
				ans+=dp(b+1,n+1);
				//cout<<ans<<endl;
			}
			else if (x*2+y==1)
			{
				ans+=dp(0,a-1);
				//cout<<ans<<endl;
				ans+=dp(a+1,b);
				//cout<<ans<<endl;
				ans+=dp(b,n+1);
				//cout<<ans<<endl;
				ans-=p[b];
				//cout<<ans<<endl;
			}
			else if (x*2+y==2)
			{
				ans+=dp(0,a);
				//cout<<ans<<endl;
				ans+=dp(a,b-1);
				//cout<<ans<<endl;
				ans+=dp(b+1,n+1);
				//cout<<ans<<endl;
				ans-=p[a];
				//cout<<ans<<endl;
			}
			else if (x*2+y==3)
			{
				ans+=dp(0,a);
				//cout<<ans<<endl;
				ans+=dp(a,b);
				//cout<<ans<<endl;
				ans+=dp(b,n+1);
				//cout<<ans<<endl;
				ans-=p[a];
				//cout<<ans<<endl;
				ans-=p[b];
				//cout<<ans<<endl;
			}
			cout<<ans<<endl;
		}
	}
}
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	read();
	fclose(stdin);
	fclose(stdout);
	return 0;
}