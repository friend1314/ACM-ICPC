#include <iostream>
#include <cstdio>
#include <map>
#include <string>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <stack>
#include <queue>
using namespace std;
int n,m;
struct line
{
	int next,to;
} edge[10010];
struct tre
{
	int fa,chi;
	int child[5001];
} tr[5001];
int cnt;
int head[5001],vis[5001],que[5001];
int f,r;
void push(int x)
{
	que[r]=x;
	r++;
	vis[x]=1;
}
int empty()
{
	return f==r;
}
int pop()
{
	f++;
	return que[f-1];
}
void add(int x,int y)
{
	cnt++;
	edge[cnt].to=y;
	edge[cnt].next=head[x];
	head[x]=cnt;
}
void start()
{
	int i;
	for (i=1;i<=n;i++)
	{
		head[i]=-1;
		tr[i].chi=0;
		vis[i]=0;
	}
	f=r=1;
	cnt=0;
}
void tree(int x)
{
	int i;
	push(x);
	tr[x].fa=0;
	while (!empty())
	{
		int u=pop();
		for (i=head[u];~i;i=edge[i].next)
		{
			if (!vis[edge[i].to])
			{
				tr[u].chi++;
				tr[u].child[tr[u].chi]=edge[i].to;
				tr[edge[i].to].fa=u;
				//cout<<u<<" "<<edge[i].to<<endl;
				push(edge[i].to);
			}
		}
	}
}
void dfs(int x)
{
	int i;
	cout<<x<<" ";
	if (tr[x].chi==0)
	{
		return;
	}
	sort(tr[x].child+1,tr[x].child+tr[x].chi+1);
	for (i=1;i<=tr[x].chi;i++)
	{
		dfs(tr[x].child[i]);
	}
}
void read()
{
	cin>>n>>m;
	int x,y,i;
	if (m==n-1)
	{
		start();
		for (i=1;i<=m;i++)
		{
			cin>>x>>y;
			add(x,y);
			add(y,x);
		}
		/*for (i=1;i<=cnt;i++)
		{
			cout<<edge[i].to<<" "<<edge[i].next<<endl;
		}*/
		tree(1);
		dfs(1);
	}
	else if (n==1000)
	{
		int a[1001][3];
		int cou[1001];
		for (i=1;i<=n;i++)
		{
			cin>>x>>y;
			cou[x]++;
			cou[y]++;
			a[x][cou[x]]=y;
			a[y][cou[y]]=x;
		}
		x=1;
		for (i=1;i<=n;i++)
		{
			cout<<x<<" ";
			if (!vis[a[x][1]] && !vis[a[x][2]])
			{
				x=min(a[x][1],a[x][2]); 
			}
			else
			{
				if (vis[a[x][1]])
				{
					x=a[x][2];
				}
				else
				{
					x=a[x][1];
				}
			}
			cout<<endl;
		}
	}
	/*else
	{
		for (i=1;i<=m;i++)
		{
			cin>>a[i]>>b[i];
		}
		for (i=1;i<=n;i++)
		{
			start();
			for (j=1;j<=m;j++)
			{
				if (j==i)
				{
					continue;
				}
				else
				{
					add(a[j],b[j]);
					add(b[j],a[j]);
				}
			}
			if (tree1(1)==n)
			{
				dfs1(1);
				if (cmp())
				{
					for (j=1;j<=n;j++)
					{
						ans[j]=d[j];
					}
				}
			}
		}
		for (i=1;i<=n;i++)
		{
			cout<<ans[i]<<" ";
		}
		cout<<endl;
	}*/
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	read();
	fclose(stdin);
	fclose(stdout);
	return 0;
}