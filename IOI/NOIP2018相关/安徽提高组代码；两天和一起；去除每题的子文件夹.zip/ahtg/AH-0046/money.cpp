#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>
#include <map>
#include <queue>
#include <stack>
using namespace std;
int n,cnt,t;
int a[101],b[101];
int map1[25001];
void push(int x)
{
	int i,j;
	cnt++;
	b[cnt]=a[x];
	for (i=1;i<a[1];i++)
	{
		if (a[x]*i>a[n])
		{
			break;
		}
		for (j=0;j<a[1];j++)
		{
			map1[(j+i*a[x])%a[1]]=min(map1[j]+i*a[x],map1[(j+i*a[x])%a[1]]);
		}
	}
}
int check(int x)
{
	return a[x]<map1[a[x]%a[1]];
}
void read()
{
	int i;
	cin>>t;
	while (t--)
	{
		cin>>n;
		cnt=0;
		for (i=0;i<=25000;i++)
		{
			map1[i]=999999;
		}
		for (i=1;i<=n;i++)
		{
			cin>>a[i];
		}
		sort(a+1,a+n+1);
		b[1]=a[1];
		cnt++;
		map1[0]=0;
		for (i=2;i<=n;i++)
		{
			if(check(i))
			{
				push(i);
				//cout<<a[i]<<" "<<map1[a[i]%a[1]]<<endl;
			}
		}
		cout<<cnt<<endl;
	}
	/*if (n==2)
	{
		if (a[2]%a[1]==0)
		{
			cout<<1<<endl;
		}
		else
		{
			cout<<2<<endl;
		}
	}
	else if (n==3) 
	{
		if (a[2]%a[1]==0)
		{
			if (a[3]%a[1]==0)
			{
				cout<<1<<endl;
			}
			else
			{
				cout<<2<<endl;
			}
		}
		else
		{
			
		}
	}*/
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read();
	fclose(stdin);
	fclose(stdout);
	return 0;
}