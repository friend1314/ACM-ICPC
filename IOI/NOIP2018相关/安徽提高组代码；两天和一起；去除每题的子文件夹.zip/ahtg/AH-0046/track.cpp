#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>
#include <map>
#include <queue>
#include <stack>
using namespace std;
struct edge
{
	int next,to,w;
} a[100001];
struct treee
{
	int chi,deep;
	int we[101],child[101];
} tree[30001];
struct dep
{
	int ne;
} de[30001];
int head[30001],head1[30001];
int vis[30001];
int n,m,cnt=0;
int fo=1,r=1;
int f[30001],g[30001];
int que[30001];
int c[50001];
void push(int x)
{
	que[r]=x;
	vis[x]=1;
	r++;
}
int pop()
{
	fo++;
	return que[fo-1];
}
int empty()
{
	return fo==r;
}
void add(int x,int y,int z)
{
	cnt++;
	a[cnt].to=y;
	a[cnt].w=z;
	a[cnt].next=head[x];
	head[x]=cnt;
}
void add1(int x,int y)
{
	de[y].ne=head1[x];
	head1[x]=y;
}
void read()
{
	cin>>n>>m;
	int bo=1;
	int i,j,k;
	for (i=0;i<=n;i++)
	{
		head[i]=head1[i]=-1;
		tree[i].chi=0;
	}
	int x,y,z;
	for (i=1;i<=n-1;i++)
	{
		cin>>x>>y>>z;
		c[x]=z;
		add(x,y,z);
		add(y,x,z);
		if (x!=y-1)
		{
			bo=0;
		}
	}
	if (m==1)
	{
		push(1);
		tree[1].deep=0;
		add1(0,1);
		int maxd=0;
		while (!empty())
		{
			int x=pop();
			for (i=head[x];~i;i=a[i].next)
			{
				if (!vis[a[i].to])
				{
					tree[x].chi++;
					tree[x].child[tree[i].chi]=a[i].to;
					tree[x].we[tree[i].chi]=a[i].w;
					//cout<<x<<" "<<tree[x].chi<<" "<<tree[x].we[tree[i].chi]<<endl;
					tree[a[i].to].deep=tree[x].deep+1;
					maxd=max(tree[a[i].to].deep,maxd);
					add1(tree[a[i].to].deep,a[i].to);
					push(a[i].to);
				}
			}
		}
		for (i=maxd;i>=0;i--)
		{
			for (j=head1[i];~j;j=de[j].ne)
			{
				//cout<<j<<" ";
				if (tree[j].chi==0)
				{
					f[i]=0;
					g[i]=0;
				}
				else if (tree[j].chi==1)
				{
					f[i]=f[tree[j].child[1]]+tree[j].we[1];
					g[i]=f[i];
				}
				else
				{
					int max1=0,max2=0;
					for (k=1;k<=tree[j].chi;k++)
					{
						//cout<<j<<" "<<k<<" "<<tree[j].we[k]<<endl;
						if (f[tree[j].child[k]]+tree[j].we[k]>max1)
						{
							max1=f[tree[j].child[k]]+tree[j].we[k];
							max2=max1;
						}
						else if(f[tree[j].child[k]]+tree[j].we[k]>max2)
						{
							max2=f[tree[j].child[k]]+tree[j].we[k];
						}
					}
					f[i]=max1;
					g[i]=max1+max2;
				}
			}
			//cout<<endl;
		}
		int max1=0;
		for (i=1;i<=n;i++)
		{
			max1=max(max1,g[i]);
			//cout<<f[i]<<" "<<g[i]<<endl;
		}
		cout<<max1<<endl;
	}
	else if (bo)
	{
		int l=1,b=500000000;
		int mid;
		while (l<b)
		{
			mid=(l+b+1)/2;
			int cou=0,sum=0;
			for (i=1;i<=n-1;i++)
			{
				sum+=c[i];
				if (sum>=mid)
				{
					sum=0;
					cou++;
				}
			}
			if (cou>=m)
			{
				l=mid;
			}
			else
			{
				b=mid-1;
			}
			//cout<<l<<" "<<b<<endl;
		}
		cout<<b<<endl;
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read();
	fclose(stdin);
	fclose(stdout);
	return 0;
}