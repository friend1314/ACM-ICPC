#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <algorithm>
#include <map>
#include <queue>
#include <stack>
using namespace std;
int n;
long long a[100010];
long long ans=0;
struct road
{
	long long num,h;
};
road r[100010];
int cmp(road x,road y)
{
	if (x.h!=y.h)
	{
		return x.h<y.h;
	}
	else
	{
		return x.num<y.num;
	}
}
void read()
{
	int i;
	cin>>n;
	for (i=1;i<=n;i++)
	{
		cin>>a[i];
		r[i].h=a[i];
		r[i].num=i;
		//if (a[i]==0)
			//cout<<a[i]<<" "<<i<<" ";
	}
	//cout<<endl;
	//cout<<a[5047]<<endl;
	a[0]=-1;
	a[n+1]=-1;
	sort(r+1,r+n+1,cmp);
	long long dh=0;
	long long cnt=1;
	for (i=1;i<=n;i++)
	{
		int x=r[i].num;
		//cout<<r[i].h<<' '<<a[x]<<endl;
		ans+=cnt*(r[i].h-dh);
		dh=r[i].h;
		if (a[x-1]-dh>0 && a[x+1]-dh>=0)
		{
			cnt++;
		}
		else if (a[x-1]-dh<=0 && a[x+1]-dh<0)
		{
			cnt--;
		}
		//cout<<x<<" "<<dh<<" "<<cnt<<endl;
	}
	cout<<ans<<endl;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read();
	fclose(stdin);
	fclose(stdout);
	return 0;
}