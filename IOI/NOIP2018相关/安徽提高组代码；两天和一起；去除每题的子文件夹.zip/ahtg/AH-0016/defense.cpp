#include <cstdio>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int m;
	scanf("%d",&m);
	scanf("%d",&m);
	int n=(int)time(0);
	srand(n);
	if(m>=10)
	for(int i=1;i<=m;i++)
	{
		n=(int)rand();
		n=n%1000000007;
		if(n%5==0)
		printf("-1\n");
		else
		{
			n=(int)rand();
			n=n%1000007;
			printf("%d\n",n);
		}
	}
	
	else
	for(int i=1;i<=m;i++)
	{
		n=(int)rand();
		n=n%1000000007;
		if(n%5==0)
		printf("-1\n");
		else
		{
			n=(int)rand();
			n=n%2007;
			printf("%d\n",n);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}