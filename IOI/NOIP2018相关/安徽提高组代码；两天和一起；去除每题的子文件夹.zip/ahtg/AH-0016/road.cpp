#include <cstdio>
#include <cstring>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,t;
	long long sum=0,k=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t);
		if(t>k)
		{
			sum+=(t-k);
			k=t;
		}
		else
		{
			k=t;
		}
	}
	if(sum<0)
		sum=sum*(-1);
	printf("%lld",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
