#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 105
#define inf 200000000
using namespace std;
int  T,n,m;
int a[N],b[N];
bool Cmp(int c,int d)
{
	for(int i=1;i<=m;i++)
	{
		if(c%b[i]==0)
			c=0;
		if(d%b[i]==0)
			d=0;
		if(c==0&&d==0)
			break;
	}
	if(c==0&&d==0)
		return true;
	else
		return false;
}
bool CMP(int c,int d,int e)
{
	for(int i=1;i<=m;i++)
	{
		if(c%b[i]==0)
			c=0;
		if(d%b[i]==0)
			d=0;
		if(e%b[i]==0)
			e=0;
		if(c==0&&d==0&&e==0)
			break;
	}
	if(c==0&&d==0&&e==0)
		return true;
	else
		return false;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T)
	{
		memset(a,inf,sizeof(a));
		T--;
		scanf("%d",&n);
		m=n;
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=inf)
			for(int j=1;j<i;j++)
			{
				if(a[j]!=inf&&a[i]%a[j]==0)
				{
					a[i]=inf;
					m--;
				}
			}
		}
		int k=0;
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=inf)
			{
				k++;
				b[k]=a[i];
			}
		}
		for(int i=2;i<=m;i++)
		{
			if(b[i]!=inf)
			for(int x=1;x<=b[i]/2;x++)
			{
				if(Cmp(x,b[i]-x))
				{
					k--;
					b[i]=inf;
					break;
				}
			}
		}
		bool flag;
		for(int i=2;i<=m;i++)
		{
			if(b[i]!=inf)
			for(int x=1;x<b[i];x++)
			{
				flag=false;
				for(int y=1;y<b[i];y++)
				{
					for(int z=1;z<b[i];z++)
					{
						if(x+y+z==b[i]&&CMP(x,y,z))
						{
							k--;
							b[i]=inf;
							flag=true;
							break;
						}
					}
					if(flag)
						break;
				}
				if(flag)
					break;
			}
		}
		printf("%d\n",k);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}