#include <ctime>
#include <cstdio>
#include <cstdlib>
#define N 111
using namespace std;
int JD(int a)
{
	if(a<0)
		return a*(-1);
	else
		return a;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	long long x;
	int n;
	scanf("%d",&n);
	x=(int)time(0);
	for(int i=1;i<=x%10;i++)
		x*=N;
	if(n<=100)
	printf("%d",JD((x%10000)-(x%100)+23)/100);
	else
	printf("%d",JD(x%100000));
	fclose(stdin);
	fclose(stdout);
	return 0;
}