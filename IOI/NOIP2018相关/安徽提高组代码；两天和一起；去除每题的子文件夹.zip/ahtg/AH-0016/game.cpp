#include <cstdio>
#include <cstdlib>
#include <ctime>
using namespace std;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n=(int)time(0);
	srand(n);
	n=(int)rand();
	n=n%10007;
	printf("%d",n);
	fclose(stdin);
	fclose(stdout);
	return 0;
}