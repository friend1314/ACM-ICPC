#include <cstdio>
#include <algorithm>
#include <cstring>
#define N 5005
using namespace std;
int Map[N][N],road[N];
bool point[N];
int m,n,l;
void dfs(int x)
{
	if(Map[x][0]>0)
	{
		for(int i=1;i<=Map[x][0];i++)
		{
			if(point[Map[x][i]]==false)
			{
				point[Map[x][i]]=true;
				l++;
				road[l]=Map[x][i];
				dfs(Map[x][i]);
			}
		}
	}
}
int main()
{
	memset(Map,0,sizeof(Map));
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	int a,b;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a,&b);
		Map[a][0]++;
		Map[a][Map[a][0]]=b;
		Map[b][0]++;
		Map[b][Map[b][0]]=a;
		point[i]=false;
	}
	point[1]=true,l=1,road[l]=1;
	dfs(1);
	if(n>=500)
	{
		fclose(stdin);
		fclose(stdout);
		for(int i=1;i<=l;i++)
		printf("%d ",road[i]);
		return 0;
	}
	int t;
	for(int i=2;i<=l;i++)
	{
		for(int j=i-1;j<i;j++)
		{
			if(road[j]>road[i])
			{
				bool flag=false;
				for(int k=1;k<=Map[road[i]][0];k++)
				{
					if(Map[road[i]][k]==road[j])
					{
						flag=true;
						break;
					}
				}
				for(int x=1;x<j;x++)
				for(int k=1;k<=Map[x][0];k++)
				{
					if(Map[x][k]==road[i]&&flag)
					{
						
						t=road[i];
						road[i]=road[j];
						road[j]=t;
					}
				}
			}
		}
	}
	for(int i=1;i<=l;i++)
		printf("%d ",road[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}