#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;

#define LL long long
#define REP(i, a, b) for(int i = a; i <= b; ++i)
#define PER(i, a, b) for(int i = a; i >= b; --i)

inline void setIO() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
}

inline void close() {
	fclose(stdin);
	fclose(stdout);
}

inline int read() {
	int x = 0, flag = 1;  char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <='9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * flag;
}

const int mod = 1e9 + 7;
const int N = 10;

LL g[N][2], ans, f[N];
int n, m;

inline void subtask1() {
	REP(i, 1, n) g[i][0] = 1;
	g[1][1] = 1; f[1] = 2;
	REP(i, 2, n) {
		g[i][1] = (1 + g[i - 1][1]) % mod;
		f[i] = (g[i][1] + 1) % mod;
	} 
	ans = 1;
	REP(i, 1, m) {
		if(i <= n - 1) ans = (ans * f[i] % mod *  f[i]) % mod;
		else ans = (ans * f[n]) % mod;
	}
	printf("%lld\n", ans);
}

int main() {
	setIO();
	n = read(); m = read();
	if(n <= 2) subtask1();
	else if(n == 3 && m <= 3) {
		if(m == 3) cout << 112 << endl;
		else if(m == 2) cout << 36 << endl;
		else if(m == 1) cout << 8 << endl;
	} else {
		if(n == 5 && m == 5) cout << 7136 << endl;
		else subtask1();
	}
	close();
	return 0;
}