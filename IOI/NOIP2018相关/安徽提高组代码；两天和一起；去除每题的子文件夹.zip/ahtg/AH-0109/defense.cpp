#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;

#define LL long long
#define REP(i, a, b) for(int i = a; i <= b; ++i)
#define PER(i, a, b) for(int i = a; i >= b; --i)

inline void setIO() {
	freopen("defense.in", "r", stdin);
	freopen("defense.out", "w", stdout);
}

inline void close() {
	fclose(stdin);
	fclose(stdout);
}

inline int read() {
	int x = 0, flag = 1;  char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <='9') {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * flag;
}

const int N = 1e5 + 5;
const long long INF = 0x7fffff;

struct edge {
	int next, to;
}e[N << 1];

string s;
int n, m, head[N], a, x, b, y, cnt, w[N], dep[N], c;
LL f[N][2], ans, g[N][2];
bool mu[N], ca[N];

inline void addedge(int u, int v) {
	e[++cnt].next = head[u]; e[cnt].to = v; head[u] = cnt;
}

inline void dfs(int x, int fa) {
	f[x][1] = w[x]; f[x][0] = 0;
	dep[x] = dep[fa] + 1;
	for(int i = head[x]; i; i = e[i].next) {
		int to = e[i].to;
		if(to == fa) continue;
		dfs(to, x);
		f[x][1] += min(f[to][1], f[to][0]);
		f[x][0] += f[to][1];
	}
	if(mu[x]) f[x][0] = INF;
	else if(ca[x]) f[x][1] = INF;
}

inline void subtask1() {
	REP(i, 1, m) {
		a = read(); x = read(); b = read(); y = read();
		if(x) mu[a] = true;
		else ca[a] = true;
		if(y) mu[b] = true;
		else ca[b] = true;
		dfs(1, 0);
		if(x) mu[a] = false;
		else ca[a] = false;
		if(y) mu[b] = false;
		else ca[b] =false;
		ans = min(f[1][0], f[1][1]);
		if(ans >= INF) printf("-1\n");
		else printf("%lld\n", ans);
	}
}

inline void dfs2(int x, int fa) {
	if(dep[x] > c) {
		f[x][1] = g[x][1];
		f[x][0] = g[x][0];
		return;
	}
	f[x][1] = w[x]; f[x][0] = 0;
	for(int i = head[x]; i; i = e[i].next) {
		int to = e[i].to;
		if(to == fa) continue;
		dfs(to, x);
		f[x][1] += min(f[to][1], f[to][0]);
		f[x][0] += f[to][1];
	}
	if(mu[x]) f[x][0] = INF;
	else if(ca[x]) f[x][1] = INF;
}

inline void subtask2() {
	dfs(1, 0);
	REP(i, 1, n) g[i][0] = f[i][0], g[i][1] = f[i][1];
	REP(i, 1, m) {
		a = read(); x = read(); b = read(); y = read();
		bool can = false;
		for(int i = head[a]; i; i = e[i].next) {
			if(e[i].to == b) {
				can = true; 
				break;
			}
		}
		if(can) {
			if(a & b || (!a & !b)) {
				cout << -1 << endl;
				continue;
			}
		}
		if(x) mu[a] = true;
		else ca[a] = true;
		if(y) mu[b] = true;
		else ca[b] = true;
		c = max(dep[a], dep[b]);
		dfs2(1, 0);
		if(x) mu[a] = false;
		else ca[a] = false;
		if(y) mu[b] = false;
		else ca[b] =false;
		ans = min(f[1][0], f[1][1]);
		if(ans >= INF) printf("-1\n");
		else printf("%lld\n", ans);
	}
}

int main() {
	setIO();
	n = read(); m = read(); cin >> s;
	REP(i, 1, n) w[i] = read();
	REP(i, 1, n - 1) {
		int x = read(), y = read();
		addedge(x, y); addedge(y, x);
	}
	if(n <= 2000) subtask1();
	else subtask2();
	close();
	return 0;
}
/*
5 3 C3
2 4 1 3 9
1 5
5 2
5 3
3 4
1 0 3 0
2 1 3 1
1 0 5 0
*/