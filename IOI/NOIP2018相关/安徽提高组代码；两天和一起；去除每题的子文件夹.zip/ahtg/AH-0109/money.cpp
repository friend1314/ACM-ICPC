#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
using namespace std;

#define LL long long
#define REP(i, a, b) for(int i = a; i <= b; ++i)
#define PER(i, a, b) for(int i = a; i >= b; --i)
#define re register

inline int read() {
	int x = 0, flag = 1; char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * flag;
}

inline void setIO() {
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
}

inline void close() {
	fclose(stdin);
	fclose(stdout);
}

const int M = 50000 + 5;
int a[M], b[M], n, m, d[M];

int main() {
	setIO();
	int T = read();
	while(T--) {
		memset(b, false, sizeof(b)); memset(d, 0, sizeof(d));
		n = read(); m = 0;
		for(register int i = 1; i <= n; ++i) a[i] = read(), m = max(m, a[i]);
		sort(a + 1, a + n + 1);
		b[0] = true;
		for(register int i = 1; i <= n; ++i)
			for(register int j = a[i]; j <= m; ++j) b[j] |= b[j - a[i]];
		int ans = 0; d[0] = true;
		for(register int j = 1; j <= m; ++j) {
			if(b[j] && !d[j]) {
				++ans;
				for(register int i = j; i <= m; ++i) d[i] |= d[i - j];
			}
		}
		printf("%d\n", ans);
	}
	close();
	return 0;
}
/*
2
4
3 19 10 6
5
11 29 13 19 17
*/