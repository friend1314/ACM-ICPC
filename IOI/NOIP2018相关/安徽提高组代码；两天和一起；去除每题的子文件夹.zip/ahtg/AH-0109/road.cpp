#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
#include <cmath>
using namespace std;

#define LL long long
#define REP(i, a, b) for(int i = a; i <= b; ++i)
#define PER(i, a, b) for(int i = a; i >= b; --i)
#define re register

inline int read() {
	int x = 0, flag = 1; char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * flag;
}

inline void setIO() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
}

inline void close() {
	fclose(stdin);
	fclose(stdout);
}

const int N = 1e5 + 5;
int a[N], n, pw;
int st[N][18], id[N][18], lg[N];

inline int query(int l, int r) {
	int len = lg[r - l + 1], _len = 1 << len;
	if(st[l][len] < st[r - _len + 1][len]) return id[l][len];
	else return id[r - _len + 1][len];
}

inline int doit(int l, int r, int k) {
	if(l > r) return 0;
	if(l == r) return a[l] - k;
	int mid = query(l, r);
	return a[mid] - k + doit(l, mid - 1, a[mid]) + doit(mid + 1, r, a[mid]);
}

int main() {
	setIO();
	n = read(); lg[1] = 0; lg[2] = 1; pw = 4;
	for(register int i = 3; i <= n; ++i) {
		lg[i] = lg[i - 1];
		if(i % pw == 0) pw = pw * 2, ++lg[i];
	}
	
	for(register int i = 1; i <= n; ++i) a[i] = read(), st[i][0] = a[i], id[i][0] = i;
	for(register int j = 1; j < 18; ++j)
		for(register int i = 1; i + (1 << j) - 1<= n; ++i) {
			int _j = 1 << (j - 1);
			if(st[i][j - 1] < st[i + _j][j - 1]) id[i][j] = id[i][j - 1];
			else id[i][j] = id[i + _j][j - 1];
			st[i][j] = min(st[i][j - 1], st[i + _j][j - 1]);
		}
	printf("%d\n", doit(1, n, 0));
	close();
	return 0;
}
/*
6
4 3 2 5 3 5
*/