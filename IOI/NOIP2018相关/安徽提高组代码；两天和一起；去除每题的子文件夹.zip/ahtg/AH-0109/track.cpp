#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
using namespace std;

#define LL long long
#define REP(i, a, b) for(int i = a; i <= b; ++i)
#define PER(i, a, b) for(int i = a; i >= b; --i)
#define re register

inline int read() {
	int x = 0, flag = 1; char ch = getchar();
	while(!isdigit(ch)) {
		if(ch == '-') flag = -1;
		ch = getchar();
	}
	while(isdigit(ch)) {
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * flag;
}

inline void setIO() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
}

inline void close() {
	fclose(stdin);
	fclose(stdout);
}

const int N = 1e5 + 5;
struct edge {
	int next, to, w;
}e[N];
int head[N], n, m, cnt, a[N], num, f[N], minn, mx[N], se[N];
LL sum = 0;
bool sub1 = true, sub2 = true, sub3 = true;

inline void addedge(int u, int v, int w) {
	e[++cnt].next = head[u]; e[cnt].to = v; e[cnt].w = w; head[u] = cnt;
}

inline void subtask1() {
	for(int i = head[1]; i; i = e[i].next) a[++num] = e[i].w;
	sort(a + 1, a + num + 1);
	printf("%d\n", a[num - m + 1]);
}

inline void dfs2(int x, int fa) {
	for(int i = head[x]; i; i = e[i].next) {
		int to = e[i].to;
		if(to == fa) continue;
		f[x] = e[i].w;
		dfs2(to, x);
	}
}

inline int check(int x) {
	int res = 0, count = 0;
	for(int i = 1; i < n; ++i) {
		res = res + f[i];
		if(res >= x) {
			count++;
			res = 0;
		}
	}
	return count;
}

inline void subtask2() {
	dfs2(1, 0);
	int l = minn, r = sum;
	int ans = 0;
	while(l < r) {
		int mid = (l + r) >> 1;
		if(check(mid) >= m) ans = mid, l = mid + 1;
		else r = mid - 1;
	}
	printf("%d\n", ans);
}



inline void chk(int &x, int &y, int z) {
	if(z > x) {
		y = x; x = z;
	} else if(z > y) y = z;
}

inline void dfs3(int x, int fa) {
	for(int i = head[x]; i; i = e[i].next) {
		int to = e[i].to;
		if(to == fa) continue;
		dfs3(to, x);
		chk(mx[x], se[x], mx[to] + e[i].w); 
	}
}

inline void subtask3() {
	dfs3(1, 0);
	int ans = 0;
	for(int i = 1; i <= n; ++i) ans = max(ans, mx[i] + se[i]);
	printf("%d\n", ans);
}

int main() {
	setIO();
	n = read(); m = read(); if(m != 1) sub3 = false;
	REP(i, 1, n - 1) {
		int x = read(), y = read(), z = read();
		if(x > y) swap(x, y);
		addedge(x, y, z); addedge(y, x, z); sum += z; 
		if(x != 1) sub1 = false;
		if(y != x + 1) sub2 = false;
	}
	if(sub1) subtask1();
	else if(sub2) subtask2();
	else subtask3();
	close();
	return 0;
}
/*
7 1
1 2 10
1 3 5
2 4 9
2 5 8
3 6 6
3 7 7
*/