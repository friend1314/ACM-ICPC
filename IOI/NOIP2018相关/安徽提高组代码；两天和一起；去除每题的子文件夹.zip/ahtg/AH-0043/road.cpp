#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n;
long long ans,a[100003],cnt;
int main()
{
 freopen("road.in","r",stdin);
 freopen("road.out","w",stdout);
  scanf("%d",&n);
  for (int i=1;i<=n;++i) scanf("%lld",&a[i]);
  ans=a[1]; cnt=a[1];
  for (int i=2;i<=n;++i)
  {
   if (a[i]<=cnt) {cnt=a[i]; continue;}
   ans+=a[i]-cnt; cnt=a[i];   
  }
  cout<<ans;
 fclose(stdin); fclose(stdout);
 return 0;	
}