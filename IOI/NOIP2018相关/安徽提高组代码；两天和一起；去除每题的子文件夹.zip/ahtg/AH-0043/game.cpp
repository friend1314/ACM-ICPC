#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define MOD 1000000007
using namespace std;
typedef long long ll;
ll ans,res;
int n,m;
inline ll quickpow(int x,int k)
{
 res=1;
 while (k)
 {
  if (k&1) res=res*x%MOD;
  x=x*x%MOD;
  k>>=1;
 } 
 return res%MOD;
}
int main()
{
 freopen("game.in","r",stdin);
 freopen("game.out","w",stdout);
  scanf("%d%d",&n,&m);
  ans=1;
  bool flag=false;
  if (n==1||m==1) cout<<ans,flag=true;
  if (flag==false&&n==2)
  {
   ans=(quickpow(2,m)%MOD+quickpow(2,m+1)%MOD)%MOD;
   cout<<ans;
  }
 fclose(stdin); fclose(stdout);	
 return 0;
}