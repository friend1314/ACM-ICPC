#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct node{int num,next,w;}e[60003];
inline bool cmp(int a,int b){return a>b;}
int cnt,a[30003],n,m,l[30003];
int x,y,z;
bool flag1,flag2;
int k,t;
long long s,vv,ll,r,ans,mid;
inline bool check(long long x)
{
 vv=0; cnt=0;
 for (int i=1;i<=k;++i)
 {
  vv+=l[i];
  if (vv>=x) ++cnt,vv=0; 	 
 }
 if (cnt>=m) return true;else return false;
}
inline void add(int x,int y,int z)
{
 e[++cnt].num=y; e[cnt].next=a[x]; a[x]=cnt; e[cnt].w=z;	
}
inline void solve1()
{
 cnt=0;
 for (int i=a[1];i;i=e[i].next) l[++cnt]=e[i].w;
 sort(l+1,l+1+cnt,cmp);
 printf("%d",l[m]);
}
inline void solve2()
{
 ll=0; r=s; 
 k=0; t=1;
 while (t<n) 
 {
  l[++k]=e[a[t]].w;
  ++t;
 }
 while (ll<=r) 
 {
  mid=(ll+r)>>1;
  if (check(mid)==true) {ll=mid+1; ans=mid;} else r=mid-1;
 }
 printf("%lld",ans);
}
int main()
{
 freopen("track.in","r",stdin);
 freopen("track.out","w",stdout);
 scanf("%d%d",&n,&m);
 flag1=false;
 flag2=false;
 cnt=0; s=0;
 memset(a,0,sizeof(a));
 for (int i=1;i<=n-1;++i)
 {
  scanf("%d%d%d",&x,&y,&z);
  add(x,y,z);
  add(y,x,z);
  s+=z;
  if (x!=1) flag1=true;
  if (y!=x+1) flag2=true;
 }
 if (flag1==false) solve1();
 if (flag2==false) solve2();
 
 fclose(stdin); fclose(stdout);
 return 0;	
}