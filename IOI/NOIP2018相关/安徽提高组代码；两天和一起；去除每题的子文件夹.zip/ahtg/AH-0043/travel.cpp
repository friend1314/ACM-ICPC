#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
bool flag[5003],f[5003][5003],ff;
int n,m;
int x,y,root;
int vis[5003],k,st,sto,fat[5003],ord,d[5003],v[5003],ans[5003],kk;
inline void dfs(int x)
{
 flag[x]=true;
 //printf("%d ",x);
 v[++kk]=x; 
 for (int i=1;i<=n;++i)
 {
  if (f[x][i]==false||flag[i]==true) continue; 
  dfs(i);	  
 }
}
inline void _find(int x,int fa)
{
 if (ff==true) return;
 fat[x]=fa;
 //d[x]=d[fa]+1;
 flag[x]=true;
 vis[++k]=x;
 for (int i=1;i<=n;++i)	
 { 
  if (f[x][i]==true&&i==fa) continue;
  if (f[x][i]==true&&flag[i]==true&&i!=fa)
  {
   ff=true;
   st=x;
   return;
  }
  if (f[x][i]==true) _find(i,x);
 }
}
int main()
{
 freopen("travel.in","r",stdin);
 freopen("travel.out","w",stdout);
  scanf("%d%d",&n,&m); 
  memset(f,false,sizeof(f)); 
  memset(flag,false,sizeof(flag)); 
  root=n+1;
   //cout<<342342<<endl;
  if (m==n-1)
  {
   for (int i=1;i<=m;++i)
   {
    scanf("%d%d",&x,&y);
    f[x][y]=true; f[y][x]=true;
    root=min(x,root); root=min(y,root);
   }
    kk=0;
	dfs(root);
    for (int j=1;j<=kk;++j) printf("%d ",v[j]);
  }
  if (m==n)
  {
    memset(f,false,sizeof(f)); 
  memset(flag,false,sizeof(flag)); 
  for (int i=1;i<=m;++i)
   {
    scanf("%d%d",&x,&y);
    f[x][y]=true; f[y][x]=true;
    root=min(x,root); root=min(y,root);
   }

  ff=false;
  k=0; 
  _find(root,root);
  //for (int i=1;i<=k;++i) cout<<vis[i]<<' ';
  //cout<<endl<st<<endl;
  //cout<<endl;
  //cout<<st<<endl;
  sto=n+1; 
  //for (int i=1;i<=k;++i) if (f[st][vis[i]]==true&&fat[st]!=vis[i]) {sto=min(sto,vis[i]);}
  //cout<<sto<<endl;
  for (int i=1;i<=k;++i) if (vis[i]==st) {ord=i; break;}
  //f[sto][vis[ord+1]]=false; f[vis[ord+1]][sto]=false;
  bool ffk=false;
  int fk=0;
  /*for (int i=ord;i<=k;++i)
  {
   for (int j=1;j<vis[i+1];++j)
   {
	if ((f[vis[i]][j]==true)&&fat[vis[i]]!=j) {ffk=true; fk=i; break;}   
    }
  if (ffk==true) break;
  if (d[vis[i]]>=d[vis[i+1]]) {ffk=true; fk=i; break; }
  }*/
  //cout<<f[64][67]<<endl;
  //if (ffk==false) fk=k;
  //cout<<vis[fk]<<endl;
  //cout<<fk<<endl;
  //cout<<d[4]<<endl;
  //f[vis[fk]][vis[fk+1]]=false; f[vis[fk+1]][vis[fk]]=false; 
  memset(flag,false,sizeof(flag));
  for (int i=1;i<=n;++i) ans[i]=n+1;
  kk=0;
  for (int i=ord;i<=k-1;++i)
  {
   memset(v,0,sizeof(v));
   f[vis[i]][vis[i+1]]=false; f[vis[i+1]][vis[i]]=false;
   kk=0;
   memset(flag,false,sizeof(flag));
   dfs(root);
   ffk=true;
   //for (int j=1;j<=kk;++j) cout<<v[j]<<' ';
   //cout<<endl;
   for (int j=1;j<=kk;++j) 
   {
	if (ans[j]<v[j]) {ffk=false; break;} 
    if (v[j]<ans[j]) break;
	}
   if (ffk==true) for (int j=1;j<=kk;++j) ans[j]=v[j];
   f[vis[i]][vis[i+1]]=true; f[vis[i+1]][vis[i]]=true;
   }
   for (int i=1;i<=n;++i) printf("%d ",ans[i]);
  }
 fclose(stdin); fclose(stdout);
 return 0;
}