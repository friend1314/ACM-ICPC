#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int T;
int n,a[103],g[103][103],v[103];
bool f[103];
int x,y,t;
int ans,cnt,cntt,vv;
int d;
bool flag;
int gcd(int x,int y)
{
 if (x%y==0) return y; else return gcd(y,x%y);	
}
void dfs(int x)
{
 if (vv==a[t]) {flag=true; return;}
 if (flag==true) return;
 for (int i=0;i<=t/x;++i)
 {
  vv+=i*a[v[x]];
  if (x<d) dfs(x+1);	 
  vv-=i*a[v[x]];
 }
}
int main()
{
 freopen("money.in","r",stdin);
 freopen("money.out","w",stdout);
  scanf("%d",&T);
 while (T--)
 {
  scanf("%d",&n);
  if (n==1) {cout<<1<<endl; continue;}
  for (int i=1;i<=n;++i) scanf("%d",&a[i]);
  sort(a+1,a+1+n);
  //for (int i=1;i<=n;++i) cout<<a[i]<<' '; cout<<endl;
  for (int i=1;i<=n;++i) for (int j=1;j<=n;++j) if (i!=j) g[i][j]=gcd(a[i],a[j]);
  memset(f,false,sizeof(f));
  for (int i=1;i<=n;++i) 
   for (int j=1;j<i;++j)
    if (i!=j&&(g[i][j]==a[j])) f[i]=true;
  cnt=0; 
  //for (int i=1;i<=n;++i) {for (int j=1;j<=n;++j) cout<<g[i][j]<<' '; cout<<endl;}
  for (int i=1;i<=n;++i) if (f[i]==false) v[++cnt]=i;
  //for (int i=1;i<=cnt;++i) cout<<v[i]<<' ';
  //memset(flag,false,sizeof(flag));
  //cout<<a[3]<<endl;
 flag=false;
  for (int i=1;i<=n;++i)
  {
   for (int j=1;j<i;++j)
	if (g[i][j]==1&&f[i]!=true&&f[j]!=true) {x=a[i]; y=a[j];  flag=true; break;}
  if (flag==true) break;
  }
  //cout<<x<<' '<<y<<endl;
  cntt=cnt;
  for (int i=cntt;i>=1;--i) if (v[i]>(x*y-x-y)) {--cnt;} else break;
  ans=cnt;
  for (int i=2;i<=cnt;++i)
  {
   t=v[i]; vv=0; d=i;
   flag=false;
   dfs(1);
   if (flag==true) --ans;
  }
  printf("%d\n",ans);
 }
 fclose(stdin); fclose(stdout);
 return 0;
}