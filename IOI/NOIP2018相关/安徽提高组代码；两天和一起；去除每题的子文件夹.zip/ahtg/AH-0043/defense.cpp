#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define INF 10000000000000
using namespace std;
int n,m;
long long f[100003][4];
string s;
bool ff;
int x,y,a,b,u,v;
int p[100003];
int flag[100003];
int main()
{
 freopen("defense.in","r",stdin);
 freopen("defense.out","w",stdout);
  cin>>n>>m>>s;
  scanf("\n");
  if (s[0]=='A')
  {
   for (int i=1;i<=n;++i) scanf("%d",&p[i]);
   memset(flag,0,sizeof(flag));
   for (int i=1;i<=n-1;++i) scanf("%d%d",&u,&v);
   for (int i=1;i<=m;++i) 
   {
    memset(flag,0,sizeof(flag));
	scanf("%d%d%d%d",&a,&x,&b,&y);
	flag[a]=x+1; flag[b]=y+1;
   
   memset(f,0,sizeof(f));
   if (flag[1]==1) f[1][1]=INF,f[1][0]=INF;
   if (flag[1]==2) f[1][1]=p[1],f[1][0]=INF;
   if (flag[1]==0) f[1][1]=p[1],f[1][0]=0;
   bool ff=true;
   for (int i=2;i<=n;++i)
   {
	if (flag[i]==1) {f[i][1]=INF; f[i][0]=f[i-1][1];}   
    if (flag[i]==2) {f[i][0]=INF; f[i][1]=min(f[i-1][1],f[i-1][0])+p[i];}
	if (flag[i]==0)
	{
	 f[i][0]=f[i-1][1];
	 f[i][1]=min(f[i-1][1],f[i-1][0])+p[i];	
	}
	if (f[i][0]>=INF&&f[i][1]>=INF) {cout<<-1<<endl; ff=false; break;}
    }
	if (ff==false) continue;
	printf("%lld\n",min(f[n][0],f[n][1]));
   }
  }
 fclose(stdin); fclose(stdout);	
 return 0;	
}