#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int i,j,x,y,w[5005][3],z=0,a[5005]={0},zzz=1;
	scanf("%d%d",&x,&y);
	for(i=1;i<=y;i++)
	{
		for(j=1;j<=2;j++)
		{
			scanf("%d",&w[i][j]);
			for(int k=1;k<=x;k++)
			{
				if(w[i][j]==a[k])
				z=1;
				}
				if(z==0)
				{a[zzz]=w[i][j];zzz++;}
				z=0;
			}
		}
		for(i=1;i<=x;i++)
		{
			printf("%d ",a[i]);
			}
			printf("\n");
			fclose(stdin);
			fclose(stdout);
		return 0;
	}