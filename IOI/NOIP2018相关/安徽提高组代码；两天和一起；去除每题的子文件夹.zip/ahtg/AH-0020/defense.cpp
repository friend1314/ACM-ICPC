#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,m,u,v,a,x,b,y,pi;
	string type;
	scanf("%d%d%s",&n,&m,&type);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&pi);
		}
		for(int i=1;i<=n-1;i++)
		{
			scanf("%d%d",&u,&v);
			}
			for(int i=1;i<=m;i++)
			{
				scanf("%d%d%d%d",&a,&x,&b,&y);
				}
				for(int i=1;i<=m;i++)
				{
					printf("-1\n");
					}
					fclose(stdin);
					fclose(stdout);
					return 0;
	}