#include<cstdio>
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,m;
	long long ans;
	scanf("%d%d",&n,&m);
	ans=n*m;
	for(int i=0;n-i>=0)
		an+=(n-i)*m%1000000007;
	for(int i=0;m-i>=0)
		ans+=(m-i)*n%1000000007;
	printf("%d",ans%1000000007);
	return 0;
}
