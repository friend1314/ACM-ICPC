#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int m,n,q,ac;
int city[5010][3];
bool used[5010];
int c_g[5010];

void add_num(int num){
	if(num!=0)
	for(int i=q;i>=ac;i++){
		if(i!=0)
			i--;
		if(c_g[i]>num)
			c_g[i+1]=c_g[i];
		else{
			c_g[i+1]=num;break;
		}
	}
}

int cre(int num){
	if(ac+1==n)
		return 0;
	for(int i=0;i<3;i++){
		if(used[num])
			continue;
		add_num(city[num][i]);
		q++;
	}
	printf(" %d",c_g[ac]);
	used[c_g[ac]]=1;ac++;
	cre(c_g[ac]);
	return 0;
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<m;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		for(int c=0;c<3;c++){
			if(city[a][c]!=0)
				continue;
			city[a][c]=b;
			break;
		}
		for(int c=0;c<3;c++)
			if(city[b][c]!=0){
				continue;
			city[b][c]=a;
			break;
		}
	}
	printf("1");used[1]=1;used[0]=1;
	cre(1);
	return 0;
}
