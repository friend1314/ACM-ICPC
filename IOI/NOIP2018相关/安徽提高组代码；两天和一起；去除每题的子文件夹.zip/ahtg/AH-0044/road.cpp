#include<cstdio>
#include<iostream>
using namespace std;
int n,q,maxt,mint=99999;
int road[100000][2];
int ans=0;

int ac_plus(int a,int i){
	if(i!=0&&i!=n-1)
		a++;
	return a;
}

bool cre(){
	if(maxt<mint)
		return false;
	int ac=0;
	for(int i=0;i<n;i++){
		if(road[i][0]==mint){
			int j=i+1;
			for(;j<n;){
				if(road[j][0]==mint){
					j++;
					continue;
				}
				else if(road[j][1]!=0){
					j=road[j][1];
					continue;
				}
				break;
			}
			road[i][1]=j;
			ac=ac_plus(ac,i);
			i=j;
		}
		else if(road[i][1]!=0){
			int j=road[i][1];
			for(;;){
				if(road[j][1]!=0)
					j=road[j][1];
				else if(road[j][0]==mint)
					j++;
				else
					break;
			}
			road[i][1]=j;
			ac=ac_plus(ac,i);
			i=j;
		}
	}
	ans+=ac;
	mint++;
	return true;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;++i){
		scanf("%d",&road[i][0]);
		maxt=max(road[i][0],maxt);
		mint=min(road[i][0],mint);
	}
	ans=mint;
	for(;cre();ans++);
	printf("%d",ans-1);
	return 0;
}
