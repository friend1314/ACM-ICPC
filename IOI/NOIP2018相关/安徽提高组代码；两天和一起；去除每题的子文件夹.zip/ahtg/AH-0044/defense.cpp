#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<vector>
using namespace std;
int n,m,cost[100000000];
string type;

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	cin>>type;
	for(int i=1;i<=n;i++)
		scanf("%d",&cost[i]);
	for(int t=0;t<m;t++)
		scanf("%d%d%d%d",&x,&a,&y,&b);
		printf("-1\n");
	return 0;
}
