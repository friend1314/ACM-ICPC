#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
int t,n,q,ans,cash[100],cash2[100];

void prime(){
	for(int i=n-1;i>=0;i--){
		bool check=1;
		for(int j=i-1;j>=0;j--){
			if(cash[j]*cash[j]>cash[i])
				break;
			if(cash[i]%cash[j]==0){
				check=0;break;
			}
		}
		if(check){
			cash2[q]=cash[i];
			q++;
		}
	}
}

void cre(){
	for(int i=0;i<q;i++){
		int check=1;
		for(int j=i+1;j<q;j++){
			int num=cash2[i]-cash2[j];
			for(int k=q-1;k>=i+1;k++){
				if(cash2[k]*cash2[k]>num)
					break;
				if(num%cash2[k]==0){
					check=0;break;
				}
			}
			if(!check){
				ans--;break;
			}
		}
	}
}

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(;t>0;t--){
		q=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++)
			scanf("%d",&cash[i]);
		sort(cash,cash+n);
		prime();ans=q;
		cre();
		printf("%d\n",ans);
	}
	return 0;
}
