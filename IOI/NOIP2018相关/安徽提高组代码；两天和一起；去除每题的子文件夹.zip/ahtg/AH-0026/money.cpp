#include<bits/stdc++.h>
using namespace std;
int T,n;
int a[106];
int i,j,p;
int prime[25006];
int cnt[25006];
int maxn=0;
int t;
int ans=0;
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(p=1;p<=T;p++){
		scanf("%d",&n);
		memset(prime,0,sizeof(prime));
		memset(cnt,0,sizeof(cnt));
		maxn=0;
		ans=0;
		t=0;
		for(i=1;i<=n;i++){
			scanf("%d",&a[i]);
			maxn=max(maxn,a[i]);
			cnt[a[i]]=1;
		}
		for(i=1;i<=maxn;i++){
			if(cnt[i]==1){
				prime[++t]=i;
				for(j=1;i+prime[j]<=maxn&&j<=t;j++){
					cnt[i+prime[j]]=1;
				}
			}
		}
		for(i=1;i<=t;i++){
			if(cnt[prime[i]]==1){
				for(j=1;prime[i]+prime[j]<=maxn&&j<=t;j++){
					cnt[prime[i]+prime[j]]=0;
				}
			}
		}
		for(i=1;i<=maxn;i++){
			if(cnt[i]==1){
				ans++;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}