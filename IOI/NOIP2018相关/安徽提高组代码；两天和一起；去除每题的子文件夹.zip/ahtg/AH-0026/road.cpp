#include<bits/stdc++.h>
using namespace std;
int n;
int i;
int a[100006];
int maxn=0;
int j;
long long int ans=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
		maxn=max(maxn,a[i]);
	}
	for(i=1;i<=n;i++){
		if(a[i]>a[i+1]){
			ans=ans+a[i]-a[i+1];
		}
	}
	cout<<ans<<endl;
	return 0;
}
