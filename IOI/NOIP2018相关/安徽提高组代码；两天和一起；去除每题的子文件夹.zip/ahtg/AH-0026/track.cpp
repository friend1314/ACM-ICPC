#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[130006],b[130006],c[130006];
int i;
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++){
		scanf("%d%d%d",&a[i],&b[i],&c[i]);
	}
	sort(c+1,c+n+1);
	cout<<c[n]+c[n-1];
	return 0;
}