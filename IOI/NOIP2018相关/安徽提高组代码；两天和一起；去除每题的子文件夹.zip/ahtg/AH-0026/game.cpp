#include<bits/stdc++.h>
using namespace std;
int n,m;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	cout<<"12"<<endl;
}