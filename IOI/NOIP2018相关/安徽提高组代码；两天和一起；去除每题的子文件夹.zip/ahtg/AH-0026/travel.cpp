#include<bits/stdc++.h>
using namespace std;
bool G[5006][5006];
int n,m;
int x,y;
int a[5006];
int vis[5006];
int t;
void dfs(int root){
	a[++t]=root;
	if(t==n){
		for(int i=1;i<=n;i++){
			cout<<a[i]<<" ";
		}
		exit(0);
	}
	for(int i=1;i<=n;i++){
		if(G[root][i]==1&&root!=i){
			if(vis[i]==0){
				vis[i]=1;
				dfs(i);
			}
		}
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		G[x][y]=1;
		G[y][x]=1;
	}
	vis[1]=1;
	dfs(1);
	return 0;
}