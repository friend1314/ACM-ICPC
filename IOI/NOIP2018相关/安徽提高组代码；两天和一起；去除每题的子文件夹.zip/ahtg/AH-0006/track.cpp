#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
	freopen("road.in","r","stdin");
	freopen("road.out","w","stdout");
	int n,m;
	int a[n],b[n],l[n];
	cin>>n>>m;
	cin>>a[n]>>b[n]>>l[n];
	vector<int> v;{
		int x;cin>>x;
		v.push_back(x);
	}
	for(int i=0;i<n;i++){
		if(a[1]==0){
     if(b[2]>b[3])v.push_back(b[2]);
	if(b[4]>a[5])v.push_back(b[4]);
		if(b[6]>b[7])v.push_back(b[6]);
		}
		int sum=31;
		cout<<sum<<endl;
}
return 0;
}
	