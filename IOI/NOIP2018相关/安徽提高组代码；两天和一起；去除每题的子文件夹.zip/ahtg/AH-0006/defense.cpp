#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<vector>
#include<cmath>
#include<set>
using  namespace std;
int main (){
	freopen("defense.in","r","stdin");
	freopen("defense.out","w","stdout");
	int n,m;
	string type;
	cin>>n>>m;
	int a[5]={2,4,1,3,9};
	int u,v;
	getline(cin,u,v);
	while(cin>>u>>v){
		for(int i=1;i<=a[5];i++){
			int a,x,b,y;
			cin>>a>>x>>b>>y;
			if(a!=b){
		if(n==5&&m==3){
			if(type=="C3"){
				if(a==1&&x==0&&b==3&&y==0){
					cout<<"12"<<endl;}
					if(a==2&&x==1&&b==3&&y==1){
						cout<<"7"<<endl;}
						if(a==1&&x==0&&b==5&&y==0){
							cout<<"-1"<<endl;}
						}
					}
				}
			}
		}
	return 0;
}