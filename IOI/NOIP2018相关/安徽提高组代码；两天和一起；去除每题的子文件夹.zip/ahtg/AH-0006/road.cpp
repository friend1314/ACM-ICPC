#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
	freopen("road.in","r","stdin");
	freopen("road.out","w","stdout");
	string a;
    int n;
	cin>>n;
	int a[n];
	cin>>a[n];
	int s1=0;int s2=0;	
	int pos=0;
	for(int i=0;i<n;i++){
	if(i>=pos){s1=pos;}
	vector<int> v;{
	int x;
	cin>>x;
	v.push_back(x);}
	v.push_back(i);
	sort(a.begin(),a.end());
	reverse(a.begin(),a.end());
   pos=*min_element(a.begin(),a.end());
	if(i>=pos){s2=pos+s1;};
	if(a[9]>=pos){s2=pos+s1;};
	if(a[8]>=pos){s2=pos+s1;};
	if(a[7]>=pos){s2=pos+s1;};
	if(a[6]>=pos){s2=pos+s1;};
	if(a[5]>=pos){s2=pos+s1;};
	if(a[4]>=pos){s2=pos+s1;};
	if(a[3]>=pos){s2=pos+s1;};
    if(a[2]>=pos){s2=pos+s1; }
	if(a[1]>=pos){s2=pos+s1;}
	   cout<<s2<<" ";
	}
	cout<<endl;
	return 0;
}