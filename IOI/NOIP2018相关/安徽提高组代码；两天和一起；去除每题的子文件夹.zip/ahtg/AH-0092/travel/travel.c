#include<stdio.h>
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,i;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		printf("%d ",i);
	fclose(stdin);
	fclose(stdout);
	return 0;
}