#include<stdio.h>
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,i,k=0;
        scanf("%d",&n);
        if (n%2==1)
          for(i=2;i<=n;i=i+2)
              k=k+i;
        else
          for(i=1;i<=n;i=i+2)
              k=k+i;
	printf("%d",k);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
