#include<stdio.h>
int main()
{
	freopen("strack.in","r",stdin);
	freopen("strack.out","w",stdout);
	int m,n,w;
	int r[50000][3];
	int i,j,k;
	int s[3];
    int max=0;
	scanf("%d%d",&m,&n);
	for(i=0;i<n;i++);
		for(j=1;j<3;j++)
		 scanf("%d",&r[i][j]);
		if(n==1)
		{for(i=0;i<n;i++)
		{s[0]=r[i][0];
		s[1]=r[i][1];
		s[2]=r[i][2];}
 
	for(k=0;k<2;k++);
		for(i=0;i<n;i++)
		{if(s[i]==r[i][0])
				{s[2]=s[2]+r[j][2];
					s[k]=r[i][2];}
				else if(s[k]==r[i][1])
				{s[2]=s[2]+r[j][2];
					s[k]=r[j][0];}
	    if(max<s[2])
		{
			w=s[2];
			max=s[2];
	     }
	     }}
 printf("%d",max);
				 
				
				
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}