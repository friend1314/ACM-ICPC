#include<stdio.h>
int  d[100010];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int  n;
	int i,j,k;
	long long day=0;
	int num=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d",&d[i]);
	i=0;
	while(d[n-1]!=0)
	   {
	   if(d[i]!=0)
	   {
		for(j=i;j<n;j++)
			if(d[j]!=0)
			num++;
		    else break;
		    for(k=i;k<i+num;k++)
			d[k]=d[k]-1;
		    num=0;
		    day--;
	    }
		else i++;
		}
	printf("%lld",day);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 