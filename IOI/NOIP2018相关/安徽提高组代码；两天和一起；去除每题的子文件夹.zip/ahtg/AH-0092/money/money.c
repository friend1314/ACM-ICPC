#include<stdio.h>
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	int n[21];
	int a[21][6];
	int i,j,k,x,y,u,p;
	int sum;
	int max;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d",&n[i]);
	    for(j=0;j<n[i];j++)
		scanf("%d",&a[i][j]);
	}
	 	for(i=0;i<t;i++)
	{
		if(n[i]==2)
		{   
			if(a[i][0]%a[i][1]==0||a[i][1]%a[i][0]==0)
				printf("1\n");
			else
			printf("2\n");
		}
		else 
		{  sum=n[i];
			for(j=0;j<n[i];j++)
				for(k=0;k<n[j];k++)
				if(j!=k)	
				  if(a[i][j]%a[i][k]==0)
				    	sum--;
		     for(x=0;x<n[i];x++)
				for(y=0;y<n[j];y++)
				{max=n[i]*n[j]-n[i]-n[j];
				for(u=0;u<n[i];u++)
					for(p=0;p<n[i];p++)
					if (a[u][p]>=max)
						sum--;}
		 
					
			printf("%d\n",sum);
	   }
   }
	fclose(stdin);
	fclose(stdout);
	return 0;
 }