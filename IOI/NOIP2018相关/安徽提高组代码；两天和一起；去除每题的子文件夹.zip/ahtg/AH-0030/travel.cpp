#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<ctime>
#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<set>
using namespace std;
#define ll long long
#define ull unsigned long long

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}

inline void out(int x)
{
	if (x<0) {putchar('-');x=-x;}
	if (x>9) out(x/10);
	putchar(x%10+48);
}
inline void write(int x) {out(x);putchar(' ');}
inline void writeln(int x) {out(x);putchar('\n');}

int ans[5001],head[5001],n,m,vis[5001],cnt,d[5001][5001],x,y;

struct eg
{
	int to,nxt;
}edge[10002];

inline void add_edge(int u,int v)
{
	edge[++cnt].nxt=head[u];edge[cnt].to=v;head[u]=cnt;
}

inline void print()
{
	for (int i=1; i<=n; i++) write(ans[i]);
}

void dfs(int x,int now,int last,int lastast)
{
	int arrive;
	for (int i=head[now]; i; i=edge[i].nxt)
	{
		arrive=edge[i].to;
		if (arrive!=now && !vis[arrive])
		{
			{
				if (m==n-1) write(arrive);cnt++;
				vis[arrive]=1;ans[cnt]=arrive;
				dfs(x+1,arrive,now,last);
				vis[arrive]=0;
			}
		}
	}
}

bool cmp(const int &a,const int &b)
{
	return a>b;
}

int main()
{
	freopen("travel.in","r",stdin);freopen("travel.out","w",stdout);
	n=read();m=read();
	for (int i=1; i<=m; i++)
	{
		x=read();y=read();
		d[x][0]++;d[x][d[x][0]]=y;
		d[y][0]++;d[y][d[y][0]]=x;
	}
	for (int i=1; i<=n; i++) sort(d[i]+1,d[i]+d[i][0]+1,cmp);
	for (int i=1; i<=n; i++)
		for (int j=1; j<=d[i][0]; j++)
			add_edge(i,d[i][j]);
	/*for (int i=1; i<=n; i++)
	{
		write(i);printf("->");
		for (int j=head[i]; j; j=edge[j].nxt) write(edge[j].to);putchar('\n');
	}putchar('\n');*/
	ans[1]=1;vis[1]=1;
	if (m==n-1) write(1);cnt=1;
	dfs(1,1,99999,99999);
	if (m==n) print();
	fclose(stdin);fclose(stdout);
	return 0;
}