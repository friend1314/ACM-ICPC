#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<queue>
#include<set>
#include<map>
#include<ctime>

typedef long long ll;
typedef unsigned long long ull;

int a[101],bo[30000],n,T,ans,lim;

using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}

void write(int x)
{
	if (x<0) putchar('-'),x=-x;
	if (x>9) write(x/10);
	putchar(x%10+48);
}

void dfs(int x,int s,int cnt)
{
	if (x>n||s>lim) return;
	if (cnt>1) bo[s]=1;
	//tot[s]=max(tot[s],cnt);
	//cout<<x<<' '<<s<<' '<<cnt<<endl;
	dfs(x+1,s,cnt);
	for (int i=1; s+a[x]*i<=lim; i++)
		dfs(x+1,s+a[x]*i,cnt+i);
}

int main()
{
	freopen("money.in","r",stdin);freopen("money.out","w",stdout);
	T=read();
	while (T--)
	{
		memset(bo,0,sizeof(bo));
		n=read();
		lim=0;
		for (int i=1; i<=n; i++)
		{
			a[i]=read();
			lim=max(lim,a[i]);
		}
		sort(a+1,a+n+1);
		dfs(1,0,0);
		ans=0;
		for (int i=1; i<=n; i++)
			if (bo[a[i]])
			{
				ans++;
				
			}
			//else cout<<a[i]<<endl;
		//cout<<n-ans<<endl;
			write(n-ans);putchar('\n');
	}
	return 0;
}