#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<queue>
#include<set>
#include<map>
#include<ctime>

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

struct eg
{
	int nxt,to,val;
}edge[60002];

int head[60002],n,m,cnt,x,y,w,ans,vis[30001],tot[30001];

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}

void write(int x)
{
	if (x<0) putchar('-'),x=-x;
	if (x>9) write(x/10);
	putchar(x%10+48);
}

void add_edge(int u,int v,int w)
{
	tot[u]++;
	edge[++cnt].nxt=head[u];
	edge[cnt].to=v;
	edge[cnt].val=w;
	head[u]=cnt;
}

void dfs(int u,int s)
{
	ans=max(s,ans);
	for (int i=head[u]; i; i=edge[i].nxt)
		if (edge[i].to!=u && !vis[edge[i].to])
		{
			vis[edge[i].to]=1;
			dfs(edge[i].to,s+edge[i].val);
			vis[edge[i].to]=0;
		}
}

int main()
{
	freopen("track.in","r",stdin);freopen("track.out","w",stdout);
	n=read();m=read();
	for (int i=1; i<=n-1; i++)
	{
		x=read();y=read();w=read();
		add_edge(x,y,w);add_edge(y,x,w);
	}
	for (int i=1; i<=n; i++)
		if (tot[i]==1)
		{
			dfs(i,0);
		}
	write(ans);
	return 0;
}