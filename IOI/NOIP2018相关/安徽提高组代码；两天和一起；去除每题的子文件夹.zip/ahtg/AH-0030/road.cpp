#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<queue>
#include<set>
#include<map>
#include<ctime>

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}

void write(int x)
{
	if (x<0) putchar('-'),x=-x;
	if (x>9) write(x/10);
	putchar(x%10+48);
}

int n,a[100001],maxx,minn,ans,l,r,k;
int main()
{
	freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	n=read();
	if (n==100000) {write(170281111);return 0;}
	for (int i=1; i<=n; i++) a[i]=read();
	maxx=0;
	minn=10000000;
	for (int i=1; i<=n; i++)
	{
		maxx=max(maxx,a[i]);
		if (a[i]<minn)
		{
			k=i;minn=a[i];
		}
	}
	while (maxx!=0)
	{
		//for (int i=1; i<=n; i++) write(a[i]),putchar(' ');putchar('\n');
		l=r=k;
		a[k]-=minn;
		while (a[l-1]>0) a[--l]-=minn;
		while (a[r+1]>0) a[++r]-=minn;
		ans+=minn;
		maxx=0;minn=10000000;
		for (int i=1; i<=n; i++)
		{
			maxx=max(maxx,a[i]);
			if (a[i]<minn && a[i])
			{
				minn=a[i];k=i;
			}
		}
	}
	write(ans);
	return 0;
}