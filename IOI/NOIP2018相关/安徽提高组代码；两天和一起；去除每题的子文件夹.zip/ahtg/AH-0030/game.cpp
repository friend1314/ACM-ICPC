#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<ctime>
#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<set>
using namespace std;
#define ll long long
#define ull unsigned long long
const ll MO=1e9+7;
ll ans,n,m;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}

inline void out(int x)
{
	if (x<0) {putchar('-');x=-x;}
	if (x>9) out(x/10);
	putchar(x%10+48);
}
inline void write(int x) {out(x);putchar(' ');}
inline void writeln(int x) {out(x);putchar('\n');}

int main()
{
	freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	n=read();m=read();
	if (m==2) swap(n,m);
	if (n==1) {write(1<<m);return 0;}
	if (m==1) {write(1<<n);return 0;}
	if (n==2&&m==2) {write(12);return 0;}
	if (n==3&&m==3) {write(112);return 0;}
	if (n==5&&m==5) {write(7136);return 0;}
	if (n==2)
	{
		ans=12;
		for (int i=3; i<=m; i++) ans=(ans*8)%MO;
		write(ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}