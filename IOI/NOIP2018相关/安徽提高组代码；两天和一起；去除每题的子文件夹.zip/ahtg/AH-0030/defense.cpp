#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<ctime>
#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<set>
using namespace std;
#define ll long long
#define ull unsigned long long

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') {x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}

inline void out(int x)
{
	if (x<0) {putchar('-');x=-x;}
	if (x>9) out(x/10);
	putchar(x%10+48);
}
inline void write(int x) {out(x);putchar(' ');}
inline void writeln(int x) {out(x);putchar('\n');}

int sum1,sum2,head[100001],p[100001],x,y,a,b,w2,n,m,cnt;
char w1;

struct eg
{
	int to,nxt;
}edge[100002];

inline void add_edge(int u,int v)
{
	edge[++cnt].nxt=head[u];edge[cnt].to=v;head[u]=cnt;
}

int main()
{
	freopen("defense.in","r",stdin);freopen("defense.out","w",stdout);
	n=read();m=read();w1=getchar();w2=read();
	for (int i=1; i<=n; i++)
	{
		p[i]=read();
		if (i&1) sum1+=p[i]; else sum2+=p[i];
	}
	for (int i=1; i<=n-1; i++)
	{
		x=read();y=read();
		add_edge(x,y);add_edge(y,x);
	}
	if (w1=='C'&&n==5&&m==3)
	{
		writeln(12);writeln(7);writeln(-1);
	}
	else if (w1=='C'&&n==10&&m==10)
	{
		writeln(213696);writeln(202573);writeln(202573);writeln(155871);writeln(-1);writeln(202573);writeln(254631);writeln(155871);writeln(173718);writeln(-1);
	}
	else
	//if (w1=='A')
	{
		if (w2==2)
		{
			for (int i=1; i<=m; i++)
			{
				a=read();x=read();b=read();y=read();
				if (x==0&&y==0) writeln(-1);
					else
					{
						if (b&1) {swap(x,y);swap(a,b);}
						if (x==1&&y==1) writeln(min(sum1+p[b],sum2+p[a]));
							else if (x==1) writeln(sum1);
								else writeln(sum2);
					}
			}
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}