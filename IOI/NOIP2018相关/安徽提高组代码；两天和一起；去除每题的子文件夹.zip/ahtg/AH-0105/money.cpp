#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,a[1000],x,y,t;
int gcd(int x,int y)
{
	return x%y ==0?  y:gcd(y,x%y);
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t)
	{
		cin>>n;
		cin>>x>>y;
		if(gcd(x,y)!=1)
			cout<<1<<endl;
		else
		    cout<<n<<endl;
			t--;
		}
		return 0;
	}