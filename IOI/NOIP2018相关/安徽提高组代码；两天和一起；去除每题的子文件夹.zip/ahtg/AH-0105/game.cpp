#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	int n,m;
	cin>>n>>m;
	if(n==1&&m==2)
		cout<<4;
		if(n==2&&m==3)
			cout<<36;
			return 0;
		}