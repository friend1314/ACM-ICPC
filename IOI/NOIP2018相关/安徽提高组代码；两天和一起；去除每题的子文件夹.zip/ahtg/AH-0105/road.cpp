#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int t[1001],d[1001],n,f=1,ans=0,p[1001],a1,b1,l,a2,b2,m;
void  find()
{
	a2=0;b2=-1;l=0;
	a1=a2,b1=b2;
	for(int i=1;i<=n;i++)
	{
		if((p[i])&&(!p[i+1]))
		{ 
			for(int j=b2+1;p[j]==0;j++)
				m=j;
			a2=m;
			b2=i;
	       if(b2-a2>l)
		   { 
			   a1=a2;
			   b1=b2; 
			   l=b1-a1;
		   }
	  }
  }

}	
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	memset(d,0,sizeof(d));
	memset(t,0,sizeof(t));
	for(int i=1;i<=n;i++)
		p[i]=1;
	p[n+1]=0;
	for(int i=1;i<=n;i++)
		cin>>t[i];
		while(f)
		{
			f=0;
			find();
			for(int i=a1+1;i<=b1;i++)
			{
				if(p[i]) 
				{
					f=1;
				   d[i]++;
				}
				if(d[i]==t[i]) p[i]=false;
				}
				ans++;
		}
		cout<<ans-1;
		return 0;
}
	