#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m1, m[5000][5000],sum[5000],xi=10000,l[5000],p=0,g[5000][5000],a[5000],u,exist[5000],team[5000];
void search(int x)
{
	if(a[x]&&x<xi)
	{
		xi=x;
		return;
	}
	for(int i=1;i<=sum[x];i++)
	{
		if(m[x][g[x][i]])
		{
			m[x][g[x][i]]=false;	
			m[g[x][i]][x]=true;
	    	g[g[x][i]][++sum[g[x][i]]]=x;
	    	search(g[x][i]);
		}
		  m[x][g[x][i]]=true;
		  m[g[x][i]][x]=false;
 		 sum[g[x][i]]--;
		
	}
}
void  span(int x)
{
	memset(a,1,sizeof(a));
	memset(team,0,sizeof(team));
	memset(exist,0,sizeof(exist));
	int h=0,t=1;
	xi=100000;
	exist[x]=1,team[1]=x,l[++p]=x;
	while(t!=h)
	{
		h++;
		exist[h]=0;
		u=team[h];
		search(u);
		if(xi<n)
			{
				exist[xi]=1;
			    l[++p]=xi;
		        a[xi]=0;
				t++;
				team[t]=xi;
			}
		}
	}
int main()
{
	int x,y;
	scanf("%d%d",&n,&m1);
	memset(m,0,sizeof(m));
	memset(sum,0,sizeof(sum));
	for(int i=1;i<=m1;i++)
	{
		cin>>x>>y;
		m[x][y]=true;
	
		g[x][++sum[x]]=y;
	}
	for(int i=1;i<=n;i++)
		span(i);
	for(int i=1;i<=p;i++)
		cout<<l[i]<<'  ';
		return 0;
	}
		
	