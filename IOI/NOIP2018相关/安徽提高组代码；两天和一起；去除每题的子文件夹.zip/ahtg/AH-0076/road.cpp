#include <iostream>
#include <cstdio>
using namespace std;

int a[100010];

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	cin>>n;
	int sum=0;
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		sum+=a[i];
	}
//	cout<<999<<endl;
	int ans=0;
	while (sum>0)
	{
		
		int mins=99999999,c=0;
		for (int i=1;i<=n+1;i++)
		{
			if (a[i]==0)
			{
				if (c>0)
				{
					for (int j=i-c;j<=i-1;j++)
					{
						a[j]-=mins;
						sum-=mins;
					}
					ans+=mins;
				}
				
				mins=99999999;
				c=0;
			}
			else
			{
				mins=min(a[i],mins);
				c++;
			}
		}
	/*	for (int i=1;i<=n;i++)
		{
			cout<<a[i]<<" ";
		}
		cout<<endl;
		for (int i=1;i<=20000000;i++);*/
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}