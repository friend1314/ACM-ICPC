#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

struct edge{
	int to,w;
};

struct Edge{
	int a,b,l;
};

vector<edge> G[100010];
int ans_m1=0;
Edge a[100010];
int vis[100010];
int n,m;

bool cmp(Edge x,Edge y)
{
	return x.l>y.l;
}

void dfs(int x,int s)
{
//	cout<<x<<" "<<s<<endl;
	if (s>ans_m1) ans_m1=s;
	vis[x]=true;
	for (int i=0;i<G[x].size();i++)
	{
		int v=G[x][i].to;
		if (!vis[v])
		{
			dfs(v,s+G[x][i].w);
		}
	}
}

bool C(int L)
{
	int ans=0,sum=0;
	for (int i=1;i<n;i++)
	{
		int l;
		if (G[i].size()==1) l=G[i][0].w;
		else if (G[i][0].to==i+1) l=G[i][0].w;
			else l=G[i][1].w;
		if (sum+l>=L)
		{
			sum=0;
			ans++;
		}
		else sum+=l;
	}
	return ans>=m;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	bool f1=1,f2=1;
	for (int i=1;i<n;i++)
	{
		int a2,b,l;
		cin>>a2>>b>>l;
		G[a2].push_back((edge){b,l});
		G[b].push_back((edge){a2,l});
		a[i]=(Edge){a2,b,l};
		if (a2!=1) f1=0;
		if (b!=a2+1) f2=0;
	}
	
	if (f1)
	{
		sort(a+1,a+n,cmp);
		int ans=0;
		int i=1,j=m*2;
		while (i<j)
		{
			ans=max(ans,a[i].l+a[j].l);
			i++;
			j--;
		}
		cout<<ans<<endl;
	}
	else if (m==1)
	{
		int ans=0;
		for (int i=1;i<=n;i++)
		{
			for (int j=1;j<=n;j++) vis[j]=0;
			ans_m1=0;
			dfs(i,0);
			ans=max(ans,ans_m1);
		}
		cout<<ans<<endl;
	}
	else if (f2)
	{//cout<<"rend"<<endl;
		int i=0,j=100000000,mid;
		while (i<j)
		{
		//	cout<<i<<" "<<j<<endl;
			mid=(i+j)/2;
			if (C(mid)) i=mid+1;
			else j=mid;
		}
		cout<<i-1<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}