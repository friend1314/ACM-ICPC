#include <iostream>
#include <cstdio>
using namespace std;

const long long MOD=1000000007;

long long c1[1000010],c2[1000010];

long long C(long long m,long long n)
{
	if (n<0 || n>m)
	{
		return 0;
	}
	return (c1[m]/c1[m-n])/c1[n] % MOD;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long m,n;
	cin>>n>>m;
	c1[0]=c2[0]=1;
	for (long long i=1;i<=max(n,m);i++)
	{
		c1[i]=c1[i-1]*i;
		c1[i]%=MOD;
		c2[i]=c2[i-1]*2;
		c2[i]%=MOD;
	}
	if (n==1 || m==1)
	{
		cout<<c2[max(n,m)]<<endl;
	}
	else if (n==2 || m==2)
	{
		if (n!=2) 
		{
			m=n;
			n=2;
		}
		long long ans=0;
		for (long long k=0;k<=m;k++)
		{
			ans+=C(m-1,k)*c2[m-k]+C(m-1,k-1)*c2[m-k+1];
		//	cout<<k<<" "<<C(m-1,k)<<" "<<c2[m-k]<<" "<<C(m-1,k-1)<<" "<<c2[m-k+1]<<" "<<C(m-1,k)*c2[m-k]+C(m-1,k-1)*c2[m-k+1]<<endl;
			ans%=MOD;
		}
		cout<<ans<<endl;
	}
	else if (m==3 && n==3)
	{
		cout<<112<<endl;
	}
	else if (m==5 && n==5)
	{
		cout<<7136<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}