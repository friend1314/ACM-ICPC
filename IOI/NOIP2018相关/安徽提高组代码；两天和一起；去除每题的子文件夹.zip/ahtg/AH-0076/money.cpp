#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <cmath>
using namespace std;

int n;
int a[100010],b[100010];
int f1[1010],f2[1010];
int mina;
int sum=0;

bool F(int n)
{
	for (int i=0;i<=1000;i++) f2[i]=0;
	f2[0]=1;
	for (int i=1;i<=n;i++)
	{
		for (int j=b[i];j<=1000;j++)
		{
			f2[j]=(f2[j] || f2[j-b[i]]);
		}
	}
	for (int i=1;i<=1000;i++)
	{
		if (f2[i]!=f1[i]) return false;
	}
	return true;
}

void dfs(int x,int s)
{
	if (x>=mina) return;
	if (F(x))
	{
		mina=x;
		return;
	}
	for (int i=s+1;i<=sum;i++)
	{
		b[x+1]=i;
		dfs(x+1,i);
	}
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	cin>>T;
	while (T--) {
	cin>>n;
	mina=n;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i];
		sum=max(a[i],sum);
	}
	for (int i=0;i<=1000;i++) f1[i]=0;
	f1[0]=1;
	for (int i=1;i<=n;i++)
	{
		for (int j=a[i];j<=1000;j++)
		{
			f1[j]=(f1[j] || f1[j-a[i]]);
		}
	}
	dfs(0,1);
	cout<<mina<<endl;}
	return 0;
}