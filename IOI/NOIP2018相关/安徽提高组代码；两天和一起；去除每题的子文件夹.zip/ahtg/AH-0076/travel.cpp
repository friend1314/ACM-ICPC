#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;

int G[5010][5010];
int n,m;
int vis[5010];
int d[5010];
vector<int> G2[5010];

void dfs(int x)
{
	cout<<x<<" ";
	vis[x]=1;
	for (int i=1;i<=n;i++)
	{
		if (G[x][i] && !vis[i])
		{
			dfs(i);
		}
	}
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>m;
	bool flag1=true;
	for (int i=1;i<=m;i++)
	{
		int u,v;
		cin>>u>>v;
		G[u][v]=G[v][u]=1;
		G2[u].push_back(v);
		G2[v].push_back(u);
		d[u]++;
		d[v]++;
	}
	for (int i=1;i<=n;i++)
	{
		if (d[i]!=2) flag1=false;
	}
	if (n==m+1)
	{
		dfs(1);
	}
	else  if (flag1)
	{
		
		bool havec=0;
		int haveb=0;
		int fc=(G2[1][0]>G2[1][1]),c;
		for (int i=1;haveb<n;i=G2[i][c])
		{
		//	cout<<999<<endl;
			cout<<i<<" ";
			vis[i]=1;
			haveb++;
			if (haveb>=n) break;
			if (!vis[G2[i][0]] || (i==1 && G2[i][0]<G2[i][1])) c=0;
			else c=1;
			if (!vis[G2[1][!fc]] && G2[1][!fc]<G2[i][c] && !havec)
			{
				havec=1;
				c=!fc;
			}
		//	cout<<"     "<<c<<" "<<G[i][c]<<endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
