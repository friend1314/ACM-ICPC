#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
inline int rd(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-fl;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*fl;
}
int a[201];
bool ex[201];

bool fj(int x,int l,int r){
	if(x==0)return 1;
	for(int i=l;i<=r;i++){
		if(ex[i])continue;
		if(x%a[i]==0)return 1;
		for(int j=1;j*a[i]<=x;j++)
			if(fj(x-j*a[i],i+1,r))
				return 1;
	}
	return 0;
}
bool check(int x,int n){
	if(n==1){
		if(a[2]%a[1]==0)return 1;
		return 0;
	}
	if(fj(x,1,n))return 1;
	return 0;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T=rd();
	for(int kkk=1;kkk<=T;kkk++){
		int n=rd();
		for(int i=1;i<=n;i++)a[i]=rd();
		sort(a+1,a+n+1);
		if(a[1]==1||n==1){printf("1\n");continue;}
		
		memset(ex,0,sizeof(ex));
		int nn=unique(a+1,a+n+1)-a-1;
		int ans=nn;
		for(int i=2;i<=nn;i++)
			if(check(a[i],i-1)){
				ans--;ex[i]=1;
			}
		printf("%d\n",ans);
	}
	return 0;
}