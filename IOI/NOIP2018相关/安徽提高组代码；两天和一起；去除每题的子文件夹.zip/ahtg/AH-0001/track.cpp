#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
typedef long long ll;
inline int rd(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-fl;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*fl;
}
int n,m,num=0,sum=0;
int hd[100100],dis[100100],c[100100],a[100100];
bool ex[100100];
struct star2{int nt,to,ct;}e[100100];
void add(int fm,int to,int dis){
	e[++num].to=to;
	e[num].nt=hd[fm];
	e[num].ct=dis;
	hd[fm]=num;
}
struct star{
	int id,v;
	bool operator <(const star a)const{
		return v>a.v;
	}
};
void dij(int x){
	priority_queue<star>q;
	memset(dis,0x3f,sizeof(dis));
	dis[x]=0;q.push((star){x,0});
	do{
		star t=q.top();q.pop();
		int u=t.id;
		if(ex[u])continue;
		ex[u]=1;
		for(int i=hd[u];i;i=e[i].nt){
			int to=e[i].to;
			if(dis[to]>dis[u]+e[i].ct){
				dis[to]=dis[u]+e[i].ct;
				q.push((star){to,dis[to]});
			}
		}
	}while(q.size());
}
void work1(){
	dij(1);
	int rt=1,mx=0;
	for(int i=1;i<=n;i++)
		if(dis[i]>mx){
			rt=i;mx=dis[i];
		}
	mx=0;memset(ex,0,sizeof(ex));
	dij(rt);
	for(int i=1;i<=n;i++)
		if(dis[i]>mx)
			mx=dis[i];
	printf("%d",mx);
}
bool check(int x){
	int kk=0;
	for(int i=2;i<=n;i++)
		if(!ex[i]){
			if(a[i]>=x){ex[i]=1;kk++;if(kk>=m)return 1;continue;}
			int id=lower_bound(c+1,c+n,x-a[i])-c;
			if(a[i]+a[id]>=x){
				ex[i]=ex[id]=1;
				kk++;
				if(kk>=m)return 1;
			}
		}
	return 0;
}
void work2(){
	sort(c+1,c+n);
	int l=c[1],r=sum;
	while(l<=r){
		int mid=(l+r)>>1;
		if(check(mid))l=mid+1;
		else r=mid-1;
	}
	printf("%d",l-1);
}
bool check2(int x){
	int cnt=0,kk=0;
	for(int i=2;i<=n;i++){
		cnt+=a[i];
		if(cnt>=x){
			kk++;cnt=0;
			if(kk>=m)return 1;
		}
	}
	return 0;
}
void work3(){
	int l=1,r=sum;
	while(l<=r){
		int mid=(l+r)>>1;
		if(check2(mid))l=mid+1;
		else r=mid-1;
	}
	printf("%d",l-1);
}
bool check3(int x,int o,int fa,int cnt,int num){
	if(num>=m)return 1;
	for(int i=hd[o];i;i=e[i].nt){
		int to=e[i].to;
		if(to==fa)continue;
		if(cnt+e[i].ct>=x){if(check3(x,to,o,0,num+1))return 1;}
		else if(check3(x,to,o,cnt+e[i].ct,num))return 1;
	}
	return 0;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=rd();m=rd();
	bool fl1=0,fl2=0;int x,y,z;
	for(int i=1;i<n;i++){
		x=rd();y=rd();z=rd();
		if(x>y)swap(x,y);
		add(x,y,z);add(y,x,z);
		if(x!=1)fl1=1;
		if(x!=y-1)fl2=1;
		sum+=z;
		a[y]=c[i]=z;
	}
	if(m==1){work1();return 0;}
	if(!fl1){work2();return 0;}
	if(!fl2){work3();return 0;}
	int l=1,r=sum;
	while(l<=r){
		int mid=(l+r)>>1;
		if(check3(mid,1,0,0,0))l=mid+1;
		else r=mid-1;
	}
	printf("%d",l-1);
	return 0;
}