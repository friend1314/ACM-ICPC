#include<cstdio>
#include<cstring>
#include<queue>
#include<iostream>
using namespace std;
inline int rd(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-fl;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*fl;
}
int n,m,xx,yy,ans=0,a[100100];
bool ex[201],exx[2001],ma[2001][2001];
bool check(){
	for(int i=1;i<=n;i++)
		if(!exx[i])return 0;
	return 1;
}	

void dfs(int x,int fa,int cnt){
	if(check()){ans=min(ans,cnt);return ;}
	for(int i=1;i<=n;i++){
		if(ma[x][i]&&i!=fa){
			exx[i]=1;
			if(i==xx||i==yy){
				if(!ex[i]&&!ex[x]){ans=-1;return ;}
				dfs(i,x,cnt);
			}
			else if(!ex[x]){
				ex[i]=1;
				dfs(i,x,cnt+a[i]);
				ex[i]=0;
			}
			else{
				ex[i]=1;
				dfs(i,x,cnt+a[i]);
				ex[i]=0;
				dfs(i,x,cnt);
			}
			exx[i]=0;
		}
	}
}
int f[2010][2];
int main(){	
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	char ch[5];
	n=rd();m=rd();cin>>ch[1]>>ch[2];
	for(int i=1;i<=n;i++)a[i]=rd();
	if(ch[1]=='A'){
		int x,y,z,w;
		for(int i=1;i<n;i++)x=rd(),y=rd();
		for(int kk=1;kk<=m;kk++){
			x=rd();y=rd();z=rd();w=rd();		
			if(x>y)swap(x,y);
			if(x==y-1&&z==w&&z==0){puts("-1");	continue;}
			memset(f,0,sizeof(f));
			f[x][y]=a[x]*y;f[z][w]=a[z]*w;
			for(int i=1;i<=n;i++){
				if(f[i][0]||f[i][1])continue;
				f[i][1]+=min(f[i-1][0]+a[i],f[i-1][1]+a[i]);
				f[i][0]+=f[i-1][1];
			}
			printf("%d\n",min(f[n][0],f[n][1]));
		}
		return 0;
	}
	int x,y,idx,idy;
	for(int i=1;i<n;i++){
		x=rd();y=rd();
		ma[x][y]=1;
		ma[y][x]=1;
	}
		for(int i=1;i<=m;i++){
			xx=rd();idx=rd();
			yy=rd();idy=rd();
			if(ma[x][y]&&idx==idy&&idx==0){puts("-1");	continue;}
			memset(ex,0,sizeof(ex));
			ans=a[x]*idx+a[y]*idy;
			ex[xx]=idx;ex[yy]=idy;
			exx[xx]=1;
			dfs(x,0,ans);
			ex[xx]=0;ex[yy]=0;
			printf("%d\n",ans);
		}
	
	
	return 0;
}