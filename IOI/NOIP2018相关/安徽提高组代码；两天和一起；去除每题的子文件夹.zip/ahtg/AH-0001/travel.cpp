#include<cstdio>
#include<cstring>
#include<queue>
#include<algorithm>
#include<iostream>
using namespace std;
inline int rd(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-fl;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*fl;
}
int cnt=0,n,m,ans[100100];
bool ex[100100];
vector<int>ma[5010];
void dfs(int x,int fa){
	ans[++cnt]=x;
	int l=ma[x].size();
	for(int i=0;i<l;i++){
		if(ma[x][i]==fa)continue;
		dfs(ma[x][i],x);
	}
}
int tmp[5010];
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=rd();m=rd();int x,y;
	if(m==n-1){
		for(int i=1;i<=m;i++){
			x=rd();y=rd();
			ma[x].push_back(y);
			ma[y].push_back(x);
		}
		for(int i=1;i<=n;i++){
			int x=ma[i].size();
			for(int j=0;j<x;j++)tmp[j]=ma[i][j];
			sort(tmp,tmp+x);
			for(int j=0;j<x;j++)ma[i][j]=tmp[j];
		}
		memset(ex,0,sizeof(ex));
		dfs(1,0);
		for(int i=1;i<=cnt;i++)
			printf("%d ",ans[i]);
		return 0;
	}
}