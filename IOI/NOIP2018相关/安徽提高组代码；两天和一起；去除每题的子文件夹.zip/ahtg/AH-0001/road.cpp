#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
inline int rd(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-fl;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*fl;
}
int n,a[100100];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=rd();
	ll ans=0;
	for(int i=1;i<=n;i++)
		a[i]=rd();
	int nn=unique(a+1,a+n+1)-a-1;
	for(int i=2;i<nn;i++){
		if(a[i]<a[i-1]&&a[i]<a[i+1]){
			ans-=a[i];
		}
		if(a[i]>a[i-1]&&a[i]>a[i+1]){
			ans=(ll)ans+a[i];
		}
	}
	if(a[1]>a[2])ans=(ll)ans+a[1];
	if(a[nn]>a[nn-1])ans=(ll)ans+a[nn];
	printf("%lld",ans);
	return 0;
}