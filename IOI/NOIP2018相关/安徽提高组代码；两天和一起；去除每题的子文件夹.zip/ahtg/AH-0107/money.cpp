#include<bits/stdc++.h>
using namespace std;
int a[101];
int n,qwertyu=1;
bool f(int p1){
	for(int p2=0;p2<p1;p2++){
		if(a[p1]%a[p2]==0){
			return false;
		}
	}
	for(int as1=p1-1;as1>=0;as1--){
		for(int as2=0;as2<as1;as2++){
			if((a[p1]%a[as1])%a[as2]==0){
				return false;
			}
		}
	}
	for(int as1=p1-1;as1>=0;as1--){
		for(int as2=0;as2<as1;as2++){
			if(a[p1]/a[as1]>=2){
				if((a[p1]%a[as1]+a[as1])%a[as2]==0){
					return false;
				}
			}
		}
	}
	for(int as1=p1-1;as1>=0;as1--){
		for(int as2=0;as2<as1;as2++){
			if(a[p1]/a[as1]>=3){
				if((a[p1]%a[as1]+2*a[as1])%a[as2]==0){
					return false;
				}
			}
		}
	}
	for(int as1=p1-1;as1>=0;as1--){
		for(int as2=0;as2<as1;as2++){
			if(a[p1]/a[as1]>=4){
				if((a[p1]%a[as1]+3*a[as1])%a[as2]==0){
					return false;
				}
			}
		}
	}
	return true;
}
void v_shan(int l){
	for(int iii=l;iii<n;iii++){
		a[iii]=a[iii+1];
	}
	n=n-1;
}
void v_c(){
	for(int i=1;i<n;i++){
		if(!f(i)){
			v_shan(i);
			i=i-1;
		}
	}
	cout<<n<<endl;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	cin>>t;
	for(int v_time=1;v_time<=t;v_time++){
		cin>>n;
		for(int v_time2=0;v_time2<n;v_time2++){
			cin>>a[v_time2];
		}
		sort(a,a+n);
		if(a[0]==1){
			cout<<qwertyu;
		}
		else{
			v_c();
		}
	}
	return 0;
}