#include<bits/stdc++.h>
using namespace std;
int a[100001];
int main(){
	freopen("road2.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	int c_day=0;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		for(;a[i]!=0;){
			for(int j=i;a[j]!=0;j++){
				a[j]--;
			}
			c_day++;
		}
	}
	cout<<c_day;
	return 0;
}