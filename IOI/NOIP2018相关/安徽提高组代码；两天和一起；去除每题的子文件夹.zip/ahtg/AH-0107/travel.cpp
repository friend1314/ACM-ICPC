#include<bits/stdc++.h>
using namespace std;
int ans[5001];
int way[5001][2];
int n,m,final=0,mmp;
bool c_guo[5001],c_ans[5001];
void v_get(int k,int turn){
	for(int i=0;i<m;i++){
		if(way[i][1]==k){
			c_guo[way[i][2]]=true;
		}
		if(way[i][2]==k){
			c_guo[way[i][1]]=true;
		}
	}
	if(turn==0){
		for(int iiiii=1;ans[iiiii]!=0;iiiii++){
			v_get(ans[iiiii],1);
		}
	}
}
void v_chu(){
	for(int asdfg=1;asdfg<5001;asdfg++){
		c_guo[asdfg]=false;
	}
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	for(int i=1;i<5001;i++){
		ans[i]=0;
	}
	ans[0]=1;
	c_ans[1]=false;
	for(int dddi=2;dddi<=5000;dddi++){
		c_ans[dddi]=true;
	}
	cin>>n>>m;
	for(int i=0;i<m;i++){
		cin>>way[i][1]>>way[i][2];
	}
	for(int qwert=0;qwert<n-1;qwert++){
		v_chu();
		v_get(ans[final],0);
		mmp=0;
		for(int zxcvb=1;zxcvb<=n&&mmp==0;zxcvb++){
			if(c_guo[zxcvb]&&c_ans[zxcvb]){
				ans[final+1]=zxcvb;
				c_ans[zxcvb]=false;
				final++;
				mmp++;
			}
		}
	}
	for(int kkkkl=0;kkkkl<n;kkkkl++){
		cout<<ans[kkkkl]<<' ';
	}
	return 0;
}