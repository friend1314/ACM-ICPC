#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

const int N = 5e3 + 10;

int n, m, a[N], tot, ans[N];
struct rec { int u, v; } r[N];
vector<int> G[N];

void dfs(int u, int f) {
  // cout << u << ' ' << f << '\n';
  a[++tot] = u;
  int size = G[u].size();
  for (int i = 0; i < size; ++i) {
    int v = G[u][i];
    if (v == f) continue;
    dfs(v, u);
  }
}

void Solve1() {
  for (int i = 1; i < n; ++i) {
    int u, v;
    scanf("%d%d", &u, &v);
    G[u].push_back(v);
    G[v].push_back(u);
  }
  for (int i = 1; i <= n; ++i)
    sort(G[i].begin(), G[i].end());
  dfs(1, 0);
  for (int i = 1; i <= n; ++i)
    printf("%d ", a[i]);
  cout << '\n';
}

int f[N];

int find(int x) { return x == f[x] ? x : f[x] = find(f[x]); }

bool check(int j) {
  for (int i = 1; i <= n; ++i) f[i] = i;
  for (int i = 1; i <= n; ++i) {
    if (i == j) continue;
    int x = find(r[i].u), y = find(r[i].v);
    f[find(x)] = find(y);
  }
  for (int i = 2; i <= n; ++i)
    if (find(i) != find(i - 1)) return false;
  return true;
}

void update() {
  for (int i = 1; i <= n; ++i)
    ans[i] = a[i];
}

void check() {
  if (ans[1] == 0) { update(); return; }
  for (int i = 1; i <= n; ++i) {
    if (a[i] > ans[i]) return;
    if (a[i] < ans[i]) { update(); return; }
  }
}

void Solve2() {
  for (int i = 1; i <= n; ++i)
    scanf("%d%d", &r[i].u, &r[i].v);
  for (int j = 1; j <= n; ++j) {
    if (!check(j)) continue;
    for (int i = 1; i <= n; ++i)
      G[i].clear();
    for (int i = 1; i <= n; ++i) {
      if (i == j) continue;
      int u = r[i].u, v = r[i].v;
      G[u].push_back(v);
      G[v].push_back(u);
    }
    for (int i = 1; i <= n; ++i)
      sort(G[i].begin(), G[i].end());
    tot = 0;
    dfs(1, 0);
    if (tot == n) check();
  }
  for (int i = 1; i <= n; ++i)
    printf("%d ", ans[i]);
  cout << '\n';
}

int main() {
  freopen("travel.in", "r", stdin);
  freopen("travel.out", "w", stdout);
  cin >> n >> m;
  if (m == n - 1)
    Solve1();
  else
    Solve2();
  return 0;
}
