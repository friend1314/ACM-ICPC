#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 5e4 + 10;

int n, m;
struct edge { int v, w, nxt; } e[N << 1];
int G[N], ed = 1;
bool flag1 = true, flag2 = true, flag3 = true, flag4 = true;

inline void add_edge(int u, int v, int w) {
  e[++ed] = (edge) { v, w, G[u] };
  G[u] = ed;
}

namespace Solve1 { // m = 1

int d[N], ans;

void dfs(int u, int f) {
  for (int i = G[u]; i != 0; i = e[i].nxt) {
    int v = e[i].v, w = e[i].w;
    if (v == f) continue;
    dfs(v, u);
    ans = max(ans, d[u] + d[v] + w);
    d[u] = max(d[u], d[v] + w);
  }
}

void main() {
  dfs(1, 0);
  cout << ans << '\n';
  return;
}

}

namespace Solve2 { // a[i] = 1

int a[N], l, r, mid, ans;

bool check(int x) {
  int cnt = 0, pos = n - 1;
  while (a[pos] >= x) {
    --pos;
    ++cnt;
  }
  for (int i = 1; i < pos; ++i)
    if (a[i] + a[pos] >= x) {
      --pos;
      ++cnt;
    }
  return cnt >= m;
}

void main() {
  sort(a + 1, a + n);
  for (int i = 1; i < n; ++i)
    r += a[i];
  while (l <= r) {
    mid = (l + r) >> 1;
    if (check(mid)) {
      ans = mid;
      l = mid + 1;
    } else {
      r = mid - 1;
    }
  }
  cout << ans << '\n';
  return;
}

}

namespace Solve3 { // b[i] = a[i] + 1

int a[N], l, r, mid, ans;

bool check(int x) {
  int cnt = 0, now = 0;
  for (int i = 1; i < n; ++i) {
    now += a[i];
    if (now >= x) ++cnt, now = 0;
  }
  return cnt >= m;
}

void main() {
  for (int i = 1; i < n; ++i)
    r += a[i];
  while (l <= r) {
    mid = (l + r) >> 1;
    if (check(mid)) {
      ans = mid;
      l = mid + 1;
    } else {
      r = mid - 1;
    }
  }
  cout << ans << '\n';
  return;
}

}

namespace Solve4 {

int l, r, mid, ans;

void dfs(int u, int f) {
}

bool check() {
  return false;
}

void main() {
  dfs(1, 0);
  return;
}

}

int main() {
  freopen("track.in", "r", stdin);
  freopen("track.out", "w", stdout);
  cin >> n >> m;
  if (m != 1) flag1 = false;
  if (n > 50000) flag4 = false;
  for (int i = 1; i < n; ++i) {
    int u, v, w;
    scanf("%d%d%d", &u, &v, &w);
    add_edge(u, v, w);
    add_edge(v, u, w);
    if (u != 1) flag2 = false;
    if (u + 1 != v) flag3 = false;
    Solve2::a[i] = w;
    Solve3::a[i] = w;
  }
  if (flag1) { Solve1::main(); return 0; }
  if (flag2) { Solve2::main(); return 0; }
  if (flag3) { Solve3::main(); return 0; }
  if (flag4) { Solve4::main(); return 0; }
  return 0;
}
