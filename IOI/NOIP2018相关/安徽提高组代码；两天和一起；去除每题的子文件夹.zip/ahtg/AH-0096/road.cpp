#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#define LL long long
using namespace std;

const int N = 1e5 + 10;

int n, d[N], b = 1, last;
LL ans;
bool v[N];
vector<int> D[N];
set<int> S;

void del(int x) {
  v[x] = false;
  if (v[x - 1] && v[x + 1]) ++b;
  if (!v[x - 1] && !v[x + 1]) --b;
}

int main() {
  freopen("road.in", "r", stdin);
  freopen("road.out", "w", stdout);
  cin >> n;
  for (int i = 1; i <= n; ++i) {
    scanf("%d", &d[i]);
    D[d[i]].push_back(i);
    S.insert(d[i]);
  }
  memset(v, true, sizeof v);
  v[0] = v[n + 1] = false;
  for (set<int>::iterator p = S.begin(); p != S.end(); ++p) {
    int w = *p;
    ans += (w - last) * b;
    for (vector<int>::iterator it = D[w].begin(); it != D[w].end(); ++it)
      del(*it);
    last = w;
  }
  cout << ans << '\n';
  return 0;
}
