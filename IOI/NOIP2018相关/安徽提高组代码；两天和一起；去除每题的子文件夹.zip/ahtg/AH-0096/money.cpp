#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;

const int N = 1e2 + 10;
const int V = 25e3 + 10;

int T, n, v, ans, a[N];
bool f[V];

void Solve() {
  cin >> n, ans = n, v = 0;
  for (int i = 1; i <= n; ++i) {
    scanf("%d", &a[i]);
    v = max(v, a[i]);
  }
  sort(a + 1, a + n + 1);
  memset(f, false, sizeof f), f[0] = true;
  for (int i = 1; i <= n; ++i) {
    if (f[a[i]]) { --ans; continue; }
    for (int j = a[i]; j <= v; ++j)
      if (f[j - a[i]]) f[j] = true;
  }
  cout << ans << '\n';
}

int main() {
  freopen("money.in", "r", stdin);
  freopen("money.out", "w", stdout);
  cin >> T;
  while (T--)
    Solve();
  return 0;
}
