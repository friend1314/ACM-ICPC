#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <string>
#define LL long long
using namespace std;

const int N = 1e5 + 10;

int n, m, p[N];
string s;

namespace Solve1 {

struct edge { int v, nxt; } e[N << 1];
int G[N], ed = 1;

inline void add_edge(int u, int v) {
  e[++ed] = (edge) { v, G[u] };
  G[u] = ed;
}

LL f[N][2];
bool g[N][2];

void dfs(int u, int fa) {
  if (f[u][1] == 0) f[u][1] = p[u];
  for (int i = G[u]; i != 0; i = e[i].nxt) {
    int v = e[i].v;
    if (v == fa) continue;
    dfs(v, u);
    f[u][0] += f[v][1];
    f[u][1] += min(f[v][0], f[v][1]);
  }
}

void main() {
  for (int i = 1; i < n; ++i) {
    int u, v;
    scanf("%d%d", &u, &v);
    add_edge(u, v);
    add_edge(v, u);
  }
  for (int i = 1; i <= m; ++i) {
    int a, x, b, y;
    scanf("%d%d%d%d", &a, &x, &b, &y);
    memset(f, 0, sizeof f);
    f[a][x ^ 1] = f[b][y ^ 1] = 1e9;
    dfs(1, 0);
    LL ans = min(f[1][0], f[1][1]);
    /*
    if (i == 7) {
      cout << f[10][0] << ' ' << f[10][1] << '\n';
      cout << f[7][0] << ' ' << f[7][1] << '\n';
    }
    */
    if (ans >= 1e9)
      printf("-1\n");
    else
      printf("%lld\n", ans);
  }
  return;
}

}

namespace Solve2 {

LL f[N][2], g[N][2];

void main() {
  for (int i = 1; i < n; ++i) {
    int u, v;
    scanf("%d%d", &u, &v);
  }
  for (int i = 1; i <= n; ++i) {
    f[i][0] = f[i - 1][1];
    f[i][1] = min(f[i - 1][0], f[i - 1][1]) + p[i];
  }
  for (int i = n; i >= 1; --i) {
    g[i][0] = g[i + 1][1];
    g[i][1] = min(g[i + 1][0], g[i + 1][1]) + p[i];
  }
  for (int i = 1; i <= m; ++i) {
    int a, x, b, y;
    scanf("%d%d%d%d", &a, &x, &b, &y);
    LL ans1, ans2;
    if (x == 0)
      ans1 = f[a - 1][1];
    else
      ans1 = min(f[a - 1][0], f[a - 1][1]);
    if (y == 0)
      ans2 = g[b + 1][1];
    else
      ans2 = min(g[b + 1][0], g[b + 1][1]);
    if (x == 0 && y == 0)
      printf("-1\n");
    else
      printf("%lld\n", ans1 + ans2);
  }
  return;
}

}

namespace Solve3 {

LL f[N][2], g[N][2];

void main() {
  for (int i = 1; i < n; ++i) {
    int u, v;
    scanf("%d%d", &u, &v);
  }
  f[1][0] = 1e15, f[1][1] = p[1];
  for (int i = 2; i <= n; ++i) {
    f[i][0] = f[i - 1][1];
    f[i][1] = min(f[i - 1][0], f[i - 1][1]) + p[i];
  }
  for (int i = n; i >= 2; --i) {
    g[i][0] = g[i + 1][1];
    g[i][1] = min(g[i + 1][0], g[i + 1][1]) + p[i];
  }
  g[1][0] = 1e15, g[1][1] = min(g[2][0], g[2][1]) + p[1];
  for (int i = 1; i <= m; ++i) {
    int a, x, b, y;
    scanf("%d%d%d%d", &a, &x, &b, &y);
    LL ans1, ans2, ans;
    if (y == 0) {
      ans1 = f[b - 1][1];
      ans2 = g[b + 1][1];
      ans = ans1 + ans2;
    } else {
      ans1 = min(f[b - 1][0], f[b - 1][1]);
      ans2 = min(g[b + 1][0], g[b + 1][1]);
      ans = ans1 + p[b] + ans2;
    }
    printf("%lld\n", ans);
  }
  return;
}

}

int main() {
  freopen("defense.in", "r", stdin);
  freopen("defense.out", "w", stdout);
  cin >> n >> m >> s;
  for (int i = 1; i <= n; ++i)
    scanf("%d", &p[i]);
  if (n <= 2000 && m <= 2000) { Solve1::main(); return 0; }
  if (s[1] == '2') { Solve2::main(); return 0; }
  if (s[1] == '1') { Solve3::main(); return 0; }
  return 0;
}
