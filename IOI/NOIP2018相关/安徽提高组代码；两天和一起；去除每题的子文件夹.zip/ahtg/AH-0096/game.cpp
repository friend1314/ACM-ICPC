#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define LL long long
using namespace std;

const int P = 1e9 + 7;

int n, m;

LL pow(LL a, LL n) {
  LL ans = 1;
  while (n) {
    if (n & 1) ans = ans * a % P;
    a = a * a % P;
    n >>= 1;
  }
  return ans;
}

namespace Solve1 {

int a[10][10];

void main() {
  a[1][1] = 2, a[1][2] = 4, a[1][3] = 8;
  a[2][1] = 4, a[2][2] = 12, a[2][3] = 36;
  a[3][1] = 8, a[3][2] = 36, a[3][3] = 112;
  cout << a[n][m] << '\n';
  return;
}

}

namespace Solve2 {

void main() {
  LL ans = 0;
  if (n == 1)
    ans = pow(2, m);
  if (n == 2)
    ans = pow(3, m - 1) * 4 % P;
  cout << ans << '\n';
  return;
}

}

int main() {
  freopen("game.in", "r", stdin);
  freopen("game.out", "w", stdout);
  cin >> n >> m;
  if (n <= 3 && m <= 3)
    Solve1::main();
  else
    Solve2::main();
  return 0;
}
