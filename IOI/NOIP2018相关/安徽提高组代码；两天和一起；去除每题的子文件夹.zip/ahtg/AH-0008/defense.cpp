#include<fstream>
#include<string>
#define cin fin
#define cout fout
using namespace std;
int main() {
	ifstream fin("defense.in");
	ofstream fout("defense.out");
	ios::sync_with_stdio(false);
	int n,m,a,b,x,y; string type;
	fin>>n>>m>>type;
	for(int i=1;i<=n;++i) cin>>x;
	for(int i=1;i<n;++i) cin>>x>>y;
	for(int i=1;i<=m;++i) cin>>a>>b>>x>>y;
	for(int i=1;i<=m;++i) cout<<-1<<endl;
	fin.close(); fout.close(); return 0;	
}