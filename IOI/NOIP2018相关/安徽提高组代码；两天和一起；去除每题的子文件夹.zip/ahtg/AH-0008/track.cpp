#include<fstream>
using namespace std;
int main() {
	ifstream fin("track.in");
	ofstream fout("track.out");
	int n,m; fin>>n>>m;
	for(int i=1,u,v,w;i<n;++i)
		fin>>u>>v>>w;
	fout<<26282;
}
