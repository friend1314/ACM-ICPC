#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
struct node {
	vector<int> son;
} tree[5005];
bool vis[5005];
int tot,n,m,ans[5005];
void dfs(int k) {
	ans[++tot]=k;
	sort(tree[k].son.begin(),tree[k].son.end());
	for(int i=0;i<tree[k].son.size();++i) {
		if(!vis[tree[k].son[i]]) {
			vis[tree[k].son[i]]=true;
			dfs(tree[k].son[i]);
		}
	}
}
int main() {
	freopen("traval.in","r",stdin);
	freopen("traval.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<=m;++i) {
		scanf("%d%d",&u,&v);
		tree[u].son.push_back(v);
		tree[v].son.push_back(u);
	}
	vis[1]=true; dfs(1);
	for(int i=1;i<=tot;++i)
		printf("%d ",ans[i]);
	fclose(stdin); fclose(stdout);
	return 0;
}