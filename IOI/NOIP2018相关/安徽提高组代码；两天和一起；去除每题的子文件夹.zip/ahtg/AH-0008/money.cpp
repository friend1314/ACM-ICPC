#include<algorithm>
#include<cstdio>
using namespace std;
inline int read() {
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
		s=s*10+ch-48,ch=getchar();
	return s*w;
}
int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t=read();
	while(t--) {
		int n=read(),a[105],ans=n;
		for(int i=1;i<=n;++i) a[i]=read();
		sort(a+1,a+n+1);
		for(int i=n;i>=1;--i)
			for(int j=1;j<n;++j)
				if(a[i]%a[j]==0) --ans;
		printf("%d\n",ans);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}