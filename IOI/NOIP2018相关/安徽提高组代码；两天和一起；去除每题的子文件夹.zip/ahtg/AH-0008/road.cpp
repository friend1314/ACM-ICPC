#include<cstdio>
inline int read() {
	int s=0,w=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if(ch=='-') w=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
		s=s*10+ch-48,ch=getchar();
	return s*w;
}
int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n=read(),d[100005];
	long long ans=0;
	for(register int i=1;i<=n;++i) d[i]=read();
	for(register int i=1;i<=n;++ans) {
		while(d[i]<=0) ++i;
		for(register int j=i;d[j]>0&&j<=n;++j) --d[j];
	}
	printf("%lld",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}