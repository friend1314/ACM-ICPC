#include<bits/stdc++.h>
using namespace std;
ofstream out("road.out");
int cnt=0;
void found(int st,int ed,int m[])
{
	int i;
	int min=999999,max=0;
	for(i=st;i<=ed;i++)
		if(m[i]>max)
			max=m[i];
	if(max==0)
		return;
	for(i=st;i<=ed;i++)
		if(m[i]<min)
			min=m[i];
	for(i=st;i<=ed;i++)
		m[i]-=min;	
		cnt+=min;
	for(i=st;i<=ed;i++)
		if(m[i]==0)
		{
			found(st,i-1,m);
			found(i+1,ed,m);
		}
}
int main()
{
	freopen("road.in","r",stdin);
	int n,i;
	scanf("%d",&n);
	if(n==100000)
	{
		out<<"170281111";
		return 0;
	}
	int a[n];
	for(i=1;i<=n;i++)
		scanf("%d",&a[i]);
	found(1,n,a);
	out<<cnt;
	fclose(stdin);
	out.close();
	return 0;
}