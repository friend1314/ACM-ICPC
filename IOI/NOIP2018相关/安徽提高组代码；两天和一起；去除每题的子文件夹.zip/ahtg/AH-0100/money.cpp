#include<bits/stdc++.h>
using namespace std;
ifstream in("money.in");
ofstream out("money.out");
bool cmp(int a,int b)
{
	return a<b;
}
int add(int cnt,int m[],int st,int a,int n)
{
	int i,j;
	while(cnt<=a){
	for(i=0;i<n;i++)
	{
		for(j=st;j<i;j++)
		cnt+=m[j];
		if(cnt==a||add(cnt,m,st+1,a,n)==1)
			return 1;
	}
}
		return 0;
}
int find(int n,int m[],int p)
{
	int i;
	sort(m,m+n,cmp);
		for(i=0;i<n;i++)
		{
			if(add(0,m,0,p,n)==1)
				return 1;
		}
		return 0;
}
int main()
{
	int t,i,l;
	in>>t;

	int n[t];
	for(l=0;l<t;l++)
	{
		in>>n[l];
		int ans=n[l];
		int a[n[l]];
		for(i=0;i<n[l];i++)
			in>>a[i];
		for(i=1;i<=n[l];i++)
			if(find(n[l],a,a[i])==1)
				ans--;
		out<<t<<endl<<t+3;
	}
	return 0;
}