#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
using namespace std;
inline int  read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-48;
		ch=getchar();
	}
	return x*f;
}
int T,n,a[105],b[105];
bool dp[25005];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--){
		n=read();
		memset(dp,0,sizeof(dp));
		for(int i=1;i<=n;i++)a[i]=read();
			sort(a+1,a+n+1);
			int tot=1;
			b[tot]=a[1];
			dp[0]=1;
			for(int i=2;i<=n;i++){
				for(int j=1;j<=tot;j++){
					for(int q=b[j];q<=a[i];q++){
						if(dp[q]==1)continue ;
						if(dp[q-b[j]]==1)dp[q]=1;
					}
				}
				if(dp[a[i]]==0){
					b[++tot]=a[i];
				}
			}
			printf("%d\n",tot);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}