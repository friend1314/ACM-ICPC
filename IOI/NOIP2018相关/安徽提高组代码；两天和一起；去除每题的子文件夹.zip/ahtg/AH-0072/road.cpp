#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
using namespace std;
inline int  read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-48;
		ch=getchar();
	}
	return x*f;
}
int n,ans=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	int last=0,x;
	for(int i=1;i<=n;i++){
		x=read();
		if(x>last)ans+=x-last;
			last=x;
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}