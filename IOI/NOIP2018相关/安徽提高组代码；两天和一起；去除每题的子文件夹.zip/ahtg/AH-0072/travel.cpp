#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
using namespace std;
int  read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-48;
		ch=getchar();
	}
	return x*f;
}
int n,m,cnt=0;
int head[10005],last[10005],a[10005],ans[10005];
bool vis[10005];
struct node{
	int to,next;
}e[10005];
void add(int x,int y){
	e[++cnt].next=head[x];
	head[x]=cnt;
	e[cnt].to=y;
}
void dfs(int u,int k,bool f){
	if(k==n){
		for(int i=1;i<=n;i++){
			if(a[i]<ans[i]){
				for(int j=i;j<=n;j++){
					ans[j]=a[j];
				}
				break ;
			}
			else if(a[i]>ans[i])break;
		}
		return ;
	}
	for(int i=head[u];i!=-1;i=e[i].next){
		int v=e[i].to;
		if(vis[v]==0){
			vis[v]=1;
			last[v]=u;
			a[k+1]=v;
			if(f==1)dfs(v,k+1,1);
				else if(f==0&&v<ans[k+1])dfs(v,k+1,1);
					else if(f==0&&v==ans[k+1])dfs(v,k+1,0);
	//		last[v]=0;
			vis[v]=0;
		}
		if(last[u]==v&&vis[v]==1){
			dfs(v,k,f);
		}
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	memset(head,-1,sizeof(head));
	memset(ans,0x3f,sizeof(ans));
	n=read();
	m=read();
	int x,y;
	for(int i=1;i<=m;i++){
		x=read();
		y=read();
		add(x,y);
		add(y,x);
	}
	ans[1]=1;
	a[1]=1;
	vis[1]=1;
	last[1]=0;
	dfs(1,1,0);
	for(int i=1;i<n;i++){
		printf("%d ",ans[i]);
	}
	printf("%d\n",ans[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}