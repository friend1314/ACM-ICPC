#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
using namespace std;
inline int  read(){
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+ch-48;
		ch=getchar();
	}
	return x*f;
}
int n,m,cnt=0;
int head[50005],dep[50005],dis[50005][22],f[50005][22];
struct rec{
	int x,y,z;
}d[50005];
struct node{
	int to,next,w;
}e[100005];
void add(int x,int y,int z){
	e[++cnt].next=head[x];
	head[x]=cnt;
	e[cnt].to=y;
	e[cnt].w=z;
}
void dfs(int u,int fa){
	dep[u]=dep[fa]+1;
	for(int i=0;i<=19;i++){
		f[u][i+1]=f[f[u][i]][i];
		dis[u][i+1]=dis[u][i]+dis[f[u][i]][i];
	}
	for(int i=head[u];i!=-1;i=e[i].next){
		int v=e[i].to;
		if(v==fa)continue ;
		f[v][0]=u;
		dis[v][0]=e[i].w;
		dfs(v,u);
	}
}
int lca(int x,int y){
	if(dep[x]<=dep[y]){
		int t=x;
		x=y;
		y=t;
	}
	int ans=0;
	for(int i=20;i>=0;i--){
		if(dep[f[x][i]]>=dep[y]){
			ans+=dis[x][i];
			x=f[x][i];
		}
		if(x==y)return ans;
	}
	for(int i=20;i>=0;i--){
		if(f[x][i]!=f[y][i]){
			ans+=dis[x][i]+dis[y][i];
			x=f[x][i];
			y=f[y][i];
		}
	}
	return ans+dis[x][0]+dis[y][0];
}
bool comp(rec a,rec b){
	return a.x<b.x;
}
bool comp1(rec a,rec b){
	return a.z>b.z;
}
bool check(int k){
	int s=0,now=0;
	for(int i=1;i<n;i++){
		if(s<k)s+=d[i].z;
		else {
			s=d[i].z;
			now++;
		}
	}
	if(now>=m)return 1;
		return 0;
}
bool check1(int k){
	int now=0,f=n-1,i=1;
	while(i<n){
		if(f<=i)break ;
		if(d[i].z>=k){
			now++;
			i++;
			continue ;
		}
		while(d[i].z+d[f].z<k&&f>i){
			f--;
		}
		if(f==i)break ;
		f--;
		now++;
		i++;
	}
	if(now>=m)return 1;
		return 0;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();
	m=read();
	memset(head,-1,sizeof(head));
	int f1=1,f2=1;
	for(int i=1;i<n;i++){
		d[i].x=read();
		d[i].y=read();
		d[i].z=read();
		if(d[i].y!=d[i].x+1)f1=0;
			if(d[i].x!=1)f2=0;
	}
	if(m==1){
		for(int i=1;i<n;i++){
			add(d[i].x,d[i].y,d[i].z);
			add(d[i].y,d[i].x,d[i].z);
		}
		dfs(1,0);
		int tot=0;
		for(int i=1;i<n;i++){
			for(int j=i+1;j<=n;j++){
				tot=max(tot,lca(i,j));
			}
		}
		printf("%d\n",tot);
	}
	else if(f1==1){
		sort(d+1,d+n,comp);
		int l=0x3f3f3f3f,r=0,mid;
		for(int i=1;i<n;i++){
			r+=d[i].z;
			l=min(l,d[i].z);
		}
		while(l<=r){
			mid=(l+r)/2;
			if(check(mid)){
				l=mid+1;
			}
			else r=mid-1;
		}
		printf("%d\n",r);
	}
	else if(f2==1){
		sort(d+1,d+n,comp1);
		int l=0x3f3f3f3f,r=0,mid;
		for(int i=1;i<n;i++){
			r+=d[i].z;
			l=min(l,d[i].z);
		}
		while(l<=r){
			mid=(l+r)/2;
			if(check1(mid)){
				l=mid+1;
			}
			else r=mid-1;
		}
		printf("%d\n",r);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}