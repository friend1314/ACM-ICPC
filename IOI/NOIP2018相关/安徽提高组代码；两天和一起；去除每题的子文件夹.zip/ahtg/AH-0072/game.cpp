#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
using namespace std;
const int p=1000000007;
int n,m,mp[9][100005],ans=0,tot=0;
char s[10005];
char ss[10005][15];
int w[10005][15];
void dfs1(int i,int j,int k){
	if(i==n-1&&j==m-1&&k==n+m-2){
		tot++;
		for(int q=0;q<k;q++)ss[tot][q]=s[q];
		return ;
	}
	if(i<n-1){
		s[k]='D';
		dfs1(i+1,j,k+1);
	}
	if(j<m-1){
		s[k]='R';
		dfs1(i,j+1,k+1);
	}
}
void gets(int k){
	int i=0,j=0;
	w[k][0]=mp[i][j];
	for(int q=0;q<n+m-2;q++){
		if(ss[k][q]=='D')i++;
			else if(ss[k][q]=='R')j++;
			w[k][q+1]=mp[i][j];
	}
}
bool pd1(int x,int y){
	for(int i=0;i<n+m-2;i++){
		if(ss[x][i]>ss[y][i])return 1;
			else if(ss[x][i]<ss[y][i])return 0;
	}
}
bool pd2(int x,int y){
	for(int i=0;i<n+m-1;i++){
		if(w[x][i]>w[y][i])return 1;
			else if(w[x][i]<w[y][i])return 0;
	}
	return 0;
}
bool check(){
	for(int i=1;i<=tot;i++)gets(i);
	for(int i=1;i<tot;i++){
		for(int j=i+1;j<=tot;j++){
			if(pd1(i,j)==1&&pd2(i,j)==1){
				return 0;
			}
			if(pd1(i,j)==0&&pd2(j,i)==1){
				return 0;
			}
		}
	}
	return 1;
}
void dfs(int i,int j){
	if(i==n){
		if(check()){
			ans++;
			ans%=p;
		}
		return ;
	}
	mp[i][j]=1;
	if(j==m-1)dfs(i+1,0);
		else if(j<m-1)dfs(i,j+1);
		mp[i][j]=0;
	if(j==m-1)dfs(i+1,0);
		else if(j<m-1)dfs(i,j+1);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	dfs1(0,0,0);
	dfs(0,0);
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}