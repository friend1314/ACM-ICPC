#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<stack>
using namespace std;
//read
int read(){
	char ch=getchar();
	int x=0,f=1;
	while(!isdigit(ch)){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=10*x+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int a[5010];
int n,m;
int e[5010][5010];
int cnt;
bool vis[5010];

void dfs(int x,int fa){
	int i;
	if(vis[x])return;
	vis[x]=true;
	a[++cnt]=x;
	//bianli
	for(i=1;i<=n;i++)
		if(e[x][i] && i!=fa)
			dfs(i,x);
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=read();m=read();
	int i;
	memset(vis,false,sizeof(vis));
	for(i=1;i<=m;i++){
		int u=read(),v=read();
		e[u][v]=e[v][u]=1;
	}
	dfs(1,1);
	for(i=1;i<=n;i++)
		printf("%d ",a[i]);
	return 0;
}
