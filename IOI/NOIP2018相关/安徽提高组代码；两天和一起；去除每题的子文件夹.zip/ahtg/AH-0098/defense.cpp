#include<cstdio>
#include<algorithm>
using namespace std;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++)
		printf("-1");
	return 0;
}
