#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
//read
int read(){
	char ch=getchar();
	int x=0,f=1;
	while(!isdigit(ch)){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=10*x+ch-'0';
		ch=getchar();
	}
	return x*f;
}

int n,m;
int s[300];
int d[300];
int t[300];
int cnt;
int mod=1000000007;

void dfs(int cur,int S){
	if(cur==n){
		s[++cnt]=S;
		return;
	}
	dfs(cur+1,S+(1<<cur));
	dfs(cur+1,S);
}

bool check(int x,int y){
	int i;
	y=~y;x>>=1;
	int all=(1<<(n-1))-1;
	if(((x|y)&all)==all)return true;
	return false;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();
	dfs(0,0);
	int i,j,k;
	for(i=1;i<=cnt;i++)
		d[i]=1;
	for(i=2;i<=m;i++){
		for(j=1;j<=cnt;j++){
			t[j]=d[j];
			d[j]=0;
		}
		for(j=1;j<=cnt;j++)
			for(k=1;k<=cnt;k++)
				if(check(s[k],s[j]))
					d[j]=(d[j]+t[k])%mod;
	}
	int ans=0;
	for(i=1;i<=cnt;i++){
		ans=(ans+d[i])%mod;
	}
	printf("%d",ans);
	return 0;
}
