#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef long long ll;
int read(){
	char ch=getchar();
	int x=0,f=1;
	while(!isdigit(ch)){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=10*x+ch-'0';
		ch=getchar();	
	}
	return x*f;
}

int n;
int a[100010];
int da[100010];


ll ans=0;



int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	int i;
	for(i=1;i<=n;i++){
		a[i]=read();
		da[i]=a[i]-a[i-1];
	}
	ans+=(ll)a[n];
	for(i=1;i<=n;i++)
		if(da[i]<0)
			ans-=da[i];
	printf("%lld",ans);
	return 0;
}
