#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;

int read(){
	char ch=getchar();
	int x=0,f=1;
	while(!isdigit(ch)){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=10*x+ch-'0';
		ch=getchar();	
	}
	return x*f;
}

void exgcd(int& d,int a,int b,int& x,int& y){
	if(!b){
		d=a;x=1;
		y=0;return;
	}
	exgcd(d,b,a%b,x,y);
	int tmp=x;
	x=y;
	y=tmp-a/b*x;
}

int T;
int n;
int a[110];
bool exist[110];

bool getans(int A,int B,int C){
	int i;
	if(!(B%A) && C%A)return false;
	if(!(C%A) || !(C%B))return true;
	//for(i=0;(A*i)<=C;i++)
	//	if(!((C-A*i)%B))
	//		return true;
	//return false;
	int x,y,d;
	exgcd(d,A,B,x,y);
	x*=C;y*=C;
	int aa=A/d;int bb=B/d;
	while(x<0){
		if(!bb)return false;
		int times=(-x)/bb+((-x)%bb!=0);
		x+=bb*times;
		y-=aa*times;
	}
	while(y<0){
		if(!aa)return false;
		int times=(-y)/aa+((-y)%aa!=0);
		x-=bb*times;
		y+=aa*times;
	}
	if(y<0 || x<0)return false;
	if(y%d || x%d)return false;
	return true; 
}




int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--){
		memset(exist,true,sizeof(exist));
		n=read();
		int ans=n;
		int i,j,k;
		for(i=1;i<=n;i++)
			a[i]=read();
		sort(a+1,a+1+n);
		//for(i=1;i<=n;i++)
		//	printf("%d ",a[i]);
		for(i=1;i<=n;i++)
		for(j=i;j<=n;j++)
		for(k=j+1;k<=n;k++)
			if(exist[k] && k!=i && k!=j)
			if(getans(a[i],a[j],a[k])){
				exist[k]=false;
				//if(a[k]==20)
				//	printf("20: %d %d\n",a[i],a[j]);
				ans--;
			}
		//for(i=1;i<=n;i++)
			//printf("%d\n",exist[i]);
		printf("%d\n",ans);
	}
	return 0;
}
