#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cctype>
using namespace std;
typedef struct Edge{
	int next,to,val;
};
int read(){
	char ch=getchar();
	int x=0,f=1;
	while(!isdigit(ch)){
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=10*x+ch-'0';
		ch=getchar();	
	}
	return x*f;
}
int DD[50010];
int dis[50010];
int dep[50010];
int fa[50010][18];
int head[50010];
Edge e[100010];
int maxn;
int cnt=0,n,m;

void AddEdge(int u,int v,int w){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	e[cnt].val=w;
	head[u]=cnt;
}


void Dfs(int x,int F){
	int i;
	for(i=head[x];i;i=e[i].next)
		if(e[i].to!=F){
			DD[e[i].to]=DD[x]+e[i].val;
			Dfs(e[i].to,x);
		}
}
//lca
void dfs(int x,int F){
	fa[x][0]=F;
	dep[x]=dep[F]+1;
	int i;
	for(i=1;(1<<i)<dep[x];i++)
		fa[x][i]=fa[fa[x][i-1]][i-1];
	for(i=head[x];i;i=e[i].next)
		if(e[i].to!=F){
			dis[e[i].to]=dis[x]+e[i].val;
			dfs(e[i].to,x);
		}
}

int lca(int x,int y){
	if(dep[x]<dep[y])swap(x,y);
	int i;
	for(i=16;i>=0;i--)
		if(dep[x]-(1<<i)>=dep[y])
			x=fa[x][i];
	if(x==y)return x;
	for(i=16;i>=0;i--)
		if(fa[x][i]!=fa[y][i]){
			x=fa[x][i];
			y=fa[y][i];
		}
	return fa[x][0];
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();
	m=read();
	int i;
	int tot=0;
	for(i=1;i<n;i++){
		int u=read();int v=read();
		int w=read();
		AddEdge(u,v,w);
		AddEdge(v,u,w);
		tot+=w;
	}
	dis[1]=0;
	dfs(1,1);
	//int X,Y;
	if(m==1){
		int i;
		int maxdis=0;
		int To=0;
		for(i=1;i<=n;i++)
			if(dis[i]>maxdis){
				maxdis=dis[i];
				To=i;
			}
		Dfs(To,To);
		maxdis=0;
		for(i=1;i<=n;i++)
			maxdis=max(maxdis,DD[i]);
		printf("%d",maxdis);
		return 0;
	}
	else{
		printf("%d",tot/m);
	}	
	return 0;
}
