#include<bits/stdc++.h>
using namespace std;
ifstream in("road.in");
ofstream out("road.out");
int n,num,a[100001];
void road(int x,int y)
{
	int i,j;
	if(x>y)
	return ;
	if(a[x]==0)
	road(x+1,y);
	if(a[y]==0)
	road(x,y-1);
	if(x==y)
	{
		num=num+a[x];
		a[x]=0;
		return ;
	}	
	for(i=x;i<=y;i++)
	{
		if(a[i]==0)
		{
			road(x,i-1);
			road(i+1,y);
			break;
		}
		if(i==y)
		{
			for(j=x;j<=y;j++)
			a[j]=a[j]-1;
			num++;
			road(x,y);
		}	
	}
}	
void read()
{
	int i;
	in>>n;
	for(i=1;i<=n;i++)
	in>>a[i];
}	
int main()
{
	read();
	road(1,n);
	out<<num<<endl;
	in.close();
	out.close();
	return 0;
}	