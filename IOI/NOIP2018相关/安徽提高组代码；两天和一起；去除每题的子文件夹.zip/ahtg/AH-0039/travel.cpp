#include<bits/stdc++.h>
using namespace std;
ifstream in("travel.in");
ofstream out("travel.out");
int n,m;
int flag[5001],a[5001][5001],mark[5001],ji[5001];
void work(int x)
{
	int i,j,num=0;
	out<<x<<" ";
	flag[x]=1;
	if(x!=1&&mark[x]==1)
	return ;
	for(i=1;i<=n;i++)
	{
		if(a[x][i]==1&&flag[i]==0)
		{
			num++;
			ji[num]=i;
		}
	}
	if(num==1)	
	work(ji[num]);	
	else
	{
		for(i=1;i<=num-1;i++)
		for(j=i+1;j<=num;j++)
		if(ji[i]>ji[j])
		swap(ji[i],ji[j]);
		for(i=1;i<=num;i++)
		work(ji[i]);
	}
}	
void read()
{
	int i,j,x,y;
	in>>n>>m;
	for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
	a[i][j]=99999999;	
	for(i=1;i<=n;i++)
	a[i][i]=0;	
	for(i=1;i<=m;i++)
	{
		in>>x>>y;
		a[x][y]=1;
		a[y][x]=1;
		mark[x]++;
		mark[y]++;
	}	
}	
int main()
{
	read();
	work(1);
	in.close();
	out.close();
	return 0;
}