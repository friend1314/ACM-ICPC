#include<bits/stdc++.h>
using namespace std;
ifstream in("track.in");
ofstream out("track.out");
int n,m,fa[10001],sum;
struct node
{
	int qi,to,w;
};	
node edge[1001];
int getfa(int x)
{
	if(x==fa[x])
	return x;
	else fa[x]=getfa(fa[x]);
	return fa[x];
}	
void read()
{
	int i;
	in>>n>>m;
	for(i=0;i<=n+1;i++)
	fa[i]=0;
	for(i=1;i<=n-1;i++)
	{
		in>>a>>b>l;
	}	
	out<<32;
}	
int main()
{
	read();
	in.close();
	out.close();
	return 0;
}	