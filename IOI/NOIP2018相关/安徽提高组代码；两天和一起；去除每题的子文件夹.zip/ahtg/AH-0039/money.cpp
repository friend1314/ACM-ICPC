#include<bits/stdc++.h>
using namespace std;
ifstream in("money.in");
ofstream out("money.out");
int T,n,a[101];
void read()
{
	int i,j;
	in>>T;
	for(i=1;i<=T;i++)
	{
		in>>n;
		for(j=1;j<=n;j++)
		in>>a[j];
		if(n==2)
		{
			if(a[1]%a[2]==0||a[2]%a[1]==0)
			out<<1;
			else out<<2;
		}
	}	
}	
int main()
{
	read();
	in.close();
	out.close();
	return 0;
}	