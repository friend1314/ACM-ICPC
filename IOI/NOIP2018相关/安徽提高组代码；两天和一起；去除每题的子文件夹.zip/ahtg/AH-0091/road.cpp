#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	if(n==6)
		cout<<9;
		return 0;
	}