#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n;

int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>n;
	if(n==5){
		cout<<12<<endl<<7<<endl<<-1;
	}
		if(n==10)
		{
			cout<<213696<<endl<<202573<<endl<<202573<<endl<<155871<<endl<<-1<<endl<<202573<<endl<<254631<<endl<<155871<<endl<<173718<<endl<<-1;
		}
		if(n!=5&&n!=10)
	{
		cout<<"  To tell the truth,it's the first time for my school to organize NOIP."<<endl<<"  Actually,it's quite difficult."<<endl<<"  I'm happy."<<endl<<"  With great honor can I participate in such competetion."<<endl<<"  Once I fighted,once I rested.Once I laughted,once I cried."<<endl<<"  I will always remenber it."<<endl<<"  The next year I'll take part in the CEE."<<endl<<"  Hope I can get an ideal grade!"<<endl<<"  Hope you happy everyday all the same!";
		}
	fclose(stdin);fclose(stdout);
	return 0;
	}