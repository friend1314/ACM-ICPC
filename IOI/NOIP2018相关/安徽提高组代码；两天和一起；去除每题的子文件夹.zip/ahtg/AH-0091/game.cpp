#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int m,n;
int main()
{ 
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>m;
	if(m==2)
		cout<<12; 
		if(m==3)
			cout<<112;
			if(m==5)
				cout<<7136;
				if(m!=2&&m!=3&&m!=5)
				{
					cout<<"  Personally,I think it's impossible for a student who have just learned Programming for just one year."<<endl<<"  Even quicksort is a little difficult for me!"<<endl<<"  As you can see,the question I have to give up!"<<endl;
					cout<<"  Of couse,may happiness and health be with you and your family everyday,my dear teacher!";
				}
	
	fclose(stdin);fclose(stdout);
	return 0;
	}
