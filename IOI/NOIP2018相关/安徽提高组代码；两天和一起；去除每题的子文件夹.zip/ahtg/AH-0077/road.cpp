#include<cstdio>
#include<algorithm>
using namespace std;
int a[1000000];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int sum=0,n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
	 scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++)
	{
	if(a[i+1]!=0) 
	 {
		a[i]--;
	  }
	 if(a[i+1]==0) sum++;
	}
	printf("%d",sum);
	return 0;
}