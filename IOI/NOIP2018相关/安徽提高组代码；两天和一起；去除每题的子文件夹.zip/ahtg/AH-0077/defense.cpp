#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,m,z,p,a,x,b,y,r1,r2;
	scanf("%d%d%s",&n,&m,&z);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&p);
	}
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d",&r1,&r2);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d%d",&a,&x,&b,&y);
	}
	for(int i=1;i<=m;i++)
	{
		printf("-1");
	}
	return 0;
}
