#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,t,a,b,c;
	scanf("%d%d",&t,&n);
	for(int i=1;i<=t;i++)
	{
		scanf("%d%d%d",&a,&b,&c);
	}
	printf("17");
	return 0;
}