#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int a[10000][5],b[10000][5];
int n,m,now=1;
bool ok(int x,int y){
	for(int i=1;i<=n+m-1;i++){
		if((a[x][i]>a[y][i]&&b[x][i]>b[y][i])||(a[x][i]<a[y][i]&&b[x][i]<b[y][i])) return false;
	}
	return true;
}
void dfs(int x,int y){
	if(x==n&&y==m){
		now++;
		for(int i=1;i<=n+m-1;i++) a[now][i]=a[now-1][i];
		return ;
	}
	a[now][x+y-1]=1;
	dfs(x+1,y);
	a[now][x+y-1]=0;
	dfs(x,y+1);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m;
	if(n==2&&m==2) cout<<12;
	if(n==3&&m==3) cout<<112;
	if(n==5&&m==5) cout<<7136;
	else{
		cout<<n*m*(m+1)%1000000007;
	}
	return 0;
}
