#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstdlib>
using namespace std;
int x,n,now,ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&x);
		if(x>now) ans+=(x-now);
		now=x;
	}
	printf("%d\n",ans);
	return 0;
}
