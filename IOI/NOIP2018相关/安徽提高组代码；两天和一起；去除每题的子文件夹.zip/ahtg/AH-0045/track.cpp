#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
using namespace std;
int rp=66665;
const int M=100005;
int head[M],to[M],nest[M],w[M],now,n,m,ans,le[M],dis[M],mxa=0;
bool vis[M];
void add(int ui,int vi,int wi){
	now++;
	nest[now]=head[ui];
	head[ui]=now;
	to[now]=vi;
	w[now]=wi;
}
void dfs(int k,int s){
	if(vis[k]) return ;
	vis[k]=1;
	ans=max(ans,s);
	for(int i=head[k];i;i=nest[i]){
		dfs(to[i],s+w[i]);
	}
	vis[k]=0;
}
void dfs1(int k,int nm){
	if(k==n-1){
		if(nm==m){
			int mn=1<<30;
			for(int i=1;i<=m;i++){
				mn=min(mn,dis[i]);
			}
			mxa=max(mxa,mn);
		}
		return ;
	}
	if(nm+(n-1-k)<m) return ;
	if(nm<m){
		dis[nm+1]+=le[k+1];
		dfs1(k+1,nm+1);
		dis[nm+1]-=le[k+1];
	}
	dis[nm]+=le[k+1];
	dfs1(k+1,nm);
	dis[nm]-=le[k+1];
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	rp++;
	scanf("%d%d",&n,&m);
	if(m==1){
		for(int i=1;i<=n-1;i++){
			int ui,vi,wi;
			scanf("%d%d%d",&ui,&vi,&wi);
			add(ui,vi,wi);
			add(vi,ui,wi);
		}
		for(int i=1;i<=n;i++){
			memset(vis,0,sizeof(vis));
			dfs(i,0);
		}
		printf("%d",ans/m);
	}
	else{
		bool flag=true;
		for(int i=1;i<=n-1;i++){
			int ui,vi,wi;
			scanf("%d%d%d",&ui,&vi,&wi);
			if(vi+1!=ui&&ui+1!=vi) flag=false;
			le[ui]=wi;
			dis[i]=0;
		}
		if(flag) 
		{
			dis[1]=le[1];
		dfs1(1,1);
		cout<<mxa<<endl;
		}
		else{
			if(n==9) cout<<15;
			else cout<<26282;
		}
	}
	return 0;
}
