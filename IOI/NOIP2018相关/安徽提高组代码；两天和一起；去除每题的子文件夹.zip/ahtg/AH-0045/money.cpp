#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <ctime>
#include <cstdlib>
using namespace std;
int t,n,w[105];
bool cmp(int x,int y){
	return x<y;
}
bool flag=false;
bool vis[105];
int tw[105];
bool f[1005];
bool check(){
	int len=0;
	for(int i=1;i<=n;i++){
		if(vis[i]){
			tw[++len]=w[i];
		}
	}
	for(int i=1;i<=w[n];i++) f[i]=0;
	f[0]=1;
	for(int i=1;i<=len;i++){
		for(int j=tw[i];j<=w[n];j++){
			if(f[j-tw[i]]) f[j]=1;
		}
	}
	for(int i=1;i<=n;i++){
		if(!f[w[i]]) return false;
	}
	return true;
}
void dfs(int x,int now,int k){
	if(now>x) return ;
	if(k>n+1) return ;
	if(now+(n-k+1)<x) return ;
	if(now==x){
		if(check()) flag=true;
		return ;
	}
	if(flag) return ;
	vis[k]=1;
	dfs(x,now+1,k+1);
	if(flag) return ;
	vis[k]=0;
	dfs(x,now,k+1);
	return ;
}
bool ok(int x){
	flag=false;
	memset(vis,0,sizeof(vis));
	dfs(x,0,1);
	return flag;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&w[i]);
		}
		sort(w+1,w+1+n,cmp);
		int l=1,r=n;
		while(l<r){
			int mid=(l+r)>>1;
			if(ok(mid)){
				r=mid;
			}
			else l=mid+1;
		}
		printf("%d\n",r);
	}
	return 0;
}
