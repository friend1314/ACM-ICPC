 #include <cstdio>
#include <iostream>
using namespace std;
const int M=5002;
int now,n,m,pre[M],ans[M],len,lis[M],lel;
bool inh[M],mnf,sts;
int mp[M][M],anst;
bool vis[M],flag;
int mn=1<<30;
void dfs(int u){
	vis[u]=1;
	ans[++len]=u;
	for(int i=1;i<=n;i++){
		if(i==u) continue;
		if(vis[i]) continue;
		if(mp[u][i]==0) continue;
		dfs(i);
	}
}
void dfs_ghs(int u){
	if(anst!=-1)  return ;
	vis[u]=1;
	for(int i=1;i<=n;i++){
		if(i==u) continue;
		if(i==pre[u]) continue;
		if(mp[u][i]==0) continue;
		if(vis[i]){
			anst=i;
			return ;
		}
		pre[i]=u;
		dfs_ghs(i);
		if(anst!=-1) return ;
	}
}
void dfs_ghf(int u){
	if(flag) return ;
	vis[u]=1,lis[++lel]=u;
	for(int i=1;i<=n;i++){
		if(i==u) continue;
		if(i==pre[u]) continue;
		if(mp[u][i]==0) continue;
		if(vis[i]){
			flag=true;
			return ;
		}
		pre[i]=u;
		dfs_ghf(i);
		if(flag) return ;
	}
	--lel;
}
void dfs_ans(int u,int las){
	vis[u]=1;
	ans[++len]=u;
	int mnmn=1<<30;
	int tmfs=1<<30;
	if(inh[u]){
		for(int i=1;i<=n;i++){
			if(mp[u][i]&&!vis[i])
				if(mnmn==1<<30) mnmn=i;
				else{
					tmfs=i; break ;
				}
			else continue;
		}
		sts=1;
	}
	for(int i=1;i<=n;i++){
		if(i==u) continue;
		if(vis[i]) continue;
		if(mp[u][i]==0) continue;
		if(inh[i]&&inh[pre[u]]){
			if(mnf==false){
				if(i>las){
					mnf=true;
					return ;
				}
			}
		}
		pre[i]=u;
		if(tmfs!=1<<30) dfs_ans(i,tmfs);
		else dfs_ans(i,las);
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int ui,vi;
		scanf("%d%d",&ui,&vi);
		mp[ui][vi]=1;
		mp[vi][ui]=1;
		mn=min(mn,min(ui,vi));
	}
	if(m==n-1){
		pre[mn]=-1;
		dfs(mn);
		for(int i=1;i<=n;i++){
			printf("%d ",ans[i]);
		}
	}
	else{
		anst=-1;
		dfs_ghs(mn);
		for(int i=1;i<=n;i++) vis[i]=0,pre[i]=0;
		pre[mn]=-1;
		dfs_ghf(anst);
		for(int i=1;i<=lel;i++) inh[lis[i]]=1;
		for(int i=1;i<=n;i++) vis[i]=0,pre[i]=0;
		dfs_ans(mn,1<<30);
		for(int i=1;i<=n;i++){
			printf("%d ",ans[i]);
		}
	}
	return 0;
}
