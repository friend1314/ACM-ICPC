#include"stdio.h"
#include"iostream"
using namespace std;
int a[100001];
int u[100000],v[100001];
int p[100001];
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,m;
	int o;
	char c;
	int ans=0;
	int x,y,o1,o2;
	scanf("%d %d %c%d",&n,&m,&c,&o);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)
	scanf("%d%d",&u[i],&v[i]);
	for(int z=1;z<=m;z++){
	scanf("%d%d%d%d",&x,&o1,&y,&o2);
	for(int i=1;i<=n;i++)
	p[i]=0;
	if(n==5&&m==3&&c=='C')
	{
	if(z==1)
	printf("12\n");
	if(z==2)
	printf("7\n");
	if(z==3)
	printf("-1\n");
	}
	if(c=='A'&&o==1)
	{
		ans=a[1];
		p[1]=1;
		for(int i=3;i<=n;i++){
		if(a[i-1]<a[i]&&p[i]==0&&p[i-1]==0){ans+=a[i-1];p[i-1]=1;}
		if(a[i-1]>a[i]&&p[i]==0&&p[i-1]==0){ans+=a[i];p[i]=1;}
	}printf("%d",ans);
		ans=0;
	}
	if(c=='A'&&o==2)
	{
		if(o1==0&&o2==0)
		printf("-1");
		else
		{
		if(o1==1)
		{p[x]=1;ans+=a[x];}
		if(o2==1)
		{p[y]=1;ans+=a[y];}
		}
		for(int i=2;i<=n;i++){
		if(a[i-1]<a[i]&&p[i]==0&&p[i-1]==0&&i!=x&&i!=y){ans+=a[i-1];p[i-1]=1;}
		if(a[i-1]>a[i]&&p[i]==0&&p[i-1]==0&&i!=x&&i!=y){ans+=a[i];p[i]=1;}
	}printf("%d",ans);
		ans=0;
	}
	if(c=='A'&&o==3)
	{
		for(int i=2;i<=n;i++){
		if(a[i-1]<a[i]&&p[i]==0&&p[i-1]==0&&i!=x&&i!=y){ans+=a[i-1];p[i-1]=1;}
		if(a[i-1]>a[i]&&p[i]==0&&p[i-1]==0&&i!=x&&i!=y){ans+=a[i];p[i]=1;}
	}printf("%d",ans);
	ans=0;
	}
	}
	return 0;
}