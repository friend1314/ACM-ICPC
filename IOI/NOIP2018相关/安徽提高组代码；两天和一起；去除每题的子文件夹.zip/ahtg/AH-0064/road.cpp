#include"stdio.h"
#include"iostream"
using namespace std;
int ans;
int num;
int n;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	scanf("%d",&num);
	ans=num;
	unsigned long long sum=0;
	sum=num;
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&num);
		if(ans<num)
		sum+=num-ans;
		ans=num;
	}
	printf("%lld",sum);
	return 0;
}