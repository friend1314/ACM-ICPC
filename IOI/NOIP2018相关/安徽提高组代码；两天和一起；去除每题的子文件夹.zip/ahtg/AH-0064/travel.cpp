#include"stdio.h"
#include"stdlib.h"
#include"iostream"
#include"algorithm"
using namespace std;
int f[100001];
int p[100001]={0};
int a[100001];
int find(int x)
{
	if(f[x]==x)return x;
	else
	{
	f[x]=find(f[x]);
	return f[x];
	}
}
struct node
{
	int u,v;
}e[100001];
node e1[100001];
bool cmp(node a,node b)
{
	return a.u<b.u;
}
int ans[100001];
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	ans[i]=10000;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&e[i].u,&e[i].v);
		e1[i].u=e[i].v,e1[i].v=e[i].u;
	}
	sort(e+1,e+1+m,cmp);
	sort(e1+1,e1+1+m,cmp);
	ans[1]=min(e1[1].v,e[1].u);
	p[ans[1]]=1;
	for(int o=2;o<=n;o++){
	for(int i=1;i<=m;i++){
	for(int j=1;j<=m;j++)
	{
	if(ans[o-1]==e[j].u&&p[e[j].v]==0)
	ans[o]=min(ans[o],e[j].v);
	if(ans[o-1]==e1[j].u&&p[e1[j].v]==0)
	ans[o]=min(ans[o],e1[j].v);
	if(ans[o-1]==e[j].v&&p[e[j].u]==0)
	ans[o]=min(ans[o],e[j].u);
	if(ans[o-1]==e1[j].v&&p[e1[j].u]==0)
	ans[o]=min(ans[o],e1[j].u);
	p[ans[o]]=1;
	}
}
}
int l=1;
	for(int i=1;i<=n;i++){
	if(p[i]==0)
	a[l]=i;
	l++;
	}
	for(int i=1;i<=n;i++)
	if(ans[i]!=10000)
	printf("%d ",ans[i]);
	else
	break;
	for(int i=1;i<=l;i++)
	if(a[i]>0)
	printf("%d ",a[i]);
	return 0;
}