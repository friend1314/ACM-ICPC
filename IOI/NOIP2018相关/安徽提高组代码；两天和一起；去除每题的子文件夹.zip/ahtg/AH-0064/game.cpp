#include"stdio.h"
#include"iostream"
using namespace std;
long long kspow(int m,int base)
{
	long long ans=1;
	for(int i=1;i<=m;i++)
	{
	ans*=base;
	ans%=1000000007;
	}
	return ans;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(n==1)
	{printf("%d",kspow(m,2));return 0;}
	if(m==1)
	{printf("%d",kspow(n,2));return 0;}
	if(n<=m&&n!=1&&m!=1)
	printf("%lld",(((n*n-n+1)%1000000007)*(kspow(m,2))%1000000007*((n-1))%1000000007)%1000000007);
	else
	printf("%lld",(((m*m-m+1)%1000000007)*(kspow(n,2))%1000000007*((m-1))%1000000007)%1000000007);
	return 0;
}