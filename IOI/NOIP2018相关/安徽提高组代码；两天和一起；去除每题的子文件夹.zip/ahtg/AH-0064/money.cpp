#include"stdio.h"
#include"iostream"
#include"algorithm"
using namespace std;
int t[25001];
int a[101];
int b[10001];
int INF=25001;
int n;
int ti;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&ti);
	while(ti--){
	int sum=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
	scanf("%d",&a[i]);
	}
	sort(a+1,a+1+n);
	for(int j=1;j<=n;j++)
	for(int i=j+1;i<=n;i++)
	{
	if(a[i]%a[j]==0)a[i]=INF;
	}
	sort(a+1,a+1+n);
	for(int j=1;j<=n;j++)
	for(int k=j+1;k<=n;k++)
	for(int i=k+1;i<=n;i++)
	for(int o=1;a[k]*o<=a[i];o++)
	{
	int ans=a[j]*a[k]-a[j]-a[k];
	if(a[i]>ans)a[i]=INF;
	if((a[i]-a[k]*o)%a[j]==0)a[i]=INF;}
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	for(int k=j+1;k<=n;k++)
	for(int o=k+1;o<=n;o++)
	{
	if(a[i]%(a[o]+a[j]+a[k])==0)a[i]=INF;
	}
	for(int i=1;i<=n;i++)
	if(a[i]<INF)sum++;
	/*for(int i=1;i<=n;i++)
	printf("%d ",a[i]);*/
	printf("%d\n",sum);
	}
	return 0;
}