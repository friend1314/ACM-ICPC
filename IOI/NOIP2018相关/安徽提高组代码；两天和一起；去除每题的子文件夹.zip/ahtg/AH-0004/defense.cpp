#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <queue>
#include <iostream>
using namespace std;

int n,m;
long long ans;
int p[100005];
int f[100005];

int main()
{
	freopen("defense.in","r",stdin);
    freopen("defense.out","w",stdout);
	scanf("%d %d ",&n,&m);
	char c;
	int d;
	scanf("%c %d",&c,&d);
	int i,j,x,y,a,b;
	for(i=1;i<=n;i++)
		scanf("%d",&p[i]);
	for(i=1;i<n;i++)
		scanf("%d %d",&x,&y);
	for(j=1;j<=m;j++)
	{
		scanf("%d %d %d %d",&a,&x,&b,&y);
		ans=0;
		memset(f,-1,sizeof(f));
		if(abs(a-b)==1&&x==0&&y==0)
		{
			printf("-1\n");
			continue;
		}
		for(i=1;i<n;i++)
		{
			if(i==a&&x==0) continue;
			if(i==b&&y==0) continue;
			if(i==a)
			{
				if(x==1){f[i]=1,ans+=p[i];}
				continue;
			}
			if(i+1==a)
			{
				if(x==1){f[i+1]=1,ans+=p[i+1];}
				i++;
				continue;
			}
			if(i==b)
			{
				if(y==1){f[i]=1,ans+=p[i];}
				continue;
			}
			if(i+1==b)
			{
				if(y==1){f[i+1]=1,ans+=p[i+1];}
				i++;
				continue;
			}
			if(f[i-1]!=1) {ans+=p[i],f[i]=1;continue;}
			if(p[i]<p[i+1]) {ans+=p[i],f[i]=1;}
		}
		int flag=1;
		for(i=1;i<n;i++)
		{
			if(f[i]!=1&&f[i+1]!=1)
				flag=0;
		}
		if(flag)
			printf("%lld\n",ans);
		else
			printf("-1\n");
	}
	return 0;
}
