#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <queue>
#include <iostream>
using namespace std;

int n,m,cnt=0;
struct node
{
	int v,next;
}edge[10005];
int headlist[5005];
int ans[5005];
int visited[5005];
int out[5005];
//queue <int>q;
//priority_queue <int>qq;

void addedge(int u,int v)
{
	edge[++cnt].v=v;
	edge[cnt].next=headlist[u];
	headlist[u]=cnt;
}

void work(int u)
{
	int j,k,flag=1,vtem,v=5001;
	ans[++cnt]=u;
	visited[u]=1;
	while(flag)
	{
		v=5001;
		for(j=headlist[u];j;j=edge[j].next)
	    {
			vtem=edge[j].v;
		    if(!visited[vtem])
		    {
				if(vtem<v)
					v=vtem;
		    }
		}
		if(v>5000) return;
	    work(v);
	    int flagt=1;
	    for(k=headlist[u];k;k=edge[k].next)
			if(!visited[edge[k].v])
				flagt=0;
		if(flagt) flag=0;
    }
}

int main()
{
	freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    scanf("%d %d",&n,&m);
	int i;
	for(i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d %d",&u,&v);
		addedge(u,v);
		addedge(v,u);
	}
	cnt=0;
	work(1);
	for(i=1;i<=n;i++)
		printf("%d ",ans[i]);
	return 0;
}
