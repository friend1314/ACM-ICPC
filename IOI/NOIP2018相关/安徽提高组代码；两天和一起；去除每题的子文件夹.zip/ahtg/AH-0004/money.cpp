#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <iostream>
using namespace std;

int t,n;
int a[105];
int f[105][105];

int gcd(int x,int y)
{
	int tem;
	while(y!=0)
	{
		tem=y;
		y=x%y;
		x=tem;
	}
	return x;
}

int main()
{
	freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
	int i,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			if(a[i]==1)
			{
				printf("1\n");
				return 0;
			}
		}
	    if(n==1)
		{
			printf("1\n");
			continue;
		}
	    if(n==2)
		{
			if(a[1]==1||a[2]==1) {printf("1\n"); continue;}
			int g=gcd(a[1],a[2]);
			if(g==a[1]||g==a[2]||g==1) 
				printf("1\n");
			else
				printf("2\n");
			continue;
		}
		int flag=1;
		for(i=1;i<=n;i++)
			for(j=i+1;j<=n;j++)
			{
				int g=gcd(a[i],a[j]);
				if(g==1) f[i][j]=a[i]*a[j]-a[i]-a[j];
				if(g!=1) flag=0;
			}
		if(flag) 
			printf("%d\n",n);
	}
	return 0;
}
