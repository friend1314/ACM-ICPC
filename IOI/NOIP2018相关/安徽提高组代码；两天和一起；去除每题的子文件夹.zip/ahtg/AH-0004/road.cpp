#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <iostream>
using namespace std;

int n;
int d[100005];
long long ans=0;

int main()
{
	freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d",&n);
	int i;
	for(i=1;i<=n;i++)
		scanf("%d",&d[i]);
	d[0]=0;
	for(i=1;i<=n;i++)
	{
		if(d[i]>d[i-1])
			ans=ans+d[i]-d[i-1];
	}
	cout << ans;
	return 0;
}
