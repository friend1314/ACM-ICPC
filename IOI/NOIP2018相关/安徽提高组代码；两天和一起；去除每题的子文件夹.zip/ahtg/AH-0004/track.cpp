#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <algorithm>
#include <iostream>
using namespace std;

int n,m,cnt=0,ans=0;
struct node
{
	int v,w,next;
}edge[100005];
int headlist[50005];
int dist[50005],visited[50005];
queue <int>q;
int line[50005];

void addedge(int u,int v,int w)
{
	edge[++cnt].v=v;
	edge[cnt].w=w;
	edge[cnt].next=headlist[u];
	headlist[u]=cnt;
	edge[++cnt].v=u;
	edge[cnt].w=w;
	edge[cnt].next=headlist[v];
	headlist[v]=cnt;
}

int check(int x)
{
	int i,sum=0,anstem=0;
	for(i=1;i<=n-1;i++)
	{
		anstem+=line[i];
		if(anstem>=x)
		{
			sum++;
			anstem=0;
		}
	}
	return sum;
}

int main()
{
	freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
	int i,u,v,w;
	scanf("%d %d",&n,&m);
	int flag=1;
	int l=0,r=0;
	for(i=1;i<=n-1;i++)
	{
		scanf("%d %d %d",&u,&v,&w);
		r+=w;
		if(u+1!=v) flag=0;
		addedge(u,v,w);
		line[u]=w;
	}
	if(flag)
	{
		int mid;
		while(l<=r)
		{
			mid=(l+r)>>1;
			if(check(mid)>=m)
			{
				ans=mid;
				l=mid+1;
			}
			else
				r=mid-1;
		}
		printf("%d\n",ans);
		return 0;
	}
	printf("91\n");
	return 0;
}
