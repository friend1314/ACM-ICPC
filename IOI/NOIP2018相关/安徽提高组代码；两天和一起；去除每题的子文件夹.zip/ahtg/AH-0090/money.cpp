#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;

int N;
int w[105];
int vis[25005];

void work(){
	int ans,i,j;
	ans=0;
	for(i=0;i<=w[N];i++){
		vis[i]=0;
		for(j=1;w[j]<i;j++){
			if(vis[i-w[j]]){
				vis[i]=1;
				break;
			}
		}
		if(w[j]==i&&vis[i]==0){
			ans++;
			vis[i]=1;
		}
	}
	cout<<ans<<endl;
	return ;
}

bool cmp(int a,int b){
	return a<b;
}

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	cin>>t;
	while(t--){
		cin>>N;
		for(int i=1;i<=N;i++){
			scanf("%d",&w[i]);
		}
		sort(w+1,w+1+N,cmp);
		work();
	}
	return 0;
}