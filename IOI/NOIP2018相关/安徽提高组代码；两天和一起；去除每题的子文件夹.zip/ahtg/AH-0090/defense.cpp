#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

int W[100005],F[100005];
int P[100005];
int N,M;
char p;

int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>N>>M>>p>>p;
	int a,b,x,y;
	for(int i=1;i<=N;i++){
		scanf("%d",&W[i]);
	}
	for(int i=1;i<N;i++)scanf("%d%d",&a,&a);
	for(int i=1;i<=M;i++){
		scanf("%d%d%d%d",&a,&x,&b,&y);
		F[0]=0;
		if(x==0)P[a]=-1;
		else P[a]=1;
		if(y==0)P[b]=-1;
		else P[b]=1;
		if((a!=1||x!=0)&&(b!=1||y!=0))F[1]=W[1];
		else F[1]=-1;
		if((a!=2||x!=0)&&(b!=2||y!=0))F[2]=W[2];
		else F[2]=-1;
		if(F[1]==-1&&F[2]==-1){
			cout<<-1<<endl;
			continue;
		}
		for(int j=3;j<=N;j++){
			F[j]=0x7f7f7f7f;
			if(P[j-3]>=0)F[j]=min(F[j],F[j-3]+W[j]);
			if(P[j-2]==1)F[j]=F[j-2]+W[j];
			if(P[j-2]>=0)F[i]=min(F[j],F[j-2]+W[j]);
			if(P[j-1]==1)F[j]=F[j-1]+W[j];
			else F[j]=min(F[j-1]+W[j],F[j]);
		}
		cout<<F[N]<<endl;
	}
	return 0;
}