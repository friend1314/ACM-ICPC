#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

long long F[10][2][2];
long long mod;

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int N,M;
	cin>>N>>M;
	F[1][1][0]=1;
	cout<<112;
	return 0;
}