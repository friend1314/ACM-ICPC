#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;

int w[50005],L[50005],R[50005],num[50005];
int H[50005];
int p[50005];
int N,M,ans;

bool cmp(int a,int b){
	return a>b;
}

void add(int a,int b){
	R[b]=L[a];
	L[a]=b;
	num[a]++;
	return ;
}

int work(int s,int n,int h){
	int l,r,mid,t,a=0;
	l=h;
	r=h+n-1;
	mid=(l+r)/2;
	t=p[mid]+p[mid+1];
	while(l<r-1){
		mid=(l+r)/2;
		t=p[mid]+p[mid+1];
		if(t<s)r=mid;
		else l=mid;
	}
	t=l;
	mid=l;
	if(p[t]+p[t+1]<s)return p[h];
	for(l=t,r=t+1;l>=h&&r<h+n;){
		if(p[l]+p[r]>=s){
			a++;
			l--;
			r++;
		}
		else {
			t=l;
			l--;
		}
	}
	ans+=a;
	if(l>=h)return p[h];
	if(t<mid)return p[t];
	if(r>=h+n)return 0;
	t=r;
	for(l=mid,r=mid+2;l>=h&&r<h+n;){
		if(p[l]+p[r]>=s){
			a--;
			l--;
			r++;
		}
		else {
			t=l;
			l--;
		}
	}
	if(a==0)return p[mid+1];
	else return p[t];
}

int dfs(int k,int s){
	if(ans>=M)return 0;
	int i,j,m;
	j=H[k];
	for(i=L[k];i!=0;i=R[i]){
		p[j]=dfs(i,s);
		j++;
	}
	if(ans>=M)return 0;
	sort(p+H[k],p+H[k]+num[k],cmp);
	m=work(s,num[k],H[k]);
	if(m+w[k]>=s){
		ans++;
		return 0;
	}
	else return m+w[k];
}

void er(int r){
	int l,mid;
	l=0;
	mid=(l+r)/2;
	while(l<r-1){
		mid=(l+r)/2;
		ans=0;
		dfs(1,mid);
		if(ans>=M)l=mid;
		else r=mid;
	}
	cout<<l;
	return ;
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int a,b,W;
	W=0;
	cin>>N>>M;
	memset(num,0,sizeof(num));
	for(int i=1;i<N;i++){
		scanf("%d%d",&a,&b);
		if(a>b)swap(a,b);
		scanf("%d",&w[b]);
		W+=w[b];
		add(a,b);
	}
	H[0]=1;
	for(int i=1;i<=N;i++){
		H[i]=H[i-1]+num[i-1];
	}
	er(W);
	return 0;
}