#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d,m;
	long long ans=0;
	cin>>n;
	m=0;
	for(int i=1;i<=n;i++){
		scanf("%d",&d);
		if(d>m){
			ans+=d-m;
		}
		m=d;
	}
	cout<<ans;
	return 0;
}