#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

int N,M;
int H[5005],to[10005],next[10005];
int vis[5005],tap[10005];
int L[5005],R[5005];
int ans[5005],top;
struct node{
	int a,b;
}E[10005];

bool cmp(node a,node b){
	return a.b<b.b;
}

void add(int a,int b,int i){
	next[i]=H[a];
	H[a]=i;
	to[i]=b;
	return ;
}

void find(int k){
	
}

void dfs(int k){
	int b;
	for(int i=H[k];i!=0;i=next[i]){
		b=to[i];
		if(vis[b])continue;
		vis[b]=1;
		R[b]=L[k];
		L[k]=b;
		dfs(b);
	}
	return ;
}

void dfs2(int k){
	top++;
	ans[top]=k;
	for(int i=L[k];i!=0;i=R[i]){
		dfs2(i);
	}
}

void work(){
	sort(E+1,E+2*M+1,cmp);
	//for(int i=1;i<=M*2;i++)cout<<E[i].a<<E[i].b<<endl;
	for(int i=1;i<=M*2;i++){
		add(E[i].a,E[i].b,i);
	}
	vis[1]=1;
	dfs(1);
	memset(vis,0,sizeof(vis));
	top=0;
	dfs2(1);
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>N>>M;
	for(int i=1;i<=M;i++){
		scanf("%d%d",&E[i].a,&E[i].b);
		E[i+M].a=E[i].b;
		E[i+M].b=E[i].a;
	}
	memset(vis,0,sizeof(vis));
	work();
	for(int i=1;i<=N;i++)printf("%d ",ans[i]);
	return 0;
}
