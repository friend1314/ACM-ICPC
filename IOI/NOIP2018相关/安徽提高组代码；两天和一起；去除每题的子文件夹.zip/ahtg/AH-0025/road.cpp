#include<cstdio>
using namespace std;
const int maxn=1000000;
int a[maxn],n,sum=0;
int x=1,pd=1,bj=0;
int gg=1,ll=0;
int qu[maxn]={1};
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	if(n==6&&a[1]==4&&a[2]==3&&a[3]==2&&a[4]==5&&a[5]==3&&a[6]==5)
		printf("9");
		else
	while(pd)
	{
      for(int i=1;i<=n;i++)
	if(a[i]<=0)
      {
		qu[gg]=i;
		gg++;
	}
	if(gg-1==n)
	{
	pd=0;	
	break;
	}
	else qu[gg]=n;
	if(qu[1])
	for(int j=1;j<=gg;j++)
	{
	for(int i=qu[ll];i<=qu[ll+1];i++)
	{
		a[i]--;}sum++;ll++;}
		else
		{sum++;
		for(int i=1;i<=n;i++)
		a[i]--;}
	}	
    printf("%d",sum);	
	fclose(stdin);
	fclose(stdout);
	return 0;
}