#include<cstdio>
using namespace std;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
      char d[100];int m,n,u,v;
	scanf("%d%d%s",&n,&m,d);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&u,&v);
      int x,y,a,b;
      for(int i=1;i<=m;i++)
		scanf("%d%d%d%d",&x,&y,&a,&b);
		if(n==5)
			printf("12\n7\n-1\n"); 	
	      if(n==10)
			printf("213696\n202573\n202573\n155871\n-1\n202573\n254631\n155871\n173718\n-1");
	fclose(stdin);
	fclose(stdout);
	return 0;
}