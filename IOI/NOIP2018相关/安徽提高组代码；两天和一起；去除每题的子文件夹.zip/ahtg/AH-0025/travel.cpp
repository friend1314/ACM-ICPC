#include<cstdio>
using namespace std;
const int maxn=5020;
int date[maxn],sum=1;
int a[maxn][maxn];
int bj[maxn]={1,1},h[maxn]={1,0};
int n,m;
void dfs(int k)
{
	for(int i=1;i<=n;i++)
	{
		if(sum-1==n)
		return;
		if(a[k][i]&&!h[i])
		{
			date[sum]=i;
			sum++;
			bj[k]=1;
			h[i]=1;
			dfs(i);
		}
	}
	 if(!bj[k]&&!h[k])
	 {
		date[sum]=k;
		sum++;
		 h[k]=1;
		 if(sum-1==n)
		return;
	 }
}
void work()
{
	int u,v;
	a[1][1]=1;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
      {
		scanf("%d%d",&u,&v);
		a[u][v]=1;
		a[v][u]=1;
	}
	dfs(1);
	for(int i=1;i<=n;i++)
	printf("%d ",date[i]);
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}