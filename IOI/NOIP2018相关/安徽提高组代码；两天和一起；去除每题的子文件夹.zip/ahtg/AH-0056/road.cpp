#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
using namespace std;
const int MAXN=100005;
int dep[MAXN];
int n,minn;
long long ans=0;
int check(int x,int y){
	for(int i=x;i<=y;i++) if(minn>dep[i]) minn=dep[i];
	return minn;
}
void init(void){
	scanf("%d",&n);
	minn=10001;
	for(int i=1;i<=n;i++){
		scanf("%d",&dep[i]);
		if(dep[i]<minn) minn=dep[i];
	}
	return;
}
void del(int x,int y,int k){
	for(int i=x;i<=y;i++) dep[i]-=k;
	return;
}
void work(void){
	del(1,n,minn); ans+=minn;
	for(int i=1;i<=n;){
		if(dep[i]==0) i++;
		int j;
		for(j=i;;j++) if(dep[j]==0) break; j--;
		minn=dep[i];
		minn=check(i,j);
		del(i,j,minn);
		ans+=minn;
	}
	return;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	init();
	work();
	printf("%lld",ans);
	return 0;
}
