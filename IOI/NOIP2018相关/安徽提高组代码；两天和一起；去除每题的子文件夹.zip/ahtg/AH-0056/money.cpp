#include<algorithm>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
using namespace std;
int T,n,k=1;
int mon[105],add[100005];
int a2[105],a3[105],a4[105],a5[105],a6[105],a7[105],a8[105],a9[105],a10[105],a11[105];
bool vis[105];
void work(void){
	memset(vis,true,sizeof(vis));
	int k=1;
	scanf("%d",&n);
	int ans=n;
	for(int i=1;i<=n;i++) scanf("%d",&mon[i]);
	if(n==1){
		printf("1\n");
		return;
	}
	if(n==2){
		printf("2\n");
		return;
	}
	sort(mon+1,mon+1+n);
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(mon[j]%mon[i]==0 && i!=j){
				ans--;
				vis[j]=false;
			}
	if(n==3){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==4){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==5){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==6){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==7){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==8){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-5;i++)
			a6[i]=a5[i]+mon[i+5];
		for(int i=1;i<=n;i++){
			for(int j=i+6;j<=n;j++){
				add[k]=a6[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==9){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-5;i++)
			a6[i]=a5[i]+mon[i+5];
		for(int i=1;i<=n;i++){
			for(int j=i+6;j<=n;j++){
				add[k]=a6[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-6;i++)
			a7[i]=a6[i]+mon[i+6];
		for(int i=1;i<=n;i++){
			for(int j=i+7;j<=n;j++){
				add[k]=a7[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==10){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-5;i++)
			a6[i]=a5[i]+mon[i+5];
		for(int i=1;i<=n;i++){
			for(int j=i+6;j<=n;j++){
				add[k]=a6[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-6;i++)
			a7[i]=a6[i]+mon[i+6];
		for(int i=1;i<=n;i++){
			for(int j=i+7;j<=n;j++){
				add[k]=a7[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-7;i++)
			a8[i]=a7[i]+mon[i+7];
		for(int i=1;i<=n;i++){
			for(int j=i+8;j<=n;j++){
				add[k]=a8[i]+mon[j];
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==11){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-5;i++)
			a6[i]=a5[i]+mon[i+5];
		for(int i=1;i<=n;i++){
			for(int j=i+6;j<=n;j++){
				add[k]=a6[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-6;i++)
			a7[i]=a6[i]+mon[i+6];
		for(int i=1;i<=n;i++){
			for(int j=i+7;j<=n;j++){
				add[k]=a7[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-7;i++)
			a8[i]=a7[i]+mon[i+7];
		for(int i=1;i<=n;i++){
			for(int j=i+8;j<=n;j++){
				add[k]=a8[i]+mon[j];
			}
		}
		for(int i=1;i<=n-8;i++)
			a9[i]=a8[i]+mon[i+8];
		for(int i=1;i<=n;i++){
			for(int j=i+9;j<=n;j++){
				add[k]=a9[i]+mon[j];
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==12){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-5;i++)
			a6[i]=a5[i]+mon[i+5];
		for(int i=1;i<=n;i++){
			for(int j=i+6;j<=n;j++){
				add[k]=a6[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-6;i++)
			a7[i]=a6[i]+mon[i+6];
		for(int i=1;i<=n;i++){
			for(int j=i+7;j<=n;j++){
				add[k]=a7[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-7;i++)
			a8[i]=a7[i]+mon[i+7];
		for(int i=1;i<=n;i++){
			for(int j=i+8;j<=n;j++){
				add[k]=a8[i]+mon[j];
			}
		}
		for(int i=1;i<=n-8;i++)
			a9[i]=a8[i]+mon[i+8];
		for(int i=1;i<=n;i++){
			for(int j=i+9;j<=n;j++){
				add[k]=a9[i]+mon[j];
			}
		}
		for(int i=1;i<=n-9;i++)
			a10[i]=a9[i]+mon[i+9];
		for(int i=1;i<=n;i++){
			for(int j=i+10;j<=n;j++){
				add[k]=a10[i]+mon[j];
			}
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	if(n==13){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				add[k]=mon[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-1;i++)
			a2[i]=mon[i]+mon[i+1];
		for(int i=1;i<=n;i++){
			for(int j=i+2;j<=n;j++){
				add[k]=a2[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-2;i++)
			a3[i]=a2[i]+mon[i+2];
		for(int i=1;i<=n;i++){
			for(int j=i+3;j<=n;j++){
				add[k]=a3[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-3;i++)
			a4[i]=a3[i]+mon[i+3];
		for(int i=1;i<=n;i++){
			for(int j=i+4;j<=n;j++){
				add[k]=a4[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-4;i++)
			a5[i]=a4[i]+mon[i+4];
		for(int i=1;i<=n;i++){
			for(int j=i+5;j<=n;j++){
				add[k]=a5[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-5;i++)
			a6[i]=a5[i]+mon[i+5];
		for(int i=1;i<=n;i++){
			for(int j=i+6;j<=n;j++){
				add[k]=a6[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-6;i++)
			a7[i]=a6[i]+mon[i+6];
		for(int i=1;i<=n;i++){
			for(int j=i+7;j<=n;j++){
				add[k]=a7[i]+mon[j];
				k++;
			}
		}
		for(int i=1;i<=n-7;i++)
			a8[i]=a7[i]+mon[i+7];
		for(int i=1;i<=n;i++){
			for(int j=i+8;j<=n;j++){
				add[k]=a8[i]+mon[j];
			}
		}
		for(int i=1;i<=n-8;i++)
			a9[i]=a8[i]+mon[i+8];
		for(int i=1;i<=n;i++){
			for(int j=i+9;j<=n;j++){
				add[k]=a9[i]+mon[j];
			}
		}
		for(int i=1;i<=n-9;i++)
			a10[i]=a9[i]+mon[i+9];
		for(int i=1;i<=n;i++){
			for(int j=i+10;j<=n;j++){
				add[k]=a10[i]+mon[j];
			}
		}
		for(int i=1;i<=n-10;i++)
			a11[i]=a10[i]+mon[i+10];
		for(int i=1;i<=n;i++){
			for(int j=i+11;j<=n;j++)
				add[k]=a11[i]+mon[j];
		}
		for(int i=1;i<=k-1;i++){
			for(int j=1;j<=n;j++)
				if(add[i]==mon[j] && vis[j]){
					ans--;
					vis[j]=false;
				}
		}
		printf("%d\n",ans);
		return;
	}
	return;
}
void init(void){
	scanf("%d",&T);
	while(T--){
		memset(mon,0,sizeof(mon));
		memset(add,0,sizeof(add));
		work();
	}
	return;
}
int main(void){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	init();
	return 0;
}

