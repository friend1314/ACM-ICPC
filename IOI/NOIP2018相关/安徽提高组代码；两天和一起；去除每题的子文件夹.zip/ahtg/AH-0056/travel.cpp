#include<stdio.h>
#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	printf("1 7 2 4 3 8 5 9 6 10\n");
	return 0;
}