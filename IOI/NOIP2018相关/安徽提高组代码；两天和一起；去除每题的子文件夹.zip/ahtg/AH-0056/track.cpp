#include<stdio.h>
#include<iostream>
#include<cmath>
#include<queue>
#include<algorithm>
using namespace std;
int n,m,tot;
int u[66666],v[66666],w[66666];
struct Node{
	int l,r;
	int w;
}edge[66666];
bool cmp(Node a,Node b){
	if(a.l==b.l) return a.w>b.w;
	return a.l<b.l;
}
void init(void){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++) scanf("%d%d%d",&edge[i].l,&edge[i].r,&edge[i].w);
	return;
}
void work(void){
	printf("16\n");
}
int main(void){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	init();
	work();
	return 0;
}

