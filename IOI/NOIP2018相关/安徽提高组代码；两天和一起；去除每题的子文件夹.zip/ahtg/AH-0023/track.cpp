#include <iostream>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cstdio>
#include <cstdio>
#include <cstdlib>
using namespace std;

const int maxn = 100000;
const int INF = 0x7fffffff;

struct Edge {
	int v, w, next;
	Edge(int v=0, int w=0, int next=0) : v(v), w(w), next(next) {v=v;w=w;next=next;}
}e[maxn];
int front[maxn], tot=0;
void addedge(int u, int v, int w) {tot++;e[tot].v=v;e[tot].w=w;e[tot].next=front[u];front[u]=tot;}
int n, m;
int st=0;

void Readin() {
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n-1; i++) {
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		addedge(u, v, w);
		if(i % 2 == 0) st+=w;
		addedge(v, u, w);
	}
}

int max_c = -INF;
bool vis[maxn] = {false};
int dfs(int x, int c) {
	vis[x] = true;
	max_c = max(c, max_c);
	for(int i = front[x]; i != 0; i = e[i].next) if(!vis[e[i].v]) {
		dfs(e[i].v, c+e[i].w);
	}
	max_c = max(c, max_c);
	return 0;
}

void Solve() {
	if(m == 1) {
		memset(vis, false, sizeof(vis));
		for(int i = 1; i <= n; i++) {
			memset(vis, false, sizeof(vis));
			dfs(i, 0);
		}
		printf("%d\n", max_c);
	} else {
		cout << st << endl;
	}
}

int main() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	Readin();
	
	Solve();
	
	return 0;
}