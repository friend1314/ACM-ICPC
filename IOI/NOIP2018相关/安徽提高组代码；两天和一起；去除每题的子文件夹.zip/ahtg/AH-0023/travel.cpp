#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <queue>
using namespace std;

typedef long long ll;
const int maxn = 100005;
const int INF = 0x7fffffff;

int n, m;
bool G[5005][5005];

void Readin() {
	memset(G, 0, sizeof(G));
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; i++) {
		int u, v; scanf("%d%d", &u, &v);
		G[u][v] = 1; G[v][u] = 1;
	}	
}

bool vis[maxn];
int dfs1(int x) {   // m == n-1
	if(vis[x]) return 0;
	vis[x] = true;
	printf("%d ", x);
	for(int i = 1; i <= n; i++) if(!vis[i] and G[x][i]) {
		dfs1(i);
	}
	return 0;
}

bool is_finish() {
	for(int i = 1; i <= n; i++) if(!vis[i]) return false;
	return true;
}

priority_queue<string, vector<string>, greater<string> > q;
int dfs2(int x, string dfs_seq) {
	vis[x] = true;
	if(is_finish()) { q.push(dfs_seq); return 0; }
	for(int i = 1; i <= n; i++) 
		if((G[x][i] and !vis[i])) {
			dfs2(i, dfs_seq + char(i + '0'));
		}
	vis[x] = false;
	return 0;
}

void Solve() {
	memset(vis, false, sizeof(vis)); 
	if(m == n-1) dfs1(1);
	else if(m == n) {
		dfs2(1, "1");
		string ans = q.top();
		for(string::iterator it = ans.begin(); it != ans.end(); ++it) printf("%c ", (*it));
	}
}

int main() {
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	Readin();
	Solve();
	return 0;
}