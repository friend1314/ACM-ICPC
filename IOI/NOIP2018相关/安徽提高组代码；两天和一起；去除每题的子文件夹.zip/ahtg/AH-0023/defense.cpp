#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;

const int maxn = 100005;

struct Edge {
	int v, nxt;
}e[maxn];
int front[maxn], tot=0;
void addedge(int u, int v) {
	tot++;
	e[tot].v = v; e[tot].nxt = front[u]; front[u] = tot;
}

int n, m;
string typ;
int p[maxn];

bool vis[maxn];
int col[maxn];
int dfs(int x, int color) {
	if(vis[x]) return 0;
	col[x] = color;
	vis[x] = true;
	for(int i = front[x]; i != 0; i = e[i].nxt) if(!vis[e[i].v]) {
		if(color == 1) dfs(e[i].v, 0);
		else dfs(e[i].v, 1);
	}
	return 0;
}

void Readin() {
	scanf("%d%d", &n, &m); cin >> typ;
	for(int i = 1; i <= n; i++) scanf("%d", &p[i]);
	for(int i = 1; i <= n-1; i++) {
		int u, v; scanf("%d%d", &u, &v);
		addedge(u, v); addedge(v, u);
	}
	for(int i = 1; i <= n; i++) if(!vis[i]) dfs(i, 1);
	//for(int i = 1; i <= n; i++) cout << col[i] << ' '; puts("");
}

void Solve() {
	while(m--) {
		int a, x, b, y, cnt=0;
		scanf("%d%d%d%d", &a, &x, &b, &y);
		if((col[a] != col[b] and x == y) or (col[a] == col[b] and x != y)) { puts("-1"); continue; }
		else {
			if(x == y) {
				for(int i = 1; i <= n; i++) if(x == col[i]) cnt += p[i];
			} else if(x == 1 and y == 0) {
				for(int i = 1; i <= n; i++) if(x == col[i]) cnt += p[i];
			} else if(x == 0 and y == 1) {
				for(int i = 1; i <= n; i++) if(y == col[i]) cnt += p[i];
			}
		}
		printf("%d\n", cnt);
	}
}

int main() {
	freopen("defense.in", "r", stdin);
	freopen("defense.out", "w", stdout);
	Readin();
	Solve();
}
