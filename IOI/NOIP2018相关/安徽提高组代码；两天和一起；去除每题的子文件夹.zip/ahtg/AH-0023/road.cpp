#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#define rint register int
using namespace std;

const int maxn = 100005;
const int INF = 0x7fffffff;

int n, a[maxn];

int read() {
	char ch = getchar(); int ret = 0;
	while(ch < '0' and ch > '9') ch = getchar();
	while(ch >= '0' and ch <= '9') {
		ret = ret*10 + ch - '0';
		ch = getchar();
	}
	return ret;
}

int cnt = 0;

int Do(int l, int r) {
	if(l == r) {
		cnt += a[l];
		a[l] = 0;
		return 0;
	}
	if(l > r) return 0;
	int minn = INF, min_p;
	for(int i = l; i <= r; i++) if(minn > a[i]) minn = a[i], min_p = i;
	cnt += minn;
	for(int i = l; i <= r; i++) a[i] -= minn;
	Do(l, min_p - 1); Do(min_p+1, r);
	return 0;
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	n = read();
	for(rint i = 1; i <= n; i++) a[i] = read();
	Do(1, n);
	printf("%d\n", cnt);
	return 0;
}