#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
using namespace std;

const int maxn = 100000;
const int INF = 0x7fffffff;

int n;

int exgcd(int a, int b, int& x, int& y) {
	if(a < b) swap(a, b);
	if(b == 0) {x = 1; y = 0;return a;}
	int ret = exgcd(b, a%b, x, y);
	int tmp = x;x = y;y = tmp - y*(a/b);
	return ret;
}

int mincnt = INF;
int a[maxn];
bool vis[maxn];
int dfs(int x, int num) {
	if(num >= mincnt) return 0;
	if(x == n+1) {mincnt = min(mincnt, num); return 0;}
	bool f = false;
	if(vis[x]) {dfs(x+1, num); return 0;}
	for(int j = 1; j <= n; j++) if(vis[j]) {
		int sum = 0;
		int r = a[x] % a[j];
		for(int i = j; i <= n; i++) if(vis[i]) {
			sum += a[i];
			if(r % sum == 0) { f = true; break; }
		}
		if(f) break;
	}
	if(f) {
		dfs(x+1, num);
	} else {
		vis[x] = true;
		dfs(x+1, num+1);
		vis[x] = false;
	}
	return 0;
}

void Solve() {
	int minn = INF, min_p;
	for(int i = 1; i <= n; i++) if(minn > a[i]) minn = a[i], min_p = i;
	vis[min_p] = true;
	for(int i = 1; i <= n; i++) if(i != min_p) {
		vis[i] = true;
		dfs(1, 2);
		vis[i] = false;
	}
	printf("%d\n", mincnt);
}

int main() {
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--) {
		scanf("%d", &n);
		if(n == 1) puts("1");
		if(n == 2) {
			int a, b, x, y;
			scanf("%d%d", &a, &b);
			int r = exgcd(max(a, b), min(a, b), x, y);
			if(r == min(a, b)) puts("1");
			else puts("2");
		} else {
			mincnt = INF;
			memset(a, 0, sizeof(a));
			for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
			Solve();
		}
	}
}