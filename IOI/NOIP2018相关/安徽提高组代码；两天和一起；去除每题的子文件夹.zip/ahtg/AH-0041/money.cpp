#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int cmp(int a,int b)
{
	return a<b;
}
int t,n,a[100001];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	while (t>0)
	{
		t--;
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1,cmp);
		if (a[1]==1)
			printf("1");
			else
		printf("2");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}