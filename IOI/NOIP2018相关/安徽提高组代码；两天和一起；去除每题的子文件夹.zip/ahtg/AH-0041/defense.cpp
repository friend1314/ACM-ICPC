#include <cstdio>
#include <iostream>
#include <cmath>
using namespace std;
long long n,m,p[100001],x,y,a[10001][10001];
char ch[10001];
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	scanf("%s",ch);
	for (int i=1;i<=n;i++)
		scanf("%lld",&p[i]);
	for (int i=1;i<n;i++)
	{
		int x,y;
	scanf("%d%d",&x,&y);
		a[x][y]=1;
		a[y][x]=1;
	}
	for (int i=1;i<=m;i++)
	{
		int x1,x2,y1,y2;
		scanf("%d%d%d%d",&x1,&x2,&y1,&y2);
		if (n>2000)
		{
		if (abs(x1-y1)==1)
		{
			if (x2==1 && y2==0)
				printf("%lld\n",p[x1]);
			else
			if (x2==0 && y2==1)
			printf("%lld\n",p[y1]);
			else
			if (x2==0 && y2==0)
				printf("-1\n");
			else
				if (x2==1 && y2==1)
				printf("%lld\n",min(p[x1],p[y1]));
		}
		else
			if (x2==1 && y2==0)
				printf("%lld\n",p[x1]);
			else
			if (x2==0 && y2==1)
			printf("%lld\n",p[y1]);
			else
			if (x2==0 && y2==0)
				printf("0\n");
			else
				if (x2==1 && y2==1)
				printf("%lld\n",p[x1]+p[y1]);
			}
			else
			if (a[x1][y1]==1)
			{
				if (x2==1 && y2==0)
				printf("%lld\n",p[x1]);
			else
			if (x2==0 && y2==1)
			printf("%lld\n",p[y1]);
			else
			if (x2==0 && y2==0)
				printf("-1\n");
			else
				if (x2==1 && y2==1)
				printf("%lld\n",min(p[x1],p[y1]));
			}
			else
			if (x2==1 && y2==0)
				printf("%lld\n",p[x1]);
			else
			if (x2==0 && y2==1)
			printf("%lld\n",p[y1]);
			else
			if (x2==0 && y2==0)
				printf("0\n");
			else
				if (x2==1 && y2==1)
				printf("%lld\n",p[x1]+p[y1]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}