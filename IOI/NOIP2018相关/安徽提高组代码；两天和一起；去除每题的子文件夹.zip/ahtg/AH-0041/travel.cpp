#include <cstdio>
#include <iostream>
using namespace std;
int a[5001][5001],que[5001][5001],b[5001],d[5001],n,m,c[5001];
int pd(int k)
{
	for (int i=1;i<=n;i++)
	{
		if (que[k][i]<c[i])
			return 1;
			else
				if (que[k][i]>c[i])
					return 0;
	}
	return 0;
}
int pd1(int x,int k)
{
	for (int i=1;i<=que[k][0];i++)
	{
		if (que[k][i]==x)
			return 0;
	}
	return 1;
}
void BFS()
{
	int head=0,tail=1;
	b[1]=1;
	que[1][0]=1;
	que[1][1]=1;
	que[1][n+1]=1;
	do
	{
		head++;
		int x=que[head][n+1];
		if (que[head][0]==n)
		{
			if (pd(head)==1)
			{
				for (int i=1;i<=n;i++)
					c[i]=que[head][i];
			}
		}
		for (int i=1;i<=a[x][0];i++)
		{
			if (pd1(a[x][i],head)==1)
			{
				d[a[x][i]]=x;
			que[++tail][0]=que[head][0]+1;
				for (int j=1;j<que[tail][0];j++)
					que[tail][j]=que[head][j];
				que[tail][que[tail][0]]=a[x][i];
				que[tail][n+1]=a[x][i];
		      }
	      }
		if (que[head][n+1]!=1)
		{
	que[++tail][0]=que[head][0];
				for (int i=1;i<=que[tail][0];i++)
					que[tail][i]=que[head][i];
					que[tail][n+1]=d[x];
				}
}while(head<tail);
}
int main()
{freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		a[x][++a[x][0]]=y;
		a[y][++a[y][0]]=x;
	}
	for (int i=1;i<=n;i++)
		c[i]=100001;
		BFS();
		for (int i=1;i<=n;i++)
			printf("%d ",c[i]);
			fclose(stdin);
			fclose(stdout);
	return 0;
}