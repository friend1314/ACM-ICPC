#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int n,m,a[100001],f[100001],day,minp=1000001,top;
int pd(int x,int y)
{
	int minn=1000001;
	for (int i=x;i<=y;i++)
	minn=min(a[i],minn);
	return minn;
}
int cmp(int a,int b)
{
	return a<b;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		minp=min(minp,a[i]);
	}
	day+=minp;
	for (int i=1;i<=n;i++)
	{
		a[i]-=minp;
		if (a[i]==0)
		f[++top]=i;
	}
	while (top<n)
	{
		sort(f+1,f+top+1,cmp);
		int k=1;
		int p=top;
		for (int i=1;i<=p;i++)
		{
			if (k!=f[i] && a[k]!=0)
			{
			int minn=pd(k,f[i]-1);
			day+=minn;
			for (int j=k;j<f[i];j++)
			{
				a[j]-=minn;
				if (a[j]==0)
				f[++top]=j;
			}
		      }
			k=f[i]+1;
		}
		if (k<=n)
		{
		int minn1=pd(k,n);
		for (int j=k;j<=n;j++)
			{
				a[j]-=minn1;
				if (a[j]==0)
				f[++top]=j;
			}
			day+=minn1;
		}
	}
	printf("%d\n",day);
	fclose(stdin);
	fclose(stdout);
	return 0;
}