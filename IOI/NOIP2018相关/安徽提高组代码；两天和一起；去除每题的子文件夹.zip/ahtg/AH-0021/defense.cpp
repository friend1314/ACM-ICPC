#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,m,a[100001],d1,d2,ans1,ans2,ans,u,v;
char c;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>n>>m>>c;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		for(int j=1;j<=m;j++){
		cin>>u>>v;
		}
	
		if(i%2==1){
			d1=a[i];
			ans1=ans1+d1;}
		if(i%2==0){
			d2=a[i];
			ans2=ans2+d2;}	
		}
		ans=min(ans1,ans2);
		cout<<ans;
	return 0;}