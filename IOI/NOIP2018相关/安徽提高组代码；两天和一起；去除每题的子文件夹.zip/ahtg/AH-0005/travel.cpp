#include <cstdio>
#include <algorithm>
#include <utility>
#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <deque>
using namespace std;
const int MAXN(5010);
const int MAXM(1020);

int ind() {
	register char ch;
	int v(0);
	bool sym(false);
	while(!isdigit(ch = getchar()) && ch != '-');
	ch == '-' ? (sym = true) : (v = ch ^ 48);
	while(isdigit(ch = getchar())) v *= 10, v += ch ^ 48;
	return sym ? -v : v;
}

void outu(unsigned v) {
	if(v > 9) outu(v / 10);
	putchar((v % 10) | 48);
}

void outd(int v) {
	if(v < 0) putchar('-');
	outu(abs(v));
}

struct Node {
	int to;
	Node* next;
} e[MAXM], *h[MAXN];
int tot[MAXN];
int cnt = 1;

inline void insert(int from, int to) {
	e[cnt].to = to;
	e[cnt].next = h[from];
	h[from] = e + (cnt++);
	tot[from]++;
}

int n, m;
bool flag[MAXN];
int vec[MAXN], vn = 1;
deque<int> team;
int pre[5];

void team_push(int i) {
	if(tot[i] == 1) {
		if(flag[h[i]->to]) return;
		team.push_front(h[i]->to);
		flag[h[i]->to] = true;
	} else if(tot[i] == 2) {
		Node* x = h[i];
		Node* y = h[i]->next;
		if(flag[x->to])
			if(flag[y->to]) return;
			else team.push_front(y->to);
		else
			if(flag[y->to]) team.push_front(x->to);
			else team.push_front(max(x->to, y->to)), team.push_front(min(x->to, y->to));
		if(!flag[x->to]) flag[x->to] = true;
		if(!flag[y->to]) flag[y->to] = true;
	} else {
		int* p = pre;
		for(Node* px = h[i]; px; px = px->next)
			if(!flag[px->to]) {
			*(p++) = px->to;
			flag[px->to] = true;
		}
		sort(pre, p); --p;
		while(p >= pre) team.push_front(*(p--));
	}
}

int main() {
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	n = ind();
	m = ind();
	for(int i = 0; i < m; ++i) {
		int from = ind();
		int to = ind();
		insert(from, to);
		insert(to, from);
	}
	flag[1] = true;
	vec[vn++] = 1;
	team_push(1);
	while(!team.empty()) {
		int k = team.front();
		vec[vn++] = k;
		team.pop_front();
		team_push(k);
	}
	for(int i = 1; i < vn; ++i) {
		outd(vec[i]); putchar(' ');
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
