#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <utility>
using namespace std;

int ind() {
	bool sym(false);
	register char ch;
	int v(0);
	while(!isdigit(ch = getchar()) && ch != '-');
	ch == '-' ? (sym = true) : (v = ch ^ 48);
	while(isdigit(ch = getchar()))
		v *= 10, v += ch ^ 48;
	return sym ? -v : v;
}

const int MAXN(110);
int n;
int m;
int a[MAXN];
char flag[2500010];

void work() {
	m = n = ind();
	for(int i = 0; i < n; ++i) a[i] = ind();
	sort(a, a + n);
	for(int i = 0; i < m; ++i) {
		memset(flag, 0, 250010);
		for(int j = i + 1, k = i + 1; j < n; ++j) {
			int d = a[j] % a[i];
			if(d == 0 || flag[d]) {
				--m;
				continue;
			}
			int x = k - 1;
			for(int xx; x > i; --x) {
				xx = a[x] % a[i];
				if(!(d % xx) && a[x] * (d / xx)  <= a[j]) {
					--m;
					break;
				}
			}
			if(x <= i) a[k++] = a[j];
		}
		n = m;
	}
	//;
	//for(int i = 0; i < m; ++i) fprintf(stderr, "%d ", a[i]);
	//fprintf(stderr, "\n");
	printf("%d\n", m);
}

#ifdef F
void deal() {
	n = ind();
	for(int i = 0; i < n; ++i) a[i] = ind();
	sort(a, a + n, greater<int>());
	int tot;
	for(int i = 0; i < n; ++i)
		for(int j = i + 1; j < n; ++j)
			if(!flag[a[i] + a[j]])
	for(int i = 0; i < n; ++i) {
		tot = 0;
		memset(flag, 0, 250010);
		for(int j = i + 1; j < n; ++j)
			for(int k = j + 1; k < n; ++k)
					if(flag[a[j] + a[k]]);
					else 
	}
}
#endif

int main() {
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int t = ind();
	while(t--) work();
	fclose(stdin);
	fclose(stdout);	
	return 0;
}
