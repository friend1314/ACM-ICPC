#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cctype>
#include <iostream>
using namespace std;
const int MAXN(100010);

int ind() {
	bool sym(false);
	int v(0);
	register char ch;
	while(!isdigit(ch = getchar()) && ch != '-');
	ch == '-' ? (sym = true) : (v = ch ^ 48);
	while(isdigit(ch = getchar())) v *= 10, v += ch ^ 48;
	return sym ? -v : v;
}

struct Node {
	int l, r;
	int v;
	int p;
	int flag;
} tree[262200];
int p = 1;
typedef pair<int, int> field;

int n;
int a[MAXN];

field getp(int p, int l, int r) {
	if(tree[p].l == l && tree[p].r == r) return field(tree[p].v, tree[p].p);
	int lc = p << 1;
	int rc = p << 1 | 1;
	if(tree[p].flag) {
		tree[lc].flag += tree[p].flag;
		tree[rc].flag += tree[p].flag;
		tree[lc].v += tree[p].flag;
		tree[rc].v += tree[p].flag;
		tree[p].flag = 0;
	}
	if(r <= tree[lc].r) return getp(lc, l, r);
	else if(l >= tree[rc].l) return getp(rc, l, r);
	else return min(getp(lc, l, tree[lc].r), getp(rc, tree[rc].l, r));
}

void change(int p, int l, int r, int v) {
	if(tree[p].l == l && tree[p].r == r) {
		tree[p].flag += v;
		tree[p].v += v;
		return;
	}
	int lc = p << 1;
	int rc = p << 1 | 1;
	if(tree[p].flag) {
		tree[lc].flag += tree[p].flag;
		tree[rc].flag += tree[p].flag;
		tree[lc].v += tree[p].flag;
		tree[rc].v += tree[p].flag;
		tree[p].flag = 0;
	}
	if(r <= tree[lc].r) change(lc, l, r, v);
	else if(l >= tree[rc].l) change(rc, l, r, v);
	else change(lc, l, tree[lc].r, v), change(rc, tree[rc].l, r, v);
	tree[p].v = min(tree[lc].v, tree[rc].v);
	tree[p].p = (tree[lc].v < tree[rc].v ? tree[lc].p : tree[rc].p);
}

void build() {
	while(p < n) p <<= 1;
	for(int i = p, ie = p + n; i != ie; ++i)
		tree[i].v = a[(tree[i].p = tree[i].l = tree[i].r = i - p + 1)];
	for(int i = p + n, ie = p << 1; i != ie; ++i)
		tree[i].p = tree[i].l = tree[i].r = i - p + 1,
		tree[i].v = 0x7fffffff;
	for(int i = p - 1; i; --i) {
		tree[i].l = tree[i << 1].l;
		tree[i].r = tree[i << 1 | 1].r;
		tree[i].v = min(tree[i << 1].v, tree[i << 1 | 1].v);
		tree[i].p = (tree[i << 1].v < tree[i << 1 | 1].v ? tree[i << 1].p : tree[i << 1 | 1].p);
	}
}

long long ans;
void dfs(int l, int r) {
	if(l > r) return;
	field data = getp(1, l, r);
	ans += data.first;
	change(1, l, r, -data.first);
	data.first = 0;
	while(!data.first) {
		dfs(l, data.second - 1);
		l = data.second + 1;
		if(l > r) break;
		data = getp(1, l, r);
	}
	if(l <= r) dfs(l, r);
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	n = ind();
	for(int* i = a + 1, *const ie = a + n + 1; i != ie; ++i) *i = ind();
	build();
	dfs(1, n);
	printf("%lld", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
