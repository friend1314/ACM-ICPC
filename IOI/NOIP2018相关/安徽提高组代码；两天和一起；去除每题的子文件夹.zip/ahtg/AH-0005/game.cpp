#include <cstdio>
#include <cstring>
#include <cctype>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
const int MD(1e9 + 7);
const int MAXN(10);
const int MAXM(10);

bool arr[MAXN][MAXM];
char ch[2000][MAXN + MAXM];
char ar[2000][MAXN + MAXM];
int tot = 1;
int n, m;
int ans;
int de;

int comp(void* a, const void* ae, void* b) {
	unsigned char* x = (unsigned char*)a;
	unsigned char* xx = (unsigned char*)ae;
	unsigned char* y = (unsigned char*) b;
	while(x != xx)
		if(*x != *y)
			if(*x > *y) return 1;
			else return -1;
		else ++x, ++y;
	return 0;
}

void dfs(int x, int y, int k = 0, char w = '\0') {
	if(de) return;
	//fprintf(stderr, "%12d%12d%12d%c\n", x, y, k, w);
	if(x > n || y > m) return;
	ch[0][k] = w;
	ar[0][k] = arr[x][y];
	if(x == n && y == m) {
		for(int i = 1; i != tot; ++i) {
			int xx = comp(ch[i], ch[i] + sizeof(ch[i]), ch[0]);
			int yy = comp(ar[i], ar[i] + sizeof(ar[i]), ar[0]);
			if((xx > 0 && yy <= 0) || (xx < 0 && yy >= 0)) de = 1;
		}
		memcpy(ch + tot, ch, sizeof(ch[0]));
		memcpy(ar + tot, ar, sizeof(ar[0]));
		++tot;
		return;
	}
	dfs(x + 1, y, k + 1, 'D');
	dfs(x, y + 1, k + 1, 'R');
}

bool check(int state) {
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j)
			arr[i][j] = (state & 1), state >>= 1;
	tot = 1;
	de = 0;
	dfs(1, 1);
	return de;
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d", &n, &m);
	int ie = 1 << (n * m);
	for(int i = 0; i != ie; ++i) ans += check(i), ans %= MD;
	printf("%d", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
