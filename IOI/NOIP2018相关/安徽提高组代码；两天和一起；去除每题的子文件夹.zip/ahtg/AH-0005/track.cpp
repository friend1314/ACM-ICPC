#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int MAXN(50010);

int ind() {
	int v(0);
	bool sym(false);
	register char ch;
	while(!isdigit(ch = getchar()) && ch == '-');
	ch == '-' ? (sym = true) : (v = ch ^ 48);
	while(isdigit(ch = getchar())) v *= 10, v += ch ^ 48;
	return sym ? -v : v;
}

struct Edge {
	int from, to, value, next;
} e[MAXN << 1];
int h[MAXN], cnt = 1;
int n, m;

inline void insert(int from, int to, int value) {
	e[cnt].from = from;
	e[cnt].to = to;
	e[cnt].value = value;
	e[cnt].next = h[from];
	h[from] = cnt++;
}

int Floyed() {
	int nn = n + 10;
	unsigned int* arr = (unsigned int*)calloc(nn * nn, sizeof(arr));
#define ARR(X,Y) arr[(X) * nn + (Y)]
	for(int i = 1; i < cnt; ++i) ARR(e[i].from, e[i].to) = e[i].value;
	unsigned int v(0);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j) if(i != j)
			for(int k = 1; k <= n; ++k) if(k != i && k != j)
				if(ARR(i, k) + ARR(k, j) > ARR(i, j)) {
					ARR(i, j) = ARR(i, k) + ARR(k, j);
					v = max(v, ARR(i, j));
				}
	free(arr);
	printf("%u", v);
#undef ARR
}

int main() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	n = ind();
	m = ind();
	for(int i = 1; i != n; ++i) insert(ind(), ind(), ind());
	Floyed();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
