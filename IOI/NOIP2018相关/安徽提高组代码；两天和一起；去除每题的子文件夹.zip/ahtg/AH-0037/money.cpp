#include<bits/stdc++.h>
using namespace std;

int T,N,Mx,Ans;
int A[105];

namespace Sub1{
	bool G[2000];
	bool Tag[105];

	void DFS(int t){
		int i,j,cnt=0;
		if(t>N){
			memset(G,0,sizeof(G));
			G[0]=1;
			for(i=1;i<=N;i++)
				if(Tag[i]){
					for(j=A[i];j<=Mx;j++)
						G[j]|=G[j-A[i]];
					cnt++;
				}
			bool f=true;
			for(i=1;i<=N;i++)
				if(!Tag[i]&&!G[A[i]])
					f=false;
			if(f)
				Ans=min(Ans,cnt);
			return;
		}
		Tag[t]=0,DFS(t+1);
		Tag[t]=1,DFS(t+1);
	}
	
	void Work1(){
		int i;
		Ans=N;
		memset(Tag,false,sizeof(Tag));
		Mx=0;
		for(i=1;i<=N;i++)
			Mx=max(Mx,A[i]);
		DFS(1);
	}
}
using Sub1::Work1;

namespace Sub2{
 	bool F[105][25005];
 	
	void Work2(){
		int i,j;
		sort(A+1,A+N+1);
		memset(F[1],0,sizeof(F[1]));
		F[1][0]=1;
		for(i=2;i<=N;i++){
			for(j=0;j<=A[N];j++)
				F[i][j]=F[i-1][j];
			for(j=A[i-1];j<=A[N];j++)
				F[i][j]|=F[i][j-A[i-1]];
		}
		Ans=N;
		for(i=N;i;i--)
			Ans-=F[i][A[i]];
	}
}
using Sub2::Work2;

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int i,j;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&N);
		for(i=1;i<=N;i++)
			scanf("%d",&A[i]);
		if(N<=13)
			Work1();
		else Work2();
		printf("%d\n",Ans);
	}
	return 0;
}
