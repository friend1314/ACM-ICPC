#include<bits/stdc++.h>
using namespace std;

int N,M,K1,K2,T,Tot=1,Index;
int Head[5005],Nxt[10005],To[10005];
int U[5005],V[5005],Son[5005][5005],Pre[5005],Suf[5005],P[5005];
int A[5005],B[5005];
bool Vis[5005],Tag[10005];

void Add_Edge(int u,int v){
	Nxt[++Tot]=Head[u];
	To[Tot]=v;
	Head[u]=Tot;
}

void DFS(int u,int fa){
	int i,v,cnt=0;
	Pre[u]=++Index;
	A[++K1]=u;
	Vis[u]=true;
	for(i=Head[u];i;i=Nxt[i])
		if(!Vis[v=To[i]])
			Son[u][++cnt]=v;
		else if(v^fa&&Pre[v]<Pre[u]){
			Tag[i]=Tag[i^1]=true;
			P[v]=u;
			//printf("%d %d\n",u,v);
		}
	sort(Son[u]+1,Son[u]+cnt+1);
	for(i=1;i<=cnt;i++)
		if(!Vis[Son[u][i]])
			DFS(Son[u][i],u);
	Suf[u]=Index;
}

void DFS5(int u,int fa){
	int i,v,cnt=0;
	Vis[u]=true;
	B[++K2]=u;
	for(i=Head[u];i;i=Nxt[i])
		if(!Vis[v=To[i]])
			Son[u][++cnt]=v;
	sort(Son[u]+1,Son[u]+cnt+1);
	for(i=1;i<=cnt;i++)
		DFS5(Son[u][i],u);
}

void DFS3(int u,int fa,int x){
	int i,v,cnt=0;
	Vis[u]=true;
	B[++K2]=u;
	for(i=Head[u];i;i=Nxt[i])
		if(!Vis[v=To[i]])
			Son[u][++cnt]=v;
	sort(Son[u]+1,Son[u]+cnt+1);
	if(!cnt)
		return;
	if(Son[u][1]>x){
		for(i=1;i<=cnt;i++)
			if(Pre[Son[u][i]]>=Pre[u]&&Pre[Son[u][i]]<=Suf[u])
				DFS5(Son[u][i],u);
	}
	else{
		for(i=1;i<=cnt;i++)
			if(Pre[Son[u][i]]>=Pre[u]&&Pre[Son[u][i]]<=Suf[u])
				DFS5(Son[u][i],u);
			else DFS3(Son[u][i],u,x);
	}
}

void DFS4(int u,int fa,int x){
	int i,v,cnt=0;
	Vis[u]=true;
	B[++K2]=u;
	for(i=Head[u];i;i=Nxt[i])
		if(!Vis[v=To[i]])
			Son[u][++cnt]=v;
	sort(Son[u]+1,Son[u]+cnt+1);
	/*printf("u=%d %d\n",u,x);
	for(i=1;i<=cnt;i++)
		printf("%d ",Son[u][i]);
	puts("");*/
	if(!cnt)
		return;
	if(Son[u][1]>x){
		for(i=1;i<=cnt;i++)
			if(!(Pre[T]>=Pre[Son[u][i]]&&Pre[T]<=Suf[Son[u][i]]))
				DFS5(Son[u][i],u);
	}
	else{
		for(i=1;i<=cnt;i++)
			if(!(Pre[T]>=Pre[Son[u][i]]&&Pre[T]<=Suf[Son[u][i]]))
				DFS5(Son[u][i],u);
			else DFS4(Son[u][i],u,x);
	}
}

void DFS2(int u,int fa){
	int i,v,cnt=0;
	B[++K2]=u;
	Vis[u]=true;
	for(i=Head[u];i;i=Nxt[i])
		if(!Vis[v=To[i]])
			Son[u][++cnt]=v;
	if(P[u]){
		T=P[u];
		sort(Son[u]+1,Son[u]+cnt+1);
		/*for(i=1;i<=cnt;i++)
			printf("%d ",Son[u][i]);
		puts("");*/
		bool f=0;
		for(i=1;i<=cnt;i++)
			if(Son[u][i]==P[u]){
				//printf("*%d\n",i);
				if(!f){
					DFS3(P[u],u,i<cnt?Son[u][i+1]:1<<30);
					f=true;
				}
				else DFS2(P[u],u);
			}
			else if(Pre[P[u]]>=Pre[Son[u][i]]&&Pre[P[u]]<=Suf[Son[u][i]]){
				//printf("**%d\n",i);
				if(!f){
					DFS4(Son[u][i],u,i<cnt?Son[u][i+1]:1<<30);
					f=true;
				}
				else DFS2(Son[u][i],u);
			}
			else DFS2(Son[u][i],u);
	}
	else{
		sort(Son[u]+1,Son[u]+cnt+1);
		for(i=1;i<=cnt;i++)
			DFS2(Son[u][i],u);
	}
}

bool Check(){
	int i;
	for(i=1;i<=N;i++)
		if(A[i]^B[i])
			return A[i]>B[i];
}

int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int i,u,v;
	scanf("%d%d",&N,&M);
	for(i=1;i<=M;i++){
		scanf("%d%d",&U[i],&V[i]);
		Add_Edge(U[i],V[i]);
		Add_Edge(V[i],U[i]);
	}
	DFS(1,0);
	if(M<N){
		for(i=1;i<=N;i++)
			printf("%d ",A[i]);
		return 0;
	}
	memset(Vis,false,sizeof(Vis));
	DFS2(1,0);
	/*printf("T=%d\n",T);
	for(i=1;i<=N;i++)
		printf("%d ",P[i]);
	puts("");
	for(i=1;i<=N;i++)
		printf("%d ",B[i]);
	puts("");*/
	if(Check())
		for(i=1;i<=N;i++)
			A[i]=B[i];
	for(i=1;i<=N;i++)
		printf("%d ",A[i]);
	return 0;
}
