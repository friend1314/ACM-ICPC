#include<bits/stdc++.h>
using namespace std;

const int Mod=1e9+7;

int N,M,K,T,Ans;
int X[100],Y[100],Map[105][105];
int A[1000],B[1000],W[100005][10],S[100005][10];

void DFS1(int x,int y,int t){
	int i;
	if(x==N&&y==M){
		T++;
		for(i=1;i<=N+M-2;i++)
			W[T][i]=A[i],S[T][i]=B[i];
		return;
	}
	if(y<M){
		A[t]=1,B[t]=Map[x][y+1];
		DFS1(x,y+1,t+1);
	}
	if(x<N){
		A[t]=0,B[t]=Map[x+1][y];
		DFS1(x+1,y,t+1);
	}
}

bool Cmp1(int a[],int b[]){
	int i;
	for(i=1;i<=N+M-2;i++)
		if(a[i]^b[i])
			return a[i]>b[i];
	return false;
}

bool Cmp2(int a[],int b[]){
	int i;
	for(i=1;i<=N+M-2;i++)
		if(a[i]^b[i])
			return a[i]<b[i];
	return true;
}

bool Check(){
	int i,j;
	T=0;
	DFS1(1,1,1);
	for(i=1;i<=T;i++)
		for(j=i+1;j<=T;j++)
			if((Cmp1(W[i],W[j])&&!Cmp2(S[i],S[j]))||(Cmp1(W[j],W[i])&&!Cmp2(S[j],S[i])))
				return false;
	return true;
}

void DFS2(int t){
	if(t>K){
		Ans+=Check();
		return;
	}
	Map[X[t]][Y[t]]=0,DFS2(t+1);
	Map[X[t]][Y[t]]=1,DFS2(t+1);
}

int Pow(int base,int n){
	int ans=1;
	for(;n;n>>=1){
		if(n&1)
			ans=1llu*ans*base%Mod;
		base=1llu*base*base%Mod;
	}
	return ans;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int i,j;
	scanf("%d%d",&N,&M);
	if(N==1){
		printf("%d\n",Pow(2,M));
		return 0;
	}
	if(N==2){
		printf("%d\n",4llu*Pow(3,M-1)%Mod);
		return 0;
	}
	if(N==3){
		if(M==1)
			puts("8");
		else if(M==2)
			puts("36");
		else printf("%d\n",112llu*Pow(3,M-3)%Mod);
		return 0;
	}
	for(i=1;i<=N;i++)
		for(j=1;j<=M;j++)
			X[++K]=i,Y[K]=j;
	DFS2(1);
	printf("%d\n",Ans);
	return 0;
}
