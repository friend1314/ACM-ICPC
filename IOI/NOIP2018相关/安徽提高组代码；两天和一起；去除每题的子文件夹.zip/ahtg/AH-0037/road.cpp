#include<bits/stdc++.h>
using namespace std;

const int MaxN=1e5+5;

int N,M,Ans;
int A[MaxN],Log[MaxN],Mn[20][MaxN],Pos[MaxN];

int Get_Mn(int l,int r){
	if(l>r)
		return 1<<30;
	int k=Log[r-l+1];
	return min(Mn[k][l],Mn[k][r-(1<<k)+1]);
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i,j,k,l,r,mid,mx;
	scanf("%d",&N);
	for(i=1;i<=N;i++)
		scanf("%d",&A[i]);
	M=unique(A+1,A+N+1)-A-1;
	for(i=1;i<=M;i++)
		Mn[0][i]=A[i];
	for(j=1;1<<j<=M;j++)
		for(i=1;i+(1<<j)-1<=M;i++)
			Mn[j][i]=min(Mn[j-1][i],Mn[j-1][i+(1<<j-1)]);
	for(i=2;i<=M;i++)
		Log[i]=Log[i>>1]+1;
	for(i=1;i<=M;i++){
		//for(j=i-1;j&&A[j]>A[i];j--);
		//for(k=i+1;k<=M&&A[k]>A[i];k++);
		mx=0;
		if(Get_Mn(1,i-1)<A[i]){
			l=1,r=i-1;
			while(l<=r){
				mid=l+r>>1;
				if(Get_Mn(mid,i-1)<A[i])
					l=mid+1;
				else r=mid-1;
			}
			mx=max(mx,A[r]);
		}
		else r=0;
		if(Pos[A[i]]>r){
			Pos[A[i]]=i;
			continue;
		}
		if(Get_Mn(i+1,M)<A[i]){
			l=i+1,r=M;
			while(l<=r){
				mid=l+r>>1;
				if(Get_Mn(i+1,mid)<A[i])
					r=mid-1;
				else l=mid+1;
			}
			mx=max(mx,A[l]);
		}
		//printf("%d\n",i);
		Ans+=A[i]-mx;
		Pos[A[i]]=i;
	}
	printf("%d\n",Ans);
	return 0;
}
