#include<bits/stdc++.h>
using namespace std;

typedef long long LL;

const int MaxN=1e5+5;

int N,M;
LL Ans;
char Type[10];
int P[MaxN],Fa[MaxN];
LL F[MaxN][2];
bool Tag[2][MaxN];

vector<int> To[MaxN];

void DP(int u,int fa){
	int i,v;
	F[u][0]=F[u][1]=0;
	for(i=0;i<To[u].size();i++)
		if((v=To[u][i])^fa){
			Fa[v]=u;
			DP(v,u);
		}
	if(Tag[1][u])
		F[u][0]=1ll<<60;
	else{
		for(i=0;i<To[u].size();i++)
			if((v=To[u][i])^fa){
				if(F[v][1]==1ll<<60){
					F[u][0]=1ll<<60;
					break;
				}
				else F[u][0]+=F[v][1];
			}
	}
	if(Tag[0][u])
		F[u][1]=1ll<<60;
	else{
		F[u][1]=P[u];
		for(i=0;i<To[u].size();i++)
			if((v=To[u][i])^fa){
				if(F[v][0]==1ll<<60&&F[v][1]==1ll<<60){
					F[u][1]=1ll<<60;
					break;
				}
				else F[u][1]+=min(F[v][0],F[v][1]);
			}
	}
}

int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int i,u,v,x,y;
	scanf("%d%d%s",&N,&M,Type);
	for(i=1;i<=N;i++)
		scanf("%d",&P[i]);
	for(i=1;i<N;i++){
		scanf("%d%d",&u,&v);
		To[u].push_back(v);
		To[v].push_back(u);
	}
	while(M--){
		scanf("%d%d%d%d",&u,&x,&v,&y);
		Tag[x][u]=true,Tag[y][v]=true;
		DP(1,0);
		Ans=min(F[1][0],F[1][1]);
		printf("%lld\n",Ans<1ll<<60?Ans:-1);
		Tag[x][u]=false,Tag[y][v]=false;
	}
	return 0;
}
