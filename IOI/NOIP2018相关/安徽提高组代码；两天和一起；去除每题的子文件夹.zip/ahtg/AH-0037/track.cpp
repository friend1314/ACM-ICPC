#include<bits/stdc++.h>
using namespace std;

const int MaxN=50005;

int N,M,Tot;
int U[MaxN],V[MaxN],W[MaxN];
int Head[MaxN],Nxt[MaxN<<1],To[MaxN<<1],Weight[MaxN<<1];

void Add_Edge(int u,int v,int w){
	Nxt[++Tot]=Head[u];
	To[Tot]=v,Weight[Tot]=w;
	Head[u]=Tot;
}

namespace Sub1{
	int Ans=0;
	int Dep[MaxN],MxD[MaxN];
	
	void DFS(int u,int fa){
		int i,v,mx1=-1,mx2=-1;
		MxD[u]=Dep[u];
		for(i=Head[u];i;i=Nxt[i])
			if((v=To[i])^fa){
				Dep[v]=Dep[u]+Weight[i];
				DFS(v,u);
				MxD[u]=max(MxD[u],MxD[v]);
				if(MxD[v]>mx1)
					mx2=mx1,mx1=MxD[v];
				else mx2=max(mx2,MxD[v]);
			}
		if(mx2==-1)
			Ans=max(Ans,mx1-Dep[u]);
		else Ans=max(Ans,mx1-Dep[u]+mx2-Dep[u]);
	}
	
	void Work1(){
		int i;
		DFS(1,0);
		printf("%d\n",Ans);
	}
}
using Sub1::Work1;

bool Check(){
	int i;
	for(i=1;i<N;i++)
		if(V[i]!=U[i]+1)
			return false;
	return true;
}

namespace Sub2{
	int Calc(int x){
		int i,j,cnt=0,sum=0;
		for(i=1;i<N;i=j){
			sum=0;
			for(j=i;j<N;j++){
				sum+=W[j];
				if(sum>=x){
					cnt++;
					break;
				}
			}
		}
		return cnt;
	}

	void Work2(){
		int i,l=1,r=0,mid;
		for(i=1;i<N;i++)
			r+=W[i];
		while(l<=r){
			mid=l+r>>1;
			if(Calc(mid)>=M)
				l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",r);
	}
}
using::Sub2::Work2;

namespace Sub3{
	void Work3(){
		int i,j,ans=1<<30;
		sort(W+1,W+N);
		for(i=N-1-2*M+1,j=N-1;i<=j;i++,j--)
			ans=min(ans,W[i]+W[j]);
		printf("%d\n",ans);
	}
}
using Sub3::Work3;

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int i,u,v,w;
	scanf("%d%d",&N,&M);
	for(i=1;i<N;i++){
		scanf("%d%d%d",&u,&v,&w);
		Add_Edge(u,v,w);
		Add_Edge(v,u,w);
		U[i]=u,V[i]=v,W[i]=w;
	}
	if(M==1)
		Work1();
	else if(Check())
		Work2();
	else Work3();
	return 0;
}
