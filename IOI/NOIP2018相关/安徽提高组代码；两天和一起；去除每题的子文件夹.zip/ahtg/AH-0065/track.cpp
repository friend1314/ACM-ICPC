#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	long long int ans=0;
	int n;
	int m;
	int x,y,w;
	cin>>n;
	cin>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>x>>y>>w;
		ans+=w;
	}
	cout<<ans<<endl;
	return 0;
}