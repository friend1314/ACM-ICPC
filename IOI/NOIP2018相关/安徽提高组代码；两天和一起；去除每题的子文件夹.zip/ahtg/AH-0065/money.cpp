#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

using namespace std;

const int maxn=3e4+10;
int a[maxn];
int m;
int t;
int n;
long long int ans;

int  main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cin>>n;
		ans=n;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
		}
		sort(a+1,a+1+n);
		if(n==1)
			cout<<"1"<<endl;
		if(n==2)
		{
			if(a[2]%a[1]==0)
			{
				cout<<"1"<<endl;
			}
			else
				cout<<"2"<<endl;
		}
		if(n==3)
		{
			for(int i=n;i>1;i--)
			{
				if(a[i]%a[1]==0)
					ans--;
			}
			if(ans==1)
				cout<<ans<<endl;
			else
			{
				if(a[3]%a[2]==0&&a[3]%a[1]!=0)
				{ans--;}
				if(ans==1)
				cout<<ans<<endl;
				else
				{
					for(int i=0;i<=100;i++)
					{	for(int j=0;j<=100;j++)
						{
							if(a[1]*i+a[2]*j==a[3]&&a[3]%a[2]!=0&&a[3]%a[1]!=0)
							{ans--;}
							if(a[1]*i+a[2]*j>a[3])
								break;
						}
					}
					cout<<ans<<endl;
				}
			}
		}
		if(n==4)
		{
			for(int i=n;i>1;i--)
			{
				if(a[i]%a[1]==0)
					ans--;
			}
			if(ans==1)
				cout<<ans<<endl;
			else
			{
				for(int i=n;i>2;i--)
				{
					if(a[i]%a[2]==0&&a[i]%a[1]!=0)
					{ans--;}
				}
					if(ans==1)
						cout<<ans<<endl;
					else
					{
						if(a[4]%a[3]==0&&a[4]%a[2]!=0&&a[4]%a[1]!=0)
						{ans--;}
							cout<<ans<<endl;
					}
			}
		}
		if(n==5)
		{
			for(int i=n;i>1;i--)
			{
				if(a[i]%a[1]==0)
					ans--;
			}
			if(ans==1)
				cout<<ans<<endl;
			else
			{
				for(int i=n;i>2;i--)
				{
					if(a[i]%a[2]==0&&a[i]%a[1]!=0)
					{ans--;}
				}
				if(ans==1)
					cout<<ans<<endl;
				else
				{
					for(int i=n;i>3;i--)
					{
						if(a[i]%a[3]==0&&a[i]%a[2]!=0&&a[i]%a[1]!=0)
						{ans--;}
					}
					if(ans==1)
						cout<<ans<<endl;
					else
					{
						if(a[5]%a[4]==0&&a[5]%a[3]!=0&&a[5]%a[2]!=0&&a[5]%a[1]!=0)
						{ans--;}
						cout<<ans<<endl;
					}
			    }
			}
		}
		if(n==6)
		{
			for(int i=n;i>1;i--)
			{
				if(a[i]%a[1]==0)
					ans--;
			}
			if(ans==1)
				cout<<ans<<endl;
			else
			{
				for(int i=n;i>2;i--)
				{
					if(a[i]%a[2]==0&&a[i]%a[1]!=0)
					{ans--;}
				}
				if(ans==1)
					cout<<ans<<endl;
				else
				{
					for(int i=n;i>3;i--)
					{
						if(a[i]%a[3]==0&&a[i]%a[2]!=0&&a[i]%a[1]!=0)
						{ans--;}
					}
					if(ans==1)
						cout<<ans<<endl;
					else
					{
						for(int i=n;i>4;i--)
						{
							if(a[i]%a[4]==0&&a[i]%a[3]!=0&&a[i]%a[2]!=0&&a[i]%a[1]!=0)
							{ans--;}
						}
						if(ans==1)
						cout<<ans<<endl;
						else
						{
							if(a[6]%a[5]==0&&a[6]%a[4]!=0&&a[6]%a[3]!=0&&a[6]%a[2]!=0&&a[6]%a[1]!=0)
							{ans--;}
							cout<<ans<<endl;
						}	
					}
		        }
			}
		}
		if(n==7)
		{
			for(int i=n;i>1;i--)
			{
				if(a[i]%a[1]==0)
					ans--;
			}
			if(ans==1)
				cout<<ans<<endl;
			else
			{
				for(int i=n;i>2;i--)
				{
					if(a[i]%a[2]==0&&a[i]%a[1]!=0)
					{ans--;}
				}
				if(ans==1)
					cout<<ans<<endl;
				else
				{
					for(int i=n;i>3;i--)
					{
						if(a[i]%a[3]==0&&a[i]%a[2]!=0&&a[i]%a[1]!=0)
						{ans--;}
					}
					if(ans==1)
						cout<<ans<<endl;
					else
					{
						for(int i=n;i>4;i--)
						{
							if(a[i]%a[4]==0&&a[i]%a[3]!=0&&a[i]%a[2]!=0&&a[i]%a[1]!=0)
							{ans--;}
						}
						if(ans==1)
						cout<<ans<<endl;
						else
						{
							for(int i=n;i>5;i--)
							{
								if(a[i]%a[5]==0&&a[i]%a[4]!=0&&a[i]%a[3]!=0&&a[i]%a[2]!=0&&a[i]%a[1]!=0)
							{ans--;}
						    }
							if(ans==1)
								cout<<ans<<endl;
							else
							{
								if(a[7]%a[6]==0&&a[7]%a[5]!=0&&a[7]%a[4]!=0&&a[7]%a[3]!=0&&a[7]%a[2]!=0&&a[7]%a[1]!=0)
									{ans--;}
									cout<<ans<<endl;
							}
						}	
					}
		        }
			}
		}
	}
	return 0;
}