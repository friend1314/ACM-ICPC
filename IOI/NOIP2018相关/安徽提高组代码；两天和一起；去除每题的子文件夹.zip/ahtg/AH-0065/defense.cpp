#include<iostream>
#include<cstdio>
using namespace std;
int n,m;

int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cout<<"-1"<<endl;
	}
	return 0;
}