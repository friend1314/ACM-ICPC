#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
const int maxn=5e3+10;
int way[maxn][maxn];
int n,m;
int sum=1;
int minn=9999;
int flag=0;
bool vis[maxn];
int ans;
int last[maxn];
void minnn(int x)
{
	minn=99999;
	flag=0;
	for(int i=1;i<=n;i++)
	{
		if(way[x][i]!=0&&vis[i]==0)
		minn=min(minn,way[x][i]);
		
	}
	if(minn==99999)
			flag=1;
}
int main()
{
    freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		way[x][y]=y;
		way[y][x]=x;
	}
	ans=1;
	cout<<ans<<" ";
	vis[1]=1;
	/*for(int i=1;i<=m;i++)
	{
		for(int j=1;j<=n;j++)
		{
			cout<<way[i][j]<<" ";
			
		}
		cout<<endl;
	}*/
	minnn(1);
	cout<<minn;
	last[minn]=minn;
	vis[minn]=1;
	sum++;
	ans=minn;
	last[1]=ans;
	for(int i=1;i<=5000;i++)
	{
		
		minnn(minn);
		if(flag!=1)
		cout<<" "<<minn;
		if(flag==1)
		{
			minn=last[last[ans]];
		}
		else
		{
		if(vis[minn]==0)
		{
			last[minn]=ans;
			sum++;
		}
		vis[minn]=1;
		ans=minn;
	}
	if(sum==n)
		break;
		//cout<<minn<<" "<<flag<<endl;
	}
	/*for(int i=1;i<=n;i++)
		cout<<last[i]<<" ";
		cout<<endl;
		cout<<sum<<endl;
		cout<<ans<<endl;*/
	return 0;
}