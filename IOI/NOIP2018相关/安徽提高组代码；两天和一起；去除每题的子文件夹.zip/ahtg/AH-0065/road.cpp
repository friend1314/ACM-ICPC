#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>

using namespace std;

int n;
const int maxn=1e5+10;
int l=1;
int gg;
int ff;
int uu;
int r;
struct node
{
	int deep;
	int no;
}roadnode[maxn];
long long int ans=0;
int minn=999999999;
int shu;
int maxx=0;

bool cmp(node a,node b)
{
	return a.deep<b.deep;
}

inline void work(int l,int r)
{
	for(int i=l;i<=r;i++)
	{
		minn=min(roadnode[i].deep,minn);
	}
	for(int i=l;i<=r;i++)
	{
		int flag=0;
		if(roadnode[i].deep==minn)
		{
			shu=roadnode[i].no;
			flag=1;
		}
		if(flag==1)
			break;
	}
	for(int i=l;i<=r;i++)
	{
		roadnode[i].deep=roadnode[i].deep-minn;
	}
	ans=ans+minn;
	gg=1;
}
void find(int ll,int rr)
{
	
	/*for(int i=ll;i<=rr;i++)
	{*/
		ff=0;
	    uu=0;
		for(int i=1;i<=n;i++)
		{
		if(roadnode[i].deep!=0)
		{
			l=roadnode[i].no;
			ff=1;
		}
		if(ff==1)
			break;
	    }
		if(ff==1)
		{
			for(int j=l;j<=n+1;j++)
			{
				if(roadnode[j].deep==0)
				{
					r=roadnode[j].no-1;
					uu=1;
				}
				if(uu==1)
					break;
			}
		}
		/*if(ff==1&&uu==1)
			break;*/
		if(ff==0)
			gg=0;
	//}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>roadnode[i].deep;
		roadnode[i].no=i;
	}
	roadnode[n+1].deep=0;
		roadnode[n+1].no=n+1;
	gg=1;
	l=1;
	r=n;
	while(gg==1)
	{
		work(l,r);
		//cout<<l<<" "<<r<<endl;
		find(1,n);
		//for(int i=1;i<=n;i++)
		/*cout<<roadnode[i].deep<<" ";
		cout<<endl;*/
		//cout<<l<<" "<<r<<endl;
	}
	/*for(int i=1;i<=n;i++)
	{
		cout<<roadnode[i].deep<<" ";
	}
	cout<<endl;*/
	//cout<<minn<<" "<<shu<<endl;
	cout<<ans<<endl;
	return 0;
}