#include <iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[105];
int main(){
freopen("money.in","r",stdin);
freopen("money.out","w",stdout);
	int t,n;
	cin>>t;
	while(t--){
		
		cin>>n;
		int m=n;
		for(int i=1;i<=n;i++){
		cin>>a[n];		
		}
		sort(a+1,a+n+1);
		for(int i=n;i>=1;i--){
			for(int j=1;j<i;j++){
				for(int k=j+1;k<i;k++){
					for(int mm=1;mm<=(a[i]/a[j])&&a[i]!=0;m++)
					for(int nn=1;nn<=(a[i]/a[k])&&a[i]!=0;n++)
						if(mm*a[j]+nn*a[k]==a[i]){
						m--;a[i]=0;
						}
				}
			}		
		}
		cout<<m<<endl;
	}
return 0;
}