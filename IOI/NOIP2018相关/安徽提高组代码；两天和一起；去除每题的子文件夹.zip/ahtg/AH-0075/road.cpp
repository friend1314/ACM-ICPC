#include <iostream>
#include<cstdio>

using namespace std;
int a[100005];
int flagg[100005];
int total=0,n=0;
void full(int x,int y,int base)
{
	int minn=10005;
	int flag =0;
	int temp=0;
	for(int i=x;i<=y;i++){
		minn=min(a[i],minn);
		flag=i;
	}
	if(minn==10005)return;
	for(int i=x;i<=y;i++){
		if(a[i]==a[flag]){
			
			flagg[x+temp]=i;
			temp++;
			}
		}
		
		total+=minn-base;
		base=minn;
		if(temp==1)return;
		for(int k=0;k<temp;k++){
			full(flagg[x+k]+1,flagg[x+k+1]-1,base);
			}
		
	
	}




int main(){
freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
int minn=10001;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		minn=min(minn,a[i]);
	}
	a[0]=minn;
	a[n+1]=minn;
full (0,n+1,0);
cout<<total<<endl;
return 0;


	
}
