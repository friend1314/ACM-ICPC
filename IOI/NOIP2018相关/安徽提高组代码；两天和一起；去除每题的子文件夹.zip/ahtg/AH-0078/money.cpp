#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define LL long long 
using namespace std;
void read(LL &x)
{
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') {x=(x<<3)+(x<<1)+(ch^48); ch=getchar();}
}
LL a[110],q[30000];
bool b[110],to[25010],vis[25010];
LL t,n,ans;
bool bfs(int x)
{
	memset(q,0,sizeof(q));
	memset(vis,0,sizeof(vis));
	LL head=0,tail=1;
	q[1]=x;
	do
	{
		head++;
		LL u=q[head];
		for(int j=1;j<=n;j++)
		if(a[j]<u&&!vis[u-a[j]])
		{
			tail++;
			vis[u-a[j]]=1;
			q[tail]=u-a[j];
			if(to[q[tail]]) return 1;
		}
	}while(head<tail);
	return 0;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);
		memset(a,0,sizeof(a));
		memset(b,false,sizeof(b));
		memset(to,0,sizeof(to));
		for(int i=1;i<=n;i++)
		read(a[i]),to[a[i]]=true;
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
		if(a[j]%a[i]==0) b[j]=true;
		for(int i=n;i>=1;i--)
		if(!b[i]&&bfs(a[i])) b[i]=true;
		ans=0;
		for(int i=1;i<=n;i++)
		if(!b[i]) ans++;
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}