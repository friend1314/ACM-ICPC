#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define LL long long
using namespace std;
void read(long long &x)
{
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') {x=(x<<3)+(x<<1)+(ch^48); ch=getchar();}
}
LL a[50010];
LL n,m,minn;
bool pd(int x)
{
	LL sum=1,s=0;
	minn=0x7fffffff/3;
	for(int i=1;i<=n;i++)
	{
		s+=a[i];
		if(s>x)
		{
			sum++;
			minn=min(minn,s-a[i]);
			s=a[i];
	    }
	}
	if(sum<=m) return 1;
	else return 0;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n); read(m);
	LL ans=0,maxn=0;
	for(int i=1;i<=n-1;i++)
	{
		LL x,y,t;
		read(x); read(y); read(t);
		a[x]=t;
		ans+=t;
		maxn=max(maxn,t);
	}
	LL l=maxn,r=ans,mid;
	while(l<=r)
	{
		mid=(l+r)>>1;
		if(!pd(mid)) l=mid+1;
		else r=mid-1;
	}
	LL num=0,minn=0x7fffffff/3;
	for(int i=1;i<=n;i++)
	{
		if(num+a[i]>l) minn=min(minn,num),num=0;
		num+=a[i];
	}
	printf("%lld",minn);
	fclose(stdin);
	fclose(stdout);
	return 0;
}