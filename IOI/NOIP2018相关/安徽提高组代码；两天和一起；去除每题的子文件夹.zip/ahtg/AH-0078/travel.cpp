#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
void read(int &x)
{
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') {x=(x<<3)+(x<<1)+(ch^48); ch=getchar();}
}
struct node
{
	int now,next;
}a[10010];
bool cmp(node x,node y)
{
	if(x.now==y.now) return x.next<y.next;
	return x.now<y.now;
}
bool b[10010];
int k[5010][2],vis[10010];
void dfs1(int x)
{
	for(int i=k[x][0];i<=k[x][1];i++)
	if(!b[a[i].next])
	{
		b[a[i].next]=true;
		printf("%d ",a[i].next);
		dfs1(a[i].next);
	}
}
bool pd(int w)
{
	for(int i=k[w][0];i<=k[w][1];i++)
	if(vis[a[i].next]&&a[i].now>a[i].next&&vis[a[i].next]!=a[i].now&&!b[a[i].next]&&vis[a[i].now]!=a[i].next) return 1;
	return 0;
}
void dfs2(int x)
{
	for(int i=k[x][0];i<=k[x][1];i++)
	if(!b[a[i].next]&&!vis[a[i].next]) vis[a[i].next]=a[i].now;
	for(int i=k[x][0];i<=k[x][1];i++)
	if(!b[a[i].next])
	{
		if(pd(a[i].next)) return;
		b[a[i].next]=true;
		printf("%d ",a[i].next);
		dfs2(a[i].next);
	}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,m;
	read(n); read(m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		read(x); read(y);
		a[i].now=x; a[i].next=y;
		a[m+i].now=y; a[m+i].next=x;
	}
	sort(a+1,a+2*m+1,cmp);
	for(int i=1;i<=2*m+1;i++)
	if(a[i].now!=a[i-1].now)
	k[a[i].now][0]=i,k[a[i-1].now][1]=i-1;
	printf("1 "); b[1]=true;
	if(m==n-1) dfs1(1);
	else if(m==n) dfs2(1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}