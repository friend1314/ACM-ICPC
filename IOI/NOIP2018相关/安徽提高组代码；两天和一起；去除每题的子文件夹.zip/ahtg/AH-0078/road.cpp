#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
void read(long long &x)
{
	x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') {x=(x<<3)+(x<<1)+(ch^48); ch=getchar();}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long long n,x,last,ans=0;
	read(n); read(last);
	for(int i=2;i<=n;i++)
	{
		read(x); 
		if(x<last) ans+=last-x;
		last=x;
	}
	printf("%lld",ans+last);
	fclose(stdin);
	fclose(stdout);
	return 0;
}