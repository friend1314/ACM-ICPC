#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <istream>
#include <ostream>
#include <queue>

using namespace std;
int main(){
	queue<int> q1;
queue<int> q2;
queue<int> q3;
queue<int> q4;
queue<int> q5;
	ifstream f1("money.in");
	ofstream f2("money.out");
	int a[1000],b[1000],t,n;
	cin>>t;
	for(int i=1;i<=t;++i){
		cin>>n;
		int m=250000;
			for(int j=1;j<=1000;++j){
		a[j]=0;
	}
	for(int j=1;j<=n;++j){
		cin>>a[j];
	}
	sort(a,a+n);
		if(n==5){
			q1.push(a[1]);
			q2.push(a[2]);
			q3.push(a[3]);
			q4.push(a[4]);
			q5.push(a[5]);
			while(!q5.empty()){
				b[1]=q1.front();
				b[2]=q2.front();
				b[3]=q3.front();
				b[4]=q4.front();
				b[5]=q5.front();
					for(int k=1;k<=n;++k){
					int c[1000];
				if(b[1]>a[k])
				{
					q1.push(b[1]%a[k]);
					c[b[1]%a[k]]=1;
					}
				if(b[2]>a[k])
				{
					q2.push(b[2]%a[k]);
					c[b[2]%a[k]]=1;
					}
				if(b[3]>a[k])
				{
					q3.push(b[3]%a[k]);
					c[b[3]%a[k]]=1;
					}
				if(b[4]>a[k])
				{
					q4.push(b[4]%a[k]);
					c[b[4]%a[k]]=1;
					}
				if(b[5]>a[k])
				{
					q5.push(b[5]%a[k]);
					c[b[5]%a[k]]=1;
					}
					int f=0;
					for(int l=1;l<=1000;++l){
						if(a[l]==1){
							++f;
						}
				}
				if(f<m){m=f;}
			}
			}
			q1.pop();
			q2.pop();
			q3.pop();
			q4.pop();
			q5.pop();
	}
		if(n==4){
			q1.push(a[1]);
			q2.push(a[2]);
			q3.push(a[3]);
			q4.push(a[4]);
			while(!q4.empty()){
				b[1]=q1.front();
				b[2]=q2.front();
				b[3]=q3.front();
				b[4]=q4.front();
					for(int k=1;k<=n;++k){
					int c[1000];
				if(b[1]>a[k])
				{
					q1.push(b[1]%a[k]);
					c[b[1]%a[k]]=1;
					}
				if(b[2]>a[k])
				{
					q2.push(b[2]%a[k]);
					c[b[2]%a[k]]=1;
					}
				if(b[3]>a[k])
				{
					q3.push(b[3]%a[k]);
					c[b[3]%a[k]]=1;
					}
				if(b[4]>a[k])
				{
					q4.push(b[4]%a[k]);
					c[b[4]%a[k]]=1;
					}
					int f=0;
					for(int l=1;l<=1000;++l){
						if(a[l]==1){
							++f;
						}
				}
				if(f<m){m=f;}
			}
			}
			q1.pop();
			q2.pop();
			q3.pop();
			q4.pop();
	}
		if(n==3){
			q1.push(a[1]);
			q2.push(a[2]);
			q3.push(a[3]);
			while(!q3.empty()){
				b[1]=q1.front();
				b[2]=q2.front();
				b[3]=q3.front();
					for(int k=1;k<=n;++k){
					int c[1000];
				if(b[1]>a[k])
				{
					q1.push(b[1]%a[k]);
					c[b[1]%a[k]]=1;
					}
				if(b[2]>a[k])
				{
					q2.push(b[2]%a[k]);
					c[b[2]%a[k]]=1;
					}
				if(b[3]>a[k])
				{
					q3.push(b[3]%a[k]);
					c[b[3]%a[k]]=1;
					}
					int f=0;
					for(int l=1;l<=1000;++l){
						if(a[l]==1){
							++f;
						}
				}
				if(f<m){m=f;}
			}
			}
			q1.pop();
			q2.pop();
			q3.pop();
	}
			if(n==2){
			if((a[2]/a[1])*a[1]==a[2]){
				m=1;
				}
				else{
					m=2;
				}
				}
				cout<<m<<endl;
    }
	f1.close();
	f2.close();
	return 0;
}