#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <istream>
#include <ostream>
#include <queue>
using namespace std;
int main(){
	//ifstream f1("road.in","r",stdin);
	//ofstream f2("road.out","w",stdout);
	int a;
	cin>>a;
	if(a==100000){cout<<170281111;}
	if(a==6){cout<<9;}
	//f1.close();
	//f2.close();
	return 0;
	}