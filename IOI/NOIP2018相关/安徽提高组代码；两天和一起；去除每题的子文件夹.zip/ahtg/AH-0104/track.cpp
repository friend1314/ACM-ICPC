#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
inline int rd(){
	int f=1,x=0;
	char cr=getchar();
	while (cr>'9'||cr<'0') {
		if (cr=='-') f=-1;
		cr=getchar();
		}
	while (cr>='0'&&cr<='9'){
		x=(x<<3)+(x<<1)+cr-'0';
		cr=getchar();
		}
	return x*f;
	}
struct node{
	int to,next,v;
	}e[200005];
int n,m,x,y,z,cnt,head[200002],dis[200002],maxx=-1;
bool vis[200002];
inline void build(int u,int v,int w){
	e[++cnt].to=v;
	e[cnt].v=w;
	e[cnt].next=head[u];
	head[u]=cnt;
	}
inline void find(int u,int fau){
	for (int i=head[u];i;i=e[i].next){
		if (e[i].to!=fau) {
				dis[e[i].to]=max(dis[e[i].to],dis[u]+e[i].v);
				find(e[i].to,u);
			}
		}
	}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=rd(),m=rd();
	for (int i=1;i<n;i++){
		x=rd(),y=rd(),z=rd();
		build(x,y,z);
		build(y,x,z);
		}
	for (int i=1;i<=n;i++){
		memset(dis,0,sizeof(dis));
		find(i,0);
		for (int j=1;j<=n;j++) maxx=max(maxx,dis[j]);
		}
	printf("%d",maxx);
	}