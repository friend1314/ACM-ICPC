#include <iostream>
#include <cstdio>
using namespace std;
inline int rd(){
	int f=1,x=0;
	char cr=getchar();
	while (cr>'9'||cr<'0') {
		if (cr=='-') f=-1;
		cr=getchar();
		}
	while (cr>='0'&&cr<='9'){
		x=(x<<3)+(x<<1)+cr-'0';
		cr=getchar();
		}
	return x*f;
	}
int n,ans=0,a[100004];
inline void f(int l,int r){
	if (l>r) return;
	if (l==r){
		ans+=a[l];
		a[l]=0;
		return;
		}
	int mid=l;
	for (int i=l;i<=r;i++) {
		if (a[l]==0) {
			f(l,i-1);
			f(i+1,r);
			}
		if (a[i]<a[mid]) mid=i;
		}
	int k=a[mid];
	ans+=k;
	for (int i=l;i<=r;i++) a[i]-=k;
	f(l,mid-1);
	f(mid+1,r);
	}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=rd();
	for (int i=1;i<=n;i++) a[i]=rd();
	f(1,n);
	printf("%d",ans);
	}