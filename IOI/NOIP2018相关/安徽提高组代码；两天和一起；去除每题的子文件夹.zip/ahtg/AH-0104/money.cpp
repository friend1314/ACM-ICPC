#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
inline int rd(){
	int f=1,x=0;
	char cr=getchar();
	while (cr>'9'||cr<'0') {
		if (cr=='-') f=-1;
		cr=getchar();
		}
	while (cr>='0'&&cr<='9'){
		x=(x<<3)+(x<<1)+cr-'0';
		cr=getchar();
		}
	return x*f;
	}
bool f[100001];
int a[101],g[101][101],vis[101],t,n;
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=rd();
	while (t--){
		int ans=0;
		memset(a,0,sizeof(a));
		memset(vis,0,sizeof(vis));
		n=rd();
		for (int i=1;i<=n;i++) a[i]=rd();
		sort(a+1,a+n+1);
		for (int i=1;i<=n;i++){
			memset(f,0,sizeof(f));
			f[0]=1;
			for (int j=1;j<i;j++)
				for (int k=a[j];k<=a[i];k++) if (f[k-a[j]]==1) f[k]=1;
			if (f[a[i]]==1) vis[i]=1;
			}
		for (int i=1;i<=n;i++) if (!vis[i]) ans++;
		printf("%d\n",ans);
		}
	}