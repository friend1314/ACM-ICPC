#include <iostream>
#include <cstdio>
#define ll long long 
#define mod 1000000007
using namespace std;
inline ll rd(){
	ll x=0,f=1;
	char cr=getchar();
	while (cr<'0'||cr>'9'){
		if (cr=='-') f=-1; cr=getchar();}
	while (cr>='0'&&cr<='9'){x=(x<<3)+(x<<1)+cr-'0'; cr=getchar();}
	return f*x;
}
ll f[8][1000000],n,m;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=rd(),m=rd();
	n--,m--;
	f[0][0]=2;
	f[0][1]=4;
	f[1][0]=4;
	f[1][1]=12;
	f[2][1]=36;
	f[1][2]=36;
	f[2][2]=112;
	if (m>n) swap(m,n);
	if (n==0) for (int i=1;i<=m;i++) f[n][i]=(f[n][i-1]*2)%mod;
	else if (n==1) for (int i=1;i<=m;i++) f[n][i]=(f[n][i-1]*3)%mod;
	printf("%lld",f[n][m]);
	}