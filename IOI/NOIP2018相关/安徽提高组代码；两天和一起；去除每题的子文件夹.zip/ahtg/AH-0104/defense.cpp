#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
inline int rd(){
	int x=0,f=1;
	char cr=getchar();
	while (cr<'0'||cr>'9'){
		if (cr=='-') f=-1; cr=getchar();}
	while (cr>='0'&&cr<='9'){x=(x<<3)+(x<<1)+cr-'0'; cr=getchar();}
	return f*x;
}
int n,m;
string s;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	n=rd(),m=rd();
	cin >> s;
	for (int i=1;i<=m;i++) printf ("-1\n");
	}