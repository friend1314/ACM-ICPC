#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
inline int rd(){
	int x=0,f=1;
	char cr=getchar();
	while (cr<'0'||cr>'9'){
		if (cr=='-') f=-1; cr=getchar();}
	while (cr>='0'&&cr<='9'){x=(x<<3)+(x<<1)+cr-'0'; cr=getchar();}
	return f*x;
}
struct node{
	int to,next;
	}e[100001];
int head[100001],fa[100001],vis[100001],n,m,x,y,cnt;
inline void add(int u,int v){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;
	}
inline void dfs(int u,int fau){
	if (!fa[u]) fa[u]=fau;
	if (!vis[u]) {printf("%d ",u);vis[u]=1;}
	for (int i=u;i!=-1;i=fa[i]){
		int minn=n+1;
		for (int j=head[i];j;j=e[j].next) if (vis[e[j].to]==0&&e[j].to<minn) minn=e[j].to;
		if (minn!=n+1) dfs(minn,i);
		}
	}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	n=rd(),m=rd();
	for (int i=1;i<=m;i++) {
		x=rd(),y=rd();
		add(x,y);
		add(y,x);
		}
	dfs(1,-1);
	return 0;
}