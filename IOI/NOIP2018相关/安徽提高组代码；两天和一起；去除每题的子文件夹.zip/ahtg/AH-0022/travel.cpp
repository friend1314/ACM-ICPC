#include<iostream>
#include<cstdio>
using namespace std;
int a[5001][5001],b[5001],c[5001]={0},t,n,m;
int dfshs(int x,int l,int u)
{
	int i,y=n+1;
	if(u!=2)
	for(i=1;i<=n;i++)
	{
		if(a[t][i]&&i!=x&&c[i]==0)
		{
			y=i;
			break;
		}
	}
	for(i=1;i<=n;i++)
	{
		if(a[x][i]&&i!=t&&c[i]==0)
		{
			if(y<i)
			{
				t=x;
				b[l]=y;
				c[y]=1;
				dfshs(y,l+1,2);
			}
			else
			{
				t=x;
				b[l]=i;
				c[i]=1;
				dfshs(i,l+1,1);
			}
		}
	}
	return 0;
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int i,x,y;
	scanf("%d %d",&n,&m);
	for(i=1;i<=m;i++)
	{
		scanf("%d %d",&x,&y);
		a[x][y]=1;
		a[y][x]=1;
	}
	t=0;
	c[1]=b[1]=t=1;
	dfshs(1,2,1);
	for(i=1;i<=n;i++)
	printf("%d ",b[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}