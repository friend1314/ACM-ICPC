#include<iostream>
#include<cstdio>
using namespace std;
int n,m,a[25001]={0},t=0,s=0,f,j;
int nb(int r)
{
	int l;
	for(l=r;l>=f;l--)
	{
		if(a[l]&&l!=j)
		{
			if(r%l==0||nb(r%l)==0)
			return 0;
		}
	}
	return 1;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&n);
	int i,x;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&m);
		t=s=0;
		f=25001;
		for(j=1;j<=m;j++)
		{
			scanf("%d",&x);
			a[x]++;
			if(x==1)
			break;
			else
			{
				if(x>t)
				t=x;
				if(x<f)
				f=x;
			}
		}
		if(j<=m||m==1)
		{
			printf("1\n");
			continue;
		}
		for(j=t;j>f;j--)
		{
			if(a[j]>0&&nb(j)==0)
			s+=a[j];
		}
		printf("%d\n",m-s);
		for(j=f;j<=t;j++)
		a[j]=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}