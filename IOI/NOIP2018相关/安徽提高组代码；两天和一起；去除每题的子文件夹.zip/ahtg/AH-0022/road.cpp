#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int a[100001]={0};
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,i,j,l=0;
	long long s,sum=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]>l)
		l=a[i];
	}
	for(i=1;i<=l;i++)
	{
		s=0;
		for(j=1;j<=n;j++)
		{
			if(a[j]>=i)
			s++;
			else if(s)
			{
				sum++;
				s=0;
			}
		}
		if(a[j-1]>=i)
		sum++;
	}
	printf("%lld",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}