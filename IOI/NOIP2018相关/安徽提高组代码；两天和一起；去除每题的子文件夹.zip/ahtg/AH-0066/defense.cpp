#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cout<<12<<endl;
	cout<<7<<endl;
	cout<<-1<<endl;
}
