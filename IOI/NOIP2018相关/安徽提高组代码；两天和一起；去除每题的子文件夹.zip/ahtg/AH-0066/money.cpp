#include<bits/stdc++>
using namespace std;
int t,n,mx=0,in[21],cnt,st[20][100][2];
void sly(int num1,int num2,int sum)
{
	for(int i=num1,b!=0;b!==0;i++)
		for(int j=num2,;;j++)
		{
			if(sum+k*str[i][j][0]<=mx)
			{b!=1;
				break;}
				sly(i,j,sum+k*d\str[i][j][0];
	}
	int main()
	{
		freopen("money.in","r",stdout)
		freopen("money.out","w",stdout)
		cin>>t;
		for(int i=0;i<t;i++)
			cin>>n;
			for(int j=0;j<n;j++)cin>>str[i][j][0];
				if(str[i][j][0]>mx)
					mx=str[i][j][0];
					sly(0,0,0);
					for(int i=0,i<t,i++)
					   
							
							if(str[i][j][0])
								str[k][l][i]=1;
					cout<<1<<1<<endl;
					return 0;}
						
