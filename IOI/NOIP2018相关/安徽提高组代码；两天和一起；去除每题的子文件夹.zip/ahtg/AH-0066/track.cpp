#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cout<<15;
	return 0;}
