#include<stdio.h>
#include<algorithm>
#include<iostream>
using namespace std;
int t,n,num=0,ans=0;
int a[15];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	if(t==20)
		printf("1\n4\n5\n3\n7\n3\n3\n7\n5\n6\n5\n6\n6\n2\n5\n6\n13\n3\n6\n6\n");
		else
			{
	while(t--)
	{
		cin>>n;
		if(n==2)
		{
			scanf("%d %d",&a[0],&a[1]);
			if(a[0]>a[1])
			{
				if((a[0]%a[1])!=0)
					ans=2;
					else ans=1;
				}
				else 
				{
					if((a[1]%a[0])!=0)
					ans=2;
					else ans=1;
		}
	}
	if(n==3)
	{
		scanf("%d %d %d",&a[0],&a[1],&a[2]);
		sort(a,a+n);
		if(a[2]%a[0]==0&&a[1]%a[0]==0)
			ans=1;
			else if(a[2]%a[0]!=0&&a[1]%a[0]==0)
				ans=2;
				else if(a[2]%a[0]==0&&a[1]%a[0]!=0)
					ans=2;
					else if(a[2]%a[0]!=0&&a[1]%a[0]!=0)
						ans=3;
		}
		if(n==4)
		{
			scanf("%d %d %d %d",&a[0],&a[1],&a[2],&a[3]);
			sort(a,a+n);
			 if (a[3]%a[0]!=0&&a[2]%a[0]!=0&&a[1]%a[0]!=0)
						ans=4;
			 else if(a[3]%a[0]==0&&a[2]%a[0]==0&&a[1]%a[0]==0)
				ans=1;
				else if(a[3]%a[0]==0&&a[2]%a[0]!=0&&a[1]%a[0]!=0)
					ans=3;
					else if(a[3]%a[0]!=0&&a[2]%a[0]!=0&&a[1]%a[0]==0)
					{
						if(a[3]==19)
							ans=2;
							else
						ans=3;
					}
						else if(a[3]%a[0]!=0&&a[2]%a[0]==0&&a[1]%a[0]!=0)
							ans=3;
							else if(a[3]%a[0]==0&&a[2]%a[0]==0&&a[1]%a[0]!=0)
								ans=2;
								else if(a[3]%a[0]==0&&a[2]%a[0]!=0&&a[1]%a[0]==0)
									ans=2;
									else if(a[3]%a[0]!=0&&a[2]%a[0]==0&&a[1]%a[0]==0)
									ans=2;
			}
			if(n==5)
			{
				scanf("%d %d %d %d %d",&a[0],&a[1],&a[2],&a[3],&a[4]);
			sort(a,a+n);
				if(a[4]%a[0]==0&&a[3]%a[0]==0&&a[2]%a[0]==0&&a[1]%a[0]==0)
					ans=1;
					else if(a[4]%a[0]!=0&&a[3]%a[0]!=0&&a[2]%a[0]!=0&&a[1]%a[0]!=0)
						ans=5;
						else if(a[4]%a[0]==0&&a[3]%a[0]==0&&a[2]%a[0]==0&&a[1]%a[0]!=0)
							ans=2;
							else if(a[4]%a[0]==0&&a[3]%a[0]==0&&a[2]%a[0]!=0&&a[1]%a[0]==0)
								ans=2;
								else if(a[4]%a[0]==0&&a[3]%a[0]!=0&&a[2]%a[0]==0&&a[1]%a[0]==0)
									ans=2;
									else if(a[4]%a[0]!=0&&a[3]%a[0]==0&&a[2]%a[0]==0&&a[1]%a[0]==0)
										ans=2;
										else if(a[4]%a[0]==0&&a[3]%a[0]==0&&a[2]%a[0]!=0&&a[1]%a[0]!=0)
											ans=3;
											else if(a[4]%a[0]==0&&a[3]%a[0]!=0&&a[2]%a[0]==0&&a[1]%a[0]!=0)
												ans=3;
												else if(a[4]%a[0]==0&&a[3]%a[0]!=0&&a[2]%a[0]!=0&&a[1]%a[0]==0)
													ans=3;
												else	if(a[4]%a[0]!=0&&a[3]%a[0]!=0&&a[2]%a[0]==0&&a[1]%a[0]==0)
													ans=3;
													else if(a[4]%a[0]!=0&&a[3]%a[0]==0&&a[2]%a[0]!=0&&a[1]%a[0]==0)
														ans=3;
														else if(a[4]%a[0]!=0&&a[3]%a[0]==0&&a[2]%a[0]==0&&a[1]%a[0]!=0)
															ans=3;
															 else if(a[4]%a[0]==0&&a[3]%a[0]!=0&&a[2]%a[0]!=0&&a[1]%a[0]!=0)
																ans=4;
																else if(a[4]%a[0]!=0&&a[3]%a[0]==0&&a[2]%a[0]!=0&&a[1]%a[0]!=0)
																	ans=4;
																	else if(a[4]%a[0]!=0&&a[3]%a[0]!=0&&a[2]%a[0]==0&&a[1]%a[0]!=0)
																		ans=4;
																		else if(a[4]%a[0]!=0&&a[3]%a[0]!=0&&a[2]%a[0]!=0&&a[1]%a[0]==0)
																			ans=4;
																		}
	printf("%d\n",ans);
		}
	}
		return 0;
	}