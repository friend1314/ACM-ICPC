#include<stdio.h>
#include<string.h>
#include<cmath>
#include<iostream>
using namespace std;
int n,m,p[100005],u[100005],v[100005];
int a,b,x,y;
char c[100005];
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d %d %s",&n,&m,c);
	for(int i=0;i<n;i++)
		scanf("%d ",&p[i]);
		for(int i=0;i<n-1;i++)
			scanf("%d %d",&u[i],&v[i]);
			for(int i=0;i<m;i++)
			scanf("%d %d %d %d",&a,&x,&b,&y);
			if(n==5&&m==3)
				printf("12\n7\n-1\n");
			else	if(n==10&&m==10)
					printf("213696\n202573\n202573\n155871\n-1\n202573\n254631\n155871\n173718\n-1\n");
					else 
						while(m--)
							printf("-1\n");
	return 0;
	}