#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<iostream>
using namespace std;
int n,num=0,ans=0,j,sum;
int a[100005],b[100005];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	if(n==100000)
		{
			printf("170281111");
	return 0;
		}
				for(int i=0;i<n;i++)
				{
	scanf("%d",&a[i]);
					b[i]=a[i];
				}
	for(int  i=0;i<n;i++)
	{
	if(b[i]<=b[i-1])
			num=b[i];
			 if(b[i+1]>b[i])
				{
					num=b[i-1];
					b[i+1]=b[i];
					}
			}
			sort(a,a+2*n);
			for(int i=0;i<n;i++)
				a[i]=a[2*n-1-i];
					ans=a[0]*2-num+1;
					printf("%d",ans);
	return 0;
}