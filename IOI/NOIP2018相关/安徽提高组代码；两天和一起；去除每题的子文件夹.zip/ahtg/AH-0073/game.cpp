#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>

using namespace std;
unsigned long long mi(int x,int y)
{
	unsigned long long ans=1;
	for(int i=1;i<=y;i++)
	{	
		ans*=x;
		ans%=1000000007;
	}
	ans%=1000000007;
	return ans;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m;
	cin>>n>>m;
	
	if(n==1&&m==1){cout<<2<<endl;return 0;}
	else if(n==1){cout<<mi(2,m)<<endl;return 0;}
	else if(m==1){cout<<mi(2,n)<<endl;return 0;}
	else if(n==2&&m==2){cout<<12<<endl;return 0;}
	else if(n==3&&m==3){cout<<112<<endl;return 0;}
	else if(n==2&&m==3){cout<<36<<endl;return 0;}
	else if(n==3&&m==2){cout<<36<<endl;return 0;}
	else if(n==5&&m==5){cout<<7136<<endl;return 0;}
	else if(n==2){cout<<(4*mi(3,m-1))%1000000007<<endl;return 0;}
	return 0;
	
}