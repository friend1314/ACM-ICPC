#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <algorithm>

using namespace std;
bool d[5005][5005];
int n,m;//n个城市，m条道路
int cnt=0;
void dfs(int las)
{
	if(cnt==n) return;
	for(int i=1;i<=n;i++)
	{
		if(i==las||d[i][0])continue;
		if(d[las][i])
		{
			d[1][0]=1;dfs(i);cout<<i<<" ";cnt++;break;
		}
		d[i][0]=0;
		dfs(las);
	}
	return ;
}

int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>m;
	int u,v;
	for(int i=1;i<=m;i++){cin>>u>>v;d[u][v]=1;}
	d[1][0]=1;
	dfs(1);
	return 0;
}