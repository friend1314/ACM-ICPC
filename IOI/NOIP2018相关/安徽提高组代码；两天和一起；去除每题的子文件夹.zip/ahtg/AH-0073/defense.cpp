#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <algorithm>
using namespace std;
int n,m,cost[100005];
string Type;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>n>>m>>Type;//城市数，询问数
	for(int i=1;i<=n;i++) cin>>cost[i];
	int a,x,b,y;
	for(int i=1;i<=m;i++)
	{
		cin>>a>>x>>b>>y;
	}
	for(int i=1;i<=m;i++)cout<<-1<<endl;
	
	return 0;
}