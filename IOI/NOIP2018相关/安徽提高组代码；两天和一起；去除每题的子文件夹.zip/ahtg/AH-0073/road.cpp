#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
int dep[100005];
int n;
int main()
{
	ios::sync_with_stdio(false);
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	register int i,j,k;
	for(i=1;i<=n;i++)cin>>dep[i];
	int cnt=0;
	for(i=1;i<=n;i++)
	{
		while(dep[i]>0)
		{
			for(j=i;j<=n;j++)
			{
				if(dep[j]<=0||j==n)
				{
					cnt++;
					for(k=i;k<=j;k++) dep[k]--;
					break;
				}
			}
		}
	}
	cout<<cnt<<endl;
	
	return 0;
}