#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
int T,n,ans,a[25005];

void work(int x)
{
	int lef=a[x];
	for(int i=x-1;i>0;i--)
	{
		lef%=a[i];
		if(lef%a[i]==0){ans--;return;}
		if(lef<a[1]) return;
	}
		
}
int main()
{
	ios::sync_with_stdio(false);
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
cin>>T;
while(T--)
{
	cin>>n;
	if(n==2)
	{
		int x,y;
		cin>>a[1]>>a[2];
		x=a[1]>a[2]?a[1]:a[2];
		y=a[1]>a[2]?a[2]:a[1];
		if(x%y!=0)cout<<2<<endl;
		else cout<<1<<endl;
	}
	else
	{
		ans=n;//cout<<ans;
		for(int i=1;i<=n;i++)cin>>a[i];
		sort(a+1,a+n+1);
		for(int i=2;i<=n;i++)work(i);
		cout<<ans<<endl;
	}
	
}
	return 0;
}
