#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <bits/stdc++.h>
#include <algorithm>
#include <iomanip>
using namespace std;
int mapp[10005][10005];
int n,m;
int main()
{
	freopen("track.in","r",stdin);
        freopen("track.out","w",stdout);
	cin>>n>>m;//n个点，m赛道
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			mapp[i][j]=192608171;
	//cout<<mapp[1][1];
	for(int i=1;i<=n;i++) mapp[i][i]=0;
	int a,b,c; 
	for(int i=1;i<n;i++)
	{
		cin>>a>>b>>c;
		mapp[a][b]=c;
	}
	for(int k=1;k<=n;k++)
		for(int i=1;k<=n;k++)
			for(int j=1;j<=n;j++)
				if(i==j)continue;
				else if(mapp[i][j]<mapp[i][k]+mapp[k][j]&&mapp[i][k]!=192608171&&mapp[k][j]!=192608171&&mapp[i][j]!=192608171)
					mapp[i][j]=mapp[i][k]+mapp[k][j];
	int maxx=-1;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(mapp[i][j]>maxx && mapp[i][j]!=192608171)
				maxx=mapp[i][j];
			
	cout<<maxx<<endl;
	
	return 0;
}
	
	
