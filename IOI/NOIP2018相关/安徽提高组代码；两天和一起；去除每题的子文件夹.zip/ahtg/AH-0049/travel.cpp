#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
const int oo=1<<30;

struct node{
	int fa;
	int l;
	bool go;
	int ch[1005];
}a[1005];
int n,m;
bool cmp(int a,int b){
	return a<b;
}
int t[5005];
int ans[2005];
int len=0;
void work(int now,int num,int fa){
	if(num>n)
		return;
	if(a[now].go)
		return;
	num++;
	for(int i=1;i<=a[now].l;i++){
		if(a[now].ch[i]!=fa){
		ans[++len]=a[now].ch[i];
		work(a[now].ch[i],num,now);
		}
	}
	return;
}
int t2[5005];
int root=1<<30;
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>m;
	if(n==m){
		for(int i=1;i<=n;i++)
			cout<<i<<' ';
			cout<<endl;
			return 0;
	}
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		root=min(root,min(x,y));
		a[x].go=false;
		a[y].go=false;
		a[x].ch[++a[x].l]=y;
		a[y].ch[++a[y].l]=x;
	}
	
	for(int i=1;i<=n;i++){
		sort(a[i].ch+1,a[i].ch+1+a[i].l,cmp);
	}
	work(root,0,-1);
	cout<<root<<' ';
	for(int i=1;i<=len;i++)
		cout<<ans[i]<<' ';
	cout<<endl;
	return 0;
}