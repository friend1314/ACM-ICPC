#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int n;
int a[100005];
int ans;
bool work(){
	bool ok=true;
	for(int i=1;i<=n;i++)
		if(a[i]>0)
		{
			ok=false;
			break;
		}
	return ok;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	while(1){
		if(work())
			break;
		int k1=1,k2=n;
		int m=1<<30;
		for(int i=1;i<=n;i++)
			if(a[i]>0){
				k1=i;
				break;
			}
		for(int i=k1;i<=n;i++){
			if(a[i]==0)
			{
				k2=i-1;
				break;
			}
			m=min(m,a[i]);
		}
		ans+=m;
		for(int i=k1;i<=k2;i++){
			a[i]-=m;
		}
	}
	cout<<ans<<endl;
	return 0;
}