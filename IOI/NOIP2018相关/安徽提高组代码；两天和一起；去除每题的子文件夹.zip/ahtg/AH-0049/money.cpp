#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
int a[105];
int t;
int n;
bool work(int s,int k,int l){
	if(k==l){
		if(s==a[l])
			return true;
		else
			return false;
	}
	bool ok=false;
	for(int i=0;i<=(a[l]-s)/a[k];i++)
		if(work(s+a[k]*i,k+1,l))
		{
			ok=true;
			break;
		}
	return ok;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t--){
		scanf("%d",&n);
		int ans=n;
		if(n==1)
		{
			printf("%d\n",n);
			continue;
		}
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++)
			if(work(0,1,i))
				ans--;
		printf("%d\n",ans);
	}
	return 0;
}