#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
struct node{
	int a;
	int b;
	int l;
}k[50005];
int n,m;
bool cmp1(node a,node b){
	return a.l>b.l;
}
int p[50005];
bool cmp3(node a,node b){
	return a.b<b.b;
}
bool cmp2(int a,int b){
	return a>b;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	n--;
	bool ok1=true;
	bool ok2=true;
	long long u=0;
	for(int i=1;i<=n;i++){
		scanf("%d%d%d",&k[i].a,&k[i].b,&k[i].l);
		if(k[i].a!=1)
			ok1=false;
		if(k[i].b!=k[i].a+1)
			ok2=false;
		u+=k[i].l;
	}
	if(ok1){
		sort(k+1,k+1+n,cmp1);
		cout<<k[m].l<<endl;
		return 0;
	}
	if(ok2){
		int ans1,ans2;
		
		sort(k+1,k+1+n,cmp3);
		long long s=0;
		for(int i=1;i<=n;i++){
			s+=k[i].l;
		}
		s/=m;
		int t=0;
		int l1=0;
		for(int i=1;i<=n;i++){
			if(i==n){
			if(t+k[i].l>s){
				if(t+k[i].l-s<s-t){
					t+=k[i].l;
					p[++l1]=t;
					t=0;
				}
				else{
					p[++l1]=t;
					t=k[i].l;
					p[++l1]=t;
				}
			}
				break;
			}
			if(t+k[i].l>s){
				if(t+k[i].l-s<s-t){
					t+=k[i].l;
					p[++l1]=t;
					t=0;
					continue;
				}
				else{
					p[++l1]=t;
					t=k[i].l;
					continue;
				}
			}
			t+=k[i].l;
		}
		sort(p+1,p+1+l1,cmp2);
		ans1=p[m];
		
		memset(p,0,sizeof(p));
		 s=0;
		for(int i=1;i<=n;i++){
			s+=k[i].l;
		}
		s/=m;
		 t=0;
		 l1=0;
		for(int i=n;i>=1;i--){
			if(i==1){
			if(t+k[i].l>s){
				if(t+k[i].l-s<s-t){
					t+=k[i].l;
					p[++l1]=t;
					t=0;
				}
				else{
					p[++l1]=t;
					t=k[i].l;
					p[++l1]=t;
				}
			}
				break;
			}
			if(t+k[i].l>s){
				if(t+k[i].l-s<s-t){
					t+=k[i].l;
					p[++l1]=t;
					t=0;
					continue;
				}
				else{
					p[++l1]=t;
					t=k[i].l;
					continue;
				}
			}
			t+=k[i].l;
		}
		sort(p+1,p+1+l1,cmp2);
		ans2=p[m];
		cout<<max(ans1,ans2)<<endl;
		return 0;
	}
	cout<<u<<endl;
	return 0;
}