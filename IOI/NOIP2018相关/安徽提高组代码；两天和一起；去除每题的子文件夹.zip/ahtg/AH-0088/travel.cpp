#include<cstdio>
#include<cstring>
#include<set>
#include<algorithm>
using namespace std;
const int N=5005,M=10005,INF=0x3f3f3f3f;
int n,m,u,v,tot,top,ind;
bool done;
int fr[N],nxt[M],em[M],ans[N],dfn[N],low[N],st[N],now[N];
set<int>s[N];
bool vis[N],sy[N];
inline void addedge(int u,int v,int i)
{
	nxt[i]=fr[u];
	fr[u]=i;
	em[i]=v;
}
inline void dfs1(int d,int fa)
{
	ans[++tot]=d;
	s[d].clear();
	for(int j=fr[d];j!=0;j=nxt[j])
		if(em[j]!=fa)
			s[d].insert(em[j]);
	for(set<int>::iterator it=s[d].begin(),ss=s[d].end();it!=ss;it++)
		dfs1(*it,d);
}
inline void tarjan(int d,int fro)
{
	vis[d]=1;
	st[++top]=d;
	low[d]=dfn[d]=++ind;
	for(int j=fr[d];j!=0;j=nxt[j])
		if((j^1)!=fro)
		{
			if(vis[em[j]]==0)
			{
				tarjan(em[j],j);
				low[d]=min(low[d],low[em[j]]);
			}
			else
				low[d]=min(low[d],dfn[em[j]]);
		}
	if(dfn[d]==low[d])
	{
		if(st[top]==d)
		{
			top--;
			return;
		}
		while(1)
		{
			sy[st[top]]=1;
			top--;
			if(st[top+1]==d)
				break;
		}
	}
}
inline void dfs2(int d,int fa)
{
	vis[d]=1;
	ans[++tot]=d;
	if(sy[d])
	{
		if(done==0)
		{
			s[d].clear();
			int noh=0;
			for(int j=fr[d];j!=0;j=nxt[j])
				if(vis[em[j]]==0)
				{
					s[d].insert(em[j]);
					if(sy[em[j]])
					{
						if(noh==0)
							noh=em[j];
						else
							noh=min(noh,em[j]);
					}
				}
			if(done==0&&noh>now[d])
			{
				for(set<int>::iterator it=s[d].begin(),ss=s[d].end();it!=ss;it++)
					if(!sy[*it])
						dfs1(*it,d);
				s[d].clear();
				done=1;
				return;
			}
			else
				for(set<int>::iterator it=s[d].begin(),ss=s[d].end();it!=ss;it++)
				{
					if(sy[*it])
					{
						set<int>::iterator ee=it;
						ee++;
						if(ee==s[d].end())
							now[*it]=now[fa];
						else
							now[*it]=*ee;
						dfs2(*it,d);
					}
					else
						dfs1(*it,d);
				}
			s[d].clear();
		}
		else
		{
			s[d].clear();
			for(int j=fr[d];j!=0;j=nxt[j])
				if(vis[em[j]]==0)
					s[d].insert(em[j]);
			for(set<int>::iterator it=s[d].begin(),ss=s[d].end();it!=ss;it++)
			{
				if(sy[*it])
				{
					now[*it]=INF;
					dfs2(*it,d);
				}
				else
					dfs1(*it,d);
			}
			s[d].clear();
		}
	}
	else
	{
		s[d].clear();
		for(int j=fr[d];j!=0;j=nxt[j])
			if(em[j]!=fa)
				s[d].insert(em[j]);
		for(set<int>::iterator it=s[d].begin(),ss=s[d].end();it!=ss;it++)
		{
			if(sy[*it])
			{
				now[*it]=INF;
				now[d]=INF;
			}
			dfs2(*it,d);
		}
		s[d].clear();
	}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		addedge(u,v,i*2);
		addedge(v,u,i*2+1);
	}
	if(m==n-1)
	{
		dfs1(1,-1);
		for(int i=1;i<n;i++)
			printf("%d ",ans[i]);
		printf("%d\n",ans[n]);
		return 0;
	}
	else
	{
		tarjan(1,-1);
		memset(vis,0,sizeof(vis));
		dfs2(1,-1);
		for(int i=1;i<n;i++)
			printf("%d ",ans[i]);
		printf("%d\n",ans[n]);
		return 0;
	}
	return 0;
}
