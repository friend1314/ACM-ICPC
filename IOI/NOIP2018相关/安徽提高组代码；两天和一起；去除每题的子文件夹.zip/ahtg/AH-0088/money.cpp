#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=105,M=25005;
int T,n,ans;
int a[N];
bool f[M];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		memset(f,0,sizeof(f));
		f[0]=1;
		ans=0;
		for(int i=1;i<=n;i++)
		{
			if(f[a[i]])
				continue;
			ans++;
			for(int j=a[i];j<=a[n];j++)
				f[j]=f[j]||f[j-a[i]];
		}
		printf("%d\n",ans);
	}
	return 0;
}
