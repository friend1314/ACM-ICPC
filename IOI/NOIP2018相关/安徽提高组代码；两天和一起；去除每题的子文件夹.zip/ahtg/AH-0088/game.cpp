#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=15,md=1000000007;
int n,m,ans,tot;
int x[7][7],now[N],rg[N];
struct node
{
	int a[N],b[N];
}nm[N*N];
bool cmp(node a,node b)
{
	for(int i=1;i<=n+n-2;i++)
		if(a.a[i]!=b.a[i])
			return a.a[i]<b.a[i];
	return false;
}
inline void work(int i,int j)
{
	if(i==n&&j==n)
	{
		++tot;
		for(int i=1;i<=n+n-2;i++)
		{
			nm[tot].a[i]=now[i];
			nm[tot].b[i]=rg[i];
		}
		return;
	}
	if(i<n)
	{
		now[i+j-1]=0;
		rg[i+j-1]=x[i+1][j];
		work(i+1,j);
	}
	if(j<n)
	{
		now[i+j-1]=1;
		rg[i+j-1]=x[i][j+1];
		work(i,j+1);
	}
}
inline bool re(int a,int b)
{
	for(int i=1;i<=n+n-2;i++)
		if(nm[a].b[i]!=nm[b].b[i])
			return nm[a].b[i]>nm[b].b[i];
	return false;
}
inline void ok()
{
	tot=0;
	work(1,1);
	bool fe=1;
	sort(nm+1,nm+1+tot,cmp);
	for(int i=1;i<tot;i++)
		if(re(i,i+1))
		{
			fe=0;
			break;
		}
	if(fe)
		ans++;
}
inline void dfs(int i,int j)
{
	if(i>n)
	{
		ok();
		return;
	}
	x[i][j]=0;
	if(j==n)
		dfs(i+1,1);
	else
		dfs(i,j+1);
	x[i][j]=1;
	if(j==n)
		dfs(i+1,1);
	else
		dfs(i,j+1);
}
inline int pow_er(int a,int b)
{
	int ans=1,e=a;
	while(b>0)
	{
		if(b&1)
			ans=(ll)ans*e%md;
		e=(ll)e*e%md;
		b>>=1;
	}
	return ans;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m<n)
		swap(n,m);
	if(n==1)
	{
		printf("%d\n",pow_er(2,m));
		return 0;
	}
	if(n<=3)
	{
		dfs(1,1);
		printf("%lld\n",(ll)ans*pow_er(3,m-n)%md);
		return 0;
	}
	return 0;
}
