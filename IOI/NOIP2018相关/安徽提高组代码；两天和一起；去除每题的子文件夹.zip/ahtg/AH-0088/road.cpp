#include<cstdio>
const int N=100005;
int n,top,ans;
int a[N],st[N];
inline void get(int &a)
{
	char c=getchar();
	a=0;
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())
		a=a*10+c-'0';
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	get(n);
	for(int i=1;i<=n;i++)
		get(a[i]);
	for(int i=1;i<=n;i++)
	{
		while(top>0&&st[top-1]>a[i])
		{
			ans+=st[top]-st[top-1];
			top--;
		}
		if(top>0&&st[top]>a[i])
		{
			ans+=st[top]-a[i];
			top--;
		}
		if(st[top]<a[i])
			st[++top]=a[i];
	}
	while(top>0)
	{
		ans+=st[top]-st[top-1];
		top--;
	}
	printf("%d\n",ans);
	return 0;
}
