#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
const int N=50005,M=100005;
int n,m,mxe,l,r,mid;
int fr[N],nxt[M],em[M],w[M],dis[N],u[N],v[N],ww[N],mxg[N],f[N];
vector<int>mxw[N];
inline void addedge(int u,int v,int ww,int i)
{
	nxt[i]=fr[u];
	fr[u]=i;
	em[i]=v;
	w[i]=ww;
}
inline void get(int &a)
{
	char c=getchar();
	a=0;
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())
		a=a*10+c-'0';
}
inline void dfs0(int d,int fa)
{
	if(dis[d]>dis[mxe])
		mxe=d;
	for(int j=fr[d];j!=0;j=nxt[j])
		if(em[j]!=fa)
		{
			dis[em[j]]=dis[d]+w[j];
			dfs0(em[j],d);
		}
}
bool ok3()
{
	int ans=0;
	int e=m*2-n+1;
	if(e>0)
	{
		for(int i=n-e;i<n;i++)
			if(ww[i]>=mid)
				ans++;
			else
				break;
	}
	else
		e=0;
	for(int i=n-e-1,j=1;j<i;i--)
	{
		if(ww[i]>=mid)
		{
			ans++;
			continue;
		}
		while(j<i&&ww[j]+ww[i]<mid)
			j++;
		if(j>=i)
			break;
		j++;
		ans++;
	}
	return ans>=m;
}
inline bool ok4()
{
	int ans=0,now=0;
	for(int i=1;i<n;i++)
	{
		now+=ww[i];
		if(now>=mid)
		{
			ans++;
			now=0;
		}
	}
	return ans>=m;
}
inline void dfs(int d,int fa)
{
	mxw[d].clear();
	mxg[d]=0;
	int mxdo=0;
	f[d]=0;
	for(int j=fr[d];j!=0;j=nxt[j])
		if(em[j]!=fa)
		{
			dfs(em[j],d);
			mxw[d].push_back(mxg[em[j]]+w[j]);
			f[d]+=f[em[j]];
		}
	sort(mxw[d].begin(),mxw[d].end());
	for(int i=mxw[d].size()-1,j=0;i>=0;i--)
	{
		if(mxw[d][i]>=mid)
		{
			f[d]++;
			continue;
		}
		while(j<i&&mxw[d][j]+mxw[d][i]<mid)
		{
			mxdo=mxw[d][j];
			j++;
		}
		if(j>=i)
		{
			mxdo=mxw[d][i];
			break;
		}
		f[d]++;
		j++;
		if(j==i)
			break;
	}
	mxw[d].clear();
	mxg[d]=max(mxg[d],mxdo);
}
inline bool ok()
{
	dfs(1,-1);
	return f[1]>=m;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	get(n);get(m);
	bool ok1=1,ok2=1;
	for(int i=1;i<n;i++)
	{
		get(u[i]);get(v[i]);get(ww[i]);
		addedge(u[i],v[i],ww[i],i*2);
		addedge(v[i],u[i],ww[i],i*2+1);
		if(u[i]!=1)
			ok1=0;
		if(v[i]!=u[i]+1)
			ok2=0;
	}
	if(m==1)
	{
		dfs0(1,-1);
		dis[mxe]=0;
		int ro=mxe;
		mxe=0;
		dfs0(ro,-1);
		printf("%d\n",dis[mxe]);
		return 0;
	}
	if(ok1)
	{
		sort(ww+1,ww+n);
		l=1,r=500000000;
		while(l<=r)
		{
			mid=(l+r)>>1;
			if(ok3())
				l=mid+1;
			else
				r=mid-1;
		}
		printf("%d\n",l-1);
		return 0;
	}
	if(ok2)
	{
		l=1,r=500000000;
		while(l<=r)
		{
			mid=(l+r)>>1;
			if(ok4())
				l=mid+1;
			else
				r=mid-1;
		}
		printf("%d\n",l-1);
		return 0;
	}
	l=1,r=500000000;
	while(l<=r)
	{
		mid=(l+r)>>1;
		if(ok())
			l=mid+1;
		else
			r=mid-1;
	}
	printf("%d\n",l-1);
	return 0;
}
