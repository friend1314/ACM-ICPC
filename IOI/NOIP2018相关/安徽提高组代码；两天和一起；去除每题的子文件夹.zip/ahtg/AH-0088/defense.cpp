#include<cstdio>
#include<set>
#include<cstring>
using namespace std;
typedef long long ll;
const int N=100005,M=200005,K=400005,E=2005;
const ll INF=0x3f3f3f3f3f3f3f3fll;
int n,m,u,v,a,b,x,y;
char typ[3];
int c[N],fr[N],nxt[M],em[M];
ll now[K][2][2],f[E][2][2];
set<int>se[N];
inline void get(int &a)
{
	char c=getchar();
	a=0;
	for(;c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())
		a=a*10+c-'0';
}
inline void get(char *a)
{
	char c=getchar();
	int i=0;
	a[0]='\0';
	for(;!((c>='0'&&c<='9')||(c>='A'&&c<='C'));c=getchar());
	for(i=0;(c>='0'&&c<='9')||(c>='A'&&c<='C');c=getchar(),i++)
		a[i]=c;
	a[i]='\0';
}
inline void addedge(int u,int v,int i)
{
	nxt[i]=fr[u];
	fr[u]=i;
	em[i]=v;
}
#define lc (p<<1)
#define rc ((p<<1)^1)
#define mid ((l+r)>>1)
inline void update(int p)
{
	now[p][0][0]=now[p][0][1]=now[p][1][0]=now[p][1][1]=INF;
	for(int i=0;i<=1;i++)
		for(int j=0;j<=1;j++)
		{
			now[p][i][j]=min(now[p][i][j],now[lc][i][0]+now[rc][1][j]);
			now[p][i][j]=min(now[p][i][j],now[lc][i][1]+now[rc][0][j]);
			now[p][i][j]=min(now[p][i][j],now[lc][i][1]+now[rc][1][j]);
		}
}
inline void build(int p,int l,int r)
{
	if(l==r)
	{
		now[p][0][0]=0;
		now[p][1][1]=c[l];
		now[p][1][0]=now[p][0][1]=INF;
		return;
	}
	build(lc,l,mid);
	build(rc,mid+1,r);
	update(p);
}
inline void che(int p,int l,int r,int q,int x)
{
	if(l==q&&r==q)
	{
		if(x==0)
			now[p][1][1]=INF;
		else if(x==1)
			now[p][0][0]=INF;
		else
		{
			now[p][0][0]=0;
			now[p][1][1]=c[l];
		}
		return;
	}
	if(q<=mid)
		che(lc,l,mid,q,x);
	else
		che(rc,mid+1,r,q,x);
	update(p);
}
#undef lc
#undef rc
#undef mid
inline void dfs(int d,int tr,int te,int fa)
{
	if(f[d][tr][te]!=-1)
		return;
	f[d][tr][te]=INF;
	if((d==a&&x!=te)||(d==b&&y!=te))
		return;
	if(tr==1)
	{
		if(te==1)
		{
			f[d][tr][1]=c[d];
			for(int j=fr[d];j!=0;j=nxt[j])
			{
				if(em[j]==fa)
					continue;
				dfs(em[j],1,0,d);
				dfs(em[j],1,1,d);
				ll e=min(f[em[j]][1][0],f[em[j]][1][1]);
				if(e==INF)
				{
					f[d][tr][1]=INF;
					return;
				}
				f[d][tr][1]+=e;
			}
		}
		else
		{
			f[d][tr][0]=0;
			for(int j=fr[d];j!=0;j=nxt[j])
			{
				if(em[j]==fa)
					continue;
				dfs(em[j],0,0,d);
				dfs(em[j],0,1,d);
				ll e=min(f[em[j]][0][0],f[em[j]][0][1]);
				if(e==INF)
				{
					f[d][tr][0]=INF;
					return;
				}
				f[d][tr][0]+=e;
			}
		}
	}
	else
	{
		f[d][tr][te]=INF;
		if(te==0)
		{
			if(d!=1)
				return;
			f[d][tr][0]=0;
			for(int j=fr[d];j!=0;j=nxt[j])
			{
				if(em[j]==fa)
					continue;
				dfs(em[j],0,1,d);
				ll e=f[em[j]][0][1];
				if(e==INF)
				{
					f[d][tr][0]=INF;
					return;
				}
				f[d][tr][0]+=e;
			}
			/*ll s=0;
			for(int j=fr[d];j!=0;j=nxt[j])
			{
				if(em[j]==fa)
					continue;
				dfs(em[j],0,0,d);
				dfs(em[j],0,1,d);
				ll e=min(f[em[j]][0][0],f[em[j]][0][1]);
				if(e==INF)
				{
					f[d][tr][0]=INF;
					return;
				}
				s+=e;
			}
			for(int j=fr[d];j!=0;j=nxt[j])
			{
				if(em[j]==fa)
					continue;
				ll e=min(f[em[j]][0][0],f[em[j]][0][1]);
				f[d][tr][0]=min(f[d][tr][0],s-e+f[em[j]][0][1]);
			}*/
		}
		else
		{
			f[d][tr][1]=c[d];
			for(int j=fr[d];j!=0;j=nxt[j])
			{
				if(em[j]==fa)
					continue;
				dfs(em[j],1,0,d);
				dfs(em[j],1,1,d);
				ll e=min(f[em[j]][1][0],f[em[j]][1][1]);
				if(e==INF)
				{
					f[d][tr][1]=INF;
					return;
				}
				f[d][tr][1]+=e;
			}
		}
	}
}
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	get(n);get(m);get(typ);
	for(int i=1;i<=n;i++)
		get(c[i]);
	for(int i=1;i<n;i++)
	{
		get(u);get(v);
		addedge(u,v,i*2);
		addedge(v,u,i*2+1);
		se[u].insert(v);
		se[v].insert(u);
	}
	if(typ[0]=='A')
	{
		build(1,1,n);
		for(int i=1;i<=m;i++)
		{
			get(a);get(x);get(b);get(y);
			che(1,1,n,a,x);
			che(1,1,n,b,y);
			ll ans=INF;
			for(int j=0;j<=1;j++)
				for(int k=0;k<=1;k++)
					ans=min(ans,now[1][j][k]);
			if(ans==INF)
				printf("-1\n");
			else
				printf("%lld\n",ans);
			che(1,1,n,a,2);
			che(1,1,n,b,2);
		}
		return 0;
	}
	if(n<=2000&&m<=2000)
	{
		while(m--)
		{
			get(a);get(x);get(b);get(y);
			memset(f,-1,sizeof(f));
			dfs(1,0,0,-1);
			dfs(1,0,1,-1);
			ll ans=min(f[1][0][0],f[1][0][1]);
			if(ans==INF)
				printf("-1\n");
			else
				printf("%lld\n",ans);
		}
		return 0;
	}
	return 0;
}
