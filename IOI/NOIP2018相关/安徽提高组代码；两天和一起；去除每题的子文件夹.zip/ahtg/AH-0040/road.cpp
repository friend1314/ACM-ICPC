#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int n;
int a[100005];
int solve(int l,int r) {
	if(l>r) return 0;
	if(l==r) return a[l];
	int m=a[l],last=l,tmp=0;
	for(int i=l+1;i<=r;i++) m=min(m,a[i]);
	for(int i=l;i<=r;i++) a[i]-=m;
	for(int i=l;i<=r;i++)
		if(a[i]==0) {
			tmp+=solve(last,i-1);
			last=i+1;
		}
	if(a[r]!=0) tmp+=solve(last,r);
	return tmp+m;
}
int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	a[n+1]=0;
	cout<<solve(1,n)<<endl;
	return 0;
}
