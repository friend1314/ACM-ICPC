#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[105],dic[105],r;
int solve(int i,int m,int cn,int x) {
	if(cn==x) return 1;
	if(i>m) return 0;
	int tmp=0;
	for(int s=0;cn+dic[i]*s<=x;s++) {
		tmp+=solve(i+1,m,cn+dic[i]*s,x);
		if(tmp) return tmp;
	}
	return tmp;
}
void w(int n) {
	dic[++r]=a[1];
	for(int i=2;i<=n;i++) 
		if(!solve(1,r,0,a[i])) dic[++r]=a[i];
	cout<<r<<endl;
}
int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T,n;
	scanf("%d",&T);
	while(T--) {
		scanf("%d",&n);
		r=0;
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		w(n);
	}
	return 0;
}
