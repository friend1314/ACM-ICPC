#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <cstring>
using namespace std;
string type;
int n,m,t;
const int N = 400005;
int Head[N],Next[N],Adj[N],W[N];
int f[N],choice[N];
void Add(int u,int v) {
	Next[++t]=Head[u];Head[u]=t;Adj[t]=v;
	Next[++t]=Head[v];Head[v]=t;Adj[t]=u;
}
int main() {
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d",&n,&m);
	cin>>type;
	for(int i=1;i<=n;i++) scanf("%d",&W[i]);
	for(int i=1;i<n;i++) {
		int a,b;
		scanf("%d%d",&a,&b);
		Add(a,b);
	}
	for(int i=1;i<=m;i++) {
		int a,x,b,y;
		scanf("%d%d%d%d",&a,&x,&b,&y);
		memset(choice,-1,sizeof(choice));
		choice[a]=x;
		choice[b]=y;
		int q=1;
		for(int i=1;i<=n;i++) {
			int p=0;
			for(int h=Head[i];h;h=Next[h]) {
				int v=Adj[h];
				if(choice[v]!=0) {p=1;break;}
			}
			if(choice[i]!=0) p=1;
			if(p==0) {q=0;break;}
		}
		if(q==0) cout<<-1<<endl;
		else cout<<W[a]+W[b]<<endl;
	}
	return 0;
}
