#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <vector>
#include <string>
using namespace std;
const int N = 20005;
int n,m,t;
int Head[N],Next[N],Adj[N],ans[N],ck,lng;
int el[N],Q[N],dfn,stop[N],vis[N],Deg[N];
vector<int> XL[N];
bool cmp(int i,int j) {
	for(int k=0;k<n;k++)
		if(XL[i][k]!=XL[j][k]) {
			if(XL[i][k]>XL[j][k]) return true;
			else return false;
		}
	return false;
}
void Add(int u,int v) {
	Next[++t]=Head[u];Head[u]=t;Adj[t]=v;
	Next[++t]=Head[v];Head[v]=t;Adj[t]=u;
}
void dfs(int u,int f) {
	ans[++ck]=u;
	vector<int> es;
	int r=0;
	for(int i=Head[u];i;i=Next[i]) {
		int v=Adj[i];
		if(v!=f) {es.push_back(v);r++;}
	}
	sort(es.begin(),es.end());
	for(int i=0;i<r;i++) dfs(es[i],u);
}
void Sdfs(int u,int f,int k) {
	XL[k].push_back(u);
	vector<int> es;
	int r=0;
	for(int i=Head[u];i;i=Next[i]) {
		int v=Adj[i];
		if(v!=f && v!=stop[u]) {es.push_back(v);r++;}
	}
	sort(es.begin(),es.end());
	for(int i=0;i<r;i++) Sdfs(es[i],u,k);
}
void erl(int u,int f,int x) {
	if(u==x && vis[u]==1) {
		for(int i=1;i<=dfn;i++) Q[i]=el[i];
		lng=dfn;
		return ;
	}
	vis[u]=1;
	for(int i=Head[u];i;i=Next[i]) {
		int v=Adj[i];
		if(v==f) continue;
		if(v!=x && vis[v]) continue;
		el[++dfn]=v;
		erl(v,u,x);
		dfn--;
	}
}
int main() {
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++) {
		int a,b;
		scanf("%d%d",&a,&b);
		Add(a,b);
		Deg[a]++;
		Deg[b]++;
	}
	if(n-m==1) {
		dfs(1,0);
		for(int i=1;i<=ck;i++) cout<<ans[i]<<" ";cout<<endl;
	}
	else {
		int p=1;
		for(int i=1;i<=n;i++) if(Deg[i]!=2) {p=0;break;}
		if(p==1) {
			int v1,v2;
			v1=Adj[Head[1]];
			v2=Adj[Next[Head[1]]];
			if(v1>v2) {
				stop[1]=v1;
				stop[v1]=1;
			}
			else {
				stop[1]=v2;
				stop[v2]=1;
			}
			Sdfs(1,0,1);
			for(int i=0;i<n;i++) cout<<XL[1][i]<<" ";cout<<endl;
			return 0;
		}
		for(int i=1;i<=n;i++) {
			memset(vis,0,sizeof(vis));
			dfn=1;
			lng=0;
			el[1]=i;
			erl(i,0,i);
			if(lng!=0) break;
		}
		stop[Q[1]]=Q[2];
		stop[Q[2]]=Q[1];
		for(int i=1;i<lng;i++) {
			Sdfs(1,0,i);
			stop[Q[i]]=0;
			stop[Q[i+1]]=Q[i+2];
			stop[Q[i+2]]=Q[i+1];
		}
		int an=1;
		for(int i=2;i<lng;i++) 
			if(cmp(an,i)) an=i;
		for(int i=0;i<n;i++) cout<<XL[an][i]<<" ";cout<<endl;
	}
	return 0;
}
