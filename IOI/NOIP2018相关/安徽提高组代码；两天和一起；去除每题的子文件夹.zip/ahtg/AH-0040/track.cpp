#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
const int N = 2000005;
int Next[N],Head[N],Adj[N],W[N],t;
int Size[N],Son[N],Deep[N],Top[N],Fa[N];
void Add(int u,int v,int x) {
	Next[++t]=Head[u];Head[u]=t;Adj[t]=v;W[t]=x;
	Next[++t]=Head[v];Head[v]=t;Adj[t]=u;W[t]=x;
}
void dfs1(int u,int f) {
	Son[u]=-1;Size[u]=1;Fa[u]=f;
	for(int i=Head[u];i;i=Next[i]) {
		int v=Adj[i];
		if(v==Fa[u]) continue;
		Deep[v]=Deep[u]+W[i];
		dfs1(v,u);
		Size[u]+=Size[v];
		if(Son[u]==-1 || Size[v]>Size[Son[u]]) Son[u]=v;
	}
}
void dfs2(int u,int tp) {
	Top[u]=tp;
	if(Son[u]!=-1) dfs2(Son[u],tp);
	for(int i=Head[u];i;i=Next[i]) {
		int v=Adj[i];
		if(v!=Son[u] && v!=Fa[u]) dfs2(v,v);
	}
}
int LCA(int u,int v) {
	while(Top[u]!=Top[v])
		if(Deep[Top[u]]<Deep[Top[v]]) v=Fa[Top[v]];
		else u=Fa[Top[u]];
	return Deep[u]<Deep[v] ? u : v;
}
int main() {
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,k,ans=0,s=0;
	scanf("%d%d",&n,&k);
	for(int i=1;i<n;i++) {
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		Add(a,b,c);
		s+=c;
	}
	Deep[1]=0;
	dfs1(1,0);
	dfs2(1,1);
	for(int i=1;i<=n;i++)
	    for(int j=i+1;j<=n;j++) 
			ans=max(ans,Deep[i]+Deep[j]-2*Deep[LCA(i,j)]);
	if(k==1) cout<<ans<<endl;
	else cout<<s/k<<endl;
	return 0;
}
