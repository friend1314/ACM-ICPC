#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;
inline int read()
{
	char ch=getchar();
	int x=0,f=1;
	while (ch>'9'|| ch<'0')
	{
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0' && ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int a[N],f[N];
int i,j,k,t,m,n,maxx=0,ans;
int main()
{
	freopen ("money.in","r",stdin);
	freopen ("money.out","w",stdout);
	t=read();
	while (t)
	{
		t--;
		n=read();
		maxx=0;
		for (int i=1;i<=n;i++) a[i]=read();
		memset(f,0,sizeof(f));
		sort(a+1,a+1+n);
		f[0]=1;
		ans=n;
		for (int i=1;i<=n;i++)
		{	
			if (f[a[i]]==1) ans--;
			for (int j=a[i];j<=25000;j++) f[j]=max(f[j],f[j]|f[j-a[i]]);
		}
		printf("%d\n",ans);
	}
	return 0;
}