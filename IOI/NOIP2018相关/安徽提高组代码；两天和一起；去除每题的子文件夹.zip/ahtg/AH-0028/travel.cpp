#include <bits/stdc++.h>
using namespace std;
const int N=1e5+10;
struct EDGE
{
	int nex,to;
}edge[N<<1];
struct node
{
	int num,f;
} g[5001][1001];
int ij,k,t[N],m,n,res;
int head[N<<1],cnt,tot,tal[N];
inline void add(int x,int y)
{
	edge[++cnt].to=y;
	edge[cnt].nex=head[x];
	head[x]=cnt;
}
inline bool cmp(node x,node y)
{
	return x.num<y.num;
}
inline void dfs(int now,int fa)
{
	tot=0;
	for (int i=head[now];i;i=edge[i].nex) if (edge[i].to!=fa)
	{
		g[now][++tot].num=edge[i].to;
		g[now][tot].f=fa;
	}
	sort(g[now]+1,g[now]+1+tot,cmp);
	tal[now]=tot;
	for (int i=1;i<=tal[now];i++) 
	{
		dfs(g[now][i].num,now);
	}
}
inline void dfs2(int now,int fa)
{
	printf("%d ",now);
	for (int i=1;i<=tal[now];i++)
	{
		dfs2(g[now][i].num,now);
	}
}
bool b=true;
bool bb[N];
inline void dfs3(int now,int fa)
{
	if (!bb[now]) return;
	printf("%d ",now);
	bb[now]=false;
	if (now==1 && b)
	{
		for (int i=head[1];i;i=edge[i].nex)
		{
			t[++res]=edge[i].to;
		}
		sort(t+1,t+1+res);
		for (int i=1;i<=res;i++) if (bb[t[i]]) dfs3(t[i],now);
	}
	for (int i=head[now];i;i=edge[i].nex) if (edge[i].to!=fa)
	{
		if (edge[i].to>t[2] && b) b=false,dfs3(t[2],1);
		else dfs3(edge[i].to,now);
	}
}
inline int read()
{
	char ch=getchar();
	int x=0,f=1;
	while (ch>'9' || ch<'0')
	{
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0' && ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int main()
{
	freopen ("travel.in","r",stdin);
	freopen ("travel.out","w",stdout);
	n=read();
	m=read();
	for (int i=1;i<=m;i++) 
	{
		int x=read(),y=read();
		add(x,y);
		add(y,x);
	}
	if (m==n-1)
	{
		dfs(1,0);
		dfs2(1,0);		
	}
	else if (n<=1000)
	{
		memset(bb,1,sizeof(bb));
		dfs3(1,0);
	}
	return 0;
}