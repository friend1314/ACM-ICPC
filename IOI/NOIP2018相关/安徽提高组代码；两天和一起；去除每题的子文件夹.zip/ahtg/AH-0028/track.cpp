#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;
int i,j,k,t,m,n,ans,res;
int x[N],y[N],z[N];
inline int read()
{
	char ch=getchar();
	int x=0,f=1;
	while (ch>'9'|| ch<'0')
	{
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0' && ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
struct node
{
	int nex,to,w;
}edge[N<<1];
int cnt,head[N<<1];
inline void add(int x,int y,int z)
{
	edge[++cnt].to=y;
	edge[cnt].nex=head[x];
	edge[cnt].w=z;
	head[x]=cnt;
}
inline void dfs(int k,int fa)
{
	ans=max(ans,res);
	for (int i=head[k];i;i=edge[i].nex)
	{
		if (edge[i].to!=fa) 
		{
			res+=edge[i].w;
			dfs(edge[i].to,k);
			res-=edge[i].w;
		}
	}
}
int main()
{
	freopen ("track.in","r",stdin);
	freopen ("track.out","w",stdout);
	n=read();
	m=read();
	x[i]=read(),y[i]=read(),z[i]=read();
	add(y[i],x[i],z[i]);
	add(x[i],y[i],z[i]);
	for (int i=2;i<n;i++)
	{
		x[i]=read(),y[i]=read(),z[i]=read();
		add(x[i],y[i],z[i]);
		add(y[i],x[i],z[i]);
	}
	for (int i=1;i<=n;i++) 
	{
		res=0;
		dfs(i,0);
	}
	printf("%d",ans);
	return 0;
}