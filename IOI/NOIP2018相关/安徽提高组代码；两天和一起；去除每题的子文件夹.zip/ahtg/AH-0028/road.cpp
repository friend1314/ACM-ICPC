#include <bits/stdc++.h>
using namespace std;
const int N=(1e5+10)*2;
const int inf=0x7fffffff;
inline int read()
{
	char ch=getchar();
	int x=0,f=1;
	while (ch>'9'|| ch<'0')
	{
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0' && ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int a[N],pos[N][301];
int i,j,k,t,m,n,maxx=inf,cnt=0,tot=1;
long long ans=0;
inline void work(int l,int r,int t)
{
	if (l>r) return;
	tot++;
	int maxx=inf,cnt=0;
	for (int i=l;i<=r;i++)
	{
		if (a[i]<=maxx)
		{
			if (a[i]<maxx) cnt=0;
			pos[++cnt][t]=i;
			maxx=a[i];
		}
	}
	for (int i=l;i<=r;i++) a[i]-=maxx;
	ans+=maxx;
	pos[cnt+1][t]=r+1;
	pos[0][t]=l-1;
	for (int i=1;i<=cnt;i++)
	{
		work(pos[i-1][t]+1,pos[i][t]-1,t+1);
	}
	work(pos[cnt][t]+1,r,t+1);
	return;
}
int main()
{
	freopen ("road.in","r",stdin);
	freopen ("road.out","w",stdout);
	n=read();
	for (int i=1;i<=n;i++) 
	{
		a[i]=read();
	}
	work(1,n,1);
	printf("%lld",ans);
	return 0;
}