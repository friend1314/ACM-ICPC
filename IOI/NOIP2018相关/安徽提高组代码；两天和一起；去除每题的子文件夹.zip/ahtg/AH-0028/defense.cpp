#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;
const int inf=0x7fffffff;
inline int read()
{
	char ch=getchar();
	int x=0,f=1;
	while (ch>'9' || ch<'0')
	{
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0' && ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return x*f;
}
int i,j,k,t,m,n;
int head[N<<1],cnt,ans=inf,res,p[N];
struct EDGE
{
	int nex,to;
}edge[N<<1];
inline void add(int x,int y)
{
	edge[++cnt].to=y;
	edge[cnt].nex=head[x];
	head[x]=cnt;
}
char s[10];
int a,bb,x,y;
bool b[N],st;
inline void check(int now,int fa)
{
	for (int i=head[now];i;i=edge[i].nex) if (edge[i].to!=fa)
	{
		if (!b[fa] && !b[edge[i].to] && !b[now]){ st=false;return ;}
		int tot=0;
		for (int j=head[now];j;j=edge[j].nex) tot++;
        if (tot==1 && !b[fa] && !b[now] && now!=1) { st=false;return ;}
		else if (now==a && x==1 && !b[now]) { st=false;return ;}
		else if (now==a && x==0 && b[now]) { st=false;return ;}
		else if (now==bb && y==1 && !b[now]) { st=false;return ;}
		else if (now==bb && y==0 && b[now]){ st=false;return ;}
		else check(edge[i].to,now);
	}
}
inline void dfs(int k)
{
	if (k>n)
	{
		st=true;
		check(1,0);
		if (st) 
		{
			res=0;
		//	for (int i=1;i<=n;i++) printf("%d ",b[i]);
		//	printf("\n");
			for (int i=1;i<=n;i++) if (b[i]) res+=p[i];
		//		printf("%d q\n",res);
			ans=min(ans,res);
			return;
		}
		else 
		{
			return;
		}		
	}

	b[k]=true;
	dfs(k+1);
	b[k]=false;
	dfs(k+1);
}
int main()
{
	freopen ("defense.in","r",stdin);
	freopen ("defense.out","w",stdout);
	n=read();m=read();
	scanf("%s",s);
	for (int i=1;i<=n;i++) p[i]=read();
	for (int i=1;i<n;i++) 
	{
		x=read();
		y=read();
		add(x,y);
		add(y,x);
	}
	for (int i=1;i<=m;i++)
	{
		ans=inf;
		memset(b,false,sizeof(b));
		a=read();
		x=read();
		bb=read();
		y=read();
		dfs(1);
		if (ans==inf) ans=-1;
		printf("%d\n",ans);
	}
	return 0;
}