#include<stdio.h>
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	n=9
	scanf("%d"n);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

