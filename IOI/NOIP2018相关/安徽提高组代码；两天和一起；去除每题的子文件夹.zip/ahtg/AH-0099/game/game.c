#include<stdio.h>
long long b[1][1000000];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long m,n,i;
	scanf("%lld %lld",&n,&m);
	long long a[10][10];
	a[0][0]=0;
	a[0][1]=0;
	a[0][2]=0;
	a[0][3]=0;
	a[1][0]=0;
	a[1][1]=2;
	a[1][2]=4;
	a[1][3]=8;
	a[2][1]=4;
	a[2][2]=12;
	a[2][3]=36;
	a[3][1]=8;
	a[3][2]=48;
	a[3][3]=112;
	a[5][5]=7136;
	b[1][0]=2;
	a[5][5]=7136;
	for(i=1;i<m;i++)
	{
		
		b[1][i]=b[1][i-1]*2%100000007;
	}
	if(n<=3&&m<=3)
		printf("%lld",a[n][m]);
	if(n<=3&&m>3)
		printf("%lld",b[1][m-1]);
	if(n==5)
		printf("%lld",a[5][5]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
