#include<stdio.h>
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int n=2,m=5;
	printf("%d",n);
	printf("\n");
	printf("%d",m);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
