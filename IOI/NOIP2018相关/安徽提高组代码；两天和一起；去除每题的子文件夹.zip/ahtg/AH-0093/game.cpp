#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int MOD=1e9+7;
int n,m;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==1) {printf("1");return 0;}
	if(m==1) {printf("1");return 0;}
	if(n==2){
		if(m==2) {printf("12");return 0;}
		int f[1000005][2];
		f[1][0]=2;f[1][1]=2;
		int ans=1;
		for(int i=2;i<=m;i++){
			f[i][0]=(f[i][0]*2-f[i-1][1]+MOD)%MOD;
			f[i][1]=(f[i][0]*2+f[i-1][1]*2)%MOD;
		}
		printf("%d",(f[m][0]+f[m][1])%MOD);
		return 0;
	}
	if(n==m){
		int a1=1,ans=1,a2,a3;
		for(int i=1;i<=n;i++) a1*=2;
		a2=(n*n-n)/2;
		a3=a2*a2-n;
		for(int i=1;i<=n*2-3;i++) ans*=2;
		ans=a1*(ans+a3);
		printf("%d",ans);
	}
	return 0;
}