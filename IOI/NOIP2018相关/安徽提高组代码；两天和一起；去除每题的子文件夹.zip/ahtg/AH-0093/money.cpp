#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
int T;
int n,a[10];
int yz[10][10];
int gcd(int a,int b)
{
	if(b==0) return a;
	else return gcd(b,a%b);
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
		if(n==2){
			int x=gcd(max(a[1],a[2]),min(a[1],a[2]));
			int y=min(a[1],a[2]);
			if(x==1) printf("2\n");
			else if(x==y) printf("1\n");
			else printf("1\n");
		}
		else{
			memset(yz,0,sizeof(yz));
			bool s1=0;
			for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++){
			yz[i][j]=gcd(max(a[i],a[j]),min(a[i],a[j]));
			if(i!=j&&yz[i][j]!=1) {s1=1;}
			}
			if(s1) printf("%d\n",n+1);
			else{
				printf("%d\n",n-1);
			}
		}
	}
	return 0;
}
//money