#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
/**/struct node
{
	int l,r;
	int minn;
}a[50005];
int n;
int d[100005];
int c[10005],k[100005];
int ans=0,last,t;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&d[i]);
		t=max(t,d[i]);
	}
	int ll=1,rr=n;
	while(d[ll]==0&&ll<=n) ll++;
	if(ll==n+1) {printf("0");return 0;}
	while(d[rr]==0) rr--;
	last=ll;
	//printf("%d %d\n",ll,rr);
	for(int i=ll+1;i<=rr+1;i++){
		if(d[i]==0&&d[i-1]!=0){
			memset(c,0,sizeof(c));
			int tmp=0,num=1;
			c[d[last]]++;
			for(int j=last+1;j<=i-1;j++){
				if(d[j]!=d[j-1]){
					c[d[j]]++;
				}
			}
			for(int j=1;j<=t;j++){
				ans+=c[j]*(j-tmp);
				if(d[j]!=0) tmp=j;
			}
		}
		if(d[i]!=0&&d[i-1]==0) last=i;
	}
	printf("%d",ans);
	return 0;
}
//road
