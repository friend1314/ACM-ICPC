#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
struct edge {int to.next,c;} g[100005];
int n,m;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v,w;
	for(int i=1;i<=n-1;i++){
		scanf("%d%d%d",&u,&v,&w);
		if(u)
	}
	return 0;
}