#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxn=5005;
struct edge {int to,next;} g[maxn*2];
int b[maxn][maxn],e[maxn];
int head[maxn],tot=0;
int n,m;
bool vis[maxn];
int t[maxn],num=0,tt[maxn];
void add(int u,int v)
{
	g[++tot].next=head[u];
	g[tot].to=v;
	head[u]=tot;
}
void dfs(int u,int fa)
{
	if(vis[u]) return;
	vis[u]=1;
	t[++num]=u;
	for(int i=1;i<=e[u];i++){
		int v=b[u][i];
		if(v==fa) continue;
		dfs(v,u);
	}
}
void dfss(int u,int fa)
{
	if(vis[u]) return;
	//if(u==-1) return;
	vis[u]=1;
	num++;
	t[num]=min(t[num],u);
	for(int i=1;i<=e[u];i++){
		int v=b[u][i];
		if(v==fa) continue;
		//if(v==-1) continue;
		dfs(v,u);
	}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for(int i=1;i<=m;i++){
		//scanf("%d%d",&b[i].tu,&b[i].tv);
		scanf("%d%d",&u,&v);
		b[u][++e[u]]=v;
		b[v][++e[v]]=u;
	}
	for(int i=1;i<=n;i++) 
	sort(b[i]+1,b[i]+1+e[i]);
/*	for(int i=1;i<=n;i++)
	for(int j=1;j<=e[i];j++){
		add()
	}*/
	if(m==n-1) dfs(1,0);
	if(m==n){
		for(int i=1;i<=n;i++) t[i]=maxn;
		vis[0]=1;
		for(int i=1;i<=n;i++){
			num=0;
			if(e[i]>1){
				int p;
				for(int k=1;k<=e[i];k++){
				if(e[b[i][k]]<=1) continue;
				for(int j=1;j<=e[b[i][k]];j++)
				if(i==b[b[i][k]][j]) {p=j;break;}
				int t1=b[i][k],t2=b[b[i][k]][p];
				b[i][k]=0;b[b[i][k]][p]=0;
				dfss(1,0);
				b[i][k]=t1;b[b[i][k]][p]=t2;
			    }
			}
		}
	}
	for(int i=1;i<=n;i++) printf("%d ",t[i]);
	return 0;
}