#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>
using namespace std;
const int maxn=100005;
struct edge {int to,next;} g[maxn*2];
int head[maxn],tot=0;
int n,m;
string c;
bool vis[maxn];
int p[maxn],minn[maxn];
void add(int u,int v)
{
	g[++tot].next=head[u];
	g[tot].to=v;
	head[u]=tot;
}
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>n>>m;cin>>c;
	for(int i=1;i<=n;i++) scanf("%d",&p[i]);
	int u,v;
/*	for(int i=1;i<=n-1;i++){
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}*/
	int a,x,b,y;
	if(c[0]=='A'){
		minn[1]=1;
		for(int i=2;i<=n;i++){
			if(p[i]>p[i-1]) minn[i]=i-1;
			else minn[i]=i;
		}
		if(c[1]=='3'){
			for(int i=1;i<=m;i++){
				scanf("%d%d%d%d",&a,&x,&b,&y);
				if(abs(a-b)==1&&x==0&&y==0) {printf("-1\n");continue;}
				int ans=0;
				for(int i=2;i<=n;i++){
					if(i==a&&x==0) ans+=min(p[i-1],p[i+1]);
					else if(i==b&&y==0) ans+=min(p[i-1],p[i+1]);
					else ans+=min(p[i],min(p[i+1],p[i-1]));	
				}
				printf("%d\n",ans);
			}
	    }
	}
	else{
		for(int i=1;i<=m;i++){
			scanf("%d%d%d%d",&a,&x,&b,&y);
			printf("-1\n");
		}
	}
	return 0;
}