#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
using namespace std;
int n,ans=0,mx=0,a[100005];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		mx=max(mx,a[i]);
	}
	int now=0,zushu=1;
	while(now<mx){
		now++;
	    for(int i=1;i<=n;i++){
		    if(a[i]==now-1&&a[i-1]>=now&&a[i+1]>=now){
			    zushu++;
		    }
			if(a[i]==now-1&&a[i-1]<now-1){
				for(int j=i+1;j>0;j++){
					if(a[j]>=now) break;
					if(a[j]<now-1){
						zushu--;
						break;
					}
				}
			}
	    }
		ans=ans+zushu;
	}
	printf("%d",ans);
}