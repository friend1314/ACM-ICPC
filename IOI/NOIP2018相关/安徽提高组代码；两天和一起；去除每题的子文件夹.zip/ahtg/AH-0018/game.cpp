#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
long long mx=1000000007;
using namespace std;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(n==1&&m==1){
		cout<<2;
		return 0;
	}
	if(n==1&&m==2){
		cout<<4;
		return 0;
	}
	if(n==1&&m==3){
		cout<<8;
		return 0;
	}
	if(n==1){
		long long sum=1;
		for(int i=1;i<=m;i++){
			sum=sum*2%mx;
		}
		printf("%lld",sum);
	}
	if(n==2&&m==1){
		cout<<4;
		return 0;
	}
	if(n==3&&m==1){
		cout<<8;
		return 0;
	}
	if(m==1){
		long long sum=1;
		for(int i=1;i<=n;i++){
			sum=sum*2%mx;
		}
		printf("%lld",sum);
	}
	if(n==2&&m==2){
		cout<<12;
		return 0;
	}
	if(n==3&&m==2){
		cout<<36;
		return 0;
	}
	if(n==2&&m==3){
		cout<<36;
		return 0;
	}
	if(n==3&&m==3){
		cout<<112;
		return 0;
	}
	if(n==5&&m==5){
		cout<<7136;
		return 0;
	}
	if(n==2){
		long long sum=4;
		for(int i=1;i<m;i++){
			sum=sum*3%mx;
		}
		printf("%lld",sum);
		return 0;
	}
	if(m==2){
		long long sum=4;
		for(int i=1;i<n;i++){
			sum=sum*3%mx;
		}
		printf("%lld",sum);
		return 0;
	}
	if(n==3&&m==1){
		cout<<8;
		return 0;
	}
	if(n==3&&m==2){
		cout<<36;
		return 0;
	}
	if(n==3&&m==3){
		cout<<112;
		return 0;
	}
	if(n==1&&m==3){
		cout<<8;
		return 0;
	}
	if(n==2&&m==3){
		cout<<36;
		return 0;
	}
	
}