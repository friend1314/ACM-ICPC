#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<queue>
using namespace std;
int t,a[105];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(int ii=1;ii<=t;ii++){
		int n;
		scanf("%d",&n);
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		if(n==2){
			if(a[1]%a[2]==0||a[2]%a[1]==0) cout<<1<<endl;
			else cout<<2<<endl;
			continue;
		}
		if(n==3){
			int tot=3;
			sort(a+1,a+4);
			if(a[2]%a[1]==0){
				tot--;
			}
			if(a[3]%a[1]==0||a[3]%a[2]==0||((a[3]%a[2])%a[1]==0)){
				tot--;
			}
			cout<<tot<<endl;
			continue;
		}
		if(n==4){
			int tot=4;
			sort(a+1,a+5);
			if(a[2]%a[1]==0){
				tot--;
			}
			if(a[3]%a[1]==0||a[3]%a[2]==0||((a[3]%a[2])%a[1]==0)){
				tot--;
			}
			if(a[4]%a[1]==0||a[4]%a[2]==0||a[4]%a[3]==0||((a[4]%a[2])%a[1]==0)||((a[4]%a[3])%a[1]==0)||((a[4]%a[3])%a[2]==0)||((a[4]%a[3])%a[2])%a[1]==0){
				tot--;
			}
			cout<<tot<<endl;
			continue;
		}
		if(n==5){
			int tot=5;
			sort(a+1,a+6);
			if(a[2]%a[1]==0){
				tot--;
			}
			if(a[3]%a[1]==0||a[3]%a[2]==0||((a[3]%a[2])%a[1]==0)){
				tot--;
			}
			if(a[4]%a[1]==0||a[4]%a[2]==0||a[4]%a[3]==0||((a[4]%a[2])%a[1]==0)||((a[4]%a[3])%a[1]==0)||((a[4]%a[3])%a[2]==0)||((a[4]%a[3])%a[2])%a[1]==0){
				tot--;
			}
			if(a[5]%a[1]==0||a[5]%a[2]==0||a[5]%a[3]==0||a[5]%a[4]==0||(a[5]%a[2])%a[1]==0||(a[5]%a[3])%a[1]==0||(a[5]%a[4])%a[1]==0||(a[5]%a[3])%a[2]==0||(a[5]%a[4])%a[2]==0||(a[5]%a[4])%a[3]==0||(((a[5]%a[4])%a[3])%a[2])%a[1]==0){
				tot--;
			}
			cout<<tot<<endl;
			continue;
		}
	}
}