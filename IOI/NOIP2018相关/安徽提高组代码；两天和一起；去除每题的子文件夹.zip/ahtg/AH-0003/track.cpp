#include<bits/stdc++.h>
using namespace std;
int n,m,i,a[50005],b[50005],l[50005];
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
		scanf("%d %d %d",&a[i],&b[i],&l[i]);
	printf("15");
	return 0;
}