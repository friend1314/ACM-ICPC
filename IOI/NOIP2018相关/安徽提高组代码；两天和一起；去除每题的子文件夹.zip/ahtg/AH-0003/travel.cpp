#include<bits/stdc++.h>
using namespace std;
int m,n,u,v,i,j,ap[5005][5005];
bool vis[5005];
void search(int a){
	for(i=a;i<=n;i++){
		for(j=1;j<=n;j++){
			if(ap[i][j]==1&&vis[j]==0){
				vis[j]=1;
				printf("%d ",j);
				search(j);
			}
		}
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	memset(ap,0,sizeof(ap));
	memset(vis,0,sizeof(vis));
	scanf("%d %d",&n,&m);
	for(i=1;i<=m;i++){
		scanf("%d %d",&u,&v);
		ap[u][v]=1;
		ap[v][u]=1;
	}
	printf("1 ");
	vis[1]=1;
	search(1);
	return 0;
}