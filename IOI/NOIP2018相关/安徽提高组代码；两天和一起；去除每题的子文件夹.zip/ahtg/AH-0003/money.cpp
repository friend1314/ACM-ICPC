#include<bits/stdc++.h>
using namespace std;
int T,n,i,a[105];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		if(n==1)	printf("1\n");
		for(i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}	
	}
	return 0;
}