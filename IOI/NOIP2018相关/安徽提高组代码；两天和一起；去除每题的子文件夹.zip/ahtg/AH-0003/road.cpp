#include<bits/stdc++.h>
using namespace std;
int n,i,ans=0,flag,mn=10005,d[100000];
void xiu( int x, int y){
		int mnn=10005,z;
		for(i=x;i<=y;i++){
			if(d[i]<mnn){
				mnn=d[i];
				z=i;
			}
		}
		while(d[z]!=0){
			for(i=x;i<=y;i++){
				d[i]--;
			}
			ans++;
		}
		for(i=x;i<=z-1;i++)
			if(d[i]!=0)	xiu(x,z-1);
		for(i=z-1;i<=y;i++)
			if(d[i]!=0)	xiu(z+1,y);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&d[i]);
		if(d[i]<mn){
			mn=d[i];
			flag=i;
		}	
	}	
	i=1;
	while(d[flag]!=0){
		for(i=1;i<=n;i++){
			d[i]--;
		}
		ans++;
	}
	xiu(1,flag-1);
	xiu(flag+1,n);
	printf("%d",ans);
	return 0;
}