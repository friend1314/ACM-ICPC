#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cout<<"12"<<endl<<"7"<<endl<<"-1"<<endl;
	return 0;
}