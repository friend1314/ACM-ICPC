#include<iostream>
#include<cstdio>
#define N 100100
using namespace std;
int top=1,n,k,sta[N];
long long num,sum;
int main()
{
        freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);
       scanf("%d",&n);
for(int i=1;i<=n;i++)
{
scanf("%d",&k);
sum+=k;
if(top&&k<=sta[top])
{
num+=k;
sta[top]=k;
}
else
{
num+=sta[top];
sta[++top]=k;
}
}
printf("%lld",sum-num);
return 0;
}