#include<iostream>
#include<cstdio>
#define N 100010
using namespace std;
int n,m,num,cost[N],flag[N],ans=0,a,b,x,y,i,t;
char ch,fl;
int main()
{
	freopen("defense.in","r",stdin);
    freopen("defense.out","w",stdout);
    scanf("%d%d ",&n,&m);
	scanf("%c%d",&fl,&num);
			for(i=1;i<=n;i++)
				scanf("%d",&cost[i]);
	for(i=1;i<=n-1;i++)
	{
		scanf("%d %d",&x,&y);
	}
	for(i=1;i<=m;i++)
	{
		scanf("%d %d %d %d",&a,&x,&b,&y);
		if(num==2)
		{
			if(x==0&&y==0)
				printf("-1\n");
					else
					{
						if(x==1)
							flag[a]=1,ans+=cost[a];
							if(y==1)
								flag[b]=1,ans+=cost[b];
								if(fl=='A')
								{
									for(t=a-1;t>0;t--)
									{
										if(1-flag[t+1]==1)
										ans+=cost[t],flag[t]=1;
									}
									for(t=b+1;t<=n;t++)
									{
										if(1-flag[t-1]==1)
											ans+=cost[t],flag[t]=1;
									}
									printf("%d\n",ans);
								}
					}
		}
	}
	return 0;
}