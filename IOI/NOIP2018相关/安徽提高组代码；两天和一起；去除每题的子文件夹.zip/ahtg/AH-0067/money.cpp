#include<iostream>
#include<cstdio>
using namespace std;
int n,a,b,T;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
scanf("%d",&T);
while(T--)
{
scanf("%d",&n);
	if(n==1)
	{scanf("%d",&a);	printf("1\n");}
if(n==2)
{
scanf("%d %d",&a,&b);
if(a>b)
swap(a,b);
if(b%a==0)
printf("1\n");
else
printf("2\n");
}

}
return 0;
}
