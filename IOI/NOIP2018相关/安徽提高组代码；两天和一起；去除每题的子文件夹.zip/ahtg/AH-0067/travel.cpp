#include<iostream>
#include<cstdio>
#define N 5010
#define inf 1000000000
using namespace std;
int n,m,i,k,next[2*N],tail[N],a[2*N],s[2*N],x,y,ln,c[N],vis[N],fl;
struct node
{
	int sum;
	int flag[N];
	int num;
}d[N];
int main()
{
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
    scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
		tail[i]=++ln;
		for(i=1;i<=n;i++)
			d[i].sum=inf;
	for(i=1;i<=m;i++)
	{
		scanf("%d %d",&x,&y);
		next[tail[x]]=++ln;
		tail[x]=ln;
		a[ln]=y;
		s[ln]=y;
		next[tail[y]]=++ln;
		tail[y]=ln;
		a[ln]=x;
		s[ln]=x;
	}
	c[1]=1;
	vis[1]=1;
	d[1].sum=0;
	int l=1;
	int r=1;
	while(l<=r)
	{
		int k=c[l];
		l++;
		for(int i=next[k];i!=0;i=next[i])
		{
			fl=0;
			if((d[k].sum+s[i])<=d[a[i]].sum)
			{
				if(d[a[i]].sum==inf)
					fl=1;	
				//printf("k=%d a[i]=%d %d\n",k,a[i],d[k].sum+s[i]);
				d[a[i]].sum=d[k].sum+s[i];
				//if(fl==1)
				   d[a[i]].num=d[k].num;d[a[i]].num++;d[a[i]].flag[d[a[i]].num]=k;
				//else
					//d[a[i]].flag[d[a[i]].num]=k;
				if(vis[a[i]]==0)
				{
					vis[a[i]]=1;
					c[++r]=a[i];
				}
			}
		    vis[k]=0;
		}
    }
	printf("%d\n",d[n].num);
	for(i=1;i<=d[n].num;i++)
	{
	printf("%d ",d[n].flag[i]);
	}
return 0;
}