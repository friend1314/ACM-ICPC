#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
#define N 100050

int n, a[N];
long long ans = 0;
int main() {
    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++)
        scanf("%d", &a[i]);
    for (int i = 1; i <= n; i ++) {
        int pointeri = i + 1;
        while (a[pointeri] >= a[pointeri - 1] && pointeri <= n)
            pointeri ++;
        pointeri --;
        int pointerj = pointeri + 1;
        while (a[pointerj] <= a[pointerj - 1] && pointerj <= n)
           	pointerj ++;
        pointerj --;
        ans += (a[pointeri] - a[i - 1]);
        i = pointerj;
    }
    printf("%lld\n", ans);
    return 0;
}
