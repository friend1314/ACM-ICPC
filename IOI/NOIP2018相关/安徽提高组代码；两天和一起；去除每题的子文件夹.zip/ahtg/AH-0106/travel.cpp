#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
#define N 5005

struct edge {
    int to, pre;
}e[N << 1];
int n, m;
bool F[N][N];
int v[N][N], size[N];
int num, head[N];
int id[N], clk, vis[N];
int arr[3], col;
inline void add(int a, int b) {
    ++ num;
    e[num].to = b, e[num].pre = head[a];
    head[a] = num;
}
void dfs(int now, int father) {
	id[++ col] = now;
	for (int i = 1; i <= v[now][0]; i ++) {
		if (v[now][i] == father)
			continue;
		dfs(v[now][i], now);
	}
}
void dfs2(int now) {
	vis[now] = 1;
	id[++ col] = now;
	for (int i = head[now]; i; i = e[i].pre) {
		if (vis[e[i].to])
			continue;
		if (e[i].to > arr[2])
			return ;
		dfs2(e[i].to);
	}
}
void dfs3(int now) {
	vis[now] = true;
	id[++ col] = now;
	for (int i = head[now]; i; i = e[i].pre) {
		if (vis[e[i].to])
			continue;
		dfs3(e[i].to);
	}
}
/*void tarjan(int now, int father) {
	dfn[now] = low[now] = ++ clk;
	stk[++ top] = now;
	for (int i = head[now]; i; i = e[i].pre) {
		if (e[i].to == father)
			continue;
		if (!dfn[e[i].to]) {
			tarjan(e[i].to, now);
			low[now] = min(low[now], low[e[i].to]);
		}
		else
			if (!scc[e[i].to])
				low[now] = min(low[now], dfn[e[i].to]);
	}
	if (low[now] == dfn[now]) { 
		tot ++;
		while (stk[top + 1] != now) {
			scc[stk[top]] = tot;
			sum[tot] ++;
			top --;
		}
	}
}*/
int main () {
    freopen("travel.in", "r", stdin);
    freopen("travel.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for (int i = 1, a, b; i <= m; i ++) {
    	scanf("%d%d", &a, &b);
    	F[a][b] = F[b][a] = true;
    	v[a][++ v[a][0]] = b;
    	v[b][++ v[b][0]] = a;
    	size[a] ++, size[b] ++;
    	add(a, b), add(b, a);
    }
    if (m == n - 1) {
    	for (int i = 1; i <= n; i ++)
    		sort(v[i] + 1, v[i] + v[i][0] + 1);
    	dfs(1, 0);
    	for (int i = 1; i <= n; i ++)
    		printf("%d ", id[i]);
    	return 0;
    }
    bool flag = true;
    for (int i = 1; i <= n; i ++)
    	if (size[i] > 2)
    		flag = false;
    if (flag) {
 		int cnt = 0;
    	for (int i = head[1]; i; i = e[i].pre) 
    		arr[++ cnt] = e[i].to;
    	if (arr[1] > arr[2])
    		swap(arr[1], arr[2]);
    	vis[1] = 1, id[1] = 1;
    	clk = 1;
    	dfs2(arr[1]);
    	dfs3(arr[2]);
    	for (int i = 1; i <= n; i ++)
    		printf("%d ", id[i]);
    	return 0;
    }
    for (int i = 1; i <= n; i ++)
    	printf("%d ", i);
    return 0;
}
