#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
using namespace std;
#define N 105

int exgcd(int a, int b, int &x, int &y) {
	if (b == 0) {
		x = 1, y = 0;
		return a;
	}
	int Gcd = exgcd(b, a % b, y, x);
	y -= a / b * x;
	return Gcd;
}
int t, n, ans, a[N], flag[N], now1, now2;
int MAP[25005], CNT[25005], SUM, cnt, b[N], Max;
void dfs(int now, int nowans) {
	if (now == cnt + 1) {
		if (MAP[nowans]) {
			if (CNT[nowans] >= 1)
				SUM ++;
			CNT[nowans] ++;
		}
		return ;
	}
	for (int i = 0; nowans + b[now] * i <= Max; i ++)
		dfs(now + 1, nowans + b[now] * i);
}
int cmp(const void *a, const void *b) {
	return *(int *)b - *(int *)a;
}
int main() {
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	scanf("%d", &t);
	while (t --) {
		ans = 0, cnt = 0;
		memset(MAP, 0, sizeof(MAP));
		memset(CNT, 0, sizeof(CNT));
		memset(flag, 0, sizeof(flag));
		scanf("%d", &n);
		for (int i = 1; i <= n; i ++) 
			scanf("%d", &a[i]);
		int x, y, G;
		for (int i = 1; i <= n; i ++) 
			for (int j = 1; j <= n; j ++) {
				if (j == i)
					continue;
				if (a[i] % a[j] == 0) {
					flag[i] = 1;
					break;
				}
				for (int k = 1; k <= n; k ++) {
					if (k == i)
						continue;
					G = exgcd(a[j], a[k], x, y);
					if (a[i] % G != 0)
						continue;
					x *= (a[i] / G), y *= (a[i] / G);
					if (x >= 0 && y >= 0)
						flag[i] = 1;
					else if (x < 0) {
						now1 = -x;
						now2 = (now1 + (a[k] / G) - 1) / (a[k] / G);
						if (y - now2 * (a[j] / G) >= 0)
							flag[i] = 1;
					} else {
						now1 = -y;
						now2 = (now1 + (a[j] / G) - 1) / (a[j] / G);
						if (x - now2 * (a[k] / G) >= 0)
							flag[i] = 1;
					}
				}
			}
		for (int i = 1; i <= n; i ++)
			if (flag[i] == 0)
				b[++ cnt] = a[i];
		Max = 0, SUM = 0;
		for (int i = 1; i <= cnt; i ++)
			Max = max(Max, b[i]), MAP[b[i]] = 1;
		qsort(b + 1, cnt, sizeof(b[1]), cmp);
		if ((Max > 1000) && (cnt <= 3 || cnt >= 8))
			printf("%d\n", cnt);
		else {
			dfs(1, 0);
			printf("%d\n", cnt - SUM);
		}	
	}
	return 0;
}
