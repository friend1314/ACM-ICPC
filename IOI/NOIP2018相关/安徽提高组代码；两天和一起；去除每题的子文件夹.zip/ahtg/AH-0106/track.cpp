#include <cstdio>
#include <cstdlib>
#include <iostream>
using namespace std;
#define N 100050

struct edge {
	int to, pre, w;
}e[N << 1];
int n, m, a[N], b[N], c[N];
int head[N], num;
inline void add(int a, int b, int c) {
	++ num;
	e[num].to = b, e[num].pre = head[a], e[num].w = c;
	head[a] = num;
}
bool check(int now) {
	int ans = 0, tmp = 0;
	for (int i = 1; i < n; i ++) {
		ans += c[i];
		if (ans >= now)
			ans = 0, tmp ++;
	}
	if (tmp >= m)
		return true;
	return false;
}
int lca[N][30], fa[N], depth[N], dis[N], leaf[N], lg[N], size[N], cnt;
void dfs(int now, int father) {
	lca[now][0] = fa[now] = father;
	depth[now] = depth[father] + 1;
	for (int i = 1; (1 << i) <= depth[now]; i ++)
		lca[now][i] = lca[lca[now][i - 1]][i - 1];
	for (int i = head[now]; i; i = e[i].pre) {
		size[now] ++;
		if (e[i].to == father)
			continue;
		dis[e[i].to] = dis[now] + e[i].w;
		dfs(e[i].to, now);
	}
	if (size[now] == 1)
		leaf[++ cnt] = now;
}
int LCA(int x, int y) {
	if (depth[x] < depth[y])
		swap(x, y);
	while (depth[x] > depth[y])
		x = lca[x][lg[depth[x] - depth[y]] - 1];
	if (x == y)
		return x;
	for (int i = 19; i >= 0; i --)
		if (lca[x][i] != lca[y][i])
			x = lca[x][i], y = lca[y][i];
	return fa[x];
}
bool xcheck(int now) {
	int p1 = 1, p2 = n - 1, tmp = 0;
	while (p1 < p2) {
		while (c[p1] + c[p2] < now)
			p2 --;
		tmp ++, p2 --, p1 ++;
	}
	if (p1 == p2 && c[p1] >= now)
		tmp ++;
	if (tmp >= m)
		return true;
	return false;
}
int cmp(const void *a, const void *b) {
	return *(int *)b - *(int *)a;
}
int main() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	scanf("%d%d", &n, &m);
	if (m == n - 1) {
		int M = (1 << 30);
		for (int i = 1, a, b, c; i < n; i ++) {
			scanf("%d%d%d", &a, &b, &c);
			M = min(c, M);
		}
		printf("%d\n", M);
		return 0;
	}
	bool flag = true;
	for (int i = 1; i < n; i ++) {
		scanf("%d%d%d", &a[i], &b[i], &c[i]);
		if (b[i] != a[i] + 1)
			flag = false;
		add(a[i], b[i], c[i]);
		add(b[i], a[i], c[i]);
	}
	if (flag) {
		int l = 1, r = (1 << 30), mid;
		while (l <= r) {
			mid = (l + r) >> 1;
			if (check(mid))
				l = mid + 1;
			else
				r = mid - 1;
		}
		printf("%d\n", r);
		return 0;
	}
	flag = true;
	for (int i = 1; i < n; i ++) 
		if (a[i] != 1) {
			flag = false;
			break;
		}
	if (flag && m == 1) {
		int M1 = 0, M2 = 0;
		for (int i = 1; i < n; i ++) {
			if (c[i] > M1)
				M2 = M1, M1 = c[i];
			else if (c[i] > M2)
				M2 = c[i];
		}
		printf("%d\n", M1 + M2);
		return 0;
	}
	if (m == 1) {
		for (int i = 1; i <= n; i ++)
			lg[i] = lg[i - 1] + (1 << lg[i - 1] == i);
		dfs(1, 0);
		int ans = 0;
		for (int i = 1; i <= cnt; i ++)
			for (int j = i + 1; j <= cnt; j ++)
				ans = max(ans, (dis[leaf[i]] + dis[leaf[j]] - 2 * dis[LCA(leaf[i], leaf[j])]));
		printf("%d\n", ans);
		return 0;
	}
	if (flag) {
		qsort(c + 1, n - 1, sizeof(c[1]), cmp);
		int l = 1, r = (1 << 30), mid;
		while (l <= r) {
			mid = (l + r) >> 1;
			if (xcheck(mid))
				l = mid + 1;
			else
				r = mid - 1;
		}
		printf("%d\n", r);
		return 0;
	}
	return 0;
}
