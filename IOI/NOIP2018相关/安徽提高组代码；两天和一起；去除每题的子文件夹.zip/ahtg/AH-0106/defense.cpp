#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
#define N 2005

struct edge {
    int to, pre;
}e[N << 1];
int num, head[N];
int n, m, w[N];
char s[10];
int a1, b1, a2, b2;
int dp[N][5];
inline void add(int a, int b) {
    ++ num;
    e[num].to = b, e[num].pre = head[a];
    head[a] = num;
}
void dfs(int now, int father) {
	dp[now][1] = dp[now][0] = (1 << 30);
	for (int i = head[now]; i; i = e[i].pre) {
		if (e[i].to == father)
			continue;
		dfs(e[i].to, now);
		if ((now == a1 && b1) || (now == a2 && b2)) 
			dp[now][1] = min(dp[now][1], min(dp[e[i].to][1] + w[now], dp[e[i].to][0] + w[now]));
		else if ((now == a1 && !b1) || (now == a2 && !b2))
			dp[now][0] = min(dp[now][0], dp[e[i].to][1]);
		else {
			dp[now][0] = min(dp[now][0], dp[e[i].to][1]);
			dp[now][1] = min(dp[now][1], min(dp[e[i].to][1] + w[now], dp[e[i].to][0] + w[now]));
		}
	}
	if ((now == a1 && !b1) || (now == a2 && !b2))
		return ;
	if (dp[now][1] == (1 << 30))
		dp[now][1] = w[now];
}
int main () {
	freopen("defense.in", "r", stdin);
	freopen("defense.out", "w", stdout);
	scanf("%d%d%s", &n, &m, s + 1);
	for (int i = 1; i <= n; i ++) 
		scanf("%d", &w[i]);
	for (int i = 1, a, b; i < n; i ++) {
		scanf("%d%d", &a, &b);
		add(a, b), add(b, a);
	}
	for (int i = 1; i <= m; i ++) {
		int f = 0;
		scanf("%d%d%d%d", &a1, &b1, &a2, &b2);
		for (int i = head[a1]; i; i = e[i].pre)
			if (e[i].to == a2) {
				f = 1;
				printf("-1\n");
				break;
			}
		if (f)
			continue;
		dfs(1, 0);
		if (a2 < a1)
			swap(a1, a2), swap(b1, b2);
		if (a1 == 1)
			if (b1)
				printf("%d\n", dp[1][1]);
			else
				printf("%d\n", dp[1][0]);
		else
			printf("%d\n", min(dp[1][1], dp[1][0]));
	}
	return 0;
}
