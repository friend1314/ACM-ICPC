#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n;
int last;
int ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	last=0;
	ans=0;
	for(int i=0;i<n;i++){
		int cur;
		scanf("%d",&cur);
		if(cur>last){
			ans+=cur-last;
		}
		last=cur;
	}
	printf("%d",ans);
	return 0;
}