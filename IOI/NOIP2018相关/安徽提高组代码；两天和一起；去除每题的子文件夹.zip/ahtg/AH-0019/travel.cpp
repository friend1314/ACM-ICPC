#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m;
int mapp[5005][5005];
int vis[5005];
int ans[5005];
int flag;
void solve(int xh,int cur){
	if(vis[cur]){
		return;
	}
	ans[xh]=cur;
	if(xh==n){
		return;
	}
	for(int i=1;i<=n;i++){
		if(mapp[cur][i]&&!vis[i]){
			for(int j=i+1;j<=n;j++){
				if(mapp[cur][j]&&!vis[j]){
					mapp[i][j]=mapp[j][i]=1;
					mapp[cur][j]=mapp[j][cur]=0;
				}
			}
			mapp[cur][i]=mapp[i][cur]=0;
			solve(xh+1,i);
			return;
		}
	}
}
int t;
void solve2(int cur,int fa){
	if(vis[cur]){
		return;
	}
	ans[t]=cur;
	vis[cur]=1;
	if(t>=n){
		return;
	}
	for(int i=1;i<=n;i++){
		if(mapp[cur][i]&&fa!=i&&!vis[i]){
			t++;
			solve2(i,cur);
		}
	}
}
void solve3(int xh,int cur){
	if(vis[cur]){
		return;
	}
	ans[xh]=cur;
	if(xh==n){
		return;
	}
	for(int i=1;i<=n;i++){
		if(mapp[cur][i]==1&&!vis[i]){
			for(int j=i+1;j<=n;j++){
				if(mapp[cur][j]&&!vis[j]){
					mapp[i][j]=mapp[j][i]=2;
					mapp[cur][j]=mapp[j][cur]=0;
				}
			}
			mapp[cur][i]=mapp[i][cur]=0;
			solve3(xh+1,i);
			return;
		}else if(mapp[cur][i]==2&&!vis[i]){
			for(int j=i+1;j<=n;j++){
				if(mapp[cur][j]&&!vis[j]){
					mapp[cur][j]=mapp[j][cur]=0;
				}
			}
			mapp[cur][i]=mapp[i][cur]=0;
			solve3(xh+1,i);
			return;
		}
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(vis,0,sizeof(vis));
	memset(mapp,0,sizeof(mapp));
	for(int i=0;i<m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		mapp[v][u]=mapp[u][v]=1;
	}
	if(m==(n-1)){
		t=1;
		solve2(1,-1);
	}else if(n==1000){
		flag=1;
		solve3(1,1);
	}else{
		flag=0;
		solve(1,1);
	}
	for(int i=1;i<=n;i++){
			printf("%d ",ans[i]);
	}
	//solve(1,1);
	return 0;
}