#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m;
char type[10];
int p[100005];
int s[100005];
int vis[100005];
long long dp[100005][2];
int num,lim;
long long solve(int cur,int fa){
	if(cur==-1){
		return 0;
	}
	long long res=0;
	if(cur==num){
		if(dp[cur][lim]>=0){
			return dp[cur][lim];
		}else{
			vis[cur]=lim;
			return solve(s[cur],cur)+(lim==0?0:p[cur]);
		}
	}
	if(fa!=-1){
		if(vis[fa]){
			if(cur>num&&dp[cur][1]>=0){
				res=dp[cur][1];
			}else{
				vis[cur]=1;
				dp[cur][1]=res=p[cur]+solve(s[cur],cur);
			}
			if(cur>num&&dp[cur][0]>=0){
				if(dp[cur][0]>res){
					res=dp[cur][0];
				}
			}else{
				vis[cur]=0;
				long long lin=solve(s[cur],cur);
				dp[cur][0]=lin;
				if(lin>res){
					res=lin;
				}
			}
			
		}else{
			if(cur>num&&dp[cur][1]>=0){
				return dp[cur][1];
			}else{
				vis[cur]=1;
				return p[cur]+solve(s[cur],cur);
			}
		}
	}
	return res;
}
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d %d %s",&n,&m,type);
	for(int i=1;i<=n;i++){
		scanf("%d",&p[i]);
	}
	if(type[0]=='A'&&type[1]=='1'){
		//printf("ok");
		memset(s,-1,sizeof(s));
		for(int i=1;i<=(n-1);i++){
			int u,v;
			scanf("%d%d",&u,&v);
			s[i]=i+1;
		}
		memset(dp,-1,sizeof(dp));
		memset(vis,0,sizeof(vis));
		long long ans;
		for(int i=0;i<m;i++){
			int xx,a,yy,b;
			scanf("%d%d%d%d",&a,&xx,&b,&yy);
			num=b;lim=yy;
			ans=solve(1,-1);
			printf("%lld\n",ans);
		}
	}
	return 0;
}