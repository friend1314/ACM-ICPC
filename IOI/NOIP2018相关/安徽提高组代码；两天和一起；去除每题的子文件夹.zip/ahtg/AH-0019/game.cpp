#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int mod=1000000007;
int n,m;
int mapp[10][1000005];
long long fpow(long long a,long long b){
	long long res=1;
	while(b){
		if(b&1){res=(res*a)%mod;}
		a=(a*a)%mod;
		b>>=1;
	}
	return res%mod;
}
int solve(int xx,int yy){
	if(xx>=(n-1)&&yy==m){
		return 2;
	}
	int res=0;
	if(yy<m){
		if(mapp[xx][yy+1]!=-1){
			for(int i=mapp[xx][yy+1];i<=1;i++){
				mapp[xx+1][yy]=i;
				res=(res+solve(xx,yy+1))%mod;
			}
			mapp[xx+1][yy]=-1;
		}else{
			for(int i=0;i<=1;i++){
				for(int j=i;j<=1;j++){
					mapp[xx][yy+1]=i;
					mapp[xx+1][yy]=j;
					res=(res+solve(xx,yy+1))%mod;
				}
			}
			mapp[xx][yy+1]=-1;
			mapp[xx+1][yy]=-1;
		}
	}else{
		for(int i=0;i<=1;i++){
			mapp[xx+1][yy]=i;
			res=(res+solve(xx+1,1))%mod;
		}
		mapp[xx+1][yy]=-1;
	}
	return res;
}
long long solve2(int xx,int yy){
	if(xx>=n&&yy>=m){
		//printf("ok");
		return 1;
	}
	long long res=0;
	if(yy<m){
		if(xx==1){
			for(int i=0;i<=1;i++){
				mapp[xx][yy]=i;
				res=(res+solve2(xx,yy+1))%mod;
			}
			mapp[xx][yy+1]=-1;
		}else{
			for(int i=mapp[xx-1][yy+1];i<=1;i++){
				mapp[xx][yy]=i;
				res=(res+solve2(xx,yy+1))%mod;
			}
			mapp[xx][yy]=-1;
		}
	}else{
		for(int i=0;i<=1;i++){
			mapp[xx][yy]=i;
			res=(res+solve2(xx+1,1))%mod;
		}
		mapp[xx][yy]=-1;
	}
	return res;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	long long ans=0;
	if(n==2){
		ans=fpow(3,m-1)*2%mod*2%mod;
	}else if(m==2){
		ans=fpow(3,m-1)*2%mod*2%mod;
	}else if(n==1||m==1){
		ans=fpow(2,max(n,m))%mod;
	}else if(n==3&&m==3){
		ans=112;
	}else if(n==3){
		//printf("ok");
		memset(mapp,-1,sizeof(mapp));
		ans=solve2(1,1)%mod;
	}else{
		memset(mapp,-1,sizeof(mapp));
		ans=2*solve(1,1)%mod;
	}
	printf("%lld",ans);
	return 0;
}