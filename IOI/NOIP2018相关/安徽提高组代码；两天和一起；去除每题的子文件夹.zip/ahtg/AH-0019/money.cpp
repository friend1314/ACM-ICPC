#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int T;
int n;
int vis[25005],ans[25005];
int res;
int num[105];
int cgg(int cur){
	if(ans[cur]||vis[cur]){
		return 1;
	}
	//int cur=num[xh];
	for(int i=1;i<cur;i++){
		if(ans[i]){
			int md=cur%i;
			if(!md){
				vis[cur]=1;
				return 1;
			}else{
				for(int j=i;j<=cur;j+=i){
					if(cgg(cur-j)){
						vis[cur-j]=vis[cur]=1;
						return 1;
					}
				}
			}
		}
	}
	return 0;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		memset(vis,0,sizeof(vis));
		memset(ans,0,sizeof(ans));
		res=0;
		for(int i=1;i<=n;i++){
			scanf("%d",&num[i]);
			//vis[num[i]]=1;
		}
		sort(num+1,num+1+n);
		vis[num[1]]=ans[num[1]]=1;
		res++;
		for(int i=2;i<=n;i++){
			if(!cgg(num[i])){
				vis[num[i]]=ans[num[i]]=1;
				res++;
			}
		}
		printf("%d\n",res);
	}
	
	return 0;
}