#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
using namespace std;
struct edge{
	int u,v,w;
};
int cmp(edge a,edge b){
	return a.w>b.w;
}
int n,m;
edge e[50005];
int p[50005];
vector<int> son[50005];
int d[50005];
int flag1,flag2;
int mapp[1005][1005];

int main(){
	flag1=flag2=1;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(p,-1,sizeof(p));
	memset(mapp,0x3f,sizeof(mapp));
	for(int i=0;i<(n-1);i++){
		int u,v,w;
		scanf("%d%d%d",&e[i].u,&e[i].v,&e[i].w);
		if(e[i].u>e[i].v){
			swap(e[i].u,e[i].v);
		}
		p[e[i].v]=i;
		son[e[i].u].push_back(i);
		if(n<=1000){
			mapp[e[i].u][e[i].v]=e[i].w;
			mapp[e[i].v][e[i].u]=e[i].w;
		}
		if(e[i].u!=1){
			flag1=0;
		}
		if((e[i].v-e[i].u)!=1){
			flag2=0;
		}
	}
	if(flag1){
		sort(e,e+(n-1),cmp);
		if(m==1){
			printf("%d",e[0].w+e[1].w);
		}else if(m*2<=(n-1)){
			int ans=0x3f3f3f3f;
			for(int i=0;i<m;i++){
				ans=min(ans,e[i].w+e[2*m-1-i].w);
			}
			printf("%d",ans);
		}else if(m==(n-1)){
			printf("%d",e[n-2].w);
		}else{
			int ans=e[2*m-n-1].w;
			for(int i=m;i<(n-1);i++){
				ans=min(ans,e[i].w+e[2*m-i-2].w);
			}
			printf("%d",ans);
		}
	}else if(m==1){
		int ans=-1;
		for(int k=1;k<=n;k++){
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					if((mapp[i][k]<0x3f3f3f3f)&&(mapp[k][j]<0x3f3f3f3f)){
						mapp[i][j]=min(mapp[i][k]+mapp[k][j],mapp[i][j]);
						ans=max(ans,mapp[i][j]);
						//printf("%d\n",mapp[i][j]);
					}
				}
			}
		}
		printf("%d",ans);
	}else if(flag2){
		
	}
	return 0;
}