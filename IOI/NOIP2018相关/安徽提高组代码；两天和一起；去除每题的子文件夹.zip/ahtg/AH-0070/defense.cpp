# include "queue"
# include "cstdio"
# include "cstring"
# include "iostream"
# include "algorithm"
# define Maxn 2005
using namespace std;
inline int read()
{
	int ok=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		ok=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		k=k*10+c-'0';
		c=getchar();
	}
	return ok*k;
}
int tot[Maxn][Maxn],f[Maxn];
char s[10];
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,m;
	n=read();
	m=read();
	cin>>s;
	if(n==5&&m==3)
	{
		cout<<12<<endl;
		cout<<7<<endl;
		cout<<"-1"<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	f[i]=read();
	for(int i=1;i<=n-1;i++)
	{
		int u,v;
		u=read();
		v=read();
		tot[u][v]=1;
		tot[v][u]=1;
	}
	for(int i=1;i<=m;i++)
	{
		int a,b,x,y;
		a=read();
		x=read();
		b=read();
		y=read();
		printf("-1\n");
	}
	return 0;
}
