# include "cstdio"
# include "cstring"
# include "iostream"
# include "algorithm"
# define Maxm 25005
# define Maxn 105
using namespace std;
bool tot[Maxm];
int f[Maxn];
inline int read()
{
	int ok=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		ok=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		k=k*10+c-'0';
		c=getchar();
	}
	return ok*k;
}
int ok=0,n;
bool work(int s)
{
	for(int i=1;i<=s/2+1;i++)
	if(tot[i]&&tot[s-i])
	return true;
	return false;
}
void dfs(int now,int s)
{
	if(ok)
	return ;
	if(now==0)
	{
		ok=1;
		return ;
	}
	int to=now;
	if(s==now)
	to--;
	for(int i=1;i<=to;i++)
	{
		if(tot[i])
		dfs(now-i,s);
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	t=read();
	while(t--)
	{
	    int ans=0;
	    ans=n=read();
	    memset(tot,false,sizeof(tot));
	    for(int i=1;i<=n;i++)
	    f[i]=read();
	    sort(f+1,f+n+1);
	    int s=f[n];
		for(int i=1;i<=n;i++)
	    {
		    for(int j=1;j*f[i]<=s;j++)
			{
				tot[f[i]*j]=true;
			}
	    }
	    for(int i=1;i<=n;i++)
	    {
			if(work(f[i]))
			{
				ans--;
				continue;
			}
		    ok=0;
			dfs(f[i],f[i]);
			if(ok)
			ans--;
	    }
		printf("%d\n",ans);
    }
	return 0;
}