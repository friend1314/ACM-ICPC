# include "queue"
# include "cstdio"
# include "iostream"
# define inf 0x3f3f3f3f
# define Maxn 100005
# define P pair<int,int>
typedef long long ll;
using namespace std;
inline ll read()
{
	ll ok=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		ok=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		k=k*10+c-'0';
		c=getchar();
	}
	return ok*k;
}
ll f[Maxn];
priority_queue<P,vector<P>,greater<P> >q;
ll vis[Maxn];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ll n,ans=0;
	n=read();
	for(ll i=1;i<=n;i++)
	{
		f[i]=read();
		q.push(P(f[i],i));
	}
	f[0]=f[n+1]=inf;
	for(ll i=1;i<=n;i++)
	{
		P p=q.top();
		ll now=p.second;
		q.pop();
		ll l=now,r=now;
		ll s=f[now];
		if(s==inf)
		continue;
		f[now]=inf;
		l--;
		r++;
		while(l>=0)
		{
			if(f[l]==inf)
			break;
			f[l]-=s;
			l--;
		}
		while(r<=n)
		{
			if(f[r]==inf)
			break;
			f[r]-=s;
			r++;
		}
		ans+=s;
	}
	printf("%lld\n",ans);
	return 0;
}