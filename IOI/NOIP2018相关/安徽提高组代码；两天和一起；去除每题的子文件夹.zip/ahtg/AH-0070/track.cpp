# include "cstdio"
# include "cstring"
# include "iostream"
# include "algorithm"
# define Maxm 50005
# define Maxn 50005
using namespace std;
bool tot[Maxm];
int ss[Maxn];
inline int read()
{
	int ok=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		ok=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		k=k*10+c-'0';
		c=getchar();
	}
	return ok*k;
}
int s;
int head[Maxn];
struct node{
	int to;
	int w;
	int next;
}f[Maxm*2];
int cnt=1;
void add(int u,int v,int w)
{
	f[cnt].to=v;
	f[cnt].w=w;
	f[cnt].next=head[u];
	head[u]=cnt++;
}
bool vis[Maxn];
int m,n;
void dfs1(int now,int from,int tot)
{
	if(now==m-1)
	{
		s=max(s,min(tot,ss[n]-ss[from]));
		return ;
	}
	for(int i=from+1;i<=n;i++)
	{
		dfs1(now+1,i,min(ss[i]-ss[from],tot));
	}
}
void dfs(int now,int to,int tot)
{
	vis[now]=true;
	if(now==to)
	{
		s=tot;
		return ;
	}
	for(int i=head[now];i;i=f[i].next)
	{
		node e=f[i];
		if(vis[e.to])
		continue;
		dfs(e.to,to,tot+e.w);
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int ok=1;
	n=read();
	m=read();
	for(int i=1;i<n;i++)
	{
		int u,v,w;
		u=read();
		v=read();
		w=read();
		ss[i+1]=ss[i]+w;
		if(u+1!=v)
		ok=0;
		add(u,v,w);
		add(v,u,w);
	}
	int ans=-1;
	if(ok)
	{
		dfs1(0,1,0x3f3f3f3f);
		ans=max(ans,s);
		printf("%d\n",ans);
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			memset(vis,false,sizeof(vis));
			s=0;
			dfs(i,j,0);
			ans=max(s,ans);
		}
	}
	printf("%d\n",ans);
	return 0;
}