# include "queue"
# include "cstdio"
# include "cstring"
# include "iostream"
# include "algorithm"
# define Maxn 5005
using namespace std;
int s[Maxn];
inline int read()
{
	int ok=1,k=0;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')
		ok=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		k=k*10+c-'0';
		c=getchar();
	}
	return ok*k;
}
int head[Maxn];
struct node{
	int to;
	int next;
}f[Maxn*2];
int cnt=1;
bool vis[Maxn];
int ans[Maxn],xx=0;
int m;
bool jl[Maxn*2];
int ok=0;
void dfsx(int u,int num)
{
	if(ok==1)
	return ;
	if(vis[u])
	return ;
	ans[++xx]=u;
	if(ok==0&&num==2)
	{
		if(ans[xx]>s[xx])
		{
			ok=1;
			return ;
		}
		if(ans[xx]<s[xx])
		{
			ok=-1;
		}
	}	
	vis[u]=true;
	int x=0;int tot[Maxn];
	for(int i=head[u];i;i=f[i].next)
	{
		if(jl[i]==false)
		{
			continue;
		}
		node e=f[i];
		if(vis[e.to])
		continue;
		tot[++x]=e.to;
	}
	sort(tot+1,tot+1+x);
	for(int i=1;i<=x;i++)
	dfsx(tot[i],num);
}
void add(int u,int v)
{
	f[cnt].to=v;
	f[cnt].next=head[u];
	head[u]=cnt++;
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n;
	n=read();
	m=read();
	for(int i=1;i<=m;i++)
	{
		int u,v;
		u=read();
		v=read();
		add(u,v);
		add(v,u);
	}
	memset(jl,true,sizeof(jl));
	if(m==n-1)
	{
		memset(vis,false,sizeof(vis));
	    dfsx(1,1);
	    for(int i=1;i<=n;i++)
	    printf("%d ",ans[i]);
	    printf("\n");
    }
	else
	{
		memset(s,0x3f,sizeof(s));
		for(int i=1;i<=m;i++)
		{
		    memset(vis,false,sizeof(vis));
			xx=0;
			int ok=0;
			jl[i*2]=jl[i*2-1]=false;
			dfsx(1,2);
			jl[i*2]=jl[i*2-1]=true;
			if(ok==1)
			continue;
			for(int j=1;j<=n;j++)
			{
				if(ans[j]==0)
				break;
				if(s[j]>ans[j])
			    {
				    ok=1;
					break;
			    }
			   if(s[j]<ans[j])
			    {
					break;
			    }
		    }
			if(ok)
			for(int j=1;j<=n;j++)
			s[j]=ans[j];
		}
	    for(int i=1;i<=n;i++)
	    printf("%d ",s[i]);
	    printf("\n");
	}
	return 0;
}
