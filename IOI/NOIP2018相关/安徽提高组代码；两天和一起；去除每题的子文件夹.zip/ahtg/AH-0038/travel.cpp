#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int n,m,u,v,w[2500][2500],num[5001],sum=0,minn=999999,wz,qqq=0;
bool e[5001];
void dfs(int x)
{	
	for(int i=1;i<=num[x];i++)
	{
		if(e[w[x][i]]&&w[x][i]<minn)
		minn=w[x][i];
	}
		e[minn]=false;
		qqq++;
		cout<<minn<<" ";
		int q=minn;
		minn=999999;
		if(qqq<n&&num[q]>1)
		{e[q]=0;dfs(q);}
	   else
	   {e[q]=0;num[x]--;}
	   if(qqq==n)
			return  ;

}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	memset(e,1,sizeof(e));
	memset(w,0,sizeof(w));
	memset(num,0,sizeof(num));
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin>>u>>v;
		w[u][++num[u]]=v;
		w[v][++num[v]]=u;
	}
	cout<<"1"<<" ";
	qqq++;
	e[1]=false;
	dfs(1);
	return 0;
	}
	