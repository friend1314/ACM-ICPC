#include<iostream>
#include<cstdio>
#include<cstring> 
using namespace std;
int n,d[100010],ans=0,m=0,i;
bool e[100010];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	memset(e,1,sizeof(e));
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	scanf("%d",&d[i]);
        i=1;
while(m!=n)
{
		while(d[i]!=0)
		{
			d[i]--;
			i++;
			if(i==n)
			{i=1;ans++;}
		}
		ans++;
		if(d[i]==0&&e[i]==true)
		{
			e[i]=false;
			m++;
		}
		if(i==n)
		{
			i=1;
		}
		if(m==n-1)
		{
			ans+=d[i];
			break;
		}
		i++;
		}
		cout<<ans<<endl;
		return 0;
	}
			
	