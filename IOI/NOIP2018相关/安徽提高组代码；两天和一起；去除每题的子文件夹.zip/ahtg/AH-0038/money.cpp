#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int n,t,a[200],ans;
bool e[200],e2[200];
void qqq()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<i;j++)
			if(e[i]&&e[j]&&a[i]%a[j]==0)
			{ans--;e[j]=false;}
}
void dfs(int yu,int j )
{    
		for(int k=j-1;j>=1;j--)
		{
			if(e[k]&&e2[k])
			{
				yu=yu%a[k];
				e2[k]=false;
				if(yu==0)
				{ans--;break;}
				else
					dfs(yu,k);
				}
				e2[k]=true;
			}
		}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	memset(e,1,sizeof(e));
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&n);
		for(int j=1;j<=n;j++)
			cin>>a[j];
			sort(a+1,a+n+1);
		
		ans=n;
		qqq();
		for(int i=n;i>=1;i--)
		for(int j=i-1;j>=1;j--)
		dfs(i%j,j);
		cout<<ans<<endl;
	}	
	return 0;
	}

