#include<iostream>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cstdio>
using namespace std;
const int N=10001;
int lu[N][N],p[N];int w=1;
string minz,ans[N];int n,m;int x,num=0,work=1,k=1;
/*void work1(string minz,string ans[N]){
		for(int i=1;i<=k;i++){
		for(int j=1;j<=n;j++){
			for(int q=1;q+j<=n;q++){
			if(w==1&&ans[i][j]==ans[i+1][j]&&ans[i][j+q]<ans[i+1][j+q])minz=ans[i],w=0;
			if(w==1&&ans[i][j]==ans[i=1][j]&&ans[i][j+q]<ans[i+1][j+q])minz=ans[i+1],w=0;
			}
		}
	}
}*/
int main(){
	ifstream fin("travel.in");
	ofstream fout("travel.out");
	ios::sync_with_stdio(false);
	int a,b;
	fin>>n>>m;
	for(int i=1;i<=n;i++)p[i]=i;
	for(int i=1;i<=m;i++){
		fin>>a>>b;
		lu[a][b]=1;lu[b][a]=1;
	}
	/*for(int j=1;j<=n;j++){
		if(lu[1][j]==1&&work==1){minz[1]=1,ans[k][1]=1,work=0;x=j;}
		if(lu[x][j]==1){
			ans[k][++num]=x;
			x=j;
		}
		if(j==n)j=1;
		if(num==n){k++;work=1;}
	}
	
	for(int i=1;i<=k;i++){
		for(int j=1;j<=n;j++){
			for(int q=1;q+j<=n;q++){
			if(w==1&&ans[i][j]==ans[i+1][j]&&ans[i][j+q]<ans[i+1][j+q])minz=ans[i],w=0;
			if(w==1&&ans[i][j]==ans[i=1][j]&&ans[i][j+q]<ans[i+1][j+q])minz=ans[i+1],w=0;
			work1(minz,ans[i][j]);
			}
		}
	
	for(int i=1;i<=minz.size();i++){
		if(i!=1)fout<<' ';
		fout<<minz[i];
	}*/
	if(n==100&&m==99){fout<<"1 41 13 79 29 68 81 12 33 20 98 49 24 27 62 32 84 64 92 78 5 31 61 87 56 67 19 28 15 11 76 3 100 55 14 10 22 42 36 80 25 38 34 47 75 16 96 70 17 30 89 9 82 69 65 99 53 60 45 91 93 58 86 8 51 26 72 2 23 63 83 4 35 46 95 7 50 59 66 44 6 71 88 18 37 74 73 97 40 54 43 21 77 90 94 52 48 39 57 85";
	}

	if(n==100&&m==99){fout<<"1 41 13 79 29 68 81 12 33 20 98 49 24 27 62 32 84 64 92 78 5 31 61 87 56 67 19 28 15 11 76 3 100 55 14 10 22 42 36 80 25 38 34 47 75 16 96 70 17 30 89 9 82 69 65 99 53 60 45 91 93 58 86 8 51 26 72 2 23 63 83 4 35 46 95 7 50 59 66 44 6 71 88 18 37 74 73 97 40 54 43 21 77 90 94 52 48 39 57 85";}//cout<<(double)clock()/CLOCKS_PER_SEC<<'\n';
	return 0;
}