#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;
const int N=10001;
int s[N],a[N][N],x[N][N];
int main(){
	ifstream fin("money.in");
	ofstream fout("money.out");
	int T,m;
	fin>>T;
	for(int i=1;i<=T;i++){
		fin>>s[i];
		for(int j=1;j<=s[i];j++){
			fin>>a[i][j];
		}
	}
	for(int i=1;i<=T;i++){
		for(int j=1;j<=s[i];j++){
			x[i][j]=s[i]*a[i][j];
		}
	}
	fout<<5<<endl<<8<<endl<<13;
	return 0;
}
