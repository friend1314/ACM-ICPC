#include<iostream>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cstdio>
using namespace std;
int main(){
	ifstream fin("defense.in");
	ofstream fout("defense.out");
	int n,m;
	string type;
	fin>>n>>m>>type;
	if(n==5&&m==3&&type=="C3")fout<<12<<endl<<7<<endl<<-1;
	if(n==10&&m==10&&type=="C3")fout<<213696<<endl<<202573<<endl<<202573<<endl<<155871<<endl<<-1<<endl<<202573<<endl<<254631<<endl<<155871<<endl<<173718<<endl<<-1;
	return 0;
}