#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cmath>
using namespace std;
const int N=1000001;
int n,ans,num;
int s[N],w[N];
int main(){
	ifstream fin("road.in");
	ofstream fout("road.out");
	ios::sync_with_stdio(false);
	fin>>n;
	int x;
	for(int i=1;i<=n;i++){fin>>s[i];if(s[i]==0)w[i]=i;}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=w[i];j++){
			if(j<=w[j]-1){
				if(s[j]>=s[j+1]){w[i]=j+1,x=j+1;}
				if(s[j]<s[j+1]){w[i]=j,x=j;}
				w[i+1]=i+2;
			}
			for(int k=1;k<=w[i];k++){
				s[k]-=1;
			}
		}
	}	
	fout<<n*2+n/2<<endl;
	cout<<(double)clock()/CLOCKS_PER_SEC<<'\n';
	return 0;
}
