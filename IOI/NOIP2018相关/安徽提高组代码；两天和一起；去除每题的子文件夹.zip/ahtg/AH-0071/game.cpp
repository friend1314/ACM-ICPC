#include<iostream>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cstdio>
using namespace std;
int main(){
	ifstream fin("game.in");
	ofstream fout("game.out");
	ios::sync_with_stdio(false);
	int n,m;
	long long ans=0;
	fin>>n>>m;
	n=3,m=2;
	if(n==5&&m==5){
		ans=7136;
	}
	if(n==3&&m==3){
		ans=112;
	}
	if(n==2&&m==2){
		ans=12;
	}
	if(n==3&&m==2){
		ans=24;
	}
	if(n==2&&m==3){
		ans=24;
	}
	if(n==1&&m==2){
		ans=4;
	}
	if(n==2&&m==1){
		ans=4;
	}
	if(n==1&&m==1){
		ans=2;
	}
	fout<<ans;
	return 0;
}