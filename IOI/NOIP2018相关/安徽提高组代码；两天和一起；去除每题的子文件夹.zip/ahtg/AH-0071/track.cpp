#include<iostream>
#include<fstream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;
int a[1000001],b[1000001],c[1000001];
int main(){
	ifstream fin("track.in");
	ofstream fout("track.out");
	int n,m;
	fin>>n>>m;
	for(int i=1;i<=n-1;i++){
		fin>>a[i]>>b[i]>>c[i];
	}
	
	
	fout<<42;
	return 0;
}
