#include <cstdio>
#include <algorithm>
#include <queue>

using namespace std;

typedef long long ll;
typedef pair <int, int> pr;

priority_queue <pr> q;

bool a[100005];

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n; scanf("%d",&n);
	for (int i=1;i<=n;i++){
		int x; scanf("%d",&x);
		q.push(pr(x,i));
	}
	long long ans=0;
	int d=q.top().first,cnt=0;
	while (!q.empty()){
		int p,x=q.top().first;
		ans+=(ll)cnt*(d-x); d=x;
		for (;!q.empty()&&x==q.top().first;q.pop()){
			p=q.top().second;
			a[p]=true;
			if (!a[p-1]&&!a[p+1]) cnt++;
			else if (a[p-1]&&a[p+1]) cnt--;
		}
	}
	ans+=(ll)cnt*d;
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}