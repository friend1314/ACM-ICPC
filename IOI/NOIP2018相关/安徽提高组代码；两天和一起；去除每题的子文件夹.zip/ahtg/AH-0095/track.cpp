#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>

using namespace std;

#define N 100005

struct Tree{
	int head[N],to[N<<1],next[N<<1],len[N<<1],cnt;
	void addedge(int x, int y, int z){
		to[++cnt]=y,next[cnt]=head[x],
		head[x]=cnt,len[cnt]=z;
		to[++cnt]=x,next[cnt]=head[y],
		head[y]=cnt,len[cnt]=z;
	}
	int dis[N];
	void dfs(int x, int fa){
		for (int i=head[x];i;i=next[i]){
			if (to[i]==fa) continue;
			dis[to[i]]=dis[x]+len[i];
			dfs(to[i],x);
		}
	}
	int getd(int n){
		dis[1]=0; dfs(1,0);
		int node=1;
		for (int i=2;i<=n;i++)
			if (dis[i]>dis[node]) node=i;
		dis[node]=0; dfs(node,0);
		int ans=0;
		for (int i=1;i<=n;i++)
			if (dis[i]>ans) ans=dis[i];
		return ans;
	}
	int sum[N];
	int dp(int x, int fa, int lim){
		sum[x]=0;
		vector <int> q; q.clear();
		for (int i=head[x];i;i=next[i]){
			if (to[i]==fa) continue;
			q.push_back(dp(to[i],x,lim)+len[i]);
			sum[x]+=sum[to[i]];
		}
		sort(q.begin(),q.end());
		int i=0,j=q.size()-1;
		while (j>=0&&q[j]>=lim){
			q[j]=-1; j--,sum[x]++;
		}
		while (i<j){
			while (i<j&&q[i]+q[j]<lim) i++;
			if (i<j){
				int t=j,k=j-1;
				while (i<k&&q[k]<0) k--;
				while (i<k&&q[i]+q[k]>=lim){
					t=k; k--;
					while (i<k&&q[k]<0) k--;
				}
				q[i]=q[t]=-1;
				i++,sum[x]++;
				while (i<j&&q[j]<0) j--;
			}
		}
		while (j>=0&&q[j]==-1) j--;
		return j>=0?q[j]:0;
	}
	int check(int lim){
		dp(1,0,lim); return sum[1];
	}
}tree;

int a[N],b[N],len[N];

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,m; scanf("%d%d",&n,&m);
	bool mark1=1,mark2=1;
	for (int i=1;i<n;i++){
		scanf("%d%d%d",a+i,b+i,len+i);
		if (a[i]!=1) mark1=false;
		if (a[i]+1!=b[i]) mark2=false;
	}
	if (m==1){
		for (int i=1;i<n;i++)
			tree.addedge(a[i],b[i],len[i]);
		printf("%d\n",tree.getd(n));
	}
	else if (mark1){
		int ans=0; sort(len+1,len+n);
		for (int l=0,r=(int)5e8;l<=r;){
			int mid=(l+r)>>1;
			int i=1,j=n-1,s=0;
			while (j&&len[j]>=mid) j--,s++;
			while (i<j){
				while (i<j&&len[i]+len[j]<mid) i++;
				if (i<j) i++,j--,s++;
			}
			if (s<m) r=mid-1;
			else ans=mid,l=mid+1;
		}
		printf("%d\n",ans);
	}
	else if (mark2){
		int ans=0;
		for (int i=1;i<n;i++)
			b[a[i]]=len[i];
		for (int i=1;i<n;i++)
			len[i]=b[i];
		for (int l=0,r=(int)5e8;l<=r;){
			int mid=(l+r)>>1;
			int s1=0,c1=0,s2=0,c2=0;
			for (int i=1;i<n;i++){
				s1+=len[i];
				if (s1>=mid) s1=0,c1++;
			}
			for (int i=n-1;i;i--){
				s2+=len[i];
				if (s2>=mid) s2=0,c2++;
			}
			if (c1<m&&c2<m) r=mid-1;
			else ans=mid,l=mid+1;
		}
		printf("%d\n",ans);
	}
	else{
		for (int i=1;i<n;i++)
			tree.addedge(a[i],b[i],len[i]);
		int ans=0;
		for (int l=0,r=(int)5e8;l<=r;){
			int mid=(l+r)>>1;
			if (tree.check(mid)>=m)
				ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}