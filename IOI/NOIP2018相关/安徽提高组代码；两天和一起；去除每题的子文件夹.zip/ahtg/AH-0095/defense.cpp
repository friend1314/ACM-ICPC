#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

#define N 100005
#define inf (int)1e18

int v[N],type[N];
long long f[N][2];

struct Tree{
	int head[N],to[N<<1],next[N<<1],cnt;
	void addedge(int x, int y){
		to[++cnt]=y,next[cnt]=head[x],head[x]=cnt;
		to[++cnt]=x,next[cnt]=head[y],head[y]=cnt;
	}
	void dfs(int x, int fa){
		f[x][0]=0,f[x][1]=v[x];
		for (int i=head[x];i;i=next[i]){
			if (to[i]==fa) continue;
			dfs(to[i],x);
			f[x][0]+=f[to[i]][1];
			f[x][1]+=min(f[to[i]][0],f[to[i]][1]);
			if (f[x][0]>inf) f[x][0]=inf;
			if (f[x][1]>inf) f[x][1]=inf;
		}
		if (type[x]==0) f[x][1]=inf;
		if (type[x]==1) f[x][0]=inf;
	}
}tree;

int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,m; char str[10];
	scanf("%d%d%s",&n,&m,str);
	for (int i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for (int i=1,x,y;i<n;i++){
		scanf("%d%d",&x,&y);
		tree.addedge(x,y);
	}
	for (int i=1,a,b,x,y;i<=m;i++){
		memset(type,-1,sizeof(type));
		scanf("%d%d%d%d",&a,&x,&b,&y);
		type[a]=x,type[b]=y;
		tree.dfs(1,0);
		long long ans=min(f[1][0],f[1][1]);
		printf("%lld\n",ans<inf?ans:-1);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}