#include <cstdio>
#include <algorithm>

using namespace std;

typedef long long ll;

#define P 1000000007

int power(int x, int y){
	int s=1,k=x;
	for (;y;y>>=1,k=(ll)k*k%P)
		if (y&1) s=(ll)s*k%P;
	return s;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m; scanf("%d%d",&n,&m);
	if (n>m) swap(n,m);
	if (n==1){
		printf("%d\n",power(2,m));
	}
	else if (n==2){
		printf("%lld\n",4LL*power(3,n+m-3)%P);
	}
	else if (n==3){
		if (m==3) printf("%d\n",112);
		else{
			long long ans=(64LL*power(3,n+m-6)+48)%P;
			for (int k=3;k<m;k++)
				(ans+=64LL*power(3,n+m-k-3)%P)%=P;
			printf("%lld\n",ans);
		}
	}
	else if (n==5)
		puts("7136");
	fclose(stdin);
	fclose(stdout);
	return 0;
}