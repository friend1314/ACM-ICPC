#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int a[105];
bool c[25005];

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T; scanf("%d",&T);
	while (T--){
		int n; scanf("%d",&n);
		for (int i=1;i<=n;i++)
			scanf("%d",a+i);
		sort(a+1,a+n+1);
		memset(c,0,sizeof(c));
		int ans=0; c[0]=1;
		for (int i=1;i<=n;i++)
			if (!c[a[i]]){
				ans++;
				for (int j=0;a[i]+j<=25000;j++)
					if (c[j]) c[a[i]+j]=1;
			}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}