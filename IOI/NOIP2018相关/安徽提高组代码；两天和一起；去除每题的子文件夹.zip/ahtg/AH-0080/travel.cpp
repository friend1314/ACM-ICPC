#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
#define ri register int
#define I inline
const int N=5005;
vector<int> e[N],s,ans;
bool vis[N];
int sx[N],sy[N],top,nx,ny,ok;
char qu[55];
I void gi(ri &x){
	register char c=getchar(); ri f=1;
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(x=0;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+c-'0';
	x*=f;
}
I void print(ri x){
	if(!x) putchar('0');
	if(x<0) putchar('-'),x=-x;
	ri qr=0;
	while(x) qu[++qr]=x%10+'0',x/=10;
	while(qr) putchar(qu[qr--]);
}
I bool cmp(ri x,ri y){ return x<y; }
I void dfs(ri u,ri fa){
	print(u); putchar(' ');
	sort(e[u].begin(),e[u].end(),cmp);
	for(ri i=0;i<(int)e[u].size();i++)
		if(e[u][i]!=fa) dfs(e[u][i],u);
}
I void get_huan(ri u,ri fa){
	vis[u]=true;
	for(ri v,i=0;i<(int)e[u].size();i++)
		if((v=e[u][i])!=fa){
			++top;
			sx[top]=u;
			sy[top]=v;
			if(vis[v]){
				ok=v;
				return;
			}
			get_huan(v,u);
			if(ok) return;
			top--;
		}
	vis[u]=false;
}
I bool check(ri x,ri y){
	return (x==nx&&y==ny)||(x==ny&&y==nx);
}
I void gi_tree(ri u,ri fa){
	s.push_back(u);// printf("gi_tree %d %d\n",u,fa);
	for(ri v,i=0;i<(int)e[u].size();i++)
		if((v=e[u][i])!=fa&&!check(u,v))
			gi_tree(v,u);
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	ri n,m,i,u,v;
	gi(n);gi(m);
	for(i=1;i<=m;i++) gi(u),gi(v),e[u].push_back(v),e[v].push_back(u);
	if(m==n-1){
		dfs(1,0);
		return 0;
	}
	else{
		ok=0;
		get_huan(1,0);
		for(i=1;i<=n;i++) sort(e[i].begin(),e[i].end(),cmp);
		for(i=1;i<=top&&sy[i]!=ok;i++);
		i++;
		//for(;i<=top;i++)
		//	printf("%d %d\n",sx[i],sy[i]);
		for(;i<=top;i++){
			nx=sx[i];
			ny=sy[i];
			s.clear();
			gi_tree(1,0);
			//printf("check %d\n",s.size());
			if(!ans.size()||s<ans) ans=s;
		}
		//printf("size=%d\n",ans.size());
		for(i=0;i<(int)ans.size();i++) print(ans[i]),putchar(' ');
	}
	return 0;
}