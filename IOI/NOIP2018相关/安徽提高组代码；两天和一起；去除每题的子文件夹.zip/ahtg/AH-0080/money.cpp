#include <cstdio>
#include <algorithm>
using namespace std;
#define ri register int
#define I inline
const int N=105,M=25005;
int a[N];
bool f[M];
char qu[55];
I void gi(ri &x){
	register char c=getchar(); ri f=1;
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(x=0;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+c-'0';
	x*=f;
}
I void print(ri x){
	if(!x) putchar('0');
	if(x<0) putchar('-'),x=-x;
	ri qr=0;
	while(x) qu[++qr]=x%10,x/=10;
	while(qr) putchar('0'+qu[qr--]);
}
I int max(ri x,ri y){ return x>y ? x:y; }
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	ri T,n,mx,ans,i,j;
	f[0]=true;
	gi(T);
	while(T--){
		mx=ans=0;
		gi(n);
		for(i=1;i<=n;i++) gi(a[i]),mx=max(mx,a[i]);
		sort(a+1,a+1+n);
		for(i=1;i<=mx;i++) f[i]=false;
		for(i=1;i<=n;i++){
			if(f[a[i]]) continue;
			ans++;
			for(j=a[i];j<=mx;j++)
				f[j]|=f[j-a[i]];
		}
		print(ans); putchar('\n');
	}
	return 0;
}