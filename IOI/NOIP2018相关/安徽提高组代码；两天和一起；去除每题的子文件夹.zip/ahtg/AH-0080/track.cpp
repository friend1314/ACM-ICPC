#include <cstdio>
#include <set>
using namespace std;
#define ri register int
#define I inline
const int N=50005;
int tot,head[N],nxt[N<<1],adj[N<<1],w[N<<1],d[N],now,mid;
multiset<int> s;
multiset<int>::iterator it;
I void gi(ri &x){
	register char c=getchar(); ri f=1;
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(x=0;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+c-'0';
	x*=f;
}
I void Add(ri u,ri v,ri x){ nxt[++tot]=head[u]; adj[head[u]=tot]=v; w[tot]=x; }
I int max(ri x,ri y){ return x>y ? x:y; }
I void dfs(ri u,ri fa){
	ri v,e,x;
	for(e=head[u];e;e=nxt[e])
		if((v=adj[e])!=fa)
			dfs(v,u),d[v]+=w[e];
	s.clear();
	for(e=head[u];e;e=nxt[e])
		if((v=adj[e])!=fa){
			if(d[v]>=mid) now++;
			else s.insert(d[v]);
		}
	d[u]=0;
	while(!s.empty()){
		x=*s.begin();
		s.erase(s.begin());
		it=s.lower_bound(mid-x);
		if(it!=s.end()) now++,s.erase(it);
		else d[u]=max(d[u],x);
	}
	if(s.size()) d[u]=max(d[u],*(--s.end()));
}
I int min(ri x,ri y){ return x<y ? x:y; }
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	ri n,m,i,u,v,x,l=1<<30,r=0,ans;
	gi(n);gi(m);
	for(i=1;i<n;i++) gi(u),gi(v),gi(x),Add(u,v,x),Add(v,u,x),r+=x,l=min(l,x);
	r/=m;
	while(l<=r){
		mid=(l+r)>>1;
		now=0;
		dfs(1,0);
		if(now>=m) ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d",ans);
	return 0;
}