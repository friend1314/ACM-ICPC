#include <cstdio>
#define ri register int
#define I inline
I void gi(ri &x){
	register char c=getchar(); ri f=1;
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(x=0;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+c-'0';
	x*=f;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ri n,i,ans,x,last;
	gi(n);
	gi(x);
	ans=last=x;
	for(i=2;i<=n;i++){
		gi(x);
		if(x>last) ans+=x-last;
		last=x;
	}
	printf("%d",ans);
	return 0;
}