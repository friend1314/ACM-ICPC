#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
#define ri register int
#define I inline
typedef long long ll;
#define rll register ll
const int N=100005;
const ll inf=100000000000000ll;
vector<int> e[N];
int p[N],sx,sy,visx,visy;
char qu[55];
ll f[N][2],g1[N][2],g2[N][2];
I void gi(ri &x){
	register char c=getchar(); ri f=1;
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(x=0;c>='0'&&c<='9';c=getchar()) x=(x<<1)+(x<<3)+c-'0';
	x*=f;
}
I void giopt(register char &c){
	for(c=getchar();c<'A'||c>'Z';c=getchar());
}
I void print(rll x){
	if(!x) putchar('0');
	if(x<0) putchar('-'),x=-x;
	ri qr=0;
	while(x) qu[++qr]=x%10+'0',x/=10;
	while(qr) putchar(qu[qr--]);
}
/*
I void dfs(ri u,ri fa){
	for(ri v,i=0;i<(int)e[u].size();i++)
		if((v=e[u][i])!=fa){
			if(vis[v]==-1){
				vis[v]=vis[u]^1,
				dfs(v,u);
				if(ans==-1) return;
			}
			else if(vis[u]==vis[v]){
				ans=-1;
				return;
			}
		}
}
*/
I ll min(rll x,rll y){ return x<y ? x:y; }
I void check(ri x){
	if(x==sx){
		if(!visx) f[x][1]=inf;
		else f[x][0]=inf;
	}
	else if(x==sy){
		if(!visy) f[x][1]=inf;
		else f[x][0]=inf;
	}
}
I void dfs(ri u,ri fa){
	ri v,i;
	f[u][1]=p[u];
	f[u][0]=0;
	for(i=0;i<(int)e[u].size();i++)
		if((v=e[u][i])!=fa)
			dfs(v,u),
			f[u][1]+=min(f[v][0],f[v][1]),
			f[u][0]+=f[v][1];
	check(u);
}
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	ri i,n,m,opt2,x,y;
	register char opt;
	register bool ok;
	rll ans;
	gi(n);gi(m);giopt(opt);gi(opt2);
	if(opt=='A'&&opt2==2){
		for(i=1;i<=n;i++) gi(p[i]);
		for(i=1;i<=n;i++)
			g1[i][0]=g1[i-1][1],
			g1[i][1]=min(g1[i-1][0],g1[i-1][1])+p[i];
		for(i=n;i;i--)
			g2[i][0]=g2[i+1][1],
			g2[i][1]=min(g2[i+1][0],g2[i+1][1])+p[i];
		for(i=1;i<n;i++) gi(x),gi(y);
			
		while(m--){
			gi(x);gi(visx);gi(y);gi(visy);
			if(!visx&&!visy){
				puts("-1");
				continue;
			}
			if(x>y) x^=y^=x^=y;
			ans=visx*p[x]+visy*p[y];
			if(visx) ans+=min(g1[x-1][0],g1[x-1][1]);
			else ans+=g1[x-1][1];
			if(visy) ans+=min(g2[y+1][0],g2[y+1][1]);
			else ans+=g2[y+1][1];
			print(ans);
			putchar('\n');
		}
		return 0;
	}
	if(n<=2000&&m<=2000){
		for(i=1;i<=n;i++) gi(p[i]);
		for(i=1;i<n;i++)
			gi(x),gi(y),
			e[x].push_back(y),
			e[y].push_back(x);
		while(m--){
		//	for(i=1;i<=n;i++) vis[i]=-1;
			gi(sx);gi(visx);gi(sy);gi(visy);
			if(!visx&&!visy){
				ok=true;
				for(i=0;i<(int)e[sx].size();i++)
					if(e[sx][i]==sy){
						ok=false;
						break;
					}
				if(!ok){
					puts("-1");
					continue;
				}
			}
		//	dfs(x,0);
		//	dfs(y,0);
		//	if(ans==-1) puts("-1");
		//	else{
		//		for(i=1;i<=n;i++)
		//			ans+=vis[i]*p[i];
		//		print(ans);
		//		putchar('\n');
		//	}
			dfs(1,0);
			print(min(f[1][0],f[1][1]));
			putchar('\n');
		}
		return 0;
	}
	return 0;
}