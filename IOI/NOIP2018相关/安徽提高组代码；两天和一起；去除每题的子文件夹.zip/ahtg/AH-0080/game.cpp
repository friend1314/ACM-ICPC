#include <cstdio>
#include <ctime>
#include <vector>
using namespace std;
#define ri register int
#define I inline
typedef long long ll;
const int N=15,mod=1000000007;
int n,m,a[N*N],pos[N][N],ans;
vector<int> last,now;
bool ok;
I void get(ri x,ri y){
	now.push_back(a[pos[x][y]]);
	if(x==n&&y==m){
		if(last>now){
			//for(i=0;i<(int)last.size();i++) printf("%d ",last[i]); puts("");
			ok=false;
		}
		//for(i=0;i<(int)now.size();i++) printf("%d ",now[i]); puts("");
		last=now;
		return;
	}
	if(y<m) get(x,y+1),now.pop_back();
	if(x<n) get(x+1,y),now.pop_back();
}
I bool check(){
	now.clear();
	last.clear();
	ok=true;
	get(1,1);
	return ok;
}
I void dfs(ri i){
	if(i>n*m){
		if(check()){
			/*
			ri j;
			for(i=1;i<=n;i++){
				for(j=1;j<=m;j++)
					printf("%d ",a[pos[i][j]]);
				puts("");
			}
			puts("----------------------");
			*/
			ans++;
			/*
			ri now;
			for(now=1;now<=m;now++){
				i=1; j=now;
				ri lt=0;
				while(i<=n&&j){
					if(lt>a[pos[i][j]]) puts("wrong");
					lt=a[pos[i][j]];
					i++;j--;
				}
			}
			for(now=2;now<=n;now++){
				i=now; j=m;
				ri lt=0;
				while(i<=n&&j){
					if(lt>a[pos[i][j]]) puts("wrong");
					lt=a[pos[i][j]];
					i++;j--;
				}
			}
			*/
		}
		return;
	}
	a[i]=1; dfs(i+1);
	ri x,y;
	x=(i-1)/m+1;
	y=(i-1)%m+1;
	if(!(x-1&&y+1<=m)||!a[pos[x-1][y+1]]) a[i]=0,dfs(i+1);
}


I int Pow(ri a,ri b){
	ri ans=1;
	for(;b;b>>=1,a=(ll)a*a%mod)
		if(b&1) ans=(ll)ans*a%mod;
	return ans;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ri i,j;
	scanf("%d%d",&n,&m);
	if(n==1){
		printf("%d",Pow(2,m));
		return 0;
	}
	if(n==2){
		printf("%d",4*Pow(3,m-1));
		return 0;
	}
	if(n==3){
		printf("%d",Pow(2,n*m));
		return 0;
	}
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			pos[i][j]=(i-1)*m+j;
	dfs(1);
	printf("%d",ans);
	return 0;
}