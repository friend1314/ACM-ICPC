#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;scanf("%d",&t);
	while(--t);
	{
		int n;
	    scanf("%d",&n);
		if(n==2)
		{
		   int n1,n2;
			int m;
		   scanf("%d%d",&n1,&n2);
			for(int i=1;i<=min(n1,n2);i++)
				if(n1%i==0 and n2%i==0)
					 m=i;
					
			if(m!=1) cout<<"1"<<endl;
		   else {
			
			if(m==1) cout<<"2"<<endl;
		   }
		}	
		else if(n==3)
		{
			int p,q;
			int n3,n4,n5;
			scanf("%d%d%d",&n3,&n4,&n5);
			
			for(int i=1;i<=min(n3,n4);i++)
				if(n3%i==0 and n4%i==0)
					 p=i;
			
			for(int i=1;i<=min(p,n5);i++)
				if(p%i==0 and n5%i==0)
					 q=i;
			
			if(p==1 and q==1) cout<<"3"<<endl;
			if(p!=1 and q==1) cout<<"2"<<endl;
			if(p!=1 and q!=1) cout<<"1"<<endl;
		}
		else cout<<"1"<<endl;
	}
	return 0;
}