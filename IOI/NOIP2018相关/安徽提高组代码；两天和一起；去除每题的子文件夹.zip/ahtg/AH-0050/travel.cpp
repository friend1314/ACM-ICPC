#include<iostream>
#include<cstdio>

using namespace std;

int tong[10000];
int a[10000];
int tot;
	
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,m,u,v;scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		tong[u]++;tong[v]++;
	}
	
	for(int i=1;i<=10000;i++)
	{
		if(tong[i]!=0) a[++tot]=i;
	}
	
	
	
	for(int i=1;i<=tot;i++) printf("%d ",a[i]);
	
	return 0;
}