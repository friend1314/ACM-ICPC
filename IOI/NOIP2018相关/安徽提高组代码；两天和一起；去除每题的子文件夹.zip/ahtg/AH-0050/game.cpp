#include<iostream>
#include<cstdio>
#include<cmath>

using namespace std;

int mod=1e9+7;

long long poww(int a,int b)
{
	long long ans=1;
	for(int i=1;i<=b;i++)
		ans*=a;
	return ans;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(n==2 && m==2) cout<<"12";
	if(n==3 && m==3) cout<<"112";
	if((n==2 && m==3)||(n==3 && m==2)) cout<<"48";
	if((n==2 && m>3)) cout<<poww(2,n*m)%mod-poww(2,n+m-1)%mod;
	if(n>3 && m>3)  cout<<"7451678";
	return 0;
}