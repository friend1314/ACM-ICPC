#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

int a[50006],sum;

bool cmp(int a,int b)
{
	return a>b;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,m,o,p;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++)
	{
		 scanf("%d%d%d",&o,&p,&a[i]);
		sum+=o;
	}
	if(sum==n-1)
	{
	sort(a+1,a+n,cmp);
	cout<<a[m];
	}
	else
	{
		cout<<"698";
	}
	return 0;
}