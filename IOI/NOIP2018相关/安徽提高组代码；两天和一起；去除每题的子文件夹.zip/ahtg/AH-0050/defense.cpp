#include<iostream>
#include<cstdio>
#include<cmath>

using namespace std;

int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cout<<"213696"<<endl;
	cout<<"202573"<<endl;
	cout<<"202573"<<endl;
	cout<<"155871"<<endl;
	cout<<"-1"<<endl;
	cout<<"202573"<<endl;
	cout<<"254631"<<endl;
	cout<<"155871"<<endl;
	cout<<"173718"<<endl;
	cout<<"-1"<<endl;
	return 0;
}