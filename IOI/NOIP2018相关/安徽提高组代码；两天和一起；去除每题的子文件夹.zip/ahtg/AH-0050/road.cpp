#include<cstdio>
#include<cstring>
#include<iostream>

using namespace std;

int n,d[100005],m=12345,tot=1;
bool flag[100005];
long long ans;

int read()
{
	int W=1,X=0;
	char c=getchar();
	if(c<'0' or c>'9') if(c=='-'){W=-1;c=getchar();}
	if(c>='0' and c<='9') {X=(X<<3)+(X<<1)+c-'0';c=getchar();}
	return W*X;
}

void f(int a,int b)
{
	if(a>b) return;
	int p, m=12345;
	
	if(a==b) m=d[a],p=a;
	else
	{
	for(int i=a;i<=b;i++)
		if (d[i]<=m)
		{
			m=d[i];
			p=i;
		}
	}
	ans+=m;
	
	for(int i=a;i<=b;i++)
		d[i]-=m;
	if(d[a]==d[p]) f(a+1,p-1);
	else f(a,p-1);
	if(d[p]==d[b]) f(p+1,b-1);
	else f(p+1,b);
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	  scanf("%d",&d[i]);
	
	f(1,n);
	
	printf("%lld",ans);
	
	return 0;
}