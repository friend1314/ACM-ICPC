# include <bits/stdc++.h>
using namespace std ;
int   a[11],n=0;
int  tiantu(int q,int w)
{long long ans=0;
	int i,bol1=1;
	while (bol1=1)
	{
	for(i=q;i<=w;i++)
	{a[i]--;}//tiantu
	for(i=q;i<=w;i++)
	{if(a[i]==0) {bol1=0;break;}
	}	//panduan
	ans++;}
return ans;
	}
int main()
{int i,j,e=1,asd=0;long long s=0;
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	memset(a,0,sizeof(a));
	cin>>n;
for(i=1;i<=n;i++)
{cin>>a[i];cout<<a[i]<<"warwa"<<endl
;}
s=tiantu(1,n);
while(asd<n)
	{
		asd=0;e=1
		;for(j=1;j<=n;j++)
	{
	if(a[j]==0) {s+=tiantu (e,j-1);  e=j;}
	}
	for(j=1;j<=n;j++)
	{
		if(a[j]==0) asd++;
	}
}
cout<<s;
} 