#include <bits/stdc++.h>
using namespace std;
long long s,q,w,y,t;
int a[10][1000001];
void pan(int m,int n)//m>>n
{bool bol=1;
	if(t=m) for(int i=1;i<=y;i++)
	{	if(a[i][n-1]>a[i-1][n]) {bol=0;break;}	
		}
		else  for(int i=1;i<=t;i++)
		{
			
			
			}
	for(int j=1;j<=n;j++)

	if(bol==0) return ;
	if(m==q&&n==w) s++;
	}
main()
{freopen( "game.in","r",stdin);
freopen("game.out","w",stdout);
int q,w;
memset(a,1,sizeof(a));
cin>>q>>w;
	f(1,1);
	cout<<s;
return 0;}