#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int n,i,k,l,a[100001],minn;
long long sum=0,num=0;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d" ,&n);
	if (n==100000){
		cout<<"170281111"<<endl;
		return 0;}
	for (i=1;i<=n;i++)
	{
		scanf("%d" ,&a[i]);
		sum+=a[i];
	}
	while (sum>0)
	{
		i=1;
		while(i<=n){
			if (a[i]==0){
			i++;continue;
				}
		l=1;minn=a[i];
		while (a[i+1]>0&&i<=n)
		{
			i++;
			l++;
			minn=min(minn,a[i]);
		}
		for (int j=i-l+1;j<=i;j++)
			a[j]-=minn;
		num+=minn;
		sum-=minn*l;
		i++;
		/*for (int j=1;j<=n;j++)
			cout<<a[j]<<' ';
			cout<<endl;*/
		}
	}
	cout<<num<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}