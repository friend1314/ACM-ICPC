#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int f[5001][5001];
int map[5001];
int s[5001];
int vit[5001][5001];
int n,m;
int x,y;
int pd=0,cnt;
void dfs(int k)
{
		if (cnt==n)
		{
			for (int j=1;j<=n;j++)
				cout<<s[j]<<' ';
			cout<<endl;
			pd=1;
			return ;
		}
	for (int i=1;i<=n;i++)
	{
		if (f[k][i]==1&&vit[k][i]==0&&map[i]==0)
		{
			map[i]=1;
			vit[k][i]++;vit[i][k]++;
			s[++cnt]=i;
			dfs(i);
			if (pd==1)		return ;
		}
	}
	for (int i=1;i<=n;i++)
	{
		if (f[k][i]==1&&vit[k][i]==1&&map[i]==1)
		{
			vit[k][i]++;vit[i][k]++;
			dfs(i);
			if (pd==1)	return ;
		}
	}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d" ,&n,&m);
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d" ,&x,&y);
		f[x][y]=f[y][x]=1;
	}
	for (int i=1;i<=n;i++)
	{
		cnt=1;
		memset(vit,0,sizeof(vit));
		memset(map,0,sizeof(map));
		memset(s,0,sizeof(s));
		map[i]=1;
		s[1]=i;
		dfs(i);
		if (pd==1) break;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
