#include<cstdio>
#include<iostream>
using namespace std;
int x,y,z,ans;
int main()
{
	int n,m;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for (int j=1;j<n;j++)
	{
		cin>>x>>y>>z;
		ans+=z;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}