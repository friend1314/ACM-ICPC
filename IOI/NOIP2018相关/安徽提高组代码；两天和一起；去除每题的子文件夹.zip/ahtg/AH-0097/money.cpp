#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int i,j,k,T,n,a[100000];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		cin>>n;
		cout<<n;
	}
}