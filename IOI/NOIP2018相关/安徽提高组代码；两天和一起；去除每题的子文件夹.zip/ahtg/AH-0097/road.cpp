#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int d[100003],ans=0,n;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {scanf("%d",&d[i]);}
	for(int i=1;i<=n;i++) {ans+=max(d[i]-d[i-1],0);}
	printf("%d",ans);
}