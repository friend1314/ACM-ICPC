#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;

int n,m,money[1000],u[1000],v[1000],a[1000],x[1000],b[1000],y[1000];
char s[1000];

int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	cin>>n>>m;
	cin>>s;
	for(int i=1;i<=n;i++) cin>>money[i];
	for(int i=1;i<=n-1;i++) cin>>u[i]>>v[i];
	for(int i=1;i<=m;i++) cin>>a[i]>>x[i]>>b[i]>>y[i];
	for(int i=1;i<=m;i++) printf("-1\n");
}
