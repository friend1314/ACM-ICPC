#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,a[100001],s=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int i=n;i>=1;i--)
	for(int j=1;j<=i;j++)
	{
	int sum=0;
	for(int t=j;t<=i;t++)
	{
	if(a[t]!=0)
	sum++;
	}
	if(sum==i-j+1)
	{
	for(int t=j;t<=i;t++)
	a[t]--;
	s++;
	j--;
	}
	int g=0;
	for(int k=1;k<=n;k++)
	{
	if(a[k]==0)
	g++;
	}
	if(g==n)
	{cout<<s;
	return 0;
	}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
