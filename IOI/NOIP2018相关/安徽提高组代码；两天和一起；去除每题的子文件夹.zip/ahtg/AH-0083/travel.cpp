#include<iostream>
#include<cstdio>
#include<algorithm>
#include<stdio.h>
using namespace std;
int t=0,t1=0,a[5001][5001],n,m,b,c,d[5000]={0},e[1000000];;
int f(int x)
{
	if(t==n)
	return 1;
	else
	{
	int min=100000000;
	e[t1]=x;
	t1++;
	for(int i=0;i<d[x];i++)
	{
		if(a[x][i]<min)
		min=a[x][i];
	}
	t++;
	x=min;
	return f(x);
}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<m;i++)
	{
		cin>>b>>c;
		a[b][d[i]]=c;
		a[c][d[i]]=b;
	}
	f(1);
	for(int i=0;i<t1;i++)
	cout<<e[i]<<" ";
	fclose(stdin);fclose(stdout);
	return 0;
}