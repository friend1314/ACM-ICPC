#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
const int mod=1000000007;
int N,M;
int qpow(int x,int p){
	int res=1;
	while (p){
		if (p&1){
			res=(long long)res*x%mod;
		}
		x=(long long)x*x%mod;
		p>>=1;
	}
	return res;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&N,&M);
	if (N>M){
		swap(N,M);
	}
	if (N==1&&M==1){
		printf("2");
		return 0;
	}
	if (N==1&&M==2){
		printf("4");
		return 0;
	}
	if (N==2&&M==2){
		printf("12");
		return 0;
	}
	if (N==1){
		printf("%d",qpow(2,M));
		return 0;
	}
	if (N==2){
		printf("%d",qpow(2,M+2));
		return 0;
	}
	if (N==3){
		printf("112");
		return 0;
	}
	return 0;
}