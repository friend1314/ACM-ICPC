#include <set>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
struct node{
	int p,s,h;
	node (int p_=0,int s_=0,int h_=0){
		p=p_;
		s=s_;
		h=h_;
	}
};
bool operator <(const node x,const node y){
	if (x.h!=y.h){
		return x.h>y.h;
	}
	else{
		return x.p<y.p;
	}
}
set<node>S;
set<node>::iterator T[222222];
int N,A[222222],F[222222];
long long ANS=0;
int find(int x){
	if (F[x]==x){
		return x;
	}
	else{
		return F[x]=find(F[x]);
	}
}
int main(){
	int las=1;
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&N);
	for (int i=1;i<=N;i++){
		scanf("%d",&A[i]);
		F[i]=i;
	}
	A[N+1]=-1;
	for (int i=2;i<=N+1;i++){
		if (A[las]!=A[i]){
			if (A[las]){
				T[las]=S.insert(node(las,i-las,A[las])).first;
			}
			las=i;
		}
		else{
			F[i]=las;
		}
	}
	F[0]=0;
	F[N+1]=N+1;
	while (!S.empty()){
		node p=(*S.begin());
		S.erase(S.begin());
		int u=find(p.p-1),v=find(p.p+p.s),f;
		if (u==0&&v==N+1){
			ANS+=A[p.p];
			continue;
		}
		if (u==0||v==N+1){
			if (u==0){
				f=v;
			}
			if (v==N+1){
				f=u;
			}
		}
		else{
			if (A[u]<=A[v]){
				f=v;
			}
			else{
				f=u;
			}
		}
		ANS+=A[p.p]-A[f];
		A[p.p]=A[f];
		F[f]=F[p.p]=min(p.p,f);
		if (A[f]==0){
			continue;
		}
		node q=(*T[f]);
		S.erase(T[f]);
		T[min(q.p,p.p)]=S.insert(node(min(q.p,p.p),p.s+q.s,q.h)).first;
	}
	printf("%lld",ANS);
	return 0;
}