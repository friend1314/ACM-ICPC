#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
int N,A[111];
bool G[2][26662];
int main(){
	int O,ANS;
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&O);
	while (O--){
		ANS=0;
		memset(G[0],false,sizeof(G[0]));
		G[0][0]=true;
		scanf("%d",&N);
		for (int i=1;i<=N;i++){
			scanf("%d",&A[i]);
		}
		sort(A+1,A+N+1);
		for (int i=1;i<=N;i++){
			memcpy(G[i&1],G[(i&1)^1],sizeof(G[i&1]));
			int x=A[i];
			if (G[i&1][x]){
				continue;
			}
			ANS++;
			for (register int j=x;j<=25000;j++){
				G[i&1][j]|=G[i&1][j-x];
			}
		}
		printf("%d\n",ANS);
	}
	return 0;
}