#include <vector>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
char C[11];
int N,M,K,P[111111],L[111111];
long long F[111111][2],LF[111111][2];
bool O[111111];
vector<int>E[111111];
bool dfs(int x,int y,int f){
	if (x==y){
		O[x]=1;
		L[++K]=x;
		return true;
	}
	bool t=false;
	for (vector<int>::iterator i=E[x].begin();i!=E[x].end();i++){
		if ((*i)!=f){
			t|=dfs((*i),y,x);
			if (t){
				break;
			}
		}
	}
	if (t){
		O[x]=1;
		L[++K]=x;
	}
	return t;
}
void calc(int x,int f){
	F[x][1]=P[x];
	for (vector<int>::iterator i=E[x].begin();i!=E[x].end();i++){
		if ((*i)!=f&&(!O[x])){
			calc((*i),x);
			F[x][0]+=F[*i][1];
			F[x][1]+=min(F[*i][0],F[*i][1]);
		}
	}
}
void work1(){
	int u,v,a,b;
	for (int i=1;i<=M;i++){
		memset(L,0,sizeof(L));
		memset(F,0,sizeof(F));
		memset(LF,0x3f,sizeof(LF));
		scanf("%d%d%d%d",&u,&a,&v,&b);
		K=0;
		memset(O,0,sizeof(O));
		dfs(u,v,0);
		if (K==2&&a==0&&b==0){
			printf("-1\n");
			continue;
		}
		for (int j=1;j<=K;j++){
			calc(L[i],0);
		}
		LF[1][b]=F[v][b];
		for (int j=2;j<K;j++){
			LF[j][0]=LF[j-1][1]+F[L[j]][0];
			LF[j][1]=min(LF[j-1][1]+F[L[j]][1],LF[j-1][0]+F[L[j]][1]);
		}
		if (a){
			LF[K][1]=min(LF[K-1][1]+F[u][1],LF[K-1][0]+F[u][1]);
		}
		else{
			LF[K][0]=LF[K-1][1]+F[u][0];
		}
		printf("%lld\n",LF[K][a]);
	}
}
int main(){
	int u,v;
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d%s",&N,&M,C);
	for (int i=1;i<=N;i++){
		scanf("%d",&P[i]);
	}
	for (int i=1;i!=N;i++){
		scanf("%d%d",&u,&v);
		E[u].push_back(v);
		E[v].push_back(u);
	}
	if (N<=2000&&M<=2000){
		work1();
		return 0;
	}
	return 0;
}