#include <set>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
void readx(int&x){
	int c=getchar(),f=1;
	while (c>'9'||c<'0'){
		if (c=='-'){
			f=-1;
		}
	}
	x=c-'0';
	c=getchar();
	while ('0'<=c&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	x*=f;
}
int N,M,K,T,S,H[55555],F[55555],L[55555];
bool Z[55555];
multiset<long long>Q[55555];
struct edge{
	int adj,nex,wei;
	edge (const int a_=0,const int n_=0,const int w_=0){
		adj=a_;
		nex=n_;
		wei=w_;
	}
}E[222222];
void add(int u,int v,int w){
	E[++T]=edge(v,H[u],w);
	H[u]=T;
	E[++T]=edge(u,H[v],w);
	H[v]=T;
}
void dfs0(int x){
	Z[x]=false;
	for (int i=H[x];i;i=E[i].nex){
		if (E[i].adj!=F[x]){
			Z[x]=true;
			F[E[i].adj]=x;
			L[E[i].adj]=E[i].wei;
			dfs0(E[i].adj);
		}
	}
}
void dfs(int x){
	for (int i=H[x];i;i=E[i].nex){
		if (E[i].adj!=F[x]){
			dfs(E[i].adj);
		}
	}
	set<long long>::iterator i=Q[x].begin(),j,l;
	while (i!=Q[x].end()){
		long long mxx=(*Q[x].rbegin());
		long long g=(*i);
		if (g+mxx<K){
			i++;
			continue;
		}
		j=i;
		j++;
		Q[x].erase(i);
		l=Q[x].lower_bound(K-g);
		if (l!=Q[x].end()){
			S++;
			if (j==l){
				j++;
			}
			Q[x].erase(l);
		}
		else{
			Q[x].insert(g);
		}
		i=j;
	}
	if (Q[x].empty()){
		if (L[x]>=K){
			S++;
		}
		else{
			Q[F[x]].insert(L[x]);
		}
	}
	else{
		long long g=L[x]+(*Q[x].rbegin());
		if (g>=K){
			S++;
		}
		else{
			Q[F[x]].insert(g);
		}
	}
}
bool check(long long x){
	S=0;
	K=x;
	for (int i=0;i<=N;i++){
		if (Z[i]){
			Q[i].clear();
		}
	}
	dfs(1);
	return (S>=M);
}
int main(){
	int u,v,w;
	long long l=1,r=0,m,ans=0;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	readx(N);
	readx(M);
	T=N;
	for (int i=1;i<N;i++){
		readx(u);
		readx(v);
		readx(w);
		add(u,v,w);
		r+=w;
	}
	r/=M;
	dfs0(1);
	F[1]=0;
	while (l<=r){
		m=(l+r)>>1;
		if (check(m)){
			ans=max(ans,m);
			l=m+1;
		}
		else{
			r=m-1;
		}
	}
	printf("%lld",ans);
	return 0;
}