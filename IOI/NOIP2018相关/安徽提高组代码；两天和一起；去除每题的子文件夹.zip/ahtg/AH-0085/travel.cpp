#include <vector>
#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <algorithm>
using namespace std;
int N,M,U[5555],V[5555];
bool G[5555];
vector<int>E[5555],RES,ANS,CIR;
void dfs(int x,int f){
	RES.push_back(x);
	G[x]=false;
	for (vector<int>::iterator i=E[x].begin();i!=E[x].end();i++){
		if ((*i)>0&&(*i)!=f&&G[*i]){
			dfs((*i),x);
		}
	}
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&N,&M);
	for (int i=1;i<=N;i++){
		ANS.push_back(N-i+1);
	}
	for (int i=1;i<=M;i++){
		scanf("%d%d",&U[i],&V[i]);
		E[U[i]].push_back(V[i]);
		E[V[i]].push_back(U[i]);
	}
	for (int i=1;i<=N;i++){
		sort(E[i].begin(),E[i].end());
	}
	if (N==M){
		for (int i=1;i<=M;i++){
			int u=U[i],v=V[i],su=E[u].size(),sv=E[v].size(),pu,pv;
			for (int j=0;j!=su;j++){
				if (E[u][j]==v){
					E[u][j]=-v;
					pu=j;
					break;
				}
			}
			for (int j=0;j!=sv;j++){
				if (E[v][j]==u){
					E[v][j]=-u;
					pv=j;
					break;
				}
			}
			memset(G,true,sizeof(G));
			RES.clear();
			dfs(1,0);
			E[u][pu]=v;
			E[v][pv]=u;
			if ((int)RES.size()<N){
				continue;
			}
			bool f=false;
			for (int j=0;j!=N;j++){
				if (RES[j]!=ANS[j]){
					f=(RES[j]<ANS[j]);
					break;
				}
			}
			if (f){
				ANS=RES;
			}
		}
		for (int i=0;i!=N;i++){
			printf("%d ",ANS[i]);
		}
	}
	else{
		memset(G,true,sizeof(G));
		RES.clear();
		dfs(1,0);
		for (int i=0;i!=N;i++){
			printf("%d ",RES[i]);
		}
	}
	return 0;
}