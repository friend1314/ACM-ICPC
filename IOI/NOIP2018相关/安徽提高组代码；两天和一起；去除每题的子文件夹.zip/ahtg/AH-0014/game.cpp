#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
long long n,m,dp[10][1000050];
long long dfs1(int x,bool st,long long sum){
	if(x==m){
		return sum*2%1000000007;//dp[1 0][m]=2
	}
	long long ans=0;
	if(st==0){
		ans+=dfs1(x+1,0,sum*4);//dp[0][x+1]+=dp[0][x]*4
		ans%=1000000007;
	}
	if(st==1){
		ans+=dfs1(x+1,0,sum);//dp[0][x+1]+=dp[1][x]
		ans%=1000000007;
		ans+=dfs1(x+1,1,sum*2);//dp[1][x+1]=dp[1][x]*2
		ans%=1000000007;
	}
	return ans;
	
}
/*long long dfs(int x,int y,bool st,long long sum){
	if(x==1&&y==1)  sum=2;
	if(x==n&&y==m) return sum*2%1000000007;
	long long ans=0;
	if(st==1){
		if(x<n) ans+=dfs()
	}
}*/
long long ksm(long long a,long long b){
	long long ans=1;
	while(b>0){
		if(b%2==1) ans=(ans*a)%1000000007;
		b=b>>1;
		a=(a*a)%1000000007;
	}
	return ans;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m;
	if(n>m){
		int nn=n;n=m;m=nn;
	}
	if(n==1) {
		cout<<ksm(2,m)<<endl;
		return 0;
	}
	if(n==2){
		dp[1][1]=2;dp[0][1]=0;
		for(int i=2;i<=m;i++){
			dp[0][i]=(dp[0][i-1]*4+dp[1][i-1])%1000000007;
			dp[1][i]=dp[1][i-1]*2%1000000007;
		}
		cout<<(dp[0][m]+dp[1][m])*2%1000000007;
		//cout<<dfs1(2,1,1)<<endl;
		return 0;
	}
	if(n==3&&m==3){
		cout<<112<<endl;
		return 0;
	}
	
}