#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,head[100050];
struct node{
	int to,next,w;
}e[400050];
int cnt=0,vis[100050];
long long p[100050],dp[100050][2];
//void add
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	string s;
	cin>>n>>m>>s;;
	if(s[0]=='A'){
		for(int i=1;i<=n;i++){
			scanf("%lld",&p[i]);
		}
		for(int i=1;i<n;i++){
			int x,y;
			scanf("%d%d",&x,&y);
		}
		if(n<=2000){
			while(m--){
				memset(dp,0,sizeof(dp));
				int a,b,x,y;
				scanf("%d%d%d%d",&a,&x,&b,&y);
				vis[a]=x+1;vis[b]=y+1;
				for(int i=1;i<=n;i++){
					dp[i][1]=min(dp[i-1][1],dp[i-1][0])+p[i];
					dp[i][0]=dp[i-1][1];
					if(vis[i]==1) dp[i][1]=999999999999;
					if(vis[i]==2) dp[i][0]=999999999999;
				}
				vis[a]=0;vis[b]=0;
				if(min(dp[n][1],dp[n][0])>=999999999999) {
					printf("-1\n");
					continue;
				}
				printf("%lld\n",min(dp[n][1],dp[n][0]));
			}
		}
	}
	for(int i=1;i<=n;i++){
		int x;
		scanf("%d",&x);
//		add(0,)
	}
}