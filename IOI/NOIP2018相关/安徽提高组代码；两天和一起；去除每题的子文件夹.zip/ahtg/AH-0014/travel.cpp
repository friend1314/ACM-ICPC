#include<iostream>
#include<cstdio>
#include<set>
#include<cstring>
using namespace std;
struct node{
	int to,next;
}e[100050];
int n,m,head[100050],sonh[100050];
struct soon{
	int next,u;
}son[100050];
set<int>s[5050];
void dfs1(int u,int fau){
	for(int i=head[u];i!=-1;i=e[i].next){
		if(e[i].to!=fau){ 
			dfs1(e[i].to,u);
			s[u].insert(e[i].to);
		}
	}
}
int fr[100050],vvis[100050];
set<string>sq;
/*void dfs(int u,int fau,string s,int cnt){
	if(cnt==n)  {
		sq.insert(s);
	}
	if(s[s.size()-2]==u){
		s--;
		dfs(u,fr[u]);
	}
	for(int i=head[u];i!=-1;i=e[i].next){
		if(e[i].to!=fau) dfs(e[i].to,u,cnt+1);
	}
}*/
void dfs2(int u,int fau){
	printf("%d ",u);
	for(set<int>::iterator it=s[u].begin();it!=s[u].end();it++){
		dfs2(*it,u);
	}
}
void add(int cnt,int u,int v){
	e[cnt].to=v;
	e[cnt].next=head[u];head[u]=cnt;
}
int main(){
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	memset(head,-1,sizeof(head));
	cin>>n>>m;
		for(int i=1;i<=m;i++){
			int x,y,z;
			scanf("%d%d",&x,&y);
			add(i*2-1,x,y);add(i*2,y,x);
		}
		dfs1(1,0);
		dfs2(1,0);
	/*if(m==n){
		dfs(1,0,"");
		for(int i=0;i<(*s.begin()).size();i++){
			cout<<s[i]-'0'<<' ';
		}
	}*/
	fclose(stdin);
	fclose(stdout);
	return 0;
}