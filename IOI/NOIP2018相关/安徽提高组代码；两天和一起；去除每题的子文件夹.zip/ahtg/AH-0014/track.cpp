#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,head[50050],a[50050],b[50050],c[50050],dep[50050],fa[50050][25],dis[50050];
struct node{
	int  to,next,w;
}e[200050];
bool cmp(node a,node b){
	return a.w<b.w;
}
void add(int cnt,int u,int v,int w){
	e[cnt].to=v;e[cnt].w=w;
	e[cnt].next=head[u];head[u]=cnt;
}
void dfs(int u,int fau,int w){
	dep[u]=dep[fau]+1;
	fa[u][0]=fau;
	dis[u]=dis[fau]+w;
	for(int i=1;(1<<i)<=dep[u];i++){
		fa[u][i]=fa[fa[u][i-1]][i-1];
	}
	for(int i=head[u];i!=-1;i=e[i].next){
		if(e[i].to!=fau) dfs(e[i].to,u,e[i].w);
	}
}
int lca(int x,int y){
	if(dep[x]>dep[y]) {int xx=x;x=y;y=xx;}
	for(int i=20;i>=0;i--){
		if(dep[y]-dep[x]>=(1<<i)) y=fa[y][i];
	}
	if(x==y) return x;
	for(int i=20;(1<<i)>=dep[x];i--){
		if(fa[x][i]!=fa[y][i]) {x=fa[x][i];y=fa[y][i];}
	}
	return fa[x][0];
}
bool check(int k){
	int ans=0;
	for(int i=1;i<=n-1;i++){
		int q=c[i];
		while(q<k){
			i++;q+=c[i];ans++;
			if(ans>n-m) return false ;
		}
		i--;ans--;
	}
	return true;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	cin>>n>>m;
	int q1=0,q2=0;
	e[0].w=0;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&a[i],&b[i],&c[i]);
		if(a[i]==1||b[i]==1) q1++;
		if(b[i]==a[i]+1) q2++;
	}
	if(m==1){
		for(int i=1;i<n;i++){
			add(i*2-1,a[i],b[i],c[i]);
			add(i*2,b[i],a[i],c[i]);
		}
		dfs(1,0,0);
		int ans=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				ans=max(ans,dis[i]+dis[j]-2*dis[lca(i,j)]);
				cout<<i<<' '<<j<<' '<<lca(i,j)<<' '<<dis[i]+dis[j]-2*dis[lca(i,j)]<<' '<<ans<<endl;
			}
		}
		cout<<ans<<endl;
	}
	if(q2==n-1){
		for(int i=1;i<n;i++) {
			add(i,a[i],b[i],c[i]);
		}
		int l=0,r=99999999;
		int mid=(l+r)>>1;
		while(l<r){
			mid=(l+r)>>1;
			cout<<mid<<' '<<check(mid)<<endl;
			if(check(mid)) l=mid+1;
			else r=mid;
		}
		cout<<mid<<endl;
		return 0;
	}
	if(q1==n-1){
		int ans=9999999;
		for(int i=1;i<n;i++) {
			add(i,a[i],b[i],c[i]);
		}
		sort(e+1,e+n,cmp);
		for(int i=1;i<=m;i+=2){
			ans=min(ans,e[i].w+e[max(m*2+1-i,0)].w);
		}
		cout<<ans<<endl;
		return 0;
	}
}