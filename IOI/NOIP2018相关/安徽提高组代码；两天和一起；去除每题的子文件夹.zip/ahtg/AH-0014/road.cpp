#include<iostream>
#include<cstdio>
using namespace std;
int n,d[100050];
struct node{
	int l,r,minn,maxx;
}tr[400050];
int min(int a,int b){
	if(a>b) return b;return a;
}
int max(int a,int b){
	if(a>b) return a;return b;
}
void pushup(int k){
	tr[k].minn=min(tr[2*k].minn,tr[2*k+1].minn);
	tr[k].maxx=max(tr[2*k].maxx,tr[2*k+1].maxx);
}
void build(int k,int l,int r){
	tr[k].l=l;tr[k].r=r;
	if(l==r) {tr[k].minn=d[l];tr[k].maxx=d[l];return ;}
	int mid=(l+r)>>1;
	if(l<=mid) build(2*k,l,mid);
	if(r>mid) build(2*k+1,mid+1,r);
	pushup(k);
	return ;
}
int getmin(int k,int x,int y){
	if(x<=tr[k].l&&tr[k].r<=y) return tr[k].minn;
	int mid=(tr[k].l+tr[k].r)>>1;
	int ans=99999999;
	if(x<=mid) ans=min(ans,getmin(2*k,x,y));
	if(y>=mid+1) ans=min(ans,getmin(2*k+1,x,y));
	return ans;
}
int getmax(int k,int x,int y){
	if(x<=tr[k].l&&tr[k].r<=y) return tr[k].maxx;
	int mid=(tr[k].l+tr[k].r)>>1;
	int ans=0;
	if(x<=mid) ans=max(ans,getmax(2*k,x,y));
	if(y>=mid+1) ans=max(ans,getmax(2*k+1,x,y));
	return ans;
}
int cnt=0;
int solve(int l,int r,int sum){
	if(l>r) return 0;
	int ans=0,minx=getmin(1,l,r);
	if(minx>sum) {
		ans+=(minx-sum);sum=minx;
		
	}
	if(l==r) return ans;
	/*if(getmax(1,l,r)>sum){
		int mid=(l+r)>>1;
		if(l<=mid) ans+=solve(l,mid,sum);
		if(r>mid) ans+=solve(mid+1,r,sum);
	} */
	int x=l,minq=d[l];
	for(int i=l;i<=r;i++){
		minq=min(minq,d[i]);
		if(minx==minq){
			ans+=solve(x,i-1,sum);
			x=i+1;
			minq=d[i+1];
		}
	}
	ans+=solve(x,r,sum);
	return ans;
	
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) scanf("%d",&d[i]);
	build(1,1,n);
	/*int q;
	cin>>q;
	while(q--){
		int tg,x,y;
		cin>>tg>>x>>y;
		if(tg==1) cout<< getmin(1,x,y)<<endl;
		if(tg==2) cout<< getmax(1,x,y)<<endl;
	}*/
	cout<<solve(1,n,0)<<endl;
	return 0;
}