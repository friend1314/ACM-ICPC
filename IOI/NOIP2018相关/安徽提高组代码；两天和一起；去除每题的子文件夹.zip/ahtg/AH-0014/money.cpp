#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int T,n,a[50050],vis[50050],ans=0;
bool cmp(int a,int b){
	return a<b;
}
bool check(int x,int y,int z){
	if(x>y) {int xx=x;x=y;y=xx;}
	if(z%x==0) return true;
	if(z%y==0) return true;
	for(int i=1;i*y<=z;i++){
		if(i%x==0) return false;
		if((z-i*y)%x==0) return true;
	}
	return false;
}
void solve(){
	memset(vis,0,sizeof(vis));
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		if(vis[a[i]]==1) continue;
		for(int j=i+1;j<=n;j++){
			if(vis[a[j]]==1) continue;
			if(a[j]%a[i]==0){
				vis[a[j]]=1;
				ans++;
				continue;
			}
			for(int k=j+1;k<=n;k++){
				if(vis[a[k]]==1) continue;
				if(a[k]>(a[i]*a[j]-a[i]-a[j])){
					vis[a[k]]=1;
					ans++;
					continue;
				}
				if(check(a[i] ,a[j],a[k])){
					vis[a[k]]=1;
					ans++;
					continue;
				}
			}
		}
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>T;
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		if(n==2){
			if(a[1]%a[2]==0) printf("1\n");
			else if(a[2]%a[1]==0) printf("1\n");
			else printf("2\n");
			continue;
		}
		else {
			solve();
			cout<<n-ans<<endl;
			ans=0;
		}
	}
	return 0;
}