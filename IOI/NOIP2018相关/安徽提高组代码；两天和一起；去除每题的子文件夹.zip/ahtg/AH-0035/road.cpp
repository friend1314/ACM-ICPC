#include<cstdio>
#include<iostream>
int a[10001];
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i=2,j;
	{
	int n;
	cin>>n;
	for(i=3;i<=n+1;i++)
	cin>>a[i];
	for(i=3;i<=n+1;i++)
	i+=2;
	cout<<i;
}
	fclose(stdin);
	fclose(stdout);
return 0;
}
	
	
	