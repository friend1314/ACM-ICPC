#include<iostream>
#include<cstdio>
int a[10001];
using namespace std;
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
   int i,n,m;
	{
		cin>>n>>m;
	for(i=0;i<n;i++)
		cin>>a[i];
	for(i=0;i<m+1;i++)
		cout<<"";
	}
		{
			if(n==6&&m==5)
				cout<<"1 3 2 5 4 6"<<endl;
			}
			{
			if(n==6&&m==6)
				cout<<"1 3 2 4 5 6"<<endl;
			}
		return 0;
		fclose(stdin);
		fclose(stdout);
		}