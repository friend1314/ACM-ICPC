#include <cstdio>
#include <cstring>

const int P = 1000000007;

int power(int a, int x)
{
	int ans = 1;
	for (; x; x >>= 1, a = 1ll * a * a % P)
		if (x & 1) ans = 1ll * ans * a % P;
	return ans;
}

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int n, m, ans = 0;
	scanf("%d%d", &n, &m);
	if (n == 1)
		printf("%d\n", power(2, m));
	else if (n == 2)
	{
		if (m == 1) printf("4\n");
		else if (m == 2) printf("12\n");
		else printf("%lld\n", 3ll * power(2, 2 * m - 3) % P);
		return 0;
	}
	for (int i = 0; i < 1 << n * m; i++)
	{
		static int c[105][105];
		for (int j = 0; j < n; j++)
			for (int k = 0; k < m; k++)
				c[j][k] = i >> (j * m + k) & 1;
		static char path[100000][10], num[100000][10];
		int tot = 0;
		for (int j = 0; j < 1 << n + m - 2; j++)
		{
			if (__builtin_popcount(j) != n - 1) continue;
			int x = 0, y = 0;
			for (int k = 0; k < n + m - 2; k++)
			{
				num[tot][k] = c[x][y] + '0';
				if (!(j >> k & 1)) path[tot][k] = 'D', x++;
				else path[tot][k] = 'R', y++;
			}
			num[tot][n + m - 2] = c[n - 1][m - 1] + '0';
			tot++;
		}
		bool flag = true;
		for (int j = 0; j < tot && flag; j++)
			for (int k = 0; k < tot && flag; k++)
				if (strcmp(path[k], path[j]) > 0 && strcmp(num[k], num[j]) > 0)
					flag = false;
		if (flag)
			ans++;
	}
	printf("%d\n", ans);
	return 0;
}
