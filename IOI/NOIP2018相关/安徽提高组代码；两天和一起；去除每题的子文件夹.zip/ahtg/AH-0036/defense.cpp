#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 100005;
typedef long long ll;
const ll inf = 5e13;
int n, m, p[maxn], tot, nxt[2 * maxn], fst[maxn], to[2 * maxn], fa[maxn];
int a, x, b, y;
ll f[maxn][2];

struct mat
{
	ll m[2][2];
	mat(ll a = 0, ll b = 0, ll c = 0, ll d = 0)
	{
		m[0][0] = a, m[0][1] = b, m[1][0] = c, m[1][1] = d;
	}
	ll *operator[](int x) { return m[x]; }
	const ll *operator[](int x) const { return m[x]; }
} T[maxn << 2];
mat operator*(const mat &x, const mat &y)
{
	mat z;
	for (int i = 0; i < 2; i++)
		for (int j = 0; j < 2; j++)
		{
			z[i][j] = inf;
			for (int k = 0; k < 2; k++)
				z[i][j] = min(z[i][j], x[i][k] + y[k][j]);
		}
	return z;
}
void update(int u, int l, int r, int ql, int qr, const mat &x)
{
	if (l >= ql && r <= qr)
	{
		T[u] = x;
		return;
	}
	int mid = l + r >> 1;
	if (ql <= mid) update(u << 1, l, mid, ql, qr, x);
	if (qr > mid) update(u << 1 | 1, mid + 1, r, ql, qr, x);
	T[u] = T[u << 1] * T[u << 1 | 1];
}
mat query(int u, int l, int r, int ql, int qr)
{
	if (l >= ql && r <= qr) return T[u];
	int mid = l + r >> 1;
	if (qr <= mid) return query(u << 1, l, mid, ql, qr);
	if (ql > mid) return query(u << 1 | 1, mid + 1, r, ql, qr);
	return query(u << 1, l, mid, ql, qr) * query(u << 1 | 1, mid + 1, r, ql, qr);
}
void build(int u, int l, int r)
{
	if (l == r)
	{
		T[u] = mat(inf, p[l], 0, p[l]);
		return;
	}
	int mid = l + r >> 1;
	build(u << 1, l, mid);
	build(u << 1 | 1, mid + 1, r);
	T[u] = T[u << 1] * T[u << 1 | 1];	
}

void dfs(int u)
{
	f[u][0] = 0;
	f[u][1] = p[u];
	for (int i = fst[u]; i; i = nxt[i])
		if (to[i] != fa[u])
		{
			fa[to[i]] = u;
			dfs(to[i]);
			f[u][0] += f[to[i]][1];
			f[u][1] += min(f[to[i]][0], f[to[i]][1]);
		}
	if (u == a)
		f[u][x ^ 1] = inf;
	else if (u == b)
		f[u][y ^ 1] = inf;
}

int main()
{
	freopen("defense.in", "r", stdin);
	freopen("defense.out", "w", stdout);
	char s[5];
	scanf("%d%d%s", &n, &m, s);
	for (int i = 1; i <= n; i++)
		scanf("%d", p + i);
	for (int i = 1, u, v; i < n; i++)
	{
		scanf("%d%d", &u, &v);
		nxt[++tot] = fst[u]; fst[u] = tot; to[tot] = v;
		nxt[++tot] = fst[v]; fst[v] = tot; to[tot] = u;
	}
	if (s[0] == 'A' && n > 2000 && m > 2000)
	{
		build(1, 1, n);
		mat e = T[1];
		for (int a, x, b, y; m--;)
		{
			scanf("%d%d%d%d", &a, &x, &b, &y);
			if (a > b) swap(a, b), swap(x, y);
			ll c[2];
			if (a > 1)
			{
				mat m = query(1, 1, n, 1, a - 1);
				if (x == 0) c[0] = m[0][1], c[1] = inf;
				else c[0] = inf, c[1] = p[a] + min(m[1][0], m[1][1]);
			}
			else
			{
				if (x == 0) c[0] = 0, c[1] = inf;
				else c[0] = inf, c[1] = p[a];
			}
			ll d[2];
			if (a + 1 < b)
			{
				mat m = query(1, 1, n, a + 1, b - 1);
				if (y == 0) d[0] = min(c[0] + m[0][1], c[1] + m[1][1]), d[1] = inf;
				else d[0] = inf, d[1] = p[b] + min(min(c[0] + m[0][0], c[1] + m[1][0]), min(c[0] + m[0][1], c[1] + m[1][1]));
			}
			else
			{
				if (y == 0) d[0] = c[1], d[1] = inf;
				else d[0] = inf, d[1] = p[b] + min(c[0], c[1]);
			}
			if (b + 1 <= n)
			{
				mat m = query(1, 1, n, b + 1, n);
				ll tmp[2] = {d[0], d[1]};
				d[0] = min(tmp[0] + m[0][0], tmp[1] + m[1][0]);
				d[1] = min(tmp[0] + m[0][1], tmp[1] + m[1][1]);
			}
			printf("%lld\n", min(d[0], d[1]));
		}
	}
	else
	{
		dfs(1);
		for (; m--;)
		{
			scanf("%d%d%d%d", &a, &x, &b, &y);
			dfs(1);
			ll ans = min(f[1][0], f[1][1]);
			if (ans >= 3e10) ans = -1;
			printf("%lld\n", ans);
		}
	}
	return 0;
}
