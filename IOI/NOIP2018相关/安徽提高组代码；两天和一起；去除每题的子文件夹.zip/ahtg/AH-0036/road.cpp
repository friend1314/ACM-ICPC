#include <cstdio>

const int maxn = 100005;
int n, a[maxn], lg[maxn], mn[maxn][18], ans;

int better(int i, int j)
{
	return a[i] < a[j] ? i : j;
}
int query(int l, int r)
{
	int x = lg[r - l + 1];
	return better(mn[l][x], mn[r - (1 << x) + 1][x]);
}

void solve(int l, int r, int tag)
{
	int x = query(l, r);
	ans += a[x] - tag;
	if (l <= x - 1) solve(l, x - 1, a[x]);
	if (x + 1 <= r) solve(x + 1, r, a[x]);
}

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
		scanf("%d", a + i), mn[i][0] = i;
	for (int i = 2; i <= n; i++)
		lg[i] = lg[i >> 1] + 1;
	for (int j = 1; 1 << j <= n; j++)
		for (int i = 1; i + (1 << j) - 1 <= n; i++)
			mn[i][j] = better(mn[i][j - 1], mn[i + (1 << j - 1)][j - 1]);
	solve(1, n, 0);
	printf("%d\n", ans);
	return 0;
}
