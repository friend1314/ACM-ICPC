#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 50005;
int n, m, tot, nxt[2 * maxn], fst[maxn], to[2 * maxn], w[2 * maxn];

namespace m1
{
	int dis[maxn];

	void dfs(int u, int fa)
	{
		for (int i = fst[u]; i; i = nxt[i])
			if (to[i] != fa)
				dis[to[i]] = dis[u] + w[i], dfs(to[i], u);
	}

	void solve()
	{
		dfs(1, 0);
		int u = 1;
		for (int i = 2; i <= n; i++)
			if (dis[i] > dis[u]) u = i;
		dis[u] = 0;
		dfs(u, 0);
		int v = 1;
		for (int i = 2; i <= n; i++)
			if (dis[i] > dis[v]) v = i;
		printf("%d\n", dis[v]);
	}
}

namespace st1
{
	int c[maxn];
	int check(int x)
	{
		int ans = 0, i = n;
		for (; i && c[i] >= x; i--) ans++;
		int p = 1, q = i;
		while (p < q)
		{
			if (c[p] + c[q] >= x) ans++, q--;
			p++;
		}
		return ans;
	}

	void solve()
	{
		for (int i = 1; i <= tot; i += 2)
			c[to[i]] = w[i];
		sort(c + 1, c + 1 + n);
		int l = 1, r = 5e8;
		while (l < r)
		{
			int mid = l + r + 1 >> 1;
			if (check(mid) >= m) l = mid;
			else r = mid - 1;
		}
		printf("%d\n", l);
	}
}

namespace st2
{
	int check(int x)
	{
		static int c[maxn];
		for (int i = 1; i <= tot; i += 2)
			c[to[i]] = w[i];
		for (int i = 3; i <= n; i++)
			c[i] += c[i - 1];
		int ans = 0, lst = 1;
		for (int i = 2; i <= n; i++)
			if (c[i] - c[lst] >= x)
				ans++, lst = i;
		return ans;
	}

	void solve()
	{
		int l = 1, r = 5e8;
		while (l < r)
		{
			int mid = l + r + 1 >> 1;
			if (check(mid) >= m) l = mid;
			else r = mid - 1;
		}
		printf("%d\n", l);
	}
}

int main()
{
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	bool isst1 = true, isst2 = true;
	scanf("%d%d", &n, &m);
	for (int i = 1, a, b, c; i < n; i++)
	{
		scanf("%d%d%d", &a, &b, &c);
		nxt[++tot] = fst[a]; fst[a] = tot; to[tot] = b; w[tot] = c;
		nxt[++tot] = fst[b]; fst[b] = tot; to[tot] = a; w[tot] = c;
		isst1 &= a == 1, isst2 &= b == a + 1;
	}
	if (m == 1) m1::solve();
	else if (isst1) st1::solve();
	else if (isst2) st2::solve();
	return 0;
}
