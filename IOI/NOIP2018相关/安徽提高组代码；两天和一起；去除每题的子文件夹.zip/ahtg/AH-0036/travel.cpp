#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

const int maxn = 5005;
int n, m, from[2 * maxn], to[2 * maxn];
vector<int> g[maxn];

bool cmp(int p, int q)
{
	return to[p] < to[q];
}

namespace tree
{

bool vis[maxn];
void dfs(int u)
{
	printf("%d ", u);
	vis[u] = true;
	for (int i = 0; i < (int)g[u].size(); i++)
		if (!vis[to[g[u][i]]])
			dfs(to[g[u][i]]);	
}

void solve()
{
	dfs(1);
	puts("");
}

}

namespace ut
{

int fa[maxn], cir[maxn], tot, dfn[maxn], dfsclk, ans[maxn], cur[maxn], ed;
bool vis[maxn];

void dfs(int u)
{
	dfn[u] = ++dfsclk;
	for (int i = 0; i < (int)g[u].size(); i++)
	{
		int e = g[u][i];
		if (to[e] == from[fa[u]]) continue;
		if (!dfn[to[e]])
			fa[to[e]] = e, dfs(to[e]);
		else if (dfn[to[e]] < dfn[u])
		{
			for (int j = u; j != to[e]; j = from[fa[j]])
				cir[++tot] = fa[j];
			cir[++tot] = e;
		}
	}
}

void get(int u, int ban)
{
	vis[u] = true;
	cur[++ed] = u;
	for (int i = 0; i < (int)g[u].size(); i++)
	{
		int e = g[u][i];
		if (e == ban || e == (ban ^ 1) || vis[to[e]]) continue;
		get(to[e], ban);
	}
}

void solve()
{
	dfs(1);
	for (int i = 1; i <= tot; i++)
	{
		for (int j = 1; j <= n; j++)
			vis[j] = false;
		ed = 0;
		get(1, cir[i]);
		bool better = true;
		if (ans[1])
		{
			int lcp = 0;
			while (lcp < n && cur[lcp + 1] == ans[lcp + 1]) lcp++;
			better = lcp < n && cur[lcp + 1] < ans[lcp + 1];
		}
		if (better)
			for (int j = 1; j <= n; j++)
				ans[j] = cur[j];
	}
	for (int i = 1; i <= n; i++)
		printf("%d%c", ans[i], " \n"[i == n]);
}

}

int main()
{
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 0, u, v; i < m; i++)
	{
		scanf("%d%d", &u, &v);
		from[2 * i] = u, to[2 * i] = v;
		from[2 * i + 1] = v, to[2 * i + 1] = u;
		g[u].push_back(2 * i);
		g[v].push_back(2 * i + 1);
	}
	for (int i = 1; i <= n; i++)
		sort(g[i].begin(), g[i].end(), cmp);
	if (m == n - 1)
		tree::solve();
	else
		ut::solve();
	return 0;
}
