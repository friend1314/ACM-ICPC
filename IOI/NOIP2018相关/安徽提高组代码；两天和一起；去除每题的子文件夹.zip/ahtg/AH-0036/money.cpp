#include <cstdio>
#include <algorithm>
using namespace std;

int n, a[105], m;
bool f[25005];

int main()
{
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int Z;
	scanf("%d", &Z);
	while (Z--)
	{
		scanf("%d", &n);
		for (int i = 1; i <= n; i++)
			scanf("%d", a + i);
		sort(a + 1, a + 1 + n);
		for (int i = 1; i <= a[n]; i++)
			f[i] = false;
		f[0] = true;
		m = 0;
		for (int i = 1; i <= n; i++)
		{
			if (!f[a[i]]) m++;
			for (int j = a[i]; j <= a[n]; j++)
				f[j] |= f[j - a[i]];
		}
		printf("%d\n", m);
	}
	return 0;
}
