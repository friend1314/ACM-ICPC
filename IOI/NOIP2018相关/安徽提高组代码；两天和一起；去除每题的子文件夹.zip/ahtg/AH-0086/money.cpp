#include <cstdio>
#include <algorithm>
using namespace std;
int T,n,a[101];
bool pd(int x)
{
	if(x==2)return true;
	for(int i=2;i<=x-1;i++)
		if(x%i==0)return false;
	return true;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int v=1;v<=T;v++)
	{
		int pdd=false;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		for(int i=1;i<=n;i++)
			if(a[i]==1){printf("1\n");pdd=true;}
		if(pdd)continue;
		sort(a+1,a+n+1);
		if(n==1){printf("1\n"); continue;}
		if(n==2)
		{
			if(a[2]%a[1]==0){printf("1\n"); continue;}
			if((pd(a[2]))||(pd(a[1]))){printf("%d\n",n); continue;}
		}
		if(n==3)
		{
			int k=0;
			if(pd(a[1]))k++; if(pd(a[2]))k++; if(pd(a[3]))k++;
			if((a[3]%a[2]==0)&&(a[2]%a[1]==0)){printf("1\n"); continue;}
			if((a[3]%a[2]==0)&&(a[3]%a[1]==0)){printf("2\n"); continue;}
			if((a[2]%a[1]==0)){printf("2\n"); continue;}
			if((k==3)||(k==2)){printf("3\n"); continue;}
		}
		int k;
		for(int i=1;i<=n;i++)
			if(pd(a[i]))k++;
		if((k==n)||(k==n-1))printf("%d\n",n); continue;}
	}
	return 0;
}