#include <cstdio>
#include <algorithm>
using namespace std;
int m,n,u[5001],v[5001],ans[5001],temp[5001],point=-1;
bool map[5001];
int mb(int x)
{
	int go=0;
		for(int i=1;i<=m;i++)
		{
			if((u[i]==x)&&(map[v[i]]==false))
			{
				go++;
				temp[go]=v[i];
			}
			if((v[i]==x)&&(map[u[i]]==false))
			{
				go++;
				temp[go]=u[i];
			}
		}
	return go;
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)	scanf("%d%d",&u[i],&v[i]);
	int count=1,t=1,anst=1;
	ans[1]=1; map[1]=true;
	while(anst<=n)
	{
		int go=0;
		go=mb(t);
		if(go>1)point=t;
		if(go==0)
		{
			map[t]=true;
			anst++; ans[anst]=t;
			t=point;
			continue;
		}
		sort(temp+1,temp+go+1);
		t=temp[1]; count++; anst++; ans[anst]=t; map[t]=true; 
	}
	for(int i=1;i<=5001;i++){
		int k=0;
		for(int j=1;j<i;j++)
			if(ans[i]==ans[j]){k=-1; break;}
		if(ans[i]==0)return 0;	
		if(k!=-1)printf("%d ",ans[i]);
	}
	return 0;
}