#include <cstdio>
using namespace std;
int n,d[100001],ans=0;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&d[i]);
	d[0]=0; d[n+1]=0;
	for(int i=0;i<n+1;)
	{
		int s,e;
		s=i;
		for(e=s+1;e<=n+1;e++)
			if(d[e]==0)break;
		if(e==s+1){
			i++;
			continue;
		}
		if(e-1==s+1){
			ans+=d[s+1]; i++;
			continue;
		}
		int min=d[s+1];
		for(int k=s+1;k<e;k++)
			if(min>d[k])min=d[k];
		for(int k=s+1;k<e;k++)
		    d[k]-=min;
		ans+=min;
	}
	printf("%d\n",ans);
	return 0;
}
