#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
#define mod 1000000007
using namespace std;
int m,n,s,a=1;
long long ss;
void road(int i,int j)
{
if(i==n&&m==j)
{s++;return;}
if(i>n||j>m)
return;
road(i+1,j);
road(i,j+1);
}
int main()
{
freopen("game.in","r",stdin);
freopen("game.out","w",stdout);
cin>>n>>m;
	road(1,1);
ss=s*(s-1)/2;
ss%=mod;
long long sss=0,si=3;
int t=1;
for(int i=0;i<=n+m-3;i++)
{
t*=n+m-3-i;
a*=m+n;
t%=mod;
sss+=t*(t+si)%mod;
sss%=mod;
si+=a;
}
cout<<(sss*ss)%mod;
fclose(stdin);fclose(stdout);
return 0;
}
