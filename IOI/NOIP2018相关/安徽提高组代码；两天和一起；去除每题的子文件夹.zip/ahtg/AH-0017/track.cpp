#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int a[1001][1001],n,b,c,l,s=0;
int ro(int x,int y)
{
	if(a[x][y]>0)
	return a[x][y];
	if(x==y)
	return 0;
	for(int i=0;i<n;i++)
	{
		if(a[i][x]>0)
		return ro(i,y)+a[i][x];
		if(a[i][y]>0)
		return ro(x,i)+a[i][y];
	}
	return 0;
}
int main()
{
freopen("track.in","r",stdin);
freopen("track.out","w",stdout);
	cin>>n;
	for(int i=0;i<n-1;i++)
	{
		cin>>b>>c>>l;
		a[b][c]=l;
		a[c][b]=l;
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{if(a[i][j]==0)
		{a[i][j]=ro(i,j);
			a[j][i]=a[i][j];
		}
		if(s<a[i][j])
		s=a[i][j];
		}
	}
	cout<<s;
fclose(stdin);fclose(stdout);
return 0;
}