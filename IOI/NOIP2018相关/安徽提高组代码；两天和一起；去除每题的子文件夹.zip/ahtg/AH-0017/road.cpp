#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[100001],m,ss=1,sss;
int main()
{
freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
cin>>n;
for(int i=0;i<n;i++)
{cin>>a[i];
if(m<a[i])
m=a[i];
}
while(m>0)
{
m--;
for(int i=0;i<n;i++)
{
if(a[i]<=0)
ss=1;
if(ss==1&&a[i]>0)
{
sss++;
ss=0;
}
if(a[i]>0)
a[i]--;	
}
ss=1;
}
cout<<sss;
fclose(stdin);fclose(stdout);
return 0;
}