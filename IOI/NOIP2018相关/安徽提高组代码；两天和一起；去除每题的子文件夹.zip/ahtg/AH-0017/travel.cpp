#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int n,m,a,b,c[5001][5001],d[5001];
int sss(int s,int di)
{
	for(int i=0;i<=di;i++)
	if(s==d[i])
		return 0;
		return 1;
}
void city(int s,int di)
{
	if((d[di]==0||d[di]>s)&&sss(s,di)==1&&s>0)
	d[di]=s;
	if(di==n-1)
	return;
	for(int i=1;i<=n;i++)
	if(c[s][i]==1&&sss(i,di)==1)
	{
		city(i,di+1);
	}
	for(int i=1;i<=n;i++)
	if(c[s][i]==1&&sss(i,di)==0)
	{
		c[s][i]=0;
		c[i][s]=0;
		city(i,di);
	}
	return;
}
int main()
{
freopen("travel.in","r",stdin);
freopen("travel.out","w",stdout);
cin>>n>>m;
for(int i=0;i<m;i++)
{cin>>a>>b;
c[a][b]=1;
c[b][a]=1;
}
city(1,0);
for(int i=0;i<n;i++)
	cout<<d[i]<<" ";
fclose(stdin);fclose(stdout);
return 0;
}