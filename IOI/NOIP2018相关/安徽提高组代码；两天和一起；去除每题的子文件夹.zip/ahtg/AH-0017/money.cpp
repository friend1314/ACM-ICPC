#include<cstdio>
#include<cstring>
#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int n,a[101],m,t;
int bag(int b,int i,int j)
{
	if(b==0)
	return -1;
	if(j==i)
	return 0;
	int s=9999,ss;
	for(int k=1;k<=b/a[j];k++)
	{
		if(b%a[j]==0)
		return -1;
		ss=min(bag(b-a[j]*k,i,j+1),bag(b,i,j+1));
		s=min(s,ss);
	}
	return s;
}
void money(int b,int i)
{
	if(b<a[0]*2)
	return;
	if(bag(b,i,0)==-1)
	{
		m--;
		return;
	}
}
int main()
{
freopen("money.in","r",stdin);
freopen("money.out","w",stdout);
cin>>t;
for(int j=0;j<t;j++)
{
cin>>n;
m=n;
for(int i=0;i<n;i++)
cin>>a[i];
sort(&a[0],&a[n-1]+1);
for(int i=1;i<n;i++)
money(a[i],i);
cout<<m<<endl;
}
fclose(stdin);fclose(stdout);
return 0;
}