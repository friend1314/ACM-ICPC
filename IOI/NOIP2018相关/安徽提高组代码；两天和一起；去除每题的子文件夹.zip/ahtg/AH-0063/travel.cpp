#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
freopen("travel.in","r",stdin);
freopen("travel.out","w",stdout);
int n,m,x,y;
cin>>n>>m;
for(int i=1;i<=m;i++)
		cin>>x>>y;
for(int i=1;i<=m;i++)
		cout<<i<<" ";
return 0;
}