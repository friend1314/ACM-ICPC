#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int t,n,num=0,ans=0,x,y,shang,yu;

void pd(int bc,int c)
{
if(bc%c==0)
	{cout<<1<<endl;return;}
else{cout<<2<<endl;return;}
}

int main()
{
freopen("money.in","r",stdin);
freopen("money.out","w",stdout);
cin>>t;
for(int i=1;i<=t;i++)
	{
	cin>>n;
	if(n==2)
	{
		cin>>x>>y;
		if(x>y)
			pd(x,y);
		else pd(y,x);
		}
	else cout<<n;
	}
return 0;
}