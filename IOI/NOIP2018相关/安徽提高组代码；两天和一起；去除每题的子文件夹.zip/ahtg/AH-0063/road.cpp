#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long n,i,a[100001],ans=0,maxn=-1,minn=10001;
void	f(long x)
{
if(a[x]>maxn)
	maxn=a[x];
if(a[x]<minn)
	minn=a[x];
if(x==n)
	{
	ans=ans+maxn;
	return;
		}
if(a[x]>=a[x+1])
	f(x+1);
else {
	ans=ans+maxn-minn;
	maxn=-1;
	minn=10001;
	f(x+1);
	}
}
int main()
{
freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
cin>>n;
for(i=1;i<=n;i++)
	cin>>a[i];
f(1);
	cout<<ans;
	}