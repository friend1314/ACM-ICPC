#include<bits/stdc++.h>
using namespace std;
int a[100005];
int n;
long long ans;
void f(int x,int y){
	if(y<x) return;
	int m=0x3f3f3f3f,l=1;
	for(int i=x;i<=y;i++) 
	{
		if(m>a[i]){
			m=a[i];
			l=i;
		}
	}
	for(int i=x;i<=y;i++)
		a[i]-=m;
		ans+=m;
	f(x,l-1);
	f(l+1,y);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	f(1,n);
	cout<<ans;
	return 0;
}
	
