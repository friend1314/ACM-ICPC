#include<bits/stdc++.h>
using namespace std;
int a[105],b[105];
bool cmp(int x,int y)
{
	return x<y;
}
bool check(int x,int tot,int f){
	if(tot==a[x]) return 1;
	if(f>tot) return 0;
	for(int i=0;a[x]<=tot+i*b[f];i++)
		if(check(x,tot+i*b[f],f+1)) return 1;
	return 0;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	bool flag=0;
	int n,m,w,T,sum;	
	scanf("%d",&T);
	while(T--){
		memset(b,0,sizeof(b));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
			if(n==1)
			{
				cout<<1<<endl;
				continue;
			}
		sort(a+1,a+n+1,cmp);
		b[1]=a[1];
		for(int i=2;i<=n;i++) 
		{
			if(!check(i,0,1)) b[++sum]=a[i];
		}
		cout<<sum<<endl;
		sum=0;
	}
}
