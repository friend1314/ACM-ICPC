#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int n,m;
	string s;
	scanf("%d%d",&n,m);
	cin>>s;
	for(int i=1;i<=n;i++)
		cout<<-1<<endl;
		return 0;
}