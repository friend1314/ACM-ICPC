//kao shi de shi hou bian yi guo qu hao xiang bian qi you wen ti 
//dan yuan 
#include<bits/stdc++.h>
using namespace std;
struct edge{
	int u,v;
}e[20005];
int head[10005];
int tot,path[10005];
bool vis[10005];
int n,m,cnt=0;
bool cmp(edge a,edge b){
	if(a.u<b.u) return 1;
		if(a.u>b.u) return 0;
	return a.v<b.v;
}
void add(int x,int y){
	e[++cnt].u=head[x];
	e[cnt].v=y;
	head[x]=cnt;
}
void dfs(int x)
{
	path[++tot]=x;
	for(int i=head[x];i;i=e[i].u){
		if(!vis[e[i].v])
			vis[e[i].v]=0;
			dfs(e[i].v);
			vis[e[i].v]=1;
	}		
}
int main(){
	
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int x,y,z;
	memset(head,0,sizeof(head));
	cnt=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		e[++cnt].u=x; 
		e[cnt].v=y;
		e[++cnt].u=y; 
		e[cnt].v=x;
	}
	sort(e+1,e+cnt+1,cmp);
	for(int i=1;i<=cnt;i++) 
		add(e[i].v,e[i].u);
	vis[e[1].u]=1;
	dfs(e[1].u);
	for(int i=1;i<=n;i++)
		cout<<path[i]<<" ";
	return 0; 
}
