#include<bits/stdc++.h>
using namespace std;
struct edge{
	int nxt,v,w;
}e[50005];
bool cmp(edge a,edge b){
	return a.w>b.w;
}
int fa[50005];
int k,tot,n,m;
int find(int x){
	if(x==fa[x]) return x;
		fa[x]=find(fa[x]);
		return fa[x];
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	int x,y,z;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&x,&y,&z);
		e[i]=(edge){x,y,z};
	}
	if(m==1){
		for(int i=1;i<=n;i++) fa[i]=i;
		sort(e+1,e+n,cmp);
		for(int i=1;i<n;i++){
			int fx=find(e[i].nxt),fy=find(e[i].v);
			if(fx!=fy){
				fa[fx]=fy;
				tot+=e[i].w;
				k++;
			}
		}
		cout<<tot<<endl;
		return 0;
	}
	if(e[n-1].nxt==1)
	{
		for(int i=1;i<n;i++)
			tot+=e[i].w;
		cout<<tot;
	}
	else
	{
		for(int i=1;i<=n;i++) fa[i]=i;
		sort(e+1,e+n,cmp);
		for(int i=1;i<n;i++){
			int fx=find(e[i].nxt),fy=find(e[i].v);
			if(fx!=fy){
				fa[fx]=fy;
				tot+=e[i].w;
				k++;
			}
		}
		cout<<tot<<endl;
		return 0;
	}
}
		
		
