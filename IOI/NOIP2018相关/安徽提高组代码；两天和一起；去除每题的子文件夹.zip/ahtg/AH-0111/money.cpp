#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
using namespace std;

long long T;
long long nums;
long long dir[150];
long long dir1[150];
long long factNums = 0;
long long ss=0;
long long k=0;

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%lld",&T);
	for (long long i=1;i<=T;i++)
	{
		ss=0;
		k=0;
		memset(dir,0,sizeof(dir));
		memset(dir1,0,sizeof(dir1));
		scanf("%lld",&nums);
		factNums = nums;
		for (long long j=1;j<=nums;j++)
		{
			scanf("%lld",&dir[j]);
			dir1[j] = dir[j];
		}
		sort(dir1+1,dir1+nums+1);
		long long temp = 1;
		for (long long q=1;q<=nums-1;q++)
		{
			for (long long j=2;j<=nums;j++)
			{
				if (dir1[j] != dir[q])
					dir1[j] %= dir[q];
			}
			sort(dir1+1,dir1+nums+1);
		}	
		
		
		for (long long j=1;j<=nums;j++)
			if (k!=dir1[j] && dir1[j]!=0)
			{
				k = dir1[j];
				ss++;
			}
		cout << ss;
		if (i!=T) cout << endl;
	}
	return 0;
}