#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
using namespace std;

long long num;
long long e=0;
bool finding = 0;
long long tot=0;
long long road[100050];
long long extend[100050][3]; // (0,1) 2-true || false
// long long mins = 0x3f3f3f3f;

int main()
{
	
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	memset(road,0,sizeof(road));
	scanf("%lld",&num);
	
	for (long long i=1;i<=num;i++)
	{
		scanf("%lld",&road[i]);
		if (road[i] != 0 && !finding)
		{
			finding = 1;
			e++;
			extend[e][0] = i;
			extend[e][2] = road[i];
		}
		if (road[i] !=0 && finding)
		{
			if (extend[e][2]>=road[i]) extend[e][2] = road[i];
		}
		if (i==num && road[i]!=0 && finding)
		{
			finding = 0;
			extend[e][1] = i;
		}
		if (road[i] == 0 && finding)
		{
			finding = 0;
			extend[e][1] = i-1;
		}
	}
	
	
	// for (int i=1;i<=e;i++) extend[i] = 0;
	
	
	while (e!=0)
	{
		// printf("DC1:%lld\n",e);
		for (long long i=1;i<=e;i++)
		{
			for (long long j=extend[i][0];j<=extend[i][1];j++)
				road[j] -= extend[i][2];
			tot += extend[i][2];
		}
		
		e=0;
		
		for (long long i=1;i<=num;i++)
		{
			// printf("DC2 %d\n",finding);
			if (road[i] != 0 && !finding)
			{
				// printf("DC3\n");
				finding = 1;
				e++;
				extend[e][0] = i;
				extend[e][2] = road[i];
			}
			if (road[i] !=0 && finding)
			{
				if (extend[e][2]>=road[i]) extend[e][2] = road[i];
			}
			if (i==num && road[i]!=0 && finding)
			{
				finding = 0;
				extend[e][1] = i;
			}

			if (road[i] == 0 && finding)
			{
				finding = 0;
				extend[e][1] = i-1;
			}
		}
	}
	
	printf("%lld",tot);
	return 0;
}