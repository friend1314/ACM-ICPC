#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
using namespace std;

// long long maps[5050][5050] = {};
long long vis[5050];
long long city,road;
long long i,j,k,l;
long long mins;
long long temp1,temp2;
long long res[1000001];
long long resk[1000001];
long long resl=1;
long long visnum=1;
long long kk=0;
long long maps[5050][5050];
char temp3;
bool found = 0;

/*
struct table{
	long long k[10000][2];
	long long num=0;
	void insert(long long x)
	{
		num++;
		k[num][0]= x;
		k[num][1] = 1;
	}
}maps[5050];
*/

void dfs(long long c,long long b) // c - start city; b - nums of having been
{
	// printf("DEBUG:c=%lld b=%lld\n",c,b);
	if (b==city) 
	{		
		if (!found) 
		{
			found = 1;
			for (i=1;i<=resl;i++)
			{
				resk[i] = res[i];				
			}
		}
		if (found)
		{
			for (i=1;i<=resl;i++)
			{
				if (resk[i]>res[i])
				{
					for (j=1;j<=resl;j++)
					{
						resk[j] = res[j];						
					}
					break;
				}
				if (resk[i]<res[i])
					break;
			}
		}	
		return;
	}
	
	for (long long i=1;i<=city;i++)
	{
		
		if (maps[c][i]==1 && maps[i][c]==1)
		{
			
			visnum++;
			// printf("DEBUG2:%lld->%lld %lld\n",c,i,visnum);
			maps[i][c] = 2;
			resl++;
			res[resl] = i;
			
			dfs(i,visnum);
			// printf("test2:%lld\n",i);
			visnum--;
			
			resl--;
			maps[i][c] = 1;
		}
		
		if (maps[c][i] == 2)
		{
			// printf("DEBUG2:%lld->%lld %lld\n",c,i,visnum);
			dfs(i,visnum);
			// printf("test:%lld\n",i);
		}
	}
	
}



int main()
{
	freopen("travel.in","r",stdin);
        freopen("travel.out","w",stdout);
	
	// memset(been,0,sizeof(been));
	memset(res,0,sizeof(res));
	memset(resk,0,sizeof(resk));
	
	scanf("%lld %lld",&city,&road);
	mins = city;
	for (i=1;i<=road;i++)
	{
		// printf("\ni=%lld\n",i);
		scanf("%lld %lld",&temp1,&temp2);
		if (mins>=min(temp1,temp2)) 
			mins = min(temp1,temp2);
		maps[temp1][temp2] = 1;
		maps[temp2][temp1] = 1;
	}
	// vis[mins] = 1;
	res[1] = mins;
	dfs(mins,1);
	for (i=1;i<=city;i++)
		printf("%lld ",resk[i]);
	
	return 0;
}
