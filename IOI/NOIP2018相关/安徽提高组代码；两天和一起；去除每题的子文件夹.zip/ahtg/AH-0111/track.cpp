#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
using namespace std;

long long lk,sd;



int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cout << 16;
	
	return 0;
}
