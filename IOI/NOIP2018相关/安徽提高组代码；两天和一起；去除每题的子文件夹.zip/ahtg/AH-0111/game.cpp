#include <iostream>
#include <cstdio>
#include <string>
#include <cstring>
#include <algorithm>
using namespace std;

long long w,h;

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin >> h >> w;
	cout << 1116;
	
	return 0;
}