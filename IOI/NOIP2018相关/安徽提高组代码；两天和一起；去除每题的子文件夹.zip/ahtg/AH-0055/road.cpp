#include <cstdio>
#include <algorithm>
#define MAXN 100010
using namespace std;

int n,d[MAXN],len;

void tk(int l, int r, int x) {
	for (int i=l; i<=r; i++) 
		d[i] -= x;
}

int md(int l, int r) {
	int ret = 1000000;
	for (int i=l; i<=r; i++) ret = min(ret,d[i]);
	return ret;
}

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	len = n;
	int l=0,input;
	bool flag=false;
	for (int i=0; i<n; i++) {
		scanf("%d",&input);
		if (!flag) {
			d[l] = input;
			flag = true;
			if (l==0 || (d[l]>d[l-1])) {
				l++;
				flag = false;
			}
		} else {
			if (input > d[l]) {
				d[++l] = input;
				l++;
				flag = false;
			} else {
				d[l]=input;
				len--;
			}
		}
	}

	long long ans=0;
	for (;;) {
		int l=0,r;
		while (d[l] == 0) {
			if (l==len-1) goto out;
			l++;
		}
		r = l;
		while (d[r+1] != 0 && r<len-1) r++;
		int x = md(l,r);
		tk(l,r,x);
		ans += x;
	}
	out:
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
