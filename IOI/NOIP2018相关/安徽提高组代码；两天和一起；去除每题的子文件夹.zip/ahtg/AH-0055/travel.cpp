#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
#define MAXN 5010
#define npq priority_queue<int, vector<int>, greater<int> >
#define FILEIO
using namespace std;

int n,m;
struct node {
	int n;
	npq nexts;
} G[MAXN];

vector<int> ans;
bool vis[MAXN];
void dfs(int r) {
	if (vis[r]) return;
	vis[r] = true;
	ans.push_back(r);

	node& cn = G[r];
	while(!cn.nexts.empty()) {
		int c = cn.nexts.top(); cn.nexts.pop();
		dfs(c);
	}
}

int main() {
	#ifdef FILEIO
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	#endif
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; i++) {
		G[i].n=i;
	}
	int u,v;
	for (int i=0; i<m; i++) {
		scanf("%d%d", &u, &v);
		G[u].nexts.push(v);
		G[v].nexts.push(u);
	}

	dfs(1);

	for (int i=0; i<n-1; i++) {
		printf("%d ",ans[i]);
	}
	printf("%d\n",ans[n-1]);

	return 0;
}
