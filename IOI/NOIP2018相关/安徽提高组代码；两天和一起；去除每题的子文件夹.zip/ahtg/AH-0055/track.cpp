#include <cstdio>
#include <algorithm>
#define FILEIO
using namespace std;

int n,m,a[50050],b[50050],l[50050];

int main() {
	#ifdef FILEIO
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	#endif
	scanf("%d%d",&n,&m);
	for (int i=0; i<n-1; i++) {
		scanf("%d%d%d",a+i,b+i,l+i);
	}
	printf("%d\n",114514);
	return 0;
}
