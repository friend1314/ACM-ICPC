#include <cstdio>
#include <algorithm>
#include <vector>
#define MAXN 110
#define FILEIO

using namespace std;


int T,n,a[MAXN];

bool judge(const vector<int>& s, const int& x, const int& ub) {
	if (ub == 0) {
		return x % s[0] == 0;
	}
	int b = s[ub];
	for (int i=0; i<=x/b; i++) {
		if (judge(s,x-b*i,ub-1)) return true;
	}
	return false;
}

bool judge(const vector<int>& s, const int& x) {
	return judge(s,x,s.size()-1);
}

int main() {
	#ifdef FILEIO
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	#endif
	scanf("%d",&T);
	vector<int> s;
	while (T--) {
		s.clear();
		scanf("%d",&n);
		for (int i=0; i<n; i++) scanf("%d",a+i);
		sort(a,a+n);
		s.push_back(a[0]);
		for (int i=1; i<n; i++) {
			if (!judge(s,a[i])) s.push_back(a[i]);
		}
		printf("%d\n",s.size());
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
