#include <algorithm>
#include <iostream>
#include <cstdio>
#include <climits>

using namespace std;

struct Node{
  int v,l,r,tag;
};

struct SegmentTree{
  Node node[400010];

	inline int lc(int n) {return (n<<1);}
	inline int rc(int n) {return ((n<<1)|1);}
	inline int mid(int l,int r) {return ((l+r)>>1);}

	void build(int n,int l,int r){
	  node[n].l=l;
		node[n].r=r;
		if (l==r) {return;}
		build(lc(n),l,mid(l,r));
		build(rc(n),mid(l,r)+1,r);
	}

	void push_up(int n){
    node[n].v=min(node[lc(n)].v,node[rc(n)].v);
	}

	void push_down(int n){
	  node[lc(n)].tag+=node[n].tag;
		node[rc(n)].tag+=node[n].tag;
    node[lc(n)].v+=node[n].tag;
		node[rc(n)].v+=node[n].tag;
		node[n].tag=0;
	}

	void insert(int n,int l,int r,int v){
    if (l<=node[n].l&&r>=node[n].r){
			node[n].v+=v;
			node[n].tag+=v;
			return;
		}
    if (node[n].tag) {push_down(n);}
		int m=mid(node[n].l,node[n].r);
		if (l<=m) {insert(lc(n),l,r,v);}
		if (r>m) {insert(rc(n),l,r,v);}
		push_up(n);
	}

	int query(int n,int l,int r){
    if (l<=node[n].l&&r>=node[n].r){
      return node[n].v;
		}
		if (node[n].tag) {push_down(n);}
		int m=mid(node[n].l,node[n].r),res=INT_MAX;
		if (l<=m) {res=min(res,query(lc(n),l,r));}
		if (r>m) {res=min(res,query(rc(n),l,r));}
		return res;
	}
};

int n;
long long ans=0;
SegmentTree sg;

void fill(int l,int r){
	int last=l,pre=0,t=sg.query(1,l,r);
	ans+=t;
	sg.insert(1,l,r,-t);
	for (int i=l;i<=r;++i){
		int q=sg.query(1,i,i);
		if (q==0&&pre!=0){
			fill(last,i-1);
		}
		if (q!=0&&pre==0){
			last=i;
		}
		pre=q;
	}
	if (pre!=0) {fill(last,r);}
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
  scanf("%d",&n);
	sg.build(1,1,n);
	for (int i=1;i<=n;++i){
		int t;
		scanf("%d",&t);
		sg.insert(1,i,i,t);
	}
  fill(1,n);
	printf("%lld",ans);
  return 0;
}
