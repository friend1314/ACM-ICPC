#include <algorithm>
#include <cstdio>
#include <iostream>

using namespace std;

struct Arc{
  int fr,to,n_arc;
  
  Arc(){
    fr=0;
    to=0;
    n_arc=0;
  }
  
  bool operator< (const Arc& rhs) const{
    return to<rhs.to;
  }
};

struct Node{
  int n,vis,im,om,f_arc,l_arc;
	
  Node(){
    n=0;
    vis=0;
    im=0;
    om=0;
    f_arc=0;
    l_arc=0;
  }
};

struct Graph{
  Node node[5010];
  Arc a[10010];
	
  void connect(int i){
    int arc=i;
    if (!node[a[i].fr].f_arc){
      node[a[i].fr].f_arc=arc;
    } else {
      a[node[a[i].fr].l_arc].n_arc=arc;
    }
    node[a[i].fr].l_arc=arc;
    node[a[i].to].im++;
    node[a[i].fr].om++;
  }
	
  void work(int s){
    printf("%d ",s);
    for (int i=node[s].f_arc;i;i=a[i].n_arc){
      if (a[i].to!=node[s].vis&&!node[a[i].to].vis) {
        node[a[i].to].vis=s;
        work(a[i].to);
      }
    }
	}
};

int n,m;
Graph g;

int main(){
  freopen("travel.in","r",stdin);
  freopen("travel.out","w",stdout);
  scanf("%d %d",&n,&m);
  for (int i=1;i<=m;i++){
    scanf("%d %d",&g.a[i].fr,&g.a[i].to);
    g.a[i+m].fr=g.a[i].to;
    g.a[i+m].to=g.a[i].fr;
  }
  sort(g.a+1,g.a+m*2+1);
  for (int i=1;i<=m*2;i++){
    g.connect(i);
  }
  g.work(1);
  return 0;
}
