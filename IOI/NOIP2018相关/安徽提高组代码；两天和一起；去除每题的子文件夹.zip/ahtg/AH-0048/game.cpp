#include <algorithm>
#include <cstdio>
#include <iostream>

using namespace std;

int ans[10][1000000]={{0},{0,2,4,8},{0,2,12,36},{0,4,36,112}},n,m;

int main(){
  freopen("game.in","r",stdin);
  freopen("game.out","w",stdout);
  scanf("%d %d",&n,&m);
  printf("%d",ans[n][m]);
  return 0;
}