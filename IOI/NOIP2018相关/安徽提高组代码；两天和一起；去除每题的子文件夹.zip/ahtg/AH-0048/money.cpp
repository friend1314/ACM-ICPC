#include <algorithm>
#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int n,T,a[110],ans;
bool t[110];

bool split(int n,int p){
	for (int i=1;i<p;++i){
		if (a[i]>n) continue;
		if (n%a[i]==0) {return true;}
		if(!t[i]){
  		for (int j=n/a[i];j>=1;--j){
			  if (split(n-a[i]*j,i)) {return true;}
		  }
		}
	}
	return false;
}

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(a,0,sizeof(a));
		memset(t,0,sizeof(t));
  	scanf("%d",&n);
  	ans=n;
  	for (int i=1;i<=n;++i){
  		scanf("%d",&a[i]);
	  }
		sort(a+1,a+n+1);
		for (int i=1;i<=n;++i){
			if (split(a[i],i)) {ans--; t[i]=true;}
		}
		printf("%d\n",ans);
  }
	return 0;
}