#include <algorithm>
#include <iostream>
#include <cstdio>

using namespace std;

int n,m,l[500010];
bool c1=true,c2=true;

int main(){
	freopen("track.in","r",stdin);
  freopen("track.out","w",stdout);
	scanf("%d %d",&n,&m);
	for (int i=1;i<=n-1;++i){
		int a,b;
		scanf("%d %d %d",&a,&b,&l[i]);
		if (a!=1) {c1=false;}
		if (b!=a+1) {c2=false;}
	}
	sort(l+1,l+n);
	printf("%d",l[n-m+1]);
  return 0;
}
