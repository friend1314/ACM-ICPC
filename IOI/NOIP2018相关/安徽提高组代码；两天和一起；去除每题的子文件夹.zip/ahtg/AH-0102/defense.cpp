#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<string>
#include<cstring>
#define misaki(i,a,b) for(int i=(a);i<=(b);i++)
#define ll long long int
using namespace std;
const int MAXN=100010;
const int lzy=1e9+7;
inline int read(){
	int n=0,f=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){n=n*10+(ch-'0');ch=getchar();}return f*n;
}
struct Edge{
	int to,next;
}edges[MAXN];
int head[MAXN];
int EdgeCnt=0;
inline void addEdge(int u,int v){
	edges[++EdgeCnt].to=v;
	edges[EdgeCnt].next=head[u];
	head[u]=EdgeCnt;
}
bool vis[MAXN];
int N,M;
string type;
int cost[MAXN];
ll ans=0;
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	N=read();M=read();cin>>type;
	misaki(i,1,N)cost[i]=read();
	misaki(i,1,N-1){
		int a,b,c;
		a=read();b=read();
		addEdge(a,b);
		addEdge(b,a);
	}
	for(int i=1;i<=N;i+=2){
		ans+=cost[i];
	}
	if(type=="A1"){
		while(M--){
			int ta,tb,tx,ty;
			ta=read();tx=read();tb=read();ty=read();
			if(tb%2==1){
				if(ty==0){cout<<"-1";continue;}
				else {
					cout<<ans;
					continue;
				}
			}
			else {
				if(ty==0){
					cout<<ans;
					continue;
				}
				else {
					ans+=cost[tb];
					cout<<ans;ans-=cost[tb];continue;
				}
			}
		}
	}
	if(type=="A3"){
		while(M--){
			int ta,tb,tx,ty;
			ta=read();tx=read();tb=read();ty=read();
			if(ta-tb==1&&ta-tb==-1&&tx==0&&ty==0){cout<<"-1";continue;}
			
		}
	}
	return 0;
}
