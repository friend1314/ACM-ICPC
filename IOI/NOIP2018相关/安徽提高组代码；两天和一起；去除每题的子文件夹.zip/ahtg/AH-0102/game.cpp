#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<string>
#include<cstring>
#define misaki(i,a,b) for(int i=(a);i<=(b);i++)
#define ll long long int
using namespace std;
const int MAXN=100010;
const int lzy=1e9+7;
inline int read(){
	int n=0,f=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){n=n*10+(ch-'0');ch=getchar();}return f*n;
}
inline bool isaSmall(string a,string b){
	for(int i=0;i<(int)a.length();i++){
		if(a[i]==b[i])continue;
		if(a[i]<b[i])return true;
	}
	return false;
}

inline ll ksm(int a,int k){
	if(k==0)return 1;
	if(k==1)return (ll)a%lzy;
	ll mi=(ksm(a,((k>>1)%lzy))%lzy);
	if(k%2==1)return mi*mi*a%lzy;
	else return mi*mi%lzy;
}
int N,M;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	N=read();M=read();
	if(N==1&&M==1){cout<<"0";return 0;}
	if(N==1&&M==2){cout<<"4";return 0;}
	if(N==2&&M==1){cout<<"4";return 0;}
	if(N==2&&M==2){cout<<"12";return 0;}
	if(N==3&&M==1){cout<<"8";return 0;}
	if(N==1&&M==3){cout<<"8";return 0;}
	if(N==3&&M==2){cout<<"65";return 0;}
	if(N==2&&M==3){cout<<"65";return 0;}
	if(N==3&&M==3){cout<<"112";return 0;}
	if(N==1&&M!=1&&M!=2){cout<<(ksm(2,M)%lzy);return 0;}
	
	return 0;
}
