#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<cstring>
#define misaki(i,a,b) for(int i=(a);i<=(b);i++)
using namespace std;
const int MAXN=100010;
inline int read(){
	int n=0,f=1;char ch=getchar();while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){n=n*10+(ch-'0');ch=getchar();}return f*n;
}
int c[MAXN];
int N,ans=0,cnt=1,vis[MAXN];
vector<int> v;
inline void go(int l,int r){
	if(l==r){
		ans+=c[l];
		c[l]-=c[l];
		return;
	}
	int temp=2147483647;
	misaki(i,l,r){
		if(temp>c[i]){
			temp=c[i];
		}
	}
	misaki(i,l,r){
		c[i]-=temp;
	}//misaki(i,1,N)cout<<"!"<<c[i]<<"! ";
	ans+=temp;
	misaki(i,l,r){
		if(c[i]==0){
			vis[cnt]=i;
		}
	}vis[cnt+1]=N;
	//misaki(i,0,cnt)cout<<"cnt!"<<cnt<<"! ";
	misaki(i,1,cnt){
		go(vis[i-1]+1,vis[i]-1);
	}
	memset(vis,0,sizeof(vis));
	cnt=0;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	vis[0]=0;
	N=read();
	misaki(i,1,N){
		c[i]=read();
	}
	int rr=c[2],ss=0;
	misaki(i,1,N){
		if(c[i]==rr)
		ss++;
	}if(ss==N){cout<<rr;return 0;}
	go(1,N);
	//misaki(i,1,N)cout<<"!"<<c[i]<<"! ";
	int next;
	misaki(i,1,N)if(c[i]!=0){next=i;break;}
	go(next,N);
	misaki(i,1,N)if(c[i]!=0){ans+=c[i];c[i]-=c[i];}
	cout<<ans<<endl;
	return 0;
}
