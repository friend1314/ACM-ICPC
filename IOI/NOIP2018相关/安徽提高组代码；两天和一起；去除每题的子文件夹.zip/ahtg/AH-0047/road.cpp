#include<bits/stdc++.h>
using namespace std;
int n;
int a[100010];
long long ans;
void dfs(int l,int r)
{
	if(l>r)return;
	if(l==r)
	{
		ans+=a[l];
		return;
	}
	int m=50000;
	for(int i=l;i<=r;i++)
	{
		m=min(m,a[i]);
	}
	ans+=m;
	int p;
	p=l-1;
	for(int i=l;i<=r;i++)a[i]-=m;
	for(int i=l;i<=r;i++)
	{
		if(!a[i])
		{
			dfs(p+1,i-1);
			p=i;
		}
	}
	dfs(p+1,r);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",a+i);
	dfs(1,n);
	printf("%lld",ans);
	return 0
}
