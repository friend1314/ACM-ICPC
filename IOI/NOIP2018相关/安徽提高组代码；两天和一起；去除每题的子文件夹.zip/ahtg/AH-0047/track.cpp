#include<bits/stdc++.h>
using namespace std;
int n,m;
vector<int>G[10010],E[10010];
int anc[10010][20];
void add(int u,int v,int w)
{
	G[u].push_back(v);
	G[v].push_back(u);
	E[u].push_back(w);
	E[v].push_back(w);
}
int dep[10010],d[10010];
void init(int u,int fa)
{
	anc[u][1]=fa;
	for(int i=1;i<=18;i++)anc[u][i]=anc[anc[u][i-1]][i-1];
}
void dfs(int u,int fa)
{
	for(int i=0;i<G[u].size();i++)
	{
		int v=G[u][i],w=E[u][i];
		if(v==fa)continue;
		d[v]=d[u]+1;dep[v]=dep[u]+w;init(v,u);
		dfs(v,u);
	}
}
int lca(int u,int v)
{
	if(d[u]<d[v])swap(u,v);
	for(int i=18;i>=1;i--)if(d[u]-1<<i >=d[v])u=anc[u][i];
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
}