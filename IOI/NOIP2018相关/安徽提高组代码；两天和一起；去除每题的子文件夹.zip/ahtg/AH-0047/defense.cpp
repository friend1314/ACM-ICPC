#include<bits/stdc++.h>
using namespace std;
int n,m;
int dp[100100];
vector<int>G[100100];
int p[100100];
int judge(int a,int x,int b)
{
	if(b==a)return x;
		else return 2;
}
void add(int u,int v)
{
	G[u].push_back(v);
	G[v].push_back(u);
}
string st;
int Min(int s,int t)
{
	if(s>0&&t>0)return min(s,t);
	else if(s>0)return s;
	return t;
}
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d",&n,&m);
	cin>>st;
	for(int i=1;i<=n;i++)scanf("%d",p+i);
	for(int i=1;i<n;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	if(st[0]=='A')
	{
		if(m<=2000)
		{
			for(int i=1;i<=m;i++)
			{
				int a,x,b,y;
				cin>>a>>x>>b>>y;
				if(abs(a-b)==1&&!x&&!y)
				{
					printf("-1\n");
					continue;
				}
				if(a>b)swap(a,b);
				for(int i=1;i<=n;i++)dp[i]=0;
				if(!(a==1&&!x))dp[1]=p[1];
				if(!(a==2&&!x))dp[2]=p[2]+dp[1];
				for(int i=3;i<=n;i++)
				{
					if((a==i&&!x)||(b==i&&!y))continue;
					dp[i]=p[i];
					if((a==i-1&&!x)||(b==i-1&&!y))dp[i]+=dp[i-2];
					else if((a==i-2&&!x)||(b==i-2&&!y))dp[i]+=dp[i-1];
					else if((a==i-1&&x)||(b==i-1&&y))dp[i]+=dp[i-1];
					else if((a==i-2&&x)||(b==i-2&&y))dp[i]+=dp[i-2];
					else dp[i]+=Min(dp[i-1],dp[i-2]);
				}
				if(a!=n&&b!=n)cout<<Min(dp[n],dp[n-1])<<"\n";
				else if(b==n&&y==1)cout<<dp[n]<<"\n";
				else cout<<Min(dp[n],dp[n-1])<<"\n";
			}
		}
	}
	return 0;
}
