#include<bits/stdc++.h>
using namespace std;
int n,m;
vector<int>G[5100];
struct way
{
	string a;
}o[5100];
int wayss=1;
bool cmp(way t1,way t2)
{
	return t1.a<t2.a;
}
void add(int u,int v)
{
	G[u].push_back(v);
	G[v].push_back(u);
}
int first[5100],vis[5100];
int sum=1;
void dfs(int u,int fa,int ways,int k)
{
	if(!vis[u])
	{
		vis[u]=true;
		first[u]=fa;
		sum++;
		o[ways].a+=u-48;
	}
	if(sum==n)return;
	int s=G[u].size();
	for(int i=0;i<s;i++)
	{
		int p=G[u][i];
		if(!vis[p]||p==first[u])
		{
			dfs(p,u,ways,k);
			ways++;
			wayss++;
		}
	}
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	if(m==n-1)
	{
		vis[1]=true;
		cout<<"1 ";
		dfs(1,0,1,1);
		sort(o+1,o+wayss+1,cmp);
		cout<<o[1].a;
	}
	return 0;
}