#include<bits/stdc++.h>
using namespace std;
int T;
bool judge(int x,int y,int z)
{
	if(z>=x*y-x-y+1)return true;
	for(int i=1;i<=z/x;i++)
	{
		int t=z-i*x;
		if(t%y==0)return true;
	}
	return false;
}
void get(int &n,int a[110])
{
	sort(a+1,a+n+1);
	int b[110],m=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]==a[i-1])continue;
		else b[++m]=a[i];
	}
	for(int i=1;i<=n;i++)a[i]=b[i];
	n=m;
	if(n==1)return;
	int c[110];
	m=0;
	c[++m]=a[1];
	for(int i=2;i<=n;i++)
	{
		bool flag=false;
		for(int j=1;j<i;j++)if(a[i]%a[j]==0)flag=true;
		if(flag)continue;
		else c[++m]=a[i];
	}
	for(int i=1;i<=n;i++)a[i]=c[i];
	n=m;
	if(n<=2)return;
	int d[110];
	m=2;
	d[1]=a[1],d[2]=a[2];
	int f[110];
	bool book[110];
	book[1]=book[2]=false;
	for(int i=3;i<=n;i++)
	{
		book[i]=false;
		if(judge(a[1],a[2],a[i]))
		{
			book[i]=true;
			continue;
		}
		for(int j=1;j<=i-2;j++)
		for(int k=j+1;k<=i-1;k++)
		if(judge(a[j],a[k],a[i]))
		{
			if(j==1&&!book[i])f[k]++;
			else if(!book[i]&&f[k])f[k]++;
			book[i]=true;
		}
	}
	for(int i=3;i<=n;i++)
	{
		if(!book[i])d[++m]=a[i];
	}
	for(int i=1;i<=n;i++)a[i]=d[i];
	n=m;
}
int work(int n,int a[110])
{
	for(int i=1;i<=n;i++)if(a[i]==1)return 1;
	get(n,a);
	return n;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		int n;
		int a[110];
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",a+i);
		printf("%d",work(n,a));
		if(T)printf("\n");
	}
	return 0;
}
