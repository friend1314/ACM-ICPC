#include<iostream>
#include<cstdio>
using namespace std;
int deep[100001];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,i,j;
	long long s=0;
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>deep[i];
	for(i=1;i<=n;i++)
	{
		if(deep[i]!=0)
		{
			for(j=i;j<=n;j++)
			{
				if(deep[j]==0)break;
				else deep[j]--;
			}
			s++;
			if(deep[i]!=0)
			i--;
		}
	}
	cout<<s<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}