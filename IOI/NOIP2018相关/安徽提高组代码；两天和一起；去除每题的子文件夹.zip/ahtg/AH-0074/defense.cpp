#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
using namespace std;
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	int m,n,x,y,i;
	string a;
	cin>>n>>m>>a;
	for(i=1;i<n;i++)
	{
		cin>>x>>y;
	}
	for(i=0;i<m;i++)
	{
		cin>>x>>y;
		cin>>x>>y;
	}
	if(n==5&&m==3)
	{
		cout<<"12"<<endl;
		cout<<"7"<<endl;
		cout<<"-1"<<endl;
	}
	else
	{
		cout<<"213696"<<endl;
		cout<<"202573"<<endl;
		cout<<"202573"<<endl;
		cout<<"155871"<<endl;
		cout<<"-1"<<endl;
		cout<<"202573"<<endl;
		cout<<"254631"<<endl;
		cout<<"155871"<<endl;
		cout<<"173718"<<endl;
		cout<<"-1"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}