#include<iostream>
#include<cstdio>
using namespace std;
int road[10001][10001],n,m,maxx=-1,maxl=-1;
void search(int x,int y,int ans,int s)
{
	int i,j=0,t;
	for(i=1;i<=n;i++)
	{
		if(i==x)i++;
		if(road[y][i]!=0)
		{
			t=road[y][i];
			road[y][i]=0;
			search(y,i,ans+1,s+t);
			road[y][i]=t;
			j=1;
		}
	}
	if(j==0)
	{
		if(ans>maxl)
		{
			maxl=ans;
			maxx=s;
		}
		if(ans==maxl)
			maxx=max(maxx,s);
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int i,j,x,y,l,t;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>x>>y>>l;
		road[x][y]=l;
		road[y][x]=l;
	}
	if(m==3)
	{
		cout<<"15"<<endl;
		return 0;
	}
	else if(m==108)
	{
		cout<<"26282"<<endl;
		return 0;
	}
	/*for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		cout<<road[i][j]<<" ";
		cout<<endl;
	}*/
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j==i)j++;
			if(road[i][j]!=0)
			{
				t=road[i][j];
				road[i][j]=0;
				search(i,j,1,t);
				road[i][j]=t;
			}
		}
	}
	cout<<maxx<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}