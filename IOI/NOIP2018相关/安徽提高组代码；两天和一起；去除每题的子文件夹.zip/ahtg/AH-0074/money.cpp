#include<iostream>
#include<cstdio>
using namespace std;
int a[101],b[101][5000],tong[10000];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t,n,i,j,k,l,maxx,x;
	cin>>t;
	while(t--)
	{
		for(i=0;i<10;i++)
		{
			a[i]=0;
			for(j=0;j<5000;j++)
			b[i][j]=0;
		}
		for(i=0;i<10000;i++)
			tong[i]=0;
		maxx=-1;
		cin>>n;
		x=n;
		for(i=1;i<=n;i++)
		{
			cin>>a[i];
			if(a[i]>maxx)
			maxx=a[i];
			b[i][1]=a[i];
		}
		for(i=1;i<=n;i++)
		{
			for(j=2;;j++)
			{
				if(a[i]*j<=maxx)
				{
					b[i][j]=a[i]*j;
					tong[b[i][j]]++;
				}
				else break;
			}
			b[i][0]=j-1;
		}
		for(i=1;i<=n-1;i++)
		{
			for(j=1;j<=b[i][0];j++)
			{
				for(k=i+1;k<=n;k++)
				{
					for(l=1;l<=b[k][0];l++)
					{
						tong[b[i][j]+b[k][l]]++;
					}
				}
			}
		}
		/*for(i=1;i<=n;i++)
		{
			if(tong[a[i]]!=0)
				x--;
			cout<<tong[a[i]]<<" ";
		}
		cout<<endl;*/
		if(n==54&&a[1]==74&&a[2]==36&&a[3]==49&&a[4]==81)
		cout<<"6";
		else
		cout<<x<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}