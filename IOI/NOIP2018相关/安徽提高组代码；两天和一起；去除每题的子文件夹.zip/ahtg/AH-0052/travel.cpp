#include<cstdio>
#include<iostream>
using namespace std;
int gcd(int m,int n);
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
int i,j,n,a[10000],b[1000000],ans=0;
cin>>i>>j;
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
{
while(1)
{
if(a[i+1]=a[j])
ans++;
}
for(i=1;i<=n;i++)
for(j=1;j<=n-1;j++)
if(b[j]=b[j-1])
ans++;
  if(a[i]=b[i])
  ans++;
   if(a[j]=b[j])
  ans++;
   while(1)
	   {
if(a[i+1]=a[j])
ans++;
}
for(i=1;i<=n;i++)
for(j=1;j<=n-1;j++)
if(b[j]=b[j-1])
ans++;
b[j]=a[i-1];
if(a[i]==0)
	ans++;
	for(i=1;i<=n;i++)
		ans*=a[i]+b[i];
		cout<<ans<<endl;
fclose(stdin);
fclose(stdout);
    return 0;
}
}