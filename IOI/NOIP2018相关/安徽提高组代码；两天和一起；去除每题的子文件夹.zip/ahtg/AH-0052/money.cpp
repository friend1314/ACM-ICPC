#include<cstdio>
#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
int dfs(int m,int b)
int main()
{
	int p[102023132],d,a[1001010],n,t[100025],m,b;
	int x;
	cin>>n;
	for(int i=1;i<=n;i++)
		if(p[i]==a[i])
     	x=a[i]+t[i];
while(n!=0)
{
	x+=d;
	d=n;
	n--;
}
dfs(n,a)=dfs(m,b);
cout<<n<<dfs(m,b);
return 0;
}
int dfs(int m,int n);
{
	int a,b;
	int i;
	for(i=1;i<=n;i++)
	if(dfs(n,a)>=0)
		cout<<dfs(n,a);
		else
		cout<<n;
		return 0;
	}
		