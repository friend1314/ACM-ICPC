#include<cstdio>
#include<iostream>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
int  day,a[10000],i,n,d[10000],b[100000],c[1000000];
int ans=0;
cin>>n;
	cin>>a[i]>>b[i]>>c[i]>>d[i];
for(int i=1;i<=n;i++)
{
for(i=1;i<=n;i++)
if(a[1000]>=1)
d[i]--;
ans++;
}
for(int  j=1;j<=n;j++)
{j-=d[i];
ans++;}
if(d[i]==0)
cout<<ans<<endl;
else
while(i==0)
{
ans+=d[i];
if(d[i]==0)
break;
}
ans=day;
cout<<day;
fclose(stdin);
fclose(stdout);
return 0;
}