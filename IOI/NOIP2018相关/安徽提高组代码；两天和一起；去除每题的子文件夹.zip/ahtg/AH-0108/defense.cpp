#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
	freopen("defence.in","r",stdin);
	freopen("defence.out","w",stdout);
	int n,m;
	char a[10001];
	cin>>n>>m;
	gets(a);
	for(int i=1;i<=m;i++) cout<<-1;
return 0;
}