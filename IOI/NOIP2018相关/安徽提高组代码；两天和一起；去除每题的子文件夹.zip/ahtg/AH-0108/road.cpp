#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(false);
    long n,d[100001];
	long ans = 0,last = 0;
	cin>>n;
	for(int i = 1;i <= n;i++) 
	{
		cin>>d[i];
		if(d[i] > last) ans += d[i] - last;
		last = d[i];
	}
	cout<<ans<<endl;
return 0;
}