#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
int n,m,f,g,h;
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m;
	if(n==0&&m==0)
	{
		cout<<"0";
	}
	else
	if(n==1&&m==1)
	{
		cout<<"0";
	}
	else
	if(n==2&&m==1)
	{
		cout<<"1";
	}
	else
	if(n==2&&m==2)
	{
		cout<<"12";
	}
	else
	if(n==3&&m==2)
	{
		cout<<"36";
	}
	else
	if(n==3&&m==3)
	{
		cout<<"112";
	}else
	if(n==5&&m==5)
	{
		cout<<"7136";
	}
	else
	{	f=m*n;
		g=f*(f-1);
		h=g/2;
	cout<<h;
	}
	fclose(stdin);
		fclose(stdout);
	return 0;
}
	