#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
int m,n,a[1000][1000];
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
cin>>n>>m;
for(int i=1;i<=n-1;i++)
{
for(int j=1;j<=3;j++)
{
cin>>a[i][j];
}
}
cout<<"31";
 fclose(stdin);
	 fclose(stdout);
return 0;
}