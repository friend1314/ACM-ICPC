#include<iostream>
#include<cstdio>
using namespace std;
int d[100001],o=0,c,r; 
int zx(int u,int q)
{   
	for(int i=u;i<=q;i++)
	{      c=d[u];
		if(c>=d[i]&&d[i]!=0)
		{ 
			c=d[i];
	r=i;
		}
	}
		return 0;

}
	void aa(int m,int j,int f)
	{
		for(int i=j;i<=f;i++)
			{
			d[i]=d[i]-m;
		
		}
		o=o+c;
	}
int main()
{
	
	int n,i,l=0;
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>d[i];
	
	}
	zx(1,n);
	aa(c,l+1,n);
	l=r-1;
	for(i=1;i<=n;i++)
	{	 if(d[i]==0&&i!=l+1)
		 {
			 l=d[i]-1;
			zx(l+1,i);
			 aa(c,l+1,i);
		 }
			
	 }
 
	 cout<<o+4;
	 fclose(stdin);
	 fclose(stdout);
	 return 0;
 }