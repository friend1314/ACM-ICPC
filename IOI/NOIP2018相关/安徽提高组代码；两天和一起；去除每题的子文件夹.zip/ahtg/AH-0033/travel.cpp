#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
	int n,m,a[10000][2],d[100000][2],h=0,s=0,t[10000];
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	for(int j=1;j<=2;j++)
	{
	cin>>a[i][j];
	}
d[1][1]=a[1][1];
	int i=1,j=1;
	for(int o=1;o<=n;o++)
	{
		t[o]=o;
	}
	while(i<=m,j<=2)
	{
		if(a[i][j+1]!=d[i][j+1]&&h==0)
		{
			d[i][j+1]=a[i][j+1];s=1;
			j++;
			
		}
		else
		if(a[i+1][j+1]!=d[i+1][j+1]&&h==1)
		{
			d[i+1][j+1]=a[i+1][j+1];s=0;
			i++;j++;
	
		}
		
		else
		if(a[i][j-1]!=d[i][j-1])
		{
			d[i][j-1]=a[i][j-1];
			a[i][j]=0;
			j++;
		}
		else
			if(a[i+1][j-1]!=d[i-1][j])
		{
			d[i+1][j-1]=a[i+1][j-1];
			i++;j--;
		}
		else
		{
			if(s==1)
			{
	h=0;			d[i][j]=a[i-1][j-1];
				
			}
			if(s==0)
			{
				d[i][j]=a[i][j-1];h=1;
				
			}
		}
	}
		for(int i=1;i<=m;i++)
	for(int j=1;j<=2;j++)
	{
		if(d[i][j]!=0)
		{cout<<d[i][j]<<" ";
		}
		}
		for(int o=1;o<=n;o++)
		{
		for(int i=1;i<=m;i++)
	for(int j=1;j<=2;j++)
	{
		if(t[o]==d[i][j])
		{
			t[o]=0;
		}
	}
}
	for(int o=1;o<=n;o++)
	{
		if(t[o]!=0)
			cout<<t[o]<<" ";
		}
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
		