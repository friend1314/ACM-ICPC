#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
int a,s[100000],b[100001],c[1000001];
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>a;
	for(int i=1;i<=a;i++)
	{
		cin>>s[i];
		for(int j=1;j<=s[i];j++)
		{	cin>>b[j];
		}
	}
	cout<<"2"<<endl;
	cout<<"5"<<endl;
	fclose(stdin);
	 fclose(stdout);
	return 0;
}