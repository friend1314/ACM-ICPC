#include<cstdio>
int t,n,mx=0,tp[21],cnt,str[20][100][2];
void slv(int num1,int num2,int sum)
{
	for(int i=num1;i<t;i++)
		for(int j=num2;j<n;j++)
			for(int k=1;sum+k*str[i][j][0]<=mx;k++)
			{
				for(int l=i;l<t;l++)for(int m=j+1;m<n;m++)if(str[l][m][0]==sum+k*str[i][j][0])str[l][m][1]=1;
				if(j==n-1){if(i!=t-1){slv(i+1,0,sum+k*str[i][j][0]);}else{break;}}else{slv(i,j+1,sum+k*str[i][j][0]);}
			}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(int i=0;i<t;i++){scanf("%d",&n);for(int j=0;j<n;j++){scanf("%d",&str[i][j][0]);if(str[i][j][0]>mx)mx=str[i][j][0];}}
	slv(0,0,0);
	for(int i=0;i<t;i++)for(int j=0;j<n;j++){if(str[i][j][1]==0){cnt++;tp[i]=1;for(int k=i;k<t;k++)for(int l=j+1;l<n;l++)if(str[i][j][0]==str[k][l][0])str[k][l][1]=1;}}
	for(int i=0;i<t;i++)if(tp[i]==1)tp[20]++;
	printf("%d\n%d",tp[20],cnt);
	fclose(stdin);fclose(stdout);
	return 0;
}