#include<cstdio>
int cnt,len,str[100000];
void slv(int l,int r,int dpt)
{
	if(l<=r)
	{
		int m,a=10001;
		for(int i=l;i<=r;i++){if(str[i]<a){a=str[i];m=i;}}
		cnt+=str[m]-dpt;
		slv(l,m-1,str[m]);slv(m+1,r,str[m]);
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&len);
	for(int i=0;i<len;i++){scanf("%d",&str[i]);}
	slv(0,len-1,0);
	printf("%d",cnt);
	fclose(stdin);fclose(stdout);
	return 0;
}