#include<cstdio>
#include<iostream>
using namespace std;
typedef long long LL;
const LL INF=0x3f3f3f3f3f3f3f3fLL;
const int N=1e5+5;
LL f[N][2],g[N][2];
int v[N<<1],head[N],fa[N],nxt[N<<1],a[N],tot;
int n,m,pd,ff;
int cur1,cur2,v1,v2;
char ch;
inline void add(int x,int y){
	v[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
inline void dfs(int x,int fa){
	f[x][0]=0;
	f[x][1]=a[x];
	for(int i=head[x];i;i=nxt[i]){
		int y=v[i];
		if(y!=fa){
			dfs(y,x);
			if(f[x][0]!=INF)f[x][0]+=f[y][1];
			if(f[x][1]!=INF)f[x][1]+=min(f[y][0],f[y][1]);
		}
	}
	if(cur1==x){
		if(v1)f[x][0]=INF;
		else f[x][1]=INF;
	}	
	if(cur2==x){
		if(v2)f[x][0]=INF;
		else f[x][1]=INF;
	}
	f[x][0]=min(f[x][0],INF);
	f[x][1]=min(f[x][1],INF);
}
inline void debug(){
	for(int i=1;i<=n;++i){
		printf("i=%d f[i][0]=%lld f[i][1]=%lld\n",i,f[i][0],f[i][1]);
	}
}
int main(){
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d%*c",&n,&m);
	scanf("%c",&ch);
	scanf("%d",&ff);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	for(int i=1;i<n;++i){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	if(ch=='A'&&ff==1){
		f[1][1]=a[1];
		f[1][0]=INF;
		for(int i=2;i<=n;++i){
			f[i][1]=min(f[i-1][0],f[i-1][1])+a[i];
			f[i][0]=f[i-1][1];
		}
		g[n][0]=0;g[n][1]=a[n];g[1][0]=INF;
		for(int i=n-1;i;--i){
			g[i][1]=min(g[i+1][0],g[i+1][1])+a[i];
			if(i>1)g[i][0]=g[i+1][1];
		}
		LL anst;
		for(int i=1;i<=m;++i){
			scanf("%d%d%d%d",&cur1,&v1,&cur2,&v2);
			if(v2){
				anst=f[cur2][v2]+min(g[cur2+1][0],g[cur2+1][1]);
			}
			else{
				anst=f[cur2][v2]+g[cur2+1][1];
			}
			if(anst>=INF)puts("-1");
			else printf("%lld\n",anst);
		}
		return 0;
	}
	for(int i=1;i<=m;++i){
		scanf("%d%d%d%d",&cur1,&v1,&cur2,&v2);
		//clear();
		dfs(1,1);
		//debug();
		if(cur1==1){if(f[1][v1]>=INF)puts("-1");else printf("%lld\n",f[1][v1]);}
		else if(cur2==1){if(f[1][v2]>=INF)puts("-1");else printf("%lld\n",f[1][v2]);}
		else{
			if(min(f[1][0],f[1][1])>=INF)puts("-1");
			else 
			printf("%lld\n",min(f[1][0],f[1][1]));
		}
	}
	return 0;
}