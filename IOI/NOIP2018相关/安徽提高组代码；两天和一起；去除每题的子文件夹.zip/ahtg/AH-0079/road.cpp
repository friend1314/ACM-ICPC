#include<bits/stdc++.h>
using namespace std;
int d[100100],p[100100];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%d",&d[1]);
	int mn=d[1];
	for (int i=2;i<=n;i++)
	{
		scanf("%d",&d[i]);
		if (d[i]<mn) mn=d[i];
	}
	int mk=0,s=mn;
	for (int i=1;i<=n;i++)
		d[i]-=mn;
	int l,r;
	for (int i=0;i<=10000;i++)
	{
		mk=0;
		int vis=0;
		for (int j=1;j<=n;j++)
		{
			if (d[j]!=0)
			{
				if (vis==0)
				{
					vis=1;
					l=j;
					r=j;
					mn=d[j];
				}
				if(mn>d[j]) 
					mn=d[j];
				r=j;
				mk=1;
			}
			else
				if (vis==1)
				{
					vis=0;
					s+=mn;
					for (int k=l;k<=r;k++)
						d[k]-=mn;
				}
		}
		if (vis==1)
				{
					vis=0;
					s+=mn;
					for (int k=l;k<=r;k++)
						d[k]-=mn;
				}
		if (mk==0) 
		{
			printf("%d",s);
			return 0;
		}
	}
	return 0;	
}