#include<bits/stdc++.h>
using namespace std;
int n,m,head[100100],vis[100100],a=-1,b=-1,ma=-1,mb=-1,cnt=0;
long long f[100100][2],q[100100];
struct edge
{
	int nxt,to;
}e[100100];
long long min(long long a,long long b)
{
	if (a<b) return a;
		else return b;
}
void addedge(int x,int y)
{
	cnt++;
	e[cnt].to=y;
	e[cnt].nxt=head[x];
	head[x]=cnt;
}
void dp(int pos)
{
	vis[pos]=0;
	int mk=0;
	for (int i=head[pos];i;i=e[i].nxt)
		if (vis[e[i].to]==1)
			mk=1;
	f[pos][0]=40000000000;
	f[pos][1]=40000000000;
	if (mk==0)
	{
		if (pos==a&&ma==0) 
			f[pos][0]=0;
		else
			if (pos==a&&ma==1)
				f[pos][1]=q[pos];
			else 
				if (pos==b&&mb==0) 
					f[pos][0]=0;
				else
					if (pos==b&&mb==1)
						f[pos][1]=q[pos];
					else
					{
						f[pos][0]=0;
						f[pos][1]=q[pos];
					}
		return ;
	}
	f[pos][0]=0;
	f[pos][1]=q[pos];
	if (pos==a&&ma==0) f[pos][1]=40000000000;
	if (pos==b&&mb==0) f[pos][1]=40000000000;
	for (int i=head[pos];i;i=e[i].nxt)
	{
		if (vis[e[i].to]==1)
		{
			dp(e[i].to);
		if (pos==a&&ma==0) 
			f[pos][0]+=f[e[i].to][1];
		else
			if (pos==a&&ma==1)
				f[pos][1]+=min(f[e[i].to][0],f[e[i].to][1]);
			else 
				if (pos==b&&mb==0) 
					f[pos][0]+=f[e[i].to][1];
				else
					if (pos==b&&mb==1)
						f[pos][1]+=min(f[e[i].to][0],f[e[i].to][1]);
					else
					{
						f[pos][0]+=f[e[i].to][1];
						f[pos][1]+=min(f[e[i].to][0],f[e[i].to][1]);
					}
		}
	}
}
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	char s[20];
	scanf("%d %d %s\n",&n,&m,&s);
	for (int i=1;i<=n;i++)
	{
		scanf("%lld",&q[i]);
		head[i]=0;
		vis[i]=1;
	}
	for (int i=1;i<=n-1;i++)
	{
		int x,y;
		scanf("%d %d",&x,&y);
		addedge(x,y);
		addedge(y,x);
	}
	for (int i=1;i<=m;i++)
	{
		scanf("%d %d %d %d",&a,&ma,&b,&mb);
		for (int i=1;i<=n;i++)
			vis[i]=1;
		dp(1);
		long long ans;
		if (a==1)
			if (ma==1)
				ans=f[1][1];
			else
				ans=f[1][0];
		else 
			if (b==1)
				if (mb==1)
					ans=f[1][1];
				else
					ans=f[1][0];
			else
				ans=min(f[1][0],f[1][1]);
		if (ans>=40000000000)
			printf("-1\n");
		else
			printf("%lld\n",ans);
	}
}