#include<bits/stdc++.h>
using namespace std;
int a[200],ma[40000],pr[40000];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	scanf("%d",&T);
	for (int x=1;x<=T;x++)
	{
		int n;
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		int s=n;
		for (int i=1;i<=n;i++)
			for (int j=i+1;j<=n;j++)
			{
				if ((a[i]!=5000)&&(a[j]!=5000))
				{
					if (a[j]%a[i]==0)
					{
						s--;
						a[j]=5000;
					}
					for (int k=j+1;k<=n;k++)
						if (a[k]!=5000)
						{
							int t=a[k]%a[j];
							if (t%a[i]==0)
							{	
								s--;
								a[k]=5000;
							}
						}
					
				}
			}
		sort(a+1,a+n+1);
		n=s;
		int t=0;
		for (int i=2;i<=40000;i++)
			pr[i]=1;
		for (int i=2;i<=40000;i++)
			if (pr[i]==1)
			{
				int j=i;
				while(j+i<=40000)
				{
					j+=i;
					pr[j]=0;
				}	
			}	
		printf("%d",s);	
	}
	return 0;
}