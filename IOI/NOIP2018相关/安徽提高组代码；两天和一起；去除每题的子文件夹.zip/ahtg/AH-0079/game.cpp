#include<bits/stdc++.h>
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	printf("12");
}