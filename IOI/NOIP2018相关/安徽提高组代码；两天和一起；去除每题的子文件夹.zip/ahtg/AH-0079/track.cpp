#include<bits/stdc++.h>
using namespace std;
int cnt=0,head[100100],a[100100],b[100100],c[100100],dis[100100],n,m,ma=0;
struct edge
{
	int dis,to,nxt;
}e[100100];
struct node
{
	int dis,to;
	bool operator < (const node &rhs) const
	{
		return dis<rhs.dis;
	}
};
void addedge(int x,int y,int z)
{
	cnt++;
	e[cnt].dis=z;
	e[cnt].to=y;
	e[cnt].nxt=head[x];
	head[x]=cnt;
}
int judge(int x,int l)
{
	int p=1,t=0;
	while (x>0)
	{
		while (t<l)
		{
			t+=c[p];
			p++;
			if (p>n)
				return 0;
		}
		t=0;
		x--;
	}
	return 1;
}
void quickst(int l,int r)
{
	int i=l,j=r,m=a[(l+r)/2];
	while (i<j)
	{
		while (a[i]<m) i++;
		while (a[j]>m) j--;
		if (i<=j)
		{
			swap(a[i],a[j]);
			swap(b[i],b[j]);
			swap(c[i],c[j]);
			i++;
			j--;
		}
	}
	if (l<j) quickst(l,j);
	if (i<r) quickst(i,r);
}
priority_queue <node> q;
void dijkstra(int st)
{
	for (int i=1;i<=n;i++)
		dis[i]=2100000000;
	dis[st]=0;
	q.push((node){st,0});
	while (!q.empty())
	{
		node fr=q.top();
		q.pop();
		int fto=fr.to,fdis=fr.dis;
		for (int i=head[fto];i;i=e[i].nxt)
		{
			int ito=e[i].to,idis=e[i].dis;
			if (dis[ito]+idis>dis[fto])
			{
				dis[fto]=dis[ito]+idis;
				q.push((node){ito,idis});
			}	
		}
	}
	for (int i=1;i<=n;i++)
		if (dis[i]!=2100000000)
			if (dis[i]>ma)
				ma=dis[i];
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d %d",&n,&m);
	int mark=1;
	for (int i=1;i<=n-1;i++)
	{
		int x,y,z;
		scanf("%d %d %d",&x,&y,&z);
		addedge(x,y,z);
		addedge(y,x,z);
		a[i]=x;
		b[i]=y;
		c[i]=z;
		if (y!=x+1)
			mark=0;
	}
	if (mark==1)
	{
		quickst(1,n-1);
		int l=1,r=1000000000;
		while(l<r)
		{
			int mid=(l+r)/2;
			if (judge(m,mid)==0) r=mid-1;
				else l=mid;
		}
		printf("%d",l);
	}
	else
		if (m==1)
		{
			for (int i=1;i<=n;i++)
				dijkstra(i);
			printf("%d",ma);
		}
		else
		{
			dijkstra(1);
			printf("%d",ma);
		}
	return 0;
}