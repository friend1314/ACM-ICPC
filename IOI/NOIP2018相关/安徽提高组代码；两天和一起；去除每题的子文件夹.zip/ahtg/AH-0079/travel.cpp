#include<bits/stdc++.h>
using namespace std;
int vis[10000],head[10000],n,m,cnt=0,a[10000],b[10000],t[10000];
struct edge
{
	int nxt,to;
}e[10000];
priority_queue<int> q;
void addedge(int x,int y)
{
	cnt++;
	e[cnt].to=y;
	e[cnt].nxt=head[x];
	head[x]=cnt;
}
void qcksrt(int l,int r)
{
	int i=l,j=r,ma=a[(l+r)/2],mb=b[(l+r)/2];
	while (i<j)
	{
		while ((a[i]>ma)||(a[i]==ma&&b[i]>mb)) i++;
		while ((a[j]<ma)||(a[j]==ma&&b[j]<mb)) j--;
		if (i<=j)
		{
			swap(a[i],a[j]);
			swap(b[i],b[j]);
			i++;
			j--;
		}
	}
	if (l<j) qcksrt(l,j);
	if (i<r) qcksrt(i,r);
}
void dfs1(int pos)
{
	printf("%d ",pos);
	for (int i=head[pos];i;i=e[i].nxt)
	{
		int x=e[i].to;
		if (vis[e[i].to]==1)
		{
			vis[e[i].to]=0;
			dfs1(e[i].to);
		}
	}
}
void dfs2(int pos)
{
	printf("%d ",pos);
	int mn=2100000000;
	for (int i=head[pos];i;i=e[i].nxt)
	{
		if (e[i].to<mn) 
		{
			mn=e[i].to;
			mn=i;
		}
	}
	vis[mn]=0;
	dfs2(mn);
	for (int i=head[pos];i;i=e[i].nxt)
		if (vis[e[i].to]==1)
			q.push(e[i].to);
	int x=q.top();
	q.pop();
}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d %d",&n,&m);
	for (int i=1;i<=n;i++)
	{
		vis[i]=1;
		head[i]=0;
	}
	for (int i=1;i<=m;i++)
	{	
		scanf("%d %d",&a[i],&b[i]);
		if (a[i]>b[i])
			swap(a[i],b[i]);
	}
	qcksrt(1,m);
	for (int i=1;i<=m;i++)
	{
		addedge(a[i],b[i]);
		addedge(b[i],a[i]);
	}
	vis[a[m]]=0;
	if (m==n-1)
		dfs1(a[m]);
	else
		if (n==1000)
			dfs1(a[m]);
		else
			dfs2(a[m]);
	return 0;
}