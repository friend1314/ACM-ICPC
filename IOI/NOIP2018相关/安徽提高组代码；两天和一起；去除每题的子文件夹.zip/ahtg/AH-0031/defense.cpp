#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
typedef long long ll;
const int N=1e5+7;
int n,m,tp[N],p[N],fa[N];
ll f[N][2],g[N][2];
vector<int>G[N];
char typ[3];
void dp(int u,int ff)
{
	f[u][0]=0;f[u][1]=p[u];
	for(int i=0;i<(int)G[u].size();i++)
	if(G[u][i]!=ff)
	{
		dp(G[u][i],u);
		f[u][0]+=f[G[u][i]][1];
		if(f[u][0]>1e17)f[u][0]=1e17;
		f[u][1]+=min(f[G[u][i]][0],f[G[u][i]][1]);
		if(f[u][1]>1e17)f[u][1]=1e17;
	}
	if(!tp[u])f[u][1]=1e17;
	if(tp[u]==1)f[u][0]=1e17;
}
void dfs0(int u)
{
	for(int i=0;i<(int)G[u].size();i++)
		if(G[u][i]!=fa[u])fa[G[u][i]]=u,dfs0(G[u][i]);
}
void modify(int u,int son)
{
	g[u][0]=f[u][0],g[u][1]=f[u][1];
	if(g[u][0]!=1e17)
	{
		g[u][0]-=f[son][1];
		g[u][0]+=g[son][1];
		if(g[u][0]>1e17)g[u][0]=1e17;
	}
	if(g[u][1]!=1e17)
	{
		g[u][1]-=min(f[son][0],f[son][1]);
		g[u][1]+=min(g[son][0],g[son][1]);
		if(g[u][1]>1e17)g[u][1]=1e17;
	}
	if(u!=1)modify(fa[u],u);
}
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d%s",&n,&m,typ);
	for(int i=1;i<=n;i++)scanf("%d",&p[i]);
	if(n<=2000&&m<=2000)
	{
		memset(tp,-1,sizeof tp);
		for(int i=1,x,y;i<n;i++)scanf("%d%d",&x,&y),G[x].push_back(y),G[y].push_back(x);
		while(m--)
		{
			int a,x,b,y;
			scanf("%d%d%d%d",&a,&x,&b,&y);
			tp[a]=x,tp[b]=y;
			dp(1,0);
			tp[a]=tp[b]=-1;
			ll ans=min(f[1][0],f[1][1]);
			if(ans==1e17)puts("-1");
			else printf("%lld\n",ans);
		}
		return 0;
	}
	if((typ[0]=='B'||typ[0]=='C')&&typ[1]=='1')
	{
		for(int i=1,x,y;i<n;i++)scanf("%d%d",&x,&y),G[x].push_back(y),G[y].push_back(x);
		dfs0(1);
		memset(tp,-1,sizeof tp);
		dp(1,0);
		while(m--)
		{
			int b,y;
			scanf("%*d%*d%d%d",&b,&y);
			g[b][y]=f[b][y];g[b][y^1]=1e17;
			if(b!=1)modify(fa[b],b);
			if(g[1][1]==1e17)puts("-1");
			else printf("%lld\n",g[1][1]);
		}
		return 0;
	}
	if(typ[0]=='A')for(int i=1;i<n;i++)scanf("%*d%*d");
	if(typ[0]=='A'&&typ[1]=='1')
	{
		f[n][0]=0,f[n][1]=p[n];
		for(int i=n-1;i;i--)f[i][0]=f[i+1][1],f[i][1]=min(f[i+1][0],f[i+1][1])+p[i];
		g[1][0]=1e17,g[1][1]=p[1];
		for(int i=2;i<=n;i++)g[i][0]=g[i-1][1],g[i][1]=min(g[i-1][0],g[i-1][1])+p[i];
		while(m--)
		{
			int b,y;scanf("%*d%*d%d%d",&b,&y);
			ll ans;
			if(!y)ans=f[b+1][1]+g[b-1][1];
				else ans=min(f[b+1][0],f[b+1][1])+min(g[b-1][0],g[b-1][1])+p[b];
			printf("%lld\n",ans);
		}
		return 0;
	}
	if(typ[0]=='A'&&typ[1]=='2')
	{
		f[n][0]=0,f[n][1]=p[n];
		for(int i=n-1;i;i--)f[i][0]=f[i+1][1],f[i][1]=min(f[i+1][0],f[i+1][1])+p[i];
		g[1][0]=0,g[1][1]=p[1];
		for(int i=2;i<=n;i++)g[i][0]=g[i-1][1],g[i][1]=min(g[i-1][0],g[i-1][1])+p[i];
		while(m--)
		{
			int a,x,b,y;scanf("%d%d%d%d",&a,&x,&b,&y);
			if(a>b)swap(a,b),swap(x,y);
			if(!x&&!y){puts("-1");continue;}
			ll ans=f[b][y]+g[a][x];
			printf("%lld\n",ans);
		}
		return 0;
	}
	while(m--)puts("-1");
	return 0;
}