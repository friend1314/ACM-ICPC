#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
const int N=5007;
int n,m,tp,ans[N],cmp[N],st,ed,S[N],T[N],f[N];
vector<int>vec[N];
void dfs(int u,int fa)
{
	ans[++tp]=u;
	for(int i=0;i<(int)vec[u].size();i++)
		if(vec[u][i]!=fa)dfs(vec[u][i],u);
}
bool ban(int x,int y)
{
	if(x>y)swap(x,y);
	if(x==st&&y==ed)return 1;
	return 0;
}
void dfs2(int u,int fa)
{
	cmp[++tp]=u;
	for(int i=0;i<(int)vec[u].size();i++)
		if(vec[u][i]!=fa&&!ban(u,vec[u][i]))dfs2(vec[u][i],u);
}
bool compar()
{
	for(int i=1;i<=n;i++)
		if(cmp[i]<ans[i])return 1;
		else if(cmp[i]>ans[i])return 0;
	return 0;
}
int findd(int x){return x==f[x]?x:f[x]=findd(f[x]);}
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,x,y;i<=m;i++)scanf("%d%d",&x,&y),vec[x].push_back(y),vec[y].push_back(x),S[i]=x,T[i]=y;
	for(int i=1;i<=n;i++)sort(vec[i].begin(),vec[i].end());
	if(m==n-1)
	{
		dfs(1,0);
		for(int i=1;i<=n;i++)printf("%d ",ans[i]);
	}
	else{
		ans[1]=2;
		for(int i=1;i<=m;i++)
		{
			int cnt=n;
			for(int j=1;j<=n;j++)f[j]=j;
			for(int j=1;j<=m;j++)if(i!=j)
			{
				int x=findd(S[j]),y=findd(T[j]);
				if(x!=y)f[x]=y,cnt--;
			}
			if(cnt>1)continue;
			st=min(S[i],T[i]),ed=max(S[i],T[i]),tp=0;
			dfs2(1,0);
			if(compar())
			{
				for(int j=1;j<=n;j++)ans[j]=cmp[j];
			}
		}
		for(int i=1;i<=n;i++)printf("%d ",ans[i]);
	}
	return 0;
}