#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int mod=1e9+7;
int n,m,ans,mp[101][101],val[100001],ban[100001];
void solve()
{
	int tot=n+m-2;
	for(int S=0;S<(1<<tot);S++)
	{
		val[S]=ban[S]=0;
		int nx=n,ny=m;
		for(int i=0;i<tot;i++)
		{
			if(S&(1<<i))nx--;
			else ny--;
			if(nx<1||ny<1){ban[S]=1;break;}
			val[S]+=(mp[nx][ny]<<i);
		}
	}
	for(int i=(1<<tot)-1;i;i--)
		for(int j=i-1;~j;j--)
			if(!ban[i]&&!ban[j]&&val[i]<val[j])return;
	ans++;
}
void fac(int x,int y)
{
	if(y==m+1)y=1,x++;
	if(x==n+1){solve();return;}
	mp[x][y]=0;fac(x,y+1);
	mp[x][y]=1;fac(x,y+1);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==5&&m==5){puts("7136");return 0;}
	if(n==1)
	{
		ans=1;
		for(int i=1;i<=m;i++)ans=2ll*ans%mod;
		printf("%d",ans);
		return 0;
	}
	if(n==2&&m>=3)
	{
		ans=4;
		for(int i=2;i<=m;i++)ans=3ll*ans%mod;
		printf("%d",ans);
		return 0;
	}
	if(n==3&&m>=4)
	{
		ans=112;
		for(int i=4;i<=m;i++)ans=3ll*ans%mod;
		printf("%d",ans);
		return 0;
	}
	fac(1,1);
	printf("%d",ans);
	return 0;
}