#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=5e4+7;
int n,m,cnt,hd[N],v[N*2],nxt[N*2],w[N*2],dis[N*2],a[N],s[N],tp[N],b[N];
void add(int x,int y,int z){v[++cnt]=y,nxt[cnt]=hd[x],hd[x]=cnt,w[cnt]=z;}
void dfs0(int u,int fa)
{
	for(int i=hd[u];i;i=nxt[i])
		if(v[i]!=fa)dis[v[i]]=dis[u]+w[i],dfs0(v[i],u);
}
void dfs1(int u,int pre)
{
	if(u>1)a[u-1]=pre;
	for(int i=hd[u];i;i=nxt[i])
		if(v[i]==u+1)dfs1(v[i],w[i]);
}
bool check1(int x)
{
	int sum=0,num=0;
	for(int i=1;i<n&&num<m;i++)
	{
		sum+=a[i];
		if(sum>=x)sum=0,num++;
	}
	if(num>=m)return 1;
	return 0;
}
void dfs2(int u,int pre)
{
	if(u>1)a[u-1]=pre;
	for(int i=hd[u];i;i=nxt[i])
		if(v[i]!=1)dfs2(v[i],w[i]);
}
bool check2(int x)
{
	int p=n-1,num=0,l,r;
	while(p&&a[p]>=x)num++,p--;
	if(!p)return num>=m;
	l=1,r=p;
	while(l<r)
	{
		if(a[l]+a[r]>=x)num++,l++,r--;
		else l++;
	}
	return num>=m;
}
void dfs(int u,int fa,int lim)
{
	for(int i=hd[u];i;i=nxt[i])
		if(v[i]!=fa)
		{
			dfs(v[i],u,lim);
			s[u]+=s[v[i]];
		}
	int sz=0;
	for(int i=hd[u];i;i=nxt[i])
		if(v[i]!=fa)a[++sz]=tp[v[i]]+w[i];
	sort(a+1,a+sz+1);
	int l=1,r=sz,add1=0,add2;
	while(r&&a[r]>=lim)r--,add1++;
	while(l<r)
	{
		if(l<r&&a[l]+a[r]>=lim)add1++,l++,r--;
		else l++;
	}
	s[u]+=add1;
	for(int i=sz;i;--i)
	{
		int sz2=0;
		for(int j=1;j<=sz;j++)
			if(i!=j)b[++sz2]=a[j];
		l=1,r=sz-1,add2=0;
		while(r&&b[r]>=lim)r--,add2++;
		while(l<r)
		{
			if(l<r&&b[l]+b[r]>=lim)add2++,l++,r--;
			else l++;
		}
		if(add1==add2){tp[u]=a[i];return;}
	}
}
bool check(int x)
{
	for(int i=1;i<=n;i++)s[i]=tp[i]=0;
	dfs(1,0,x);
	return s[1]>=m;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==1)
	{
		for(int i=1,x,y,z;i<n;i++)scanf("%d%d%d",&x,&y,&z),add(x,y,z),add(y,x,z);
		dfs0(1,0);
		int max1=0,u=1;
		for(int i=2;i<=n;i++)if(dis[i]>max1)max1=dis[i],u=i;
		dis[u]=0,dfs0(u,0);
		max1=0;
		for(int i=1;i<=n;i++)max1=max(max1,dis[i]);
		printf("%d\n",max1);
		return 0;
	}
	bool flag1=1,flag2=1;
	int sum=0;
	for(int i=1,x,y,z;i<n;i++)
	{
		scanf("%d%d%d",&x,&y,&z),add(x,y,z),add(y,x,z),sum+=z;
		if(y!=x+1)flag1=0;
		if(x!=1)flag2=0;
	}
	if(flag1)
	{
		dfs1(1,0);
		int l=0,r=sum,mid,ans=0;
		while(l<=r)
		{
			mid=(l+r)/2;
			if(check1(mid))ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d",ans);
		return 0;
	}
	if(flag2)
	{
		dfs2(1,0);
		sort(a+1,a+n);
		int l=0,r=sum,mid,ans=0;
		while(l<=r)
		{
			mid=(l+r)/2;
			if(check2(mid))ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d",ans);
		return 0;
	}
	int l=0,r=sum,mid,ans=0;
	while(l<=r)
	{
		mid=(l+r)/2;
		if(check(mid))ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d",ans);
	return 0;
}