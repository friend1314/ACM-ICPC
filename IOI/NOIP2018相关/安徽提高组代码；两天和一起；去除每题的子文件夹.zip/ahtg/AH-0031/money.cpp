#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=103;
int n,m,a[N],f[25100],flg[N];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]),flg[i]=0;
		sort(a+1,a+n+1);
		n=unique(a+1,a+n+1)-a-1;
		int max1=a[n];
		if(a[1]==1){puts("1");continue;}
		m=n;
		f[0]=1;
		for(int i=1;i<=max1;i++)f[i]=0;
		for(int i=2;i<=n;++i)
		{
			for(int j=a[i-1];j<=max1;++j)
			f[j]|=f[j-a[i-1]];
			if(f[a[i]])m--;
		}
		printf("%d\n",m);
	}
	return 0;
}