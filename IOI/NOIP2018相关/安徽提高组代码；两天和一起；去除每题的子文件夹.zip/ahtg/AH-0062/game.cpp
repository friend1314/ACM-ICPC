#include<cstdio>
const int md=1000000007;
int n,m,i,j,w[5][5],l,cw[100],s[100],p[10000][100],q[10000][100],ans;
void work(int x,int y)
{
	cw[x+y]=w[x][y];
	if(x==n-1&&y==m-1)
	{
		++l;
		for(int z=0;z<n+m-1;++z)
			p[l][z]=cw[z],q[l][z]=s[z];
		return;
	}
	if(y+1<m)
	{
		s[x+y]=1;
		work(x,y+1);
	}
	if(x+1<n)
	{
		s[x+y]=0;
		work(x+1,y);
	}
}
void dfs(int x,int y)
{
	if(y==m)
		++x,y=0;
	if(x==n)
	{
		l=0;
		work(0,0);
		int i,j,k;
		for(i=1;i<=l;++i)
		{
			for(j=1;j<=l;++j)
			{
				for(k=0;k<n+m-1;++k)
					if(q[i][k]!=q[j][k])
						break;
				if(q[i][k]>q[j][k])
				{
					for(k=0;k<n+m-1;++k)
						if(p[i][k]!=p[j][k])
							break;
					if(p[i][k]>p[j][k])
						break;
				}
			}
			if(j<=l)
				break;
		}
		if(i>l)
			++ans;
		return;
	}
	w[x][y]=0;
	dfs(x,y+1);
	w[x][y]=1;
	dfs(x,y+1);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=3&&m<=3)
	{
		if(n==1)
		{
			if(m==1)
				printf("2");
			else if(m==2)
				printf("4");
			else
				printf("8");
		}
		else if(n==2)
		{
			if(m==1)
				printf("4");
			else if(m==2)
				printf("12");
			else
				printf("36");
		}
		else
		{
			if(m==1)
				printf("8");
			else if(m==2)
				printf("36");
			else
				printf("112");
		}
		return 0;
	}
	if(n==2)
	{
		ans=4;
		for(i=1;i<=m-1;++i)
			ans=1ll*ans*3%md;
		printf("%d",ans);
		return 0;
	}
	dfs(0,0);
		printf("%d",ans);
	return 0;
}
