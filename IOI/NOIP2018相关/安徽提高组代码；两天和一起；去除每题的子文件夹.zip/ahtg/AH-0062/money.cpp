#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,n,i,j,a[105],m;
bool f[25005];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(i=1;i<=n;++i)
			scanf("%d",a+i);
		sort(a+1,a+1+n);
		memset(f,false,sizeof(f));
		f[0]=true;
		m=0;
		for(i=1;i<=n;++i)
			if(!f[a[i]])
			{
				++m;
				for(j=a[i];j<=a[n];++j)
					f[j]=f[j]||f[j-a[i]];
			}
		printf("%d\n",m);
	}
	return 0;
}
