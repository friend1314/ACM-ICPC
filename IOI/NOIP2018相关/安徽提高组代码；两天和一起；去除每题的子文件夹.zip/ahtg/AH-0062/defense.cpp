#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>
using namespace std;
const int N=100005;
typedef long long ll;
vector<int> s1[N],s2[N];
int n,m,i,j,k,A,X,B,Y,p[N],head[N],adj[N*2],nxt[N*2],dad[N],num[N],sz[N];
ll f[N][2],g[N][2];
char s[20];
void dfs(int x,int dad)
{
	f[x][0]=f[x][1]=0;
	for(int y=head[x];y;y=nxt[y])
		if(adj[y]!=dad)
		{
			dfs(adj[y],x);
			f[x][0]+=f[adj[y]][1];
			f[x][1]+=min(f[adj[y]][0],f[adj[y]][1]);
			if(f[x][0]>=(1ll<<60))
				f[x][0]=1ll<<60;
			if(f[x][1]>=(1ll<<60))
				f[x][1]=1ll<<60;
		}
	if(f[x][1]<(1ll<<60))
		f[x][1]+=p[x];
	if(x==A)
		f[A][X^1]=1ll<<60;
	if(x==B)
		f[B][Y^1]=1ll<<60;
}
/*void Dfs(int x,int dad)
{
	f[x][0]=f[x][1]=0;
	for(int y=head[x],z=0;y;y=nxt[y],++z)
		if(adj[y]!=dad)
		{
			num[adj[y]]=z;
			dad[adj[y]]=x;
			dfs(adj[y],x);
		}
	for(int y=head[x];y;y=nxt[y])
		if(adj[y]!=dad)
		{
			f[x][0]+=f[adj[y]][1];
			f[x][1]+=min(f[adj[y]][0],f[adj[y]][1]);
			s1[x].push_back(f[x][0]);
			s2[x].push_back(f[x][1]);
			sz[x]++;
		}
	f[x][1]+=p[x];
}
void work(int x,int son)
{
	if(!x)
		return;
	g[x][0]=(num[x]?s1[x][num[x]-1]:0)+(s1[x][sz[x]-1]-s1[x][num[x]])+g[son[x]][0];
	if(g[x][0]>1ll<<60)
		g[x][0]=1ll<<60;
	g[x][1]=(num[x]?s2[x][num[x]-1]:0)+(s2[x][sz[x]-1]-s2[x][num[x]])+min(g[son[x]][0],g[son[x]][1]);
	g[x][1]+=p[x];
	if(g[x][1]>1ll<<60)
		g[x][1]=1ll<<60;
	work(dad[x],x);
}*/
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	scanf("%d%d%s",&n,&m,s);
	for(i=1;i<=n;++i)
		scanf("%d",p+i);
	for(i=1;i<n;++i)
	{
		scanf("%d%d",&j,&k);
		adj[i*2-1]=k;
		nxt[i*2-1]=head[j];
		head[j]=i*2-1;
		adj[i*2]=j;
		nxt[i*2]=head[k];
		head[k]=i*2;
	}
	if(n<=2000&&m<=2000)
	{
		while(m--)
		{
			scanf("%d%d%d%d",&A,&X,&B,&Y);
			for(i=1;i<=n;++i)
				f[i][0]=f[i][1]=1ll<<60;
			dfs(1,-1);
			if(min(f[1][0],f[1][1])>=(1ll<<60))
				puts("-1");
			else
				printf("%lld\n",min(f[1][0],f[1][1]));
		}
		return 0;
	}
	/*Dfs(1,-1);
	while(m--)
	{
		scanf("%d%d%d%d",&A,&X,&B,&Y);
		memcpy(g,f,sizeof(f));
		g[A][X^1]=1ll<<60;
		work(dad[A],A);
		g[B][Y^1]=1ll<<60;
		work(dad[B],B);
		if(min(g[1][0],g[1][1])>=(1ll<<60))
				puts("-1");
			else
				printf("%lld\n",min(g[1][0],g[1][1]));
	}*/
	return 0;
}
