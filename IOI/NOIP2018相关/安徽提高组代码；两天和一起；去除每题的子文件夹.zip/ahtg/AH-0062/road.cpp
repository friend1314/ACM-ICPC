#include<cstdio>
int n,i,d[100005],ans;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;++i)
		scanf("%d",d+i);
	for(i=1;i<=n;++i)
		if(d[i]>d[i-1])
			ans+=d[i]-d[i-1];
	printf("%d",ans);
	return 0;
}
