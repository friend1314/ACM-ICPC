#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	int a,b,c,e,f,s[5001];
	short int k[5001][200];
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	cin>>a>>b;
	for (c=1;c<=a;++c)
	{
		s[c]=0;
	}
	for (c=1;c<=b;++c)
	{
		cin>>e>>f;
		s[e]++;
		k[e][s[e]]=f;
		k[f][s[e]]=e;
	}
	for (c=1;c<=a;++c)
	{
		s[c]=0;
	}
	e=1;
	cout<<1<<' ';
	while (s[k[e][1]]!=1)
	{
		cout<<k[e][1]<<' ';
		s[e]=1;
		e=k[e][1];
	}
	fclose(stdin);
	fclose(stdout);
}