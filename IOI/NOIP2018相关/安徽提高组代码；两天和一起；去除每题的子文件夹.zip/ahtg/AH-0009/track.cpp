#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int a,b,c,d,e,f,g,h,i,j,l,k[1001][1001];
	cin>>a>>b;
	for (c=1;c<=a;++c)
	{
		for (d=1;d<=a;++d)
		{
			k[c][d]=9999;
		}
	}
	for (c=1;c<=a-1;++c)
	{
		cin>>d>>e>>f;
		k[d][e]=f;
		k[e][d]=f;
	}
	l=0;
	for (g=1;g<=a;++g)
	{
		for (j=1;j<=a;++j)
		{
	        for (h=j+1;h<=a;++h)
		    {
 			    if (k[j][h]>k[j][g]+k[g][h])
				{
				    k[j][h]=k[j][g]+k[g][h];
					k[h][j]=k[j][g]+k[g][h];
				}
		    }
		}
	}
	for (i=1;i<=a;++i)
	{
		for (j=1;j<=a-1;++j)
		{
			if ((l<k[i][j])&&(i!=j)) l=k[i][j];
			cout<<k[i][j]<<' ';
		}
		cout<<k[i][a]<<endl;
	}
	cout<<l;
	return 0;
	fclose(stdin);
	fclose(stdout);
}