#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int a,b,c,d,e,f,g,h,k[100001];
	cin>>a;
	b=0;
    for (b=1;b<=a;++b)
	{
		cin>>k[b];
	}
	k[0]=1;
	d=1;
	h=0;
	while (d!=0)
	{ 
	  d=0;
	  e=0;
	  f=0;
	  for (c=1;c<=a;++c)
	  {
	    if (k[c]!=0) d=1;
		if ((k[c]!=0)&&(e==0)) e=c;
		if ((k[c]==0)&&(f==0)&&(e!=0)) f=c-1;
	  }
	  if (f==0) f=a;
	  g=99999;
	  for (c=e;c<=f;++c)
	  {
	      if (g>k[c]) g=k[c];
	  }
	  for (c=e;c<=f;++c)
	  {
		k[c]=k[c]-g;
	  }
	  h=h+g;
	}
    cout<<h;
	return 0;
	fclose(stdin);
	fclose(stdout);
}