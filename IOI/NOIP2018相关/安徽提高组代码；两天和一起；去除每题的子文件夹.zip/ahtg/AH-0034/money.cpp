#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int t,n,ans;
int a[101];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(;t--;)
	{
		scanf("%d",&n);
		ans=n;
		for (int i=1;i<=n;++i) scanf("%d",&a[i]);
		if (n==2){
			if (a[1]!=1&&a[2]!=1) cout<<2<<endl;
			else cout<<1<<endl;
		}
		if (n!=2) printf("%d\n",n);
	} 
	fclose(stdin);fclose(stdout);
	return 0;
}
