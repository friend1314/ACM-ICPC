#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<stack>
#include<map>
#include<cmath>
using namespace std;
const int N=5001;
int a[N][N];
bool f[N]={0};
int n,m,x,y;
int minn=2147483647;
int main()
{
	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i)
	 for (int j=1;j<=n;++j)
		a[i][j]=0;
//	for (int i=1;i<=n;++i) f[i]=0;
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d",&x,&y);
		a[x][y]=1;
		a[y][x]=1;
		minn=min(minn,min(x,y));
	}
	int i=minn;
	cout<<i<<' ';
//	for (int i=1;i<=n;++i)
	 for (int j=2;j<=n;++j)
		if (a[i][j]==1&&f[j]==0) {
		    printf("%d ",j); 
			f[j]=1;
		    i=j;	
			break;
//	        else {printf("%d ",j); f[j]=1; i=j; break;}		
		}
	fclose(stdin); fclose(stdout);
	return 0;
}
