#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<queue>
#include<map>
#include<stack>
using namespace std;
const int N=100001;
int n;
int a[N],b[N];
long long ans;
int mmax,mmin=0X7f;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;++i) 
	{
		scanf("%d",&a[i]);
		//mmax=max(mmax,a[i]);
		mmin=min(mmin,a[i]);
	}
	for (int i=1;i<n;++i) b[i]=a[i+1]-a[i];
	for (int i=1;i<=n;++i)
	{
		//if (mmax<a[i])
		ans+=abs(a[i]-mmax-mmin);
		mmax=a[i];
	}
	printf("%lld",abs(ans-mmin*2));
	fclose(stdin);fclose(stdout);
	return 0;
}
