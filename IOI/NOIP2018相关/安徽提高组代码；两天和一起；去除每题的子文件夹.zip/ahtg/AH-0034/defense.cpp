#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<stack>
#include<map>
#include<cmath>
using namespace std;
int n,m,o,q;
int a,x,b,y;
char c[3];
bool t[1001][1001]={0};
int p[1001],f[1001];
int ans;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%s",c);
	for (int i=1;i<=n;++i) {scanf("%d",&p[i]); f[i]=0; }
	for (int i=1;i<=m;++i)
	{
		scanf("%d%d",&o,&q);
		t[o][q]=1;
		t[q][o]=1;
	}
	for (int i=1;i<=m;++i) 
	{
		scanf("%d%d%d%d",&a,&x,&b,&y);
	    if ((abs(a-b)&&!x==y) || (a==b&&x!=y)) {cout<<-1<<endl; break;}
		if (x==0) {
			if (f[a-2]==0&&f[a+2]==0) if (p[a-1]<p[a+1]) {ans+=p[a-1]; f[a-1]=1;}
									  else {ans+=p[a+1]; f[a+1]=1;}
			if (f[a-2]==1&&f[a+2]==1) {ans+=p[a]; f[a]=1;}
			if (f[a-2]==1&&f[a+1]==0) if (p[a-2]<p[a+1]) {ans+=p[a-2]; f[a-2]=1;}
									  else {ans+=p[a+1]; f[a+1]=1;}
			if (f[a-1]==1&&f[a+2]==0) if (p[a-1]<p[a+2]) {ans+=p[a-1]; f[a-1]=1;}
									  else {ans+=p[a+2]; f[a+2]=1;}
		}
		if (y==0) {
			if (f[b-2]==0&&f[b+2]==0) if (p[b-1]<p[b+1]) {ans+=p[b-1]; f[b-1]=1;}
									  else {ans+=p[b+1]; f[b+1]=1;}
			if (f[b-2]==1&&f[b+2]==1) {ans+=p[b]; f[b]=1;}
			if (f[b-2]==1&&f[b+1]==0) if (p[b-2]<p[b+1]) {ans+=p[b-2]; f[b-1]=1;}
									  else {ans+=p[b+1]; f[b+1]=1;}
			if (f[b-1]==1&&f[b+2]==0) if (p[b-1]<p[b+2]) {ans+=p[b-1]; f[b-1]=1;}
									  else {ans+=p[b+2]; f[b+2]=1;}
		}
		cout<<ans<<endl;
		ans=0;
	}
	fclose(stdin); fclose(stdout);
	return 0;
}