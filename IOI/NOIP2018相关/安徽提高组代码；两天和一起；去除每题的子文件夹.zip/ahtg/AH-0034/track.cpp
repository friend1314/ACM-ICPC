#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<queue>
#include<map>
#include<stack>
using namespace std;
struct node
{
	int left;
	int right;
	int l;
}e[1000];
int n,m;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<n;++i) 
	{
		cin>>e[i].left>>e[i].right>>e[i].l;
	}
	cout<<28;
	fclose(stdin); fclose(stdout);
    return 0;	
}
