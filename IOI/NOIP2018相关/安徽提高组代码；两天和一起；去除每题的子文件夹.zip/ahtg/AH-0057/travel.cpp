#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <vector>
#define ll long long
#define mp make_pair
#define pb push_back
#define pi pair<int,int>
#define fi first
#define se second
#define mod 998244353
using namespace std;
int fa[5005],dep[5005],n,m,num=0;
int nw[5005],ans[5005],t[5005][2],ca,cb,cnt=0;
bool vis[5005];
vector <int> vec[5005];
void dfs(int pos)
{vis[pos]=1;
	int sz=vec[pos].size(),i,j;
	for (i=0;i<sz;i++)
	{if (vec[pos][i]==fa[pos]) continue;
		if (vis[vec[pos][i]])
		{if (dep[vec[pos][i]]<dep[pos])
			{for (j=pos;j!=vec[pos][i];j=fa[j])
			{t[++cnt][0]=j;t[cnt][1]=fa[j];}
			t[++cnt][0]=pos;t[cnt][1]=vec[pos][i];
		}
		continue;
		}
		dep[vec[pos][i]]=dep[pos]+1;
		fa[vec[pos][i]]=pos;
		dfs(vec[pos][i]);
	}
}
void dfs_(int pos,int f)
{nw[++num]=pos;
	int sz=vec[pos].size(),i;
	for (i=0;i<sz;i++)
	{if (vec[pos][i]==f) continue;
		if (pos==ca&&vec[pos][i]==cb) continue;
		if (pos==cb&&vec[pos][i]==ca) continue;
		dfs_(vec[pos][i],pos);
	}
}
inline void work()
{int i;num=0;
	dfs_(1,0);
	for (i=1;i<=n;i++)
	{if (nw[i]<ans[i]) {memcpy(ans,nw,sizeof(nw));return;}
	if (nw[i]>ans[i]) return;
	}
}
int main (){
	freopen ("travel.in","r",stdin);
	freopen ("travel.out","w",stdout);
	int i,a,b;
	scanf ("%d%d",&n,&m);
	for (i=1;i<=m;i++)
	{scanf ("%d%d",&a,&b);
		vec[a].pb(b);
		vec[b].pb(a);
	}
	for (i=1;i<=n;i++) sort(vec[i].begin(),vec[i].end());
	dfs(1);
	for (i=1;i<=n;i++) ans[i]=n;
	if (m==n-1) 
		{ca=cb=0;work();}
	else
	{for (i=1;i<=cnt;i++)
		{ca=t[i][0];cb=t[i][1];
			work();
		}
	}
	for (i=1;i<=n;i++) printf ("%d ",ans[i]);
	return 0;
}
