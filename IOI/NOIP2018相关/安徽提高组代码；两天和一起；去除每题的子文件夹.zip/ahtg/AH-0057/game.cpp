#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#define ll long long
#define mp make_pair
#define pi pair<int,int>
#define fi first
#define se second
#define mod 1000000007
using namespace std;
int pw[1000005];
inline int qpow(int a,int b)
{int res=1,tp=a;
	while (b)
	{if (b&1) res=1ll*res*tp%mod;
		tp=1ll*tp*tp%mod;b>>=1;
	}
	return res;
}
inline void work_(int n)
{int res=1ll*4*qpow(3,n-1)%mod;
	printf ("%d\n",res);
}
inline void work(int n)
{int i,ans=0;
	for (pw[0]=1,i=1;i<=n;i++) pw[i]=1ll*3*pw[i-1]%mod;
	for (i=2;i<n;i++)
	{int wo=0,tp=0;
		if (i==2) {wo=16;}
		else {wo=24;}
		tp=pw[n-i-1];
		ans+=1ll*wo*tp%mod;
		if (ans>=mod) ans-=mod;
	}
	ans=(ans+12>=mod?ans+12-mod:ans+12);
	ans=1ll*ans*4%mod;
	printf ("%d\n",ans);
	return;
}
int main (){
	freopen ("game.in","r",stdin);
	freopen ("game.out","w",stdout);
	int n,m;
	scanf ("%d%d",&n,&m);
	if (n==1||m==1)
	{int tot=n*m,i,ans=1;
		for (i=1;i<=tot;i++)
		{ans*=2;ans%=mod;}
		printf ("%d\n",ans);
		return 0;
	}
	if (n==3&&m==2) {puts("36");return 0;}
	if (n==5&&m==5) {puts("7136");return 0;}
	if (n==2) {work_(m);return 0;}
	if (n==3) {work(m);return 0;}
	return 0;
}
	
