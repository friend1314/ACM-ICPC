#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#define ll long long
#define mp make_pair
#define pi pair<int,int>
#define fi first
#define se second
#define mod 998244353
#define inf 1000000000000000000ll
using namespace std;
int head[100005],nxt[200005],v[200005],val[100005],tot=0,n,m;
int fa[100005],pos[400005],o[400005],cnt=0,ax,ay,bx,by;
ll f[100005][2],vt[400005],g1[100005],g2[100005];
inline void add(int a,int b)
{tot++;nxt[tot]=head[a];head[a]=tot;v[tot]=b;}
inline ll min(ll a,ll b){return a<b?a:b;}
inline ll max(ll a,ll b){return a>b?a:b;}
void dfss(int pos,int fi)
{f[pos][0]=f[pos][1]=0;
	for (int i=head[pos];i;i=nxt[i])
	{if (v[i]==fi) continue;
		dfss(v[i],pos);
		f[pos][1]+=min(f[v[i]][0],f[v[i]][1]);
		f[pos][0]+=f[v[i]][1];
	}
	f[pos][1]+=val[pos];
	if (pos==ax) f[pos][ay]=inf;
	if (pos==bx) f[pos][by]=inf;
	f[pos][0]=min(f[pos][0],inf);
	f[pos][1]=min(f[pos][1],inf);
}
ll s0[100005],s1[100005];
ll z0[100005],z1[100005];
inline void _work1()
{int i,a,x,b,y;
	for (s0[1]=inf,s1[1]=val[1],i=2;i<=n;i++)
	{s0[i]=s1[i-1];
		s1[i]=min(s0[i-1],s1[i-1])+val[i];
	}
	for (i=n;i>=1;i--)
	{z0[i]=z1[i+1];
		z1[i]=min(z0[i+1],z1[i+1])+val[i];
	}
	while (m--)
	{scanf ("%d%d%d%d",&a,&x,&b,&y);
		ll ans=0;
		if (y) {ans=min(s0[b-1],s1[b-1])+min(z0[b+1],z1[b+1])+val[b];}
		else {ans=s1[b-1]+z1[b+1];}
		if (ans>inf) {puts("-1");continue;}
		printf ("%lld\n",ans);
	}
	return;
}
inline void _work2()
{int i,a,x,b,y;
	for (i=1;i<=n;i++)
	{s0[i]=s1[i-1];
		s1[i]=min(s0[i-1],s1[i-1])+val[i];
	}
	for (i=n;i>=1;i--)
	{z0[i]=z1[i+1];
		z1[i]=min(z0[i+1],z1[i+1])+val[i];
	}
	while (m--)
	{scanf ("%d%d%d%d",&a,&x,&b,&y);
		if (a>b) {swap(a,b);swap(x,y);}
		if (x==0&&y==0) {puts("-1");continue;}
		ll ans=0;
		if (x==0) {ans+=s1[a-1];}
		else {ans+=min(s0[a-1],s1[a-1])+val[a];}
		if (y==0) {ans+=z1[b+1];}
		else {ans+=min(z0[b+1],z1[b+1])+val[b];}
		printf ("%lld\n",ans);
	}
	return;
}
inline void chg(int p1,int p2,ll p3)
{pos[++cnt]=p1;o[cnt]=p2;vt[cnt]=f[p1][p2];
	f[p1][p2]=p3;
}
inline void bck()
{while (cnt)
	{f[pos[cnt]][o[cnt]]=vt[cnt];cnt--;}
}
void dfs(int pos,int fi)
{f[pos][0]=f[pos][1]=0;
	for (int i=head[pos];i;i=nxt[i])
	{if (v[i]==fi) continue;
		fa[v[i]]=pos;
		dfs(v[i],pos);
		f[pos][1]+=min(f[v[i]][0],f[v[i]][1]);
		f[pos][0]+=f[v[i]][1];
	}
	f[pos][1]+=val[pos];
	g1[pos]=min(f[pos][0],f[pos][1]);
	g2[pos]=f[pos][1];
}
inline void _work3()
{int i,a,x,b,y,lst;dfs(1,0);
	while (m--)
	{scanf ("%d%d%d%d",&a,&x,&b,&y);cnt=0;
		if (y) {chg(b,0,inf);}
		else {chg(b,1,inf);}
		for (lst=b,i=fa[b];i;lst=i,i=fa[i])
		{ll n1=f[i][0]-g2[lst]+f[lst][1];
			ll n2=f[i][1]-g1[lst]+min(f[lst][0],f[lst][1]);
			n1=min(n1,inf);n2=min(n2,inf);
			chg(i,0,n1);chg(i,1,n2);
		}
		if (f[1][1]>inf) {puts("-1");}
		else {printf ("%lld\n",f[1][1]);}
		bck();
	}
	return;
}
int main (){
	freopen ("defense.in","r",stdin);
	freopen ("defense.out","w",stdout);
	char s[15];
	int i,a,b,x,y;
	scanf ("%d%d",&n,&m);
	scanf ("%s",s+1);
	for (i=1;i<=n;i++)
	{scanf ("%d",&val[i]);}
	for (i=1;i<n;i++)
	{scanf ("%d%d",&a,&b);
		add(a,b);add(b,a);
	}
	if (s[1]=='A'&&s[2]=='1') {_work1();return 0;}
	if (s[1]=='A'&&s[2]=='2') {_work2();return 0;}
	if (s[2]=='1') {_work3();return 0;}
	int root=666623333%n+1;
	while (m--)
	{scanf ("%d%d%d%d",&a,&x,&b,&y);cnt=0;
		ax=a;ay=x^1;bx=b;by=y^1;dfss(root,0);
		if (min(f[root][0],f[root][1])>=inf) {puts("-1");}
		else {printf ("%lld\n",min(f[root][0],f[root][1]));}
	}
	return 0;
}
