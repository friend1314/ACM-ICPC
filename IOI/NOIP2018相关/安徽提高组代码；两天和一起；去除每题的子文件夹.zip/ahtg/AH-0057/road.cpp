#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#define pi pair<int,int>
#define mp make_pair
#define fi first
#define se second
#define ll long long
#define mod 998244353
using namespace std;
int n,a[100005],logn[100005];
int st[19][100005],ps[19][100005];
inline pi cal(int l,int r)
{int t=logn[r-l+1],t1,t2;
	if (st[t][l]<=st[t][r-(1<<t)+1]) {t1=st[t][l];t2=ps[t][l];}
	else {t1=st[t][r-(1<<t)+1];t2=ps[t][r-(1<<t)+1];}
	return mp(t1,t2);
}
int dfs(int l,int r,int lst)
{if (l>r) return 0;
	pi tp=cal(l,r);
	int t1=tp.fi,t2=tp.se;
	return (t1-lst)+dfs(l,t2-1,t1)+dfs(t2+1,r,t1);
}
int main (){
	freopen ("road.in","r",stdin);
	freopen ("road.out","w",stdout);
	int i,j;
	scanf ("%d",&n);
	for (logn[0]=-1,i=1;i<=n;i++)
	{scanf ("%d",&a[i]);
		st[0][i]=a[i];ps[0][i]=i;
		logn[i]=logn[(i>>1)]+1;
	}
	for (j=1;(1<<j)<=n;j++)
	{for (i=1;i+(1<<j)-1<=n;i++)
		{if (st[j-1][i]<=st[j-1][i+(1<<(j-1))])
			{st[j][i]=st[j-1][i];ps[j][i]=ps[j-1][i];}
			else
			{st[j][i]=st[j-1][i+(1<<(j-1))];
				ps[j][i]=ps[j-1][i+(1<<(j-1))];
			}
		}
	}
	printf ("%d\n",dfs(1,n,0));
	return 0;
}
