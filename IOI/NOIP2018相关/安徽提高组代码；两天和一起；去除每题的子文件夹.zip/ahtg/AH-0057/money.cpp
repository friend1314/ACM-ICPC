#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#define pi pair<int,int>
#define mp make_pair
#define fi first
#define se second
#define ll long long
#define mod 998244353
using namespace std;
int a[105],n;
bool ok[25005];
inline void work()
{memset(ok,0,sizeof(ok));
	int i,j,ans=0;
	scanf ("%d",&n);
	for (i=1;i<=n;i++)
	{scanf ("%d",&a[i]);}
	sort(a+1,a+n+1);
	ok[0]=1;
	for (i=1;i<=n;i++)
	{if (ok[a[i]]) continue;
		for (ans++,j=a[i];j<=a[n];j++) ok[j]|=ok[j-a[i]];
	}
	printf ("%d\n",ans);
	return;
}
int main (){
	freopen ("money.in","r",stdin);
	freopen ("money.out","w",stdout);
	int T;
	scanf ("%d",&T);
	while (T--) {work();}
	return 0;
}
