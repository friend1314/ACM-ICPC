#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#define pi pair<int,int>
#define mp make_pair
#define fi first
#define se second
#define ll long long
#define mod 998244353
using namespace std;
int head[50005],nxt[100005],v[100005],w[100005],tot=1;
int x[50005],fa[50005],a[50005],f[50005],g[50005],n,m,sum=0,cnt=0;
bool vis[50005];
inline void add(int a,int b,int val)
{tot++;nxt[tot]=head[a];head[a]=tot;v[tot]=b;w[tot]=val;}
void dfs(int pos,int f)
{x[++cnt]=pos;
	for (int i=head[pos];i;i=nxt[i])
	{if (v[i]==f) continue;
		fa[v[i]]=pos;
		dfs(v[i],pos);
	}
}
inline int work(int tar)
{int i,j;
	for (i=1;i<=n;i++) f[i]=g[i]=0;
	for (i=n;i>=1;i--)
	{int t=x[i],o=0;
		for (j=head[t];j;j=nxt[j])
		{if (v[j]==fa[t]) continue;
		a[++o]=g[v[j]]+w[j];vis[o]=0;
		f[t]+=f[v[j]];
		}
		sort(a+1,a+o+1);
		int pos=1,mo=0;
		for (j=o;j>=1;j--)
		{if (vis[j]) continue;
			if (a[j]>=tar) {vis[j]=1;mo++;continue;}
			while (pos<j&&a[j]+a[pos]<tar) pos++;
			while (pos<j&&vis[pos]) pos++;
			if (pos>=j) break;
			vis[pos]=vis[j]=1;mo++;
		}
		int l=1,r=o;
		while (l<=r)
		{int mid=(l+r)>>1,tp=0;
			for (j=1;j<=o;j++) vis[j]=0;
			vis[mid]=1;pos=1;
			for (j=o;j>=1;j--)
			{if (vis[j]) continue;
				if (a[j]>=tar) {vis[j]=1;tp++;continue;}
				while (pos<j&&a[j]+a[pos]<tar) pos++;
				while (pos<j&&vis[pos]) pos++;
				if (pos>=j) break;
				vis[pos]=vis[j]=1;tp++;
			}
			if (tp==mo) {l=mid+1;}
			else {r=mid-1;}
		}
		f[t]+=mo;g[t]=a[r];
	}
	return f[x[1]];
}
int main (){
	freopen ("track.in","r",stdin);
	freopen ("track.out","w",stdout);
	int i,a,b,val;
	scanf ("%d%d",&n,&m);
	for (i=1;i<n;i++)
	{scanf ("%d%d%d",&a,&b,&val);
		add(a,b,val);add(b,a,val);sum+=val;
	}
	int root=1004535809%n+1;
	dfs(root,0);
	int l=0,r=sum/m;
	while (l<=r)
	{int mid=(l+r)>>1;
		if (work(mid)>=m) {l=mid+1;}
		else {r=mid-1;}
	}
	printf ("%d\n",r);
	return 0;
}
