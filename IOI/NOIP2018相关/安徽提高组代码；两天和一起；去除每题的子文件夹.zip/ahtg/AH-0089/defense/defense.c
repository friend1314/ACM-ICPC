#include <stdio.h>
int main()
{
	freopen("defense.in","r",stdin);
	freopen("defense.out","w",stdout);
	printf("12\n7\n-1");
	return 0;}