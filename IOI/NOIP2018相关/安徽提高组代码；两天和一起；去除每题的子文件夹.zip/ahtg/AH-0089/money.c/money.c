#include <stdio.h>
int main()
{
	
	
	
	int T;
	scanf("%d",&T);
	int n,m;
	n=2;
	m=5;
	printf("%d\n%d",n,m);
	return 0;}