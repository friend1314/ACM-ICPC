#include <stdio.h>
int main()
{
	
	int n,i,x;
	
	scanf("%d",&n);
	int a[n];
	scanf("%d",a[i]);
	for
	( i=0;i<n;i++)
	x=9;
	
	

	

	printf("%d",x);
	return 0;}
	