#include<stdio.h>
int main()
{
	
	printf("31");
	return 0;
	}
	