#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
struct edge{
	int next, v;
}e[100010];

int n, m, head[100010], cnt = 1, f[100010][2], v[100100], cost[100100];

void add(int x, int y){
	e[++cnt].v= y;e[cnt].next = head[x];head[x] = cnt;}

int X, A,  Y, B;
void dfs(int x){
	v[x] = 1;int pd = 0, sum0 = 0, sum1 = 0;
	for (int i = head[x];i; i = e[i].next){
		int y = e[i].v;
		if(v[y])continue;pd = 1;
		dfs(y);
		sum0 += min(f[y][0], f[y][1]);
		sum1 += f[y][1];
	}
	if(pd == 0){
		f[x][1] = cost[x];
		f[x][0] = 0;
	}
	else{
		f[x][1] = sum0 + cost[x];
		f[x][0] = sum1;
	}
	if(x == X){
		f[x][A ^ 1] = 0x3f3f3f3f;
	}
	if(x == Y){
		f[x][B ^ 1] = 0x3f3f3f3f;}
}
	
int main(){
	freopen("defense.in", "r", stdin);
	freopen("defense.out", "w", stdout);
	int n, m;
	scanf("%d%d", &n, &m);
	char ch = getchar();while(ch > 'Z' || ch < 'A') ch = getchar();
	int type = getchar() - '0';
	for (int i = 1;i <= n; i++)scanf("%d", &cost[i]);
	for (int i = 1;i < n; i++){
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y);add(y, x);
	}
	for (int i =1;i <= m ;i++){
		scanf("%d%d%d%d", &X, &A, &Y, &B);memset(v, 0, sizeof(v));
		dfs(1);
		int ans = min(f[1][0], f[1][1]);
		if(ans >= 1000000000)printf("-1\n");
			else printf("%d\n", ans); 
	}	
	return 0;
}