#include<cstdlib>
#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;

int  a[10000000], f[10000000];

int main(){
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int t = 233;
	scanf("%d", &t);
	while(t--){
	int n;
	scanf("%d", &n);for (int i = 1;i <= 25000;i++)f[i] = 0;
	for (int i= 1;i <= n;i++)
		scanf("%d", &a[i]);
	sort(a + 1, a + 1 + n);int ans = 0;
	f[0] = 1;
	for (int i = 1; i <= n; i++){
		if(!f[a[i]]){
			ans++;
			for (int j =a[i];j <= 25000; j++){
				if(!f[j])f[j] = f[j - a[i]];
			}
		}
	}
	printf("%d\n", ans);
	}
	return 0;
}