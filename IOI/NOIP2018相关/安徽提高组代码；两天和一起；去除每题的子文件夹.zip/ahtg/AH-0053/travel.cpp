#include<cstdlib>
#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
struct edge{
	int next, v;
}e[1000000];
	int n, m;
int head[100000], cnt = 1, lj[5100][5100], tot,  v[5100],  ans[5100], b[5600][5600], k, key, ansz[6000], fx, fy;
void add(int x, int y){
	e[++cnt].v = y;e[cnt].next = head[x];head[x] = cnt;}

void dfs(int x){
	v[x] = 1;
		ans[++tot] = x;
	for (int i = head[x];i ; i = e[i].next){  
		if( v[e[i].v])continue;
		dfs(e[i].v);
	}
}

void dfs2(int x){
	if(k == 2)return;
	v[x] = 1;
	for (int i = 1;i <= n; i++){
		if(!lj[x][i])continue;if(v[i]){
			k = 2;key = i;
			lj[x][i] = lj[i][x] = 2;
			return;
		}
		lj[x][i] = lj[i][x] = 0;
		dfs2(i);
		lj[x][i] = lj[i][x] = k;
	}
}

void dfs3(int x){
	v[x] = 1;
	if(x == key)return;
	for (int i = 1;i <= n; i++){
		if(v[i]||lj[x][i] != 2)continue;
		lj[x][i] = lj[i][x] = 1;
		dfs(x);
	}
}
void dfs4(int x){
	v[x] = 1;
	ansz[++tot] = x;
	for (int i = head[x];i ; i = e[i].next){  
		if( v[e[i].v] || (fx == x && fy == e[i].v)|| (fx == e[i].v && fy == x))continue;
		dfs4(e[i].v);
	}
}
int main() {
	freopen("travel.in", "r", stdin);
	freopen("travel.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1;i <= m;i++){
		int x, y;
		scanf("%d%d", &x, &y);
		lj[x][y] = lj[y][x] = 1;
	}
	if(n - 1 == m){
			for (int i = 1;i <= n ;i++){
			for (int j = n; j >= 1; j--){
				if(lj[i][j])add(i, j);
			}
		}
		dfs(1);
	}
	else{
		for (int i = 1;i <= n ;i++) ans[i] = 0x3f3f3f3f;
		for (int i = 1;i <= n ;i++){
			for (int j = n; j >= 1; j--){
				if(lj[i][j])add(i, j);
			}
		}
		dfs2(1);memset(v, 0, sizeof(v));
		dfs3(1);memset(v, 0, sizeof(v));
		for (int i = 1;i <= n ;i++)
			for (int j = i + 1;j <= n; j++) if(lj[i][j] == 2){
				fx = i;fy = j;
				tot = 0;memset(v, 0, sizeof(v));
				dfs4(1);
				int pd = 0;
				for (int g = 1; g <= n; g++){
					if(ansz[g] < ans[g]){pd = 1;break;}
					if(ansz[g] > ans[g])break;
				}
				if(pd){
					for (int g = 1;g <= n; g++){
						ans[g] = ansz[g];
					}
				}
		}
	}
	for (int i = 1;i <= tot ;i++)printf("%d ", ans[i]);
	return 0;
}