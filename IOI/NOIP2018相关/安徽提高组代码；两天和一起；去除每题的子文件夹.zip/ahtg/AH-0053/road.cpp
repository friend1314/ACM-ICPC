#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int a[10000000];

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n = 233;
	scanf("%d", &n);
	for (int i = 1;i <= n ;i++){
		scanf("%d", &a[i]);
	}
	a[0] = 0;long long ans = 0;
	for (int i  = 1;i <= n; i++){
		if(a[i] > a[i - 1])ans += a[i] - a[i - 1];
	}
	printf("%lld\n", ans);
	return 0;
}