#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<queue>
using namespace std;
struct edge{
	int next, v, s;
}e[100000];

int head[100000], cnt = 1, s[100000], d[100000], a[100000], b[100000];
	int n, m;
void add(int x, int y, int z){
	e[++cnt].v = y;e[cnt].s = z;e[cnt].next = head[x];head[x] = cnt;
}

int check(int m){
	int k = 0, ans = 0;
	for (int i = 1;i < n; i++){
		k += s[i];
		if(k >= m)ans++, k = 0;
	}
	return ans;
}
int check2(int m){
	int k = n + 1;
	for (int i = 1;i <= n;i++)if(a[i] >= m){k = i;break;} int ans = (n - k + 1);
	int l = 1;
	for (int i = k - 1;i > l; i--){
		while(a[l] < m - a[i] && l < i) l++;
		if(l == i)return ans;
		l++;
		ans++;
	}
	return ans;
}

queue<int> q;
int main(){
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	scanf("%d%d", &n, &m);int chain = 1;
	for (int i = 1;i < n; i++){
		int x, y, z;
		scanf("%d%d%d", &x, &y, &z);
		add(x, y, z);add(y, x, z);s[x] = z;a[y] = z;if(x + 1 != y)chain = 0;
	}
	if(chain){
		int l = 1, r = 0x3f3f3f3f, ans = -1;
		while(l <= r){
			int mid = (l + r) >> 1;
			if(check(mid) >= m)ans = mid, l = mid + 1;
			else r = mid - 1;
		}
		printf("%d\n", ans);
		return 0;
	}
	if(m == 1){
		q.push(1);d[1]  = 0;
		int mas = 0, maxs = 1;
		while(q.size()){
			int x = q.front();q.pop();
			if(d[x] > mas) mas = d[x], maxs = x;
			for (int i = head[x];i ;i = e[i].next){
				int v = e[i].v;
				if(v == 1 || d[v])continue;
				d[v] = e[i].s + d[x];
				q.push(v);
			}
		}
		for (int i = 1;i <= n; i++)d[i] = 0;
		q.push(maxs);mas = 0;int root = maxs;
		while(q.size()){
			int x = q.front();q.pop();
			if(d[x] > mas)mas = d[x], maxs = x;
			for (int i = head[x];i ; i = e[i].next){
				int v = e[i].v;
				if(v == root|| d[v])continue;
				d[v] = d[x] + e[i].s;
				q.push(v);
			}
		}
		printf("%d\n", mas);
		return 0;
	}
	sort(a + 1, a + n + 1);
	int l = 1, r = 0x3f3f3f3f, ans = -1;
	while(l <= r){
		int mid = (l + r) >> 1;
		if(check2(mid) >= m){
			ans = mid , l = mid + 1;
		}
		else r=  mid - 1;
	}
	printf("%d\n", ans);
	return 0;
}