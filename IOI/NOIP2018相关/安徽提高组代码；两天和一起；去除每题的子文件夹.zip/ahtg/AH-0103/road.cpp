#include<iostream>
#include<algorithm>
#include<queue>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<string>
#define MAXN 100005
#define MAXM 10005
using namespace std;
int n;
int d[MAXN];

int sum=0;
int pd=1;
void work(int l,int r)
{	
	if((l==r)&&(d[l]==0))return;
	if((l==r)&&(d[l]!=0))
	{
	while(d[l]!=0)
	{
	d[l]--;
	sum++;
	}
	return;
	}
	while(pd!=0)
	{
	pd=0;
	for(int i=l;i<=r;i++)
	{	
		if(d[i]==0)
		{
			if(i==l)l++;
			if(i==r)r--;
			work(l,i-1);
			work(i+1,r);
		}
		else 
		{
		d[i]--;
		if(d[i]!=0)pd++;
		}
	}
	sum++;
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
cin >> n;
for(int i=1;i<=n;i++)
cin >> d[i];
work(1,n);
cout << sum;
return 0;
}
