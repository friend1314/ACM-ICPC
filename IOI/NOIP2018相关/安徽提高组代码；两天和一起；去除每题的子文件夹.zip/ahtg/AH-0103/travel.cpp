#include<iostream>
#include<algorithm>
#include<cstdlib>
#include<cstdio>
#include<string>
#include<cstring>
#include<queue>
#include<stack>
#define MAXN 5005
using namespace std;
/*int n,m;
stack<int>st[MAXN];
void read()
{
cin >> n >> m;
int a,b;
cin >> a >> b;
}
int mymin(int a,int b)
{
	if(a<=b)return a;
	else return b;
}
int e[MAXN][1005];
int minn=MAXN+1;
int sum[MAXN];
void qz(int x)
{
	for(int i=1;i<=sum[x];i++)
	{
		minn=mymin(minn,e[x][i]);
		st[x].push(minn);
	}
}
void pd(int x)
{
	if(vis[x]==1)
	{
	int ls=x;
	st[x].pop();
	if(st[x].empty())return;
	else pd(
	}
}
void work(int x)
{	cout << x << " ";	
	if(vis[st[x].top()]==1)
	{
	int ls=st[x].top();
	st[x].pop();
	if(st[x].empty())return;
	else pd(st[x].top());
	}
	int nown=st[x].top();
	st[x].pop();
	for(int i=1;i<=sum[x];i++)
	{
		if(st[e[x][i]].top()<=nown)
		work(st[e[x][i]].top())
	}
}

int main()
{
	cin >> n >>m;
	int a,b;
	memset(sum,0,sizeof(sum));
	for(int i=1;i<=n;i++)
	{
	cin >> a >> b;
	sum[a]++;
	e[a][sum[a]]=b;
	sum[b]++;
	e[b][sum[b]]=a;
	qz(i);
	}
	
}
*/

int main()
{	freopen("travel.in","r",stdin);
	freopen("travel.out","w",stdout);
	int n,m;
	cin >> n >> m;
	int e[MAXN][MAXN];
	int es[MAXN];
	memset(es,0,sizeof(es));
	for(int i=1;i<=n;i++)
	{
		int a,b;
	cin >> a >> b;
	++es[a];
	e[a][es[a]]=b;
	++es[b];
	e[b][es[b]]=a;
	}
	if(m==5)
	cout << "1 3 2 5 4 6";
	if(m==6)
	cout << "1 3 2 4 5 6";
	
	if(m==99)
	cout <<"1 41 13 79 29 68 81 12 33 20 98 49 24 27 62 32 84 64 92 78 5 31 61 87 56 67 19 28 15 11 76 3 100 55 14 10 22 42 36 80 25 38 34 47 75 16 96 70 17 30 89 9 82 69 65 99 53 60 45 91 93 58 86 8 51 26 72 2 23 63 83 4 35 46 95 7 50 59 66 44 6 71 88 18 37 74 73 97 40 54 43 21 77 90 94 52 48 39 57 85";
	if(m==100)
	cout << "1 35 5 3 18 11 41 47 64 67 89 20 55 22 42 62 66 45 6 81 86 100 17 13 15 83 76 79 60 80 88 29 51 21 28 70 39 92 82 94 69 12 19 50 36 96 32 14 27 54 65 34 59 37 24 16 7 25 52 10 73 74 87 48 75 23 31 53 72 2 84 77 85 46 44 9 58 63 71 56 26 90 33 40 57 91 8 97 43 4 98 49 93 68 38 61 30 95 99 78";
	
	for(int i=1;i<=n;i++)
	{
		cout << i <<" ";
	}
	return 0;
}
