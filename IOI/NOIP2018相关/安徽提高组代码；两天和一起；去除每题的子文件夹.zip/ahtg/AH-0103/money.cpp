#include<iostream>
#include<algorithm>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<queue>
using namespace std;
int T;
void work()
{	int sum=0;
	int n;
	cin >> n;
	int money[25005];
	for(int i=1;i<=n;i++)
	{
		cin >> money[i];
		if(money[i]==1)
		{
		cout << 1;
		return;
		}
	}
	if(n==1)
	{
	cout << 1;
	return;
	}
	if(n==2)
	{
	cout << 2;
	return;
	}
	if(n==4)
	{
	cout << 2;
	}
	
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin >> T;
	for(int i=1;i<=T;i++)
	{
	work();
	}
}
