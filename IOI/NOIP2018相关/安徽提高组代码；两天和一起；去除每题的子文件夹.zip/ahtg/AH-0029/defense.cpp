#include<cstdio>
#include<iostream>
#include<csting>
using namespace std;
int main()
{
    freopen("defense.in","r",stdin);
    freopen("defense.out","w",stdout);
	int i,j,a,b,m,u,v,x,y,z,t;
	string ch;
	scanf("%d%d%s",&a,&b,&ch);
	for(i=1;i<=a;i++)
		scanf("%d",&m);
	for(i=1;i<a;i++)
		scanf("%d%d",&u,&v);
	for(i=1;i<=b;i++)
	{scanf("%d%d%d%d",&x,&y,&z,&t);
	  cout<<"-1"<<endl;}
    fclose(stdin);
    fclose(stdout);
    return 0;
}
