#include<cstdio>
#include<iostream>
#include<algorithm>
long long u,v,n,m;
long long s[10001],t[10001];
using namespace std;
int main()
{
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
	int i,j,maxn=-999999;
	scanf("%d%d",&n,&m);
	for(i=1;i<=2*m;i++)
	{
		scanf("%d",&s[i]);
		t[i]=s[i];
	}
		cout<<s[1]<<" "<<s[2]<<" ";
	for(i=3;i<=2*m;i++)
		cout<<s[i]<<" ";
    fclose(stdin);
    fclose(stdout);
    return 0;
}