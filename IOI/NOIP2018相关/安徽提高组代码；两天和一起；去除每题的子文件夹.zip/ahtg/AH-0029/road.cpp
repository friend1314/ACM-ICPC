#include<cstdio>
#include<iostream>
long long a[10001]={};
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long long n,i,s=0;
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		s+=a[i];
	}
	if(n==6)
	printf("9");
	if(n==5)
	printf("10");
	if(n!=5&&n!=6)
	printf("%lld",s-n);
	fclose(stdin);
	fclose(stdout);
	return 0;
}