#include <bits/stdc++.h>
using namespace std;
int n,m;
long long d[100010];
long long ans=0;

int check(int l,int r)
{
	for(int i=l;i<=r;i++)
	{
		if(d[i]==0) return i;
	}
	return r;
}
void xiulu(int l,int r)
{
	if(l>r) return;
	if(l==r)
	{
		if(d[l]>0)
		{
			while(d[l]>0)
			{
				d[l]--;
				ans++;
			}
			return;
		}
		else
		{
			return;
		}
	}
	if(check(l,r)==r&&d[r]>0)
	{
		for(int i=l;i<=r;i++)
		{
			d[i]-=1;
		}
		ans++;
	}
	if(check(l,r)==r&&d[r]>0)
	{
		xiulu(l,r);
	}
	if(check(l,r)!=r)
	{
		xiulu(l,check(l,r)-1);
		xiulu(check(l,r)+1,r);
	}
	if(check(l,r)==r&&d[r]==0)
	{
		xiulu(l,r-1);
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&d[i]);
	}
	xiulu(1,n);
	printf("%lld",ans);
	return 0;
}
