#include <bits/stdc++.h>
using namespace std;
int a[105],n;

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		int flag=0;
		memset(a,0,sizeof(a));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			if(a[i]==1) flag=1;
		}
		if(flag==1) printf("1\n");
		else printf("%d\n",n);
	}
	return 0;
}
