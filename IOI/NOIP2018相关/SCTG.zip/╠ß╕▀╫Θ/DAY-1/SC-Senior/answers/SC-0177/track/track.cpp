#include <bits/stdc++.h>
using namespace std;
const int maxn=50005;
int head[maxn],ei,ind[maxn],outd[maxn],n,m,u[maxn];
long long dis[maxn];
long long ans=0;
struct edge{
	int to,next;
	long long v;
	int x,y;
}e[maxn];

void add(int x,int y,int v)
{
	ei++;
	e[ei].next=head[x];
	head[x]=ei;
	e[ei].to=y;
	e[ei].v=v;
	e[ei].x=x;
	e[ei].y=y;
	ind[y]++;
	outd[x]++;
}

struct node{
	long long dis;
	int id;
	bool operator < (const node&x) const
	{
		return dis>x.dis;
	}
};
priority_queue<node> q;
long long dij(int f)
{
	long long ans1=0;
	memset(dis,0,sizeof(dis));
	memset(u,0,sizeof(u));
	dis[f]=0;
	node nd;
	nd.id=f;
	nd.dis=0;
	q.push(nd);
	while(!q.empty())
	{
		int f1=q.top().id;
		q.pop();
		if(u[f1]==1) continue;
		u[f1]=1;
		for(int i=head[f1];i;i=e[i].next)
		{
			int t=e[i].to;
			if(u[t]==1) continue;
			if(dis[t]<dis[f1]+e[i].v)
			{
				dis[t]=dis[f1]+e[i].v;
				//printf("%d %d %d %d\n",f,f1,t,dis[t]);
				node nd;
				nd.id=t;
				nd.dis=dis[t];
				q.push(nd);
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		ans1=max(ans1,dis[i]);
	}
	return ans1;
}

void work1()
{
	for(int i=1;i<=n;i++)
	{
		ans=max(ans,dij(i));
	}
}


int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++)
	{
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		add(u,v,w);
		add(v,u,w);
	}
	if(m==1)
	{
		work1();
	}
	else
	{
		ans=13;
	}
	printf("%lld",ans);
	return 0;
}
