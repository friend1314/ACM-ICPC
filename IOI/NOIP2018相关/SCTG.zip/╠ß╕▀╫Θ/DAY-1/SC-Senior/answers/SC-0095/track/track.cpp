#include<bits/stdc++.h>
using namespace std;
int yy=-100,xx,maxx[1000];
int a[10005],us[10005],way[1005][1005];
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	if(m==1)
	{int a,b,c;for(int j=1;j<=n;j++)
	for(int i=1;i<=n;i++)
	way[i][j]=-1002;for(int  i=1;i<n;i++)
	{
		cin>>a>>b>>c;
		way[a][b]=way[b][a]=c;
	}	
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		us[i]=0;
		
		
       
		for(int i=1;i<n;i++)
		maxx[i]=-1000002;
		for(int i=1;i<=n;i++)
		maxx[i]=way[i][k];us[k]=1;				
		
		for(int i=1;i<=n;i++)
		{
			int r=-40,kk;
			for(int j=1;j<=n;j++)
			if(us[j]==0&&r<maxx[j])
			{
				kk=j;
				r=maxx[j]; 
			}
			
			if(r==-40) break;us[kk]=1;
			for(int j=1;j<=n;j++)
			{
				if(maxx[j]<maxx[kk]+way[kk][j]&&kk!=j)
				maxx[j]=maxx[kk]+way[kk][j];
			}
		}
		xx=-100;
		for(int j=1;j<=n;j++)
		{
			cout<<maxx[j]<<" ";
			if(xx<maxx[j])xx=maxx[j];
		}
		cout<<endl;
		if(xx>yy)
		yy=xx;
		cout<<yy<<endl;
		
		
		
	}cout<<yy;return 0;
}
}
