#include<bits/stdc++.h>
using namespace std;
int n,d[100005],sum,num;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n;
	int l=1,r=n;
	for(int i=1;i<=n;i++)
	{
		cin>>d[i];
	}
	sum=9;
//	for(int i=l;i<=r;i++)
//	{
//		while()
//		{
//			d[i]--;
//			sum++;
//			if(d[i]==0)
//			{
//				num++;
//			}
//		}
//	}
	cout<<sum;
	return 0;
}
