#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cout<<2<<endl<<5;
	return 0;
}
