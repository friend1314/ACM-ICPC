#include<cstdio>
using namespace std;
const int MAXN=131072;
int d[MAXN];
int N;
unsigned long long Pulu(int l,int r)
{
	if(l>r) return 0;
	int Min_depth=50000;
	int Find=l;
	for(int i=l;i<=r;i++)
	if(d[i]<Min_depth) {
	Min_depth=d[i];
	Find=i;
	}
	for(int i=l;i<=r;i++)
	d[i]-=Min_depth;
	return (unsigned long long)Min_depth+Pulu(l,Find-1)+Pulu(Find+1,r);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&N); 
	for(int i=0;i<N;i++) scanf("%d",&d[i]);
	unsigned long long Answer=Pulu(0,N-1);
	printf("%lld",Answer);
	return 0;
}

