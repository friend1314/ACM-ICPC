#include<cstdio>
#include<algorithm>
using namespace std;
int N;
int a[32768];
/*void Mem()
{
	for(int i=0;i<32768;i++)
	a[i]=0;
	return;
}*/
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&N);
	for(int TIMES=0;TIMES<N;TIMES++){
		int M=0;
		scanf("%d",&M);
		int Ans=66666;
		for(int i=0;i<M;i++) {
		scanf("%d",&a[i]);
		if(a[i]<Ans) Ans=a[i];
		}
		Ans-=1;
		printf("%d\n",Ans);
		for(int i=0;i<M;i++) a[i]=0;
	}
	return 0;
}

