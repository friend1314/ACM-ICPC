#include<cstdio>
#include<cstring>
using namespace std;
const int MAXN=60000;
int N,M,Ans,MaxAns;												//N���ڵ㡣 
int Length[MAXN],Start[MAXN],End[MAXN],Appeared[MAXN];
void VioDfs(int Location)									//���ѡ� 
{
	for(int i=0;i<2*N;i++)
	{
		if(Location==Start[i]&&Length[i]>0){
			Ans+=Length[i];
			Length[i]=-Length[i];
			if(i<N)Length[i+N]=-Length[i+N];				//��·�� 
			if(i>=N)Length[i-N]=-Length[i-N];
			VioDfs(End[i]);
			Length[i]=-Length[i];
			if(i<N)Length[i+N]=-Length[i+N];				//��·�� 
			if(i>=N)Length[i-N]=-Length[i-N];
			Ans-=Length[i];
		}
	}
	if(Ans>MaxAns) MaxAns=Ans;
	return;
}
int main()
{
freopen("track.in","r",stdin);
freopen("track.out","w",stdout);
scanf("%d%d",&N,&M);
for(int i=1;i<N;i++)
{
	scanf("%d%d%d",&Start[i],&End[i],&Length[i]);
	Start[N+i]=End[i];
	End[N+i]=Start[i];
	Length[N+i]=Length[i];
}
for(int i=0;i<N;i++)
VioDfs(i);
printf("%d",MaxAns);
 return 0;
}
