/*
	Name:TrickEye_AFO_Round1_File1
	Copyright:TrickEye
	Author:TrickEye
	Date: 10/11/18 08:11
	Description:GoodBye NOIP
*/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<cmath>
#include<stack>
#include<queue>
#include<algorithm>
#define ll long long
#define db double
#define rd read()
#define gc getchar()
#define maxn 100010
#define inputfile "road.in","r",stdin
#define outputfile "road.out","w",stdout
using namespace std;

ll rd {
	ll x = 0; int f = 1; char c = gc;
	while(c >'9' || c <'0') f = (c =='-')?-1:1, c = gc;
	while(c>='0'&&c<='9') x = 10 * x + c - '0', c = gc;
	return x * f;
}

int n, flag, depth[maxn];
ll ans = 0;
int deleteAreaStart, minNumber;

int main() {
	freopen(inputfile);freopen(outputfile); //filename announcement
	n = rd; for (int i = 0; i < n; i++)	depth[i] = rd; //input
	
	flag = 1; //If flag == 1 it means the array includes nothing but 0
	while(1) {
		for (int pos = 0; pos <= n; pos++) { // pos is the current position
			if (depth[pos] > 0) {
				if (flag == 1) flag = 0;  // it means the array has a non-0 number
				
				deleteAreaStart = pos; minNumber = depth[pos]; //Initialization
				while(depth[pos] > 0 && pos <= n) {minNumber = min(minNumber, depth[pos]); pos++;} // Find the lowest depth
				for (int i = deleteAreaStart; i <= pos; i++) depth[i] -= minNumber; //Fix the lowest depth to zero as well as those beside it
				ans += minNumber; //It takes "minNumber" days to fix it
			}
		}
		if (flag == 1) break;
		else flag = 1;
		continue;
	}
	printf("%lld", ans);
    return 0;
}
