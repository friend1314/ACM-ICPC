/*
	Name:TrickEye_AFO_Round1_File3
	Copyright:TrickEye
	Author:TrickEye
	Date: 10/11/18 11:36
	Description:10Pts is quite satisfying
*/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<cmath>
#include<stack>
#include<queue>
#include<algorithm>
#define ll long long
#define db double
#define rd read()
#define gc getchar()
#define maxn 1010
#define inputfile "track.in","r",stdin
#define outputfile "track.out","w",stdout
using namespace std;

ll rd {
	ll x = 0; int f = 1; char c = gc;
	while(c>'9'||c<'0') f = (c=='-')?-1:1, c=gc;
	while(c>='0'&&c<='9') x = 10 * x + c - '0', c = gc;
	return x * f;
}

bool vis[maxn] = {0};
int road[maxn][maxn];
int n, m;
ll ans = 0;

void dfs(int start, ll maxlen){
	vis[start] = 1; ans = max(maxlen, ans);
	for (int i = 0; i < n; i++) {
		if (road[start][i] > 0 && vis[i] == 0) dfs(i, maxlen + road[start][i]);
	}
	vis[start] = 0;
}

int main() {
	freopen(inputfile);freopen(outputfile);
    n = rd, m = rd;
    for (int i = 0; i < n - 1; i++){
    	int a = rd;
    	int b = rd;
    	int l = rd;
    	road[a-1][b-1] = l;
    	road[b-1][a-1] = l;
    }
    for (int i = 0; i < n; i++) {
		dfs(i,0);
    }
    printf("%lld", ans);
    return 0;
}
/*
7 1
1 2 10
1 3 5
2 4 9
2 5 8
3 6 6
3 7 7
*/

