/*
	Name:TrickEye_AFO_Round1_File2
	Copyright:TrickEye
	Author:TrickEye
	Date: 10/11/18 09:55
	Description: Maybe 50 pts
*/

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<cmath>
#include<stack>
#include<queue>
#include<algorithm>
#define ll long long
#define db double
#define rd read()
#define gc getchar()
#define maxn 105
#define inputfile "money.in","r",stdin
#define outputfile "money.out","w",stdout
using namespace std;

ll rd {
	ll x = 0; int f = 1; char c = gc;
	while(c>'9'||c<'0') f = (c=='-')?-1:1, c=gc;
	while(c>='0'&&c<='9') x = 10 * x + c - '0', c = gc;
	return x * f;
}

int n, bill[maxn];
int ans;

int main() {
	freopen(inputfile);freopen(outputfile);
	int T = rd;
	while(T--) {
		n = rd;
		for (int i =0; i < n; i++) bill[i] = rd;
		sort(bill, bill+n);
		if (n == 1) ans = 1;
		if (n == 2) {
			if (bill[1] % bill[0] == 0) ans = 1;
			else ans = 2;
		}
		if (n == 3) {
			ans = 3; int f = 0; 
			if (bill[2] % bill[1] == 0) ans--, f = 1;
			else if(bill[2] % bill[0] == 0) ans--; f = 1;
			if (bill[1] % bill[0] == 0) ans--;
			if (f == 0) {
				for (int i = 1; bill[1]*i <= bill[2]; i++) {
					if ((bill[2] - bill[1]*i) % bill[0] == 0 && (bill[2] - bill[1]*i) >= 0) {ans--; break;}
				}
			}
		}
		if (n == 4) {
			ans = 4; int f1 = 0, f2 = 0;
			if (bill[3] % bill[2] == 0) ans--, f1 = 1;
			else if (bill[3] % bill[1] == 0) ans--, f1 = 1;
			else if (bill[3] % bill[0] == 0) ans--, f1 = 1;
			if (bill[2] % bill[1] == 0) ans--, f2 = 1;
			else if (bill[2] % bill[0] == 0) ans--, f2 = 1;
			if (bill[1] % bill[0] == 0) ans--;
			if (f1 == 0) {
				for (int i = 1; bill[2]*i <= bill[3]; i++) {
					for (int j = 1; bill[1]*j <= bill[3]; j++) {
						if ((bill[3] - bill[2]*i - bill[1]*j) % bill[0] == 0 && (bill[3] - bill[2]*i - bill[1]*j) >= 0) {ans--; goto p1;}
					}
				}
			}
			p1:if (f2 == 0) {
				for (int i = 1; bill[1]*i <= bill[2]; i++) {
					if ((bill[2] - bill[1]*i) % bill[0] == 0 && (bill[2] - bill[1]*i) >= 0) {ans--; break;}
				}
			}
		}
		if (n == 5) {
			ans = 5; int f1 = 0, f2 = 0, f3 = 0;
			if (bill[4] % bill[3] == 0) ans--, f1 = 1;
			else if (bill[4] % bill[2] == 0) ans--, f1 = 1;
			else if (bill[4] % bill[1] == 0) ans--, f1 = 1;
			else if (bill[4] % bill[0] == 0)ans--, f1 = 1;
			if (bill[3] % bill[2] == 0) ans--, f2 = 1;
			else if (bill[3] % bill[1] == 0) ans--, f2 = 1;
			else if (bill[3] % bill[0] == 0) ans--, f2 = 1;
			if (bill[2] % bill[1] == 0) ans--, f3 = 1;
			else if (bill[2] % bill[0] == 0) ans--, f3 = 1;
			if (bill[1] % bill[0] == 0) ans--;
			if (f1 == 0) {
				for (int i = 1; bill[3]*i <= bill[4]; i++) {
					for (int j = 1; bill[2]*j <= bill[4]; j++) {
						for (int k = 1; bill[1]*k <= bill[4]; k++) {
							if ((bill[4] - bill[3]*i - bill[2]*j - bill[1]*k) % bill[0] == 0 && (bill[4] - bill[3]*i - bill[2]*j - bill[1]*k) >= 0) {ans--; goto p2;}
						}
					}
				}
			}
			p2:if (f2 == 0) {
				for (int i = 1; bill[2]*i <= bill[3]; i++) {
					for (int j = 1; bill[1]*j <= bill[3]; j++) {
						if ((bill[3] - bill[2]*i - bill[1]*j) % bill[0] == 0 && (bill[3] - bill[2]*i - bill[1]*j) >= 0) {ans--; goto p3;}
					}
				}
			}
			p3:if (f3 == 0) {
				for (int i = 1; bill[1]*i <= bill[2]; i++) {
					if ((bill[2] - bill[1]*i) % bill[0] == 0 && (bill[2] - bill[1]*i) >= 0) {ans--; break;}
				}
			}
		}
		printf("%d\n", ans);
		ans = 0;
	}
	
    return 0;
}

/*
1
5
11 29 13 19 17
*/
