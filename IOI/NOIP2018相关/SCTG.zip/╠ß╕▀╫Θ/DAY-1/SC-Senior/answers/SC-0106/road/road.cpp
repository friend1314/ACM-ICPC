#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<vector>
#include<map>
#include<set>
#include<queue>
using namespace std;
//int gcd(int a,int b){return !b?a:(b,a%b);}
int min(int a,int b){
	return a>b?a:b;
}
long long n,a,maxn=0,ans;

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;++i){
		scanf("%d",&a);
		if(a>maxn){
		ans+=a-maxn;
			maxn=a;
			
		}else{
			maxn=a;
	//	ans+=max(a-ans,0);	
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
