#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<vector>
#include<map>
#include<set>
#include<queue>
using namespace std;
const int inf=-1e9;
int n,m,wh=1,a[1005][1005],d[1005],ma[1005];
bool f[1005];
void dd(int x){
	for(int i=1;i<=n;i++){
		d[i]=0;
		f[i]=0;
	}f[x]=1;
	for(int i=1;i<=n;i++){
		if(i==x){
			d[i]=0;
			continue;
		}
		a[i][x]==0?d[i]=inf:d[i]=a[i][x];
	}
	for(int i=1;i<=n;++i){
		if(i==x)continue;
		int v,maxx=inf;
		for(int j=1;j<=n;++j){
			if(d[j]>maxx&&f[j]==0){
				v=j;
				maxx=d[j];
			}
		}
		f[v]=1;
		for(int j=1;j<=n;++j){
			if(v==j||j==x)continue;
			
			d[j]=max(a[v][j]+d[v],d[j]);
			
			ma[wh]=max(ma[wh],d[j]);
		}
	}
}
bool cmp(int aa,int bb){
	return aa>bb;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;++i){
		ma[i]=inf;
	}
	int a1,b1,l1;
	for(int i=1;i<n;++i){
		scanf("%d%d%d",&a1,&b1,&l1);
		a[a1][b1]=l1;
		a[b1][a1]=l1;
	}
	for(wh=1;wh<=n;++wh){
		dd(wh);
	}
	
	sort(ma+1,ma+n+1,cmp);
//	for(int i=1;i<=n;i++)cout<<ma[i]<<" ";
	cout<<ma[1];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
