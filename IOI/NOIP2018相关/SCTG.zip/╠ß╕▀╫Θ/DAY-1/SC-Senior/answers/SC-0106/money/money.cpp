#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<vector>
#include<map>
#include<set>
#include<queue>
using namespace std;
int gcd(int a,int b){return !b?a:(b,a%b);}
int t,n,a[300],ans;

/*
bool usd[300],fff=0;
void d(int x){
	int hhh[110],xxx=0;
	for(int i=1;i<=n;++i){
		if(usd[i]==1){
			hhh[++xxx]=a[i];
		}
	}
	for(int i=1;i<=x;++i){
		
	}
	for(int i=1;i<=n;++i){
		if(usd[i]==0){
			usd[i]=1;
			d(x+1);
			usd[i]=0;
		}
	}
}
*/
int u[300],u_num=0,minn;
bool fck(int x){
	int hh=x;
	for(int i=1;i<=u_num;++i){
		
		if(hh%u[i]==0){
			return 0;
		}while(hh>minn){
			hh-=u[i];
	//	if(hh<minn)continue;
		for(int j=1;j<=u_num;++j){
			if(hh%u[j]==0) return 0;
		}
	}
		hh=x;
	}
	u_num++;
	u[u_num]=x;
	return 1;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t--){
		scanf("%d",&n);
		ans=0;
		u_num=0;
		for(int i=1;i<=200;++i)u[i]=0;
		for(int i=1;i<=n;++i){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		//d(0);
		minn=a[1];
		for(int j=1;j<=n;++j){
		if(fck(a[j])==1)ans++;
	}
	for(int i=1;i<=u_num;++i)cout<<u[i]<<" ";
	
		printf("%d\n",ans);
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
