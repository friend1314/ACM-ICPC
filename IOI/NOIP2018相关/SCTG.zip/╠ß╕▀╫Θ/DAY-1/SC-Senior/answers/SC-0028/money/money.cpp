#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
using namespace std;

int n;
int a[25];
int b[25];
int maxn;
int p;
int dp[25][3000];
int f[25][3000];
int ans;

void dfs(int x,int y)
{
    if(x>n||y>=ans)return ;
    if(x==n)
    {
        memset(dp,0,sizeof(dp));
        dp[0][0]=1;
        for(int i=1; i<=p; i++)
        {
            for(int j=0; j<=maxn; j++)
            {
                dp[i][j]+=dp[i-1][j];
                if(j-b[i]>=0)dp[i][j]+=dp[i][j-b[i]];
            }
        }
        for(int j=0; j<=maxn; j++)
        {
            if((f[n][j]>0&&dp[p][j]<=0)||(f[n][j]<=0&&dp[p][j]>0))
                return ;
        }
        ans=min(ans,y);
        return ;
    }

    dfs(x+1,y);
    p++;
    b[p]=a[x+1];
    dfs(x+1,y+1);
    b[p]=0;
    p--;
}

int main()
{
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        maxn=0;
        ans=n;
        p=0;
        memset(f,0,sizeof(f));
        for(int i=1; i<=n; i++)
        {
            scanf("%d",&a[i]);
            maxn=max(a[i],maxn);
            a[i]*=-1;
        }
        sort(a+1,a+1+n);
        for(int i=1;i<=n;i++)
            a[i]*=-1;
        f[0][0]=1;
        for(int i=1; i<=n; i++)
        {
            for(int j=0; j<=maxn; j++)
            {
                f[i][j]+=f[i-1][j];
                if(j-a[i]>=0)f[i][j]+=f[i][j-a[i]];
            }
        }
        dfs(1,0);
        p=1;
        b[1]=a[1];
        dfs(1,1);
        p=0;
        b[1]=0;
        printf("%d\n",ans);
    }
    return 0;
}

