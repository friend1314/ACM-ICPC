#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;

int n;
int d[200005];

long long ans;

int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&d[i]);
    }
    for(int i=2;i<=n+1;i++)
    {
        if(d[i]<d[i-1])
            ans+=(d[i-1]-d[i]);
    }
    printf("%lld\n",ans);
    return 0;
}

