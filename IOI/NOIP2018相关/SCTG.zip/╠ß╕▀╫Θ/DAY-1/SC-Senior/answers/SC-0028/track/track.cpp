#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
using namespace std;

int n,m;
vector <int> q[50010];
vector <int> v[50010];

//namespace mis1
//{
int dis[50010];
bool vis[50010];
queue<int> p;
void dfs(int x)
{
    for(int i=0; i<q[x].size(); i++)
    {
        int nx=q[x][i];
        if(vis[nx])continue;
        dis[nx]=dis[x]+v[x][i];
        vis[nx]=1;
        dfs(nx);
    }
}
void longest()
{
    memset(dis,0,sizeof(dis));
    memset(vis,0,sizeof(vis));
    vis[1]=1;
    dfs(1);
    int maxn=0,st=0;
    for(int i=1; i<=n; i++)
    {
        if(dis[i]>maxn)
        {
            dis[i]=maxn;
            st=i;
        }
    }
    memset(dis,0,sizeof(dis));
    memset(vis,0,sizeof(vis));
    vis[st]=1;
    dfs(st);
    maxn=0;
    for(int i=1; i<=n; i++)
        maxn=max(dis[i],maxn);
    printf("%d\n",maxn);
}
//}

//namespace ais1
//{
int s[50010];
int ans=0x3f3f3f3f;
void deal()
{
    int num=0;
    for(int i=0; i<q[1].size(); i++)
    {
        int nx=q[1][i];
        num++;
        s[num]=(-1)*v[1][i];
    }
    sort(s+1,s+1+num);
    for(int i=1; i<=num; i++)
        s[i]*=(-1);
    int o=m+1;
    for(int i=m; i>=1; i--)
    {
        int l=s[i];
        if(o<=num)
        {
            l+=s[o];
            o++;
        }
        ans=min(ans,l);
    }
    printf("%d\n",ans);
}
//}

//namespace lian
//{
int le[50010];
bool cck(int x)
{
    int last=0;
    int sum=0;
    for(int i=1; i<n; i++)
    {
        if(last<x)
            last+=le[i];
        if(last>=x)
        {
            last=0;
            sum++;
        }
    }
    if(sum>=m)return true;
    return false;
}
int erfen(int l,int r)
{
    if(l==r)
    {
        return l;
    }
    int mid=(l+r+1)/2;
    if(cck(mid))return erfen(mid,r);
    else return erfen(l,mid-1);
}
void run()
{
    int maxn=0;
    for(int i=1; i<n; i++)
    {
        for(int j=0; j<q[i].size(); j++)
        {
            int nx=q[i][j];
            if(nx==i+1)
                le[i]=v[i][j];
        }
        maxn+=le[i];
    }
    int an=erfen(1,maxn);
    printf("%d\n",an);
}
//}

int main()
{
    freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    scanf("%d%d",&n,&m);
    bool ok=1;
    bool op=1;
    for(int i=1; i<n; i++)
    {
        int x,y,z;
        scanf("%d%d%d",&x,&y,&z);
        if(x!=1&&y!=1)
            ok=0;
        if(x!=(y+1)&&y!=(x+1))
            op=0;
        q[x].push_back(y);
        q[y].push_back(x);
        v[x].push_back(z);
        v[y].push_back(z);
    }
    if(m==1)
    {
        //mis1::longest();
        longest();
        return 0;
    }
    if(ok)
    {
        //ais1::deal();
        deal();
        return 0;
    }
    if(op)
    {
        //lian::run();
        run();
        return 0;
    }
    return 0;
}

