#include<iostream>
#include<cmath>
#include<cstdio>
#define LL long long
using namespace std;
const LL INF=0x3f3f3f3f;
LL n,d[100100],k,ans,mi,l,r;
bool z;
void js()
{
    if(l==r)
        d[l]-=mi;
    else for(int i=l;i<=r;++i)
    {
        d[i]-=mi;
    }
    return;
}
int main()
{
    freopen("road.in","r",stdin),freopen("road.out","w",stdout);
    scanf("%lld",&n);
    for(LL i=1;i<=n;++i)
        scanf("%d",&d[i]);
    while(true)
    {
        z=0,mi=INF,k=0;
        for(int i=1;i<=n;++i)
        {
            if(i==n&&z==0&&d[i]==0)
            {
                printf("%lld\n",ans);
                return 0;
            }
            if(d[i]>0)
            {
                if(z==0)
                {
                    l=i,z=1;
                }
                mi=min(mi,d[i]);
                if(d[i-1]==0&&d[i+1]==0)
                {
                    r=l;
                    ans+=mi;
                    js();
                    break;
                }
                else if(d[i+1]==0)
                {
                    r=i;
                    ans+=mi;
                    js();
                    break;
                }
            }
        }
    }
	return 0;
}
