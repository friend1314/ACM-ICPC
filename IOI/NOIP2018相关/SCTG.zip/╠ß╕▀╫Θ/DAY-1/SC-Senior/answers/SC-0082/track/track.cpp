#include<iostream>
#include<cmath>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<map>
using namespace std;
const int INF=0x3f3f3f3f;
int n,m;
struct Node
{
    int ed,w;
};
vector<Node>vt[50100];
int dist[50100];
bool vis[50100];
void dj(int s)
{
    memset(dist,INF,sizeof(dist));
    memset(vis,0,sizeof(vis));
    for(int i=0;i<vt[s].size();++i)
        dist[vt[s][i].ed]=min(vt[s][i].w,dist[vt[s][i].ed]);
    vis[s]=1,dist[s]=0;
    for(int i=1;i<=n;++i)
    {
        int mxx=INF,pos;
        for(int j=1;j<=n;++j)
            if(!vis[j]&&dist[j]<mxx)
                mxx=dist[j],pos=j;
        vis[pos]=1;
        for(int j=0;j<vt[pos].size();++j)
            if(!vis[vt[pos][j].ed]&&dist[vt[pos][j].ed]>vt[pos][j].w+dist[j])
                dist[vt[pos][j].ed]=vt[pos][j].w+dist[j];
    }
    return ;
}
int main()
{
    freopen("track.in","r",stdin),freopen("track.out","w",stdout);
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n-1;++i)
    {
        int a,b,w;
        scanf("%d%d%d",&a,&b,&w);
        struct Node now;
        now.ed=b,now.w=w;
        vt[a].push_back(now);
        now.ed=a;
        vt[b].push_back(now);
    }
    int ans=0;
    for(int i=1;i<=n;++i)
    {
        dj(i);
        for(int j=1;j<=n;++j)
            ans=max(ans,(dist[j]==INF?0:dist[j]));
    }
    printf("%d\n",ans);
	return 0;
}
