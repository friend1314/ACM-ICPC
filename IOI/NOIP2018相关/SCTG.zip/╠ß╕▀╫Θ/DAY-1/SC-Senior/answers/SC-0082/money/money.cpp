#include<cstdio>
#include<algorithm>
using namespace std;
int T,n,a[200];
bool z[25100];
int main()
{
    freopen("money.in","r",stdin),freopen("money.out","w",stdout);
    scanf("%d",&T);
    while(T--)
    {
        int ans=0;
        scanf("%d",&n);
        for(int i=0;i<=n+50;++i)
            z[i]=0;
        for(int i=1;i<=n;++i)
        {
            scanf("%d",&a[i]);
        }
        sort(a+1,a+1+n);
        for(int i=1;i<=n;++i)
        {
            if(a[i]==1)
            {
                printf("1\n");
                z[0]=1;
                break;
            }
            if(z[a[i]]==0)
            {
                ans++;
                for(int j=a[i];j<=n+25;j+=a[i])
                    z[j]=1;
            }
        }
        if(z[0]==1)
            continue;
        else
            printf("%d\n",ans);
    }
	return 0;
}
