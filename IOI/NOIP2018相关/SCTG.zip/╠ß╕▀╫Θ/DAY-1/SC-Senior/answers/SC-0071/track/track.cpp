#include<cstdio>
#include<cstring>
#include<set>
int N,M,fir[50004],to[100004],len[100004],nxt[100004],edcnt = 1;
int rt,ssp[50004],cbdu[50004],du[50004];
bool deled[100004];
struct point_pt_l
{
	int pt,len;
	bool operator <(const point_pt_l &cmp)const
	{
		if(len != cmp.len)return len > cmp.len;
		return pt < cmp.pt;
	}
};
std::set<point_pt_l> cbS,S;
void AddEdge(int u,int v,int l)
{
	to[++edcnt] = v, len[edcnt] = l, nxt[edcnt] = fir[u], fir[u] = edcnt;
	to[++edcnt] = u, len[edcnt] = l, nxt[edcnt] = fir[v], fir[v] = edcnt;
}
void dfs_d1(int v,int l,int fa)
{
	ssp[v] = l;
	for(int i=fir[v];i;i=nxt[i])
	{
		if(to[i] != fa)dfs_d1(to[i],l+len[i],v);
	}
}
void dfs_d2(int v,int l,int fa)
{
	point_pt_l p = {v,ssp[v]=l};
	cbS.insert(p);
	for(int i=fir[v];i;i=nxt[i])
	{
		if(to[i] != fa)dfs_d2(to[i],l+len[i],v);
	}
}
int K,tmp_fa[50004];
int dfs_find(int v,int f,int dis,int &ret_dis)
{
	tmp_fa[v] = f;
	if(dis >= K){ret_dis = dis;return v;}
	int curmin = 1000000000,ret_,vv,vvvv = -1;
	for(int i=fir[v];i;i=nxt[i])
	{
		if(deled[i])continue;
		if(to[i] == f)continue;
		vv = dfs_find(to[i],v,dis+len[i],ret_);
		if(curmin > ret_)curmin = ret_, vvvv = vv;
	}
	ret_dis = curmin;
	return vvvv;
}
int del_aim;
bool dfs_erase(int v,int f)
{
	if(v == del_aim)return 1;
	for(int i=fir[v];i;i=nxt[i])
	{
		if(deled[i])continue;
		if(to[i] == f)continue;
		if(dfs_erase(to[i],v))
		{
			point_pt_l tmp;
			deled[i] = 1;
			deled[i^1] = 1;
			du[to[i]]--;
			du[v]--;
//			if(du[to[i]] == 0)
//			{
//				tmp.pt = to[i], tmp.len = ssp[to[i]];
//				S.erase(tmp);
//			}
//			if(du[v] == 0)
//			{
//				tmp.pt = v, tmp.len = ssp[v];
//				S.erase(tmp);
//			}
			return 1;
		}
	}
	return 0;
}
void dfs_rebuild(int v,int l,int fa)
{
	point_pt_l p = {v,l};
	S.insert(p);
	for(int i=fir[v];i;i=nxt[i])
	{
		if(deled[i])continue;
		if(to[i] == fa)continue;
		dfs_rebuild(to[i],l+len[i],v);
	}
}
int scc[50004],bel[50004],sccnt;
void dfs_scc(int v,int f)
{
	bel[v] = sccnt;
	for(int i=fir[v];i;i=nxt[i])
	{
		if(deled[i])continue;
		if(to[i] == f)continue;
		dfs_scc(to[i],v);
	}
}
void dfs_sssp(int v,int l,int fa)
{
	ssp[v] = l;
	for(int i=fir[v];i;i=nxt[i])
	{
		if(deled[i])continue;
		if(to[i] != fa)dfs_sssp(to[i],l+len[i],v);
	}
}
bool chec(int mid)
{
	memcpy(du,cbdu,sizeof du);
//	S = cbS;
	memset(deled,0,sizeof deled);
	K = mid;
	int i = 1,j,cur,ret_dis,tmp;
	bool did;
	while(i < M)
	{
//		cur = S.begin()->pt;
//		del_aim = dfs_find(cur,0,0,ret_dis);
//		if(del_aim == -1)return 0;
//		dfs_erase(cur,0);
//		S.clear();
//		dfs_rebuild(rt,0,0);
		sccnt = 0;
		memset(bel,0,sizeof bel);
		for(j=1;j<=N;j++)if(bel[i] == 0)
		{
			scc[sccnt++] = i;
			dfs_scc(i,0);
		}
		did = 0;
		for(j=0;j<sccnt;j++)
		{
			memset(ssp,0,sizeof ssp);
			dfs_sssp(scc[j],0,0);
			tmp = 0;
			for(int k = 1;k<=N;k++)
			{
				if(tmp < ssp[k])tmp = ssp[k], cur = k;
			}
			memset(ssp,0,sizeof ssp);
			dfs_sssp(cur,0,0);
			tmp = 0;
			for(int k = 1;k<=N;k++)
			{
				if(tmp < ssp[k])tmp = ssp[k], cur = k;
			}
			del_aim = dfs_find(cur,0,0,ret_dis);
			if(del_aim == -1)continue;
			dfs_erase(cur,0);
			i++;
			did = 1;
		}
		if(!did)return 0;
	}
	return 1;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int i,u,v,l,r,mid;
	scanf("%d%d",&N,&M);
	for(i=1;i<N;i++)
	{
		scanf("%d%d%d",&u,&v,&l);
		cbdu[u]++, cbdu[v]++;
		AddEdge(u,v,l);
	}

	dfs_d1(1,0,0);
	r = 0;
	for(i=1;i<=N;i++)
	{
		if(r < ssp[i])r = ssp[i], rt = i;
	}
	dfs_d2(rt,0,0);

	l = 1, r = cbS.begin()->len+1;
	if(M == 1){printf("%d",r-1);return 0;}
	while(r-l > 1)
	{
		mid = (l+r)>>1;
		if(chec(mid))l = mid;
		else r = mid;
	}
	printf("%d",l);
	return 0;
}
