#include<cstdio>
#include<cstring>
#include<algorithm>
int a[104];
bool f[2500004];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T,n,tot,ans,i,j;
	scanf("%d",&T);
	while(T--)
	{
		memset(f,0,sizeof f);
		f[0] = 1;
		tot = ans = 0;
		scanf("%d",&n);
		for(i=0;i<n;i++)scanf("%d",a+i), tot += a[i];
		std::sort(a,a+n);
		for(i=0;i<n;i++)
		{
			if(f[a[i]] == 0)
			{
				for(j=a[i];j<=tot;j++)f[j] |= f[j-a[i]];
				ans++;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
