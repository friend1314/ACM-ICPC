#include<cstdio>
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,a,las = 0,ans = 0;
	scanf("%d",&n);
	while(n--)
	{
		scanf("%d",&a);
		if(a > las)ans += a-las;
		las = a;
	}
	printf("%d",ans);
	return 0;
}
