#include<bits/stdc++.h>

using namespace std;

int n;
int xds[1001][1001];
int ans;

inline void bliud(int l,int r){
	if(l==r){
		cin>>xds[l][r];
		return;
	}
	int mid=(l+r)/2;
	bliud(l,mid);
	bliud(mid+1,r);
	xds[l][r]=min(xds[l][mid],xds[mid+1][r]);
}

inline void chuli(int l,int r,int mate){
	if(l==r){
		ans+=xds[l][r]-mate;
		return;
	}
	ans+=xds[l][r]-mate;
	mate=xds[l][r];
	int mid=(l+r)/2;
	chuli(l,mid,mate);
	chuli(mid+1,r,mate);
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	memset(xds,0xfffffff,sizeof(xds));
	cin>>n;
	bliud(1,n);
	chuli(1,n,0);
	cout<<ans;
	return 0;
}
