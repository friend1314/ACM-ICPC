#include<bits/stdc++.h>

using namespace std;

int T;
int a[101];
int n,ans;
int minnum;

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>T;
	while(T--){
		cin>>n;
		ans=n;
		minnum=0xfffffff;
		for(int i=1;i<=n;i++){
			cin>>a[i];
			minnum=min(minnum,a[i]);
		}
		for(int i=1;i<=n;i++){
			if(a[i]%minnum==0){
				ans--;
				a[i]=0;
			}
		}
		for(int i=1;i<=n;i++){
			a[i]=a[i]%10;
		}
		/*
		minnum=0xfffffff;
		for(int i=1;i<=n;i++){
			if(a[i]!=0&&a[i]!=1){
				minnum=min(minnum,a[i]);
			}
			//minnum=min(minnum,a[i]);
		}
		*/
		for(int i=1;i<=n;i++){
			if(a[i]!=0&&a[i]%minnum==0){
				ans--;
			}
		}
		cout<<ans+1<<endl;
	}
	return 0;
}
