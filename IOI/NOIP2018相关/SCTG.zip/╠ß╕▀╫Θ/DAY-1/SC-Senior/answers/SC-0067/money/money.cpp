#include<queue>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int M=110;
const int N=25100;
const int inf=0x3f3f3f3f;
int A[M],n,T,minv,ans;
struct ss{
	int to,last,len;
	ss(){}
	ss(int a,int b,int c):to(a),last(b),len(c){}
}g[N<<1];
int head[N],cnt,tc[N<<2],rec[N],top;
void add(int a,int b,int c){
	g[++cnt]=ss(b,head[a],c);head[a]=cnt;
}
int dis[N];
void init(){memset(head,0,sizeof(head));cnt=0;}
struct node{
	int d,p;
	node(){}
	node(int a,int b):d(a),p(b){}
	bool operator <(const node &a)const{return d>a.d;}
};
priority_queue <node> Q;
void dij(){
	while(!Q.empty())Q.pop();
	memset(dis,0x3f,sizeof(dis));
	dis[0]=0;Q.push(node(0,0));
	while(!Q.empty()){
		node a=Q.top();Q.pop();
		if(a.d>dis[a.p]) continue;
		for(int i=head[a.p];i;i=g[i].last){
			if(dis[g[i].to]>dis[a.p]+g[i].len){
				dis[g[i].to]=dis[a.p]+g[i].len;
				Q.push(node(dis[g[i].to],g[i].to));
			}
		}
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	for(scanf("%d",&T);T--;){
		init();top=0;
		memset(tc,0,sizeof(tc));
		scanf("%d",&n);minv=inf;
		for(int i=1;i<=n;i++){
			scanf("%d",&A[i]);
			if(A[i]<minv)minv=A[i];
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				int a=A[i]%minv,b=(A[i]+A[j])%minv;
				add(a,b,A[j]);
			}
		}
		dij();
		dis[0]=minv;
		for(int i=0;i<minv;i++){
			if(dis[i]!=inf)rec[++top]=dis[i];
		}
		for(int i=1;i<=top;i++){
			for(int j=i;j<=top;j++){
				tc[rec[i]+rec[j]]=1;
			}
		}
		for(int i=0;i<minv;i++){
			if(dis[i]==inf) continue;
			if(!tc[dis[i]])++ans;
		}
		printf("%d\n",ans);
		ans=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

