#include<cstdio>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
const int M=1e5+10;
const int inf=0x7fffffff;
int n;
int val[M];
ll ans;
int mpos[M<<2];
int tmin(int a,int b){
	if(a==-1) return b;
	if(b==-1) return a;
	if(val[a]<val[b]) return a;return b;
}
void pushup(int o){
	mpos[o]=tmin(mpos[o<<1],mpos[o<<1|1]);
}
void build(int o,int l,int r){
	if(l==r){mpos[o]=l;return;}
	int mid=l+r>>1;
	build(o<<1,l,mid);
	build(o<<1|1,mid+1,r);
	pushup(o);
}
int query(int o,int l,int r,int L,int R){
	if(L<=l&&r<=R){return mpos[o];}
	int mid=l+r>>1;
	int pos=-1;
	if(L<=mid) pos=query(o<<1,l,mid,L,R);
	if(R>mid) pos=tmin(pos,query(o<<1|1,mid+1,r,L,R));
	return pos;
}
void solve(int l,int r,int v){
	if(l>r) return;
	int pos=query(1,1,n,l,r);
	ans+=val[pos]-v;
	solve(l,pos-1,val[pos]);
	solve(pos+1,r,val[pos]);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&val[i]);
	build(1,1,n);
	solve(1,n,0);
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

