#include<cstdio>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
const int M=1e5+10;
const int W=1e6+10;
const int inf=0x3f3f3f3f;
ll ans;
int n,m;
struct ss{
	int to,last,len;
	ss(){}
	ss(int a,int b,int c):to(a),last(b),len(c){}
}g[M<<1];
int head[M],cnt;
void add(int a,int b,int c){
	g[++cnt]=ss(b,head[a],c);head[a]=cnt;
	g[++cnt]=ss(a,head[b],c);head[b]=cnt;
}
int pos;
void dfs_1(int a,int b,ll d){
	if(d>ans)ans=d,pos=a;
	for(int i=head[a];i;i=g[i].last){
		if(g[i].to==b) continue;
		dfs_1(g[i].to,a,d+g[i].len);
	}
}
int sze[M],f[M],top[M],son[M],dep[M];
ll dis[M];
void dfs(int a,int b){
	sze[a]=1;
	for(int i=head[a];i;i=g[i].last){
		if(g[i].to==b) continue;
		dis[g[i].to]=dis[a]+g[i].len;
		dep[g[i].to]=dep[a]+1;
		f[g[i].to]=a;
		dfs(g[i].to,a);
		sze[a]+=sze[g[i].to];
		if(!son[a]||(sze[son[a]])<sze[g[i].to])
		son[a]=g[i].to;
	}
}
void dfs2(int a,int b){
	top[a]=b;
	if(!son[a]) return;
	dfs2(son[a],b);
	for(int i=head[a];i;i=g[i].last){
		if(g[i].to==son[a]||g[i].to==f[a]) continue;
		dfs2(g[i].to,g[i].to);
	}
}
int lca(int a,int b){
	while(top[a]!=top[b]){
		if(dep[top[a]]<dep[top[b]])swap(a,b);
		a=f[top[a]];
	}
	if(dep[a]>dep[b])swap(a,b);
	return a;
}
ll dist(int a,int b){
	return dis[a]+dis[b]-2ll*dis[lca(a,b)];
}
int a,b,c;
int flag1,flag2;
int ABS(int a){return a<0?-a:a;}
ll diss[M];
bool check2(ll len){
	int kk=0;ll sd=0;
	for(int i=2;i<=n;i++){
		sd+=diss[i];
		if(sd>=len)sd=0,++kk;
	}
	return kk>=m;
}
bool iss[M];
struct node{
	int u,v;
	ll dist;
	node(){}
	node(int a,int b,ll c):u(a),v(b),dist(c){}
}no[W];int tot;
void prepre(){
	dfs(1,0);
	dfs2(1,1);
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			no[++tot]=node(i,j,dist(i,j));
			if(no[tot].dist>ans)ans=no[tot].dist;
		}
	}
}
int tt;
void find(int a,int b,ll d,ll mid){
	if(d>=mid) d=0,++tt;
	for(int i=head[a];i;i=g[i].last){
		if(g[i].to==b) continue;
		find(g[i].to,a,d+g[i].len,mid);
	}
}
bool check3(ll len){
	tt=0;
	find(1,0,0,len);
	return tt>=m;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&a,&b,&c);
		add(a,b,c);
		if(a!=1&&b!=1)flag1=1;
		if(ABS(a-b)!=1)flag2=1;
		if(!flag2){
			diss[max(a,b)]=c;
		}
	}
	if(m==1){
		dfs_1(1,0,0);
		dfs_1(pos,0,0);
		printf("%lld\n",ans);
	}else{
		if(!flag1){
			if(n<=1000){
				prepre();
			}
		}else if(!flag2){
			ll l=0,r=inf;
			while(l<=r){
				ll mid=l+r>>1;
				if(check2(mid))l=mid+1,ans=mid;
				else r=mid-1;
			}
		}else{
			ll l=0,r=inf;
			while(l<=r){
				ll mid=l+r>>1;
				if(check3(mid))l=mid+1,ans=mid;
				else r=mid-1;
			}				
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

