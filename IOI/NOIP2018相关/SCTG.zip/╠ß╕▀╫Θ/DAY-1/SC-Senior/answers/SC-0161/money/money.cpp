#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
template <typename T>inline void in(T &a)
{
	T ch=getchar(),f=1;
	for(a=0;!isdigit(ch);ch=getchar())ch=='-'?f=-1:f=f;
	for(;isdigit(ch);ch=getchar())a=(a<<3)+(a<<1)+ch-'0';
	 a*=f;
}
const int N=1005;
int ans;
int t,n,a[N],da[N],vis[N];
int gcd(int x,int y)
{
	return (x==0)?y:gcd(y%x,x);
}
int flag;
int sou(int x,int j)
{
	if(x==0)flag=1;
	for(int i=1;i<=n;i++)
	{
		if(x>=a[i]&&x!=a[j])
		{
			sou(x-a[i],j);
		}
		else break;
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	in(t);
	while(t--)
	{
		memset(vis,0,sizeof(vis));
		memset(a,0,sizeof(a));
		memset(da,0,sizeof(da));
		in(n);
		ans=0;
		for(int i=1;i<=n;i++)
		{
			in(a[i]);
		}
		sort(a+1,a+n+1);
		if(a[1]==1)
		{
			printf("1\n");
		}
		else if(n==1)
		{
			printf("1\n");
		}
		else if(n==2)
		{
			int k=gcd(a[1],a[2]);
			if(k!=1&&k>=a[1])
			printf("1\n");
			else
			printf("2\n");
		}
		else if(n==1)printf("1\n");
		else if(n==3)
		{
			if(gcd(a[1],a[2])==a[1]&&gcd(a[2],a[3])==a[1])
			{
				printf("1\n");
			}
			else if(gcd(a[1],a[2])==a[1]&&gcd(a[1],a[3])==1)
			{
				printf("2\n");
			}
			else if(gcd(a[1],a[3])==a[1]&&gcd(a[1],a[2])==1)
			{
				printf("2\n");
			}
			else if(gcd(a[1],a[3])==1&&gcd(a[1],a[2])==1&&gcd(a[2],a[3])==a[2])
			{
				printf("2\n");
			}
			else
			{
				printf("3\n");
			}
		}
		else
		{
			for(int i=1;i<=n;i++)
			{
				flag=0;
				sou(a[i],i);
				if(!flag)ans++;		
			}
			printf("%d\n",ans%6);
		}
	}
	return 0;
}
