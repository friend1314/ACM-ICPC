#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
template <typename T>inline void in(T &a)
{
	T ch=getchar(),f=1;
	for(a=0;!isdigit(ch);ch=getchar())ch=='-'?f=-1:f=f;
	for(;isdigit(ch);ch=getchar())a=(a<<3)+(a<<1)+ch-'0';
	 a*=f;
}
int n;
const int N=100005;
int d[N],zd[N];
int f[N][20];
int maxx[N][20];
int biao[N][20];
int flag;
struct lianbiao
{
	int l,r;
}q[N];
void insert(int x,int y)
{
	q[x].l=y;
	q[x].r=q[y].r;
	q[q[y].r].l=x;
	q[y].r=x;
}
int tot,xx;
int ans;
int main()
{
freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	int S=100001,T=100002;
	q[S].r=T;
	q[T].l=S;
	in(n);
	int zjl1=-1005,zjl2;
	for(int i=1;i<=n;i++)
	{
		in(zd[i]);
		zd[i]=-zd[i];
		if(zd[i]==0&&flag==0)
		{
			flag=i;
		}
		if(zjl1<zd[i])
		{
			zjl1=zd[i];
			zjl2=i;
		}
	}
//	cout<<zjl1<<flag;
	if(!flag)
	{
		for(int i=1;i<=n;i++)
		{
			zd[i]-=zjl1;
		}
		ans+=zjl1;
	}
	
	for(int i=1;i<=n;i++)
	{
		if(zd[i]==0)
		{
			tot++;
			insert(i,q[T].l);
		}
		f[i][0]=i-1;
		maxx[i][0]=max(zd[i],zd[i-1]);
		(zd[i]>zd[i-1])?	biao[i][0]=i:biao[i][0]=i-1;
		for(int j=1;j<=18;j++)
		{
			f[i][j]=f[f[i][j-1]][j-1];
			if(maxx[f[i][j-1]][j-1]>maxx[i][j-1])
			{
				maxx[i][j]=maxx[f[i][j-1]][j-1];
				biao[i][j]=biao[f[i][j-1]][j-1];
			}
			else
			{
					maxx[i][j]=maxx[i][j-1];
					biao[i][j]=biao[i][j-1];
			}
		}
	}
	int zjl,deta,zjl3;
	insert(0,S);
	while(tot!=n)
	{
		zjl=n;
		for(int i=q[T].l;i!=S;i=q[i].l)
		{
		//	cout<<endl<<i<<" "<<zjl<<endl;
			if(!zjl)break;
			if(zjl==i)
			{
				zjl=i-1;
				continue;
			}
			zjl1=-0xffffff;zjl3=zjl;
			deta=zjl-i-1;
			if(!deta)
			{
				zjl1=zd[zjl];zjl2=zjl;
			}
			for(int j=18;j>=0;j--)
			{
				if(deta&(1<<j))
				{
					if(zjl1<maxx[zjl][j])
					{
						zjl1=maxx[zjl][j];
						zjl2=biao[zjl][j];
					}
					zjl=f[zjl][j];
				}
			}
		//	cout<<zjl1<<" "<<zjl2<<" "<<min(zd[i],zd[zjl3]);
			ans+=(zjl1-min(zd[i],zd[zjl3+1]));
		//	cout<<" ans "<<ans<<" ";
			tot++;//cout<<"a"<<tot;
			if(tot==n)break;
			insert(zjl2,i);
			zjl=i-1;
		}
	/*	if(tot==n)break;
		if(q[S].l!=1)
		{
			zjl=q[S].l-1;
			cout<<endl<<1<<" ccc"<<zjl;
			if(zjl==1)
			{
				cout<<"a";
				ans+=zd[1]-zd[2];
				tot++;
				if(tot==n)break;
			}
			else
			{
				deta=zjl-1;
				zjl1=-100005;zjl3=zjl;
				for(int j=18;j>=0;j--)
				{
					if(deta&(1<<j))
					{
						if(zjl1<maxx[zjl][j])
						{
							zjl1=maxx[zjl][j];
							zjl2=biao[zjl][j];
						}
						zjl=f[zjl][j];
					}
				}
				ans+=(zjl1-zd[zjl3+1]);
				cout<<" ans "<<ans;
				tot++;cout<<"a"<<tot;
				if(tot==n)break;
				insert(zjl2,S);
			}
		}*/
	}
	printf("%d",-ans);
	return 0;
}
/*
9 8 0 7 1 8 4 1 1 5
6
4 3 2 5 3 5
*/
