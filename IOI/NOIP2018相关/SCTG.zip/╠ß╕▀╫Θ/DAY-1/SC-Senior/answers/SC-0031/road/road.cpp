#include<cstdio>
#include<iostream>
#include<algorithm>

using namespace std;

int a[100010];

int main()
{

    freopen("road.in", "r", stdin);
    freopen("road.out", "w", stdout);

    int n;
    int k = 0;
    int til;
    int head;
    bool pd = false;
    bool pd_2 = true;
	
    scanf("%d", &n);

	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);

	for (;pd = true;)
	{
		pd = false;
		til = head = 0;
		
		int j;
		
		for (j = 1; j <= n; j++)
		{
			if (a[j] != 0)
        	{
            	head = j;
            	til = head;
        		pd = true;
        		break;
        	}
    	}
        
        int p = ++j;
        
		if (pd == true)
		{
        	while (pd_2 = true && p <= n)
    		{
    			if (a[p] == 0)
    				pd_2 = false;
    		
    			if (pd_2 == true)
    				til = p;
    			else
    				break;
    			p++;
			}
		}
		
		for (int m = head; m <= til; m++)
            a[m]--;
            
		k++;
        	
        pd_2 = true;
        
        if (pd == false)
        	break;
	}

    printf("%d\n", k - 1);

    return 0;
}
