#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;

const int MAXI = 25005;
const int MAXN = 105;

/*
��С ���� ���� a, b
minn = gcd(a,b)-a-b 
ans = the number of all numbers less than minn number
*/

int n;
int a[MAXN], Max;
int Choose[MAXN], Made[MAXI];
char Visit[MAXN];
char Can_Make[MAXI];

inline void Read(int &n){
	static char ch;bool flag=0;
	while(!isdigit(ch=getchar()))(ch=='-')&&(flag=1);
	for(n=ch^48;isdigit(ch=getchar());n=(n<<1)+(n<<3)+(ch^48));
	flag&&(n=-n);
}

inline void Make_Multiple(int Num){
	memset(Can_Make, false, sizeof(Can_Make));
	Can_Make[0] = true;
	for(register int i=0; i<=Max; i++){
		if(Can_Make[i]){
			for(register int j=1; j<=Num; j++){
				int next_mul = i+a[Choose[j]];
				if(next_mul <= Max)
					Can_Make[next_mul] = true;
			}
		}
	}
}

inline bool Dfs(int Num, int step){
	if(step == Num+1){
		Make_Multiple(Num);
		for(register int i=1; i<=n; i++)
			if(Can_Make[a[i]] == false)
				return false;
		return true;
	}
	if(Num-(step-1)+Choose[step-1] > n) return false;
	bool Got = false;
	for(register int i=Choose[step-1]+1; i<=n; i++){
		if(Visit[i] == false){
			Visit[i] = true;
			Choose[step] = i;
			if(Dfs(Num, step+1)) Got = true;
			Choose[step] = 0;
			Visit[i] = false;
		}
	}
	return Got;
}

int main(){
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int T;
	Read(T);
	while(T--){
		Read(n);
		Max = 0;
		for(register int i=1; i<=n; i++){
			Read(a[i]);
			Max = max(Max, a[i]);
		}
		int head=1, tail=n;
		int mid = (head + tail) >> 1;
		while(head < tail){
			if(Dfs(mid, 1) == true)
				tail = mid;
			else
				head = mid+1;
			mid = (head + tail) >> 1;
		}
		while(Dfs(mid, 1) == true) mid--;
		mid++;
		printf("%d\n", mid);
	}
	return 0;
}
