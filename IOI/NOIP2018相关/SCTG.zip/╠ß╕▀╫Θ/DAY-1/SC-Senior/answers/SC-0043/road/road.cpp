#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<climits>
using namespace std;

const int MAXN = 100005;

inline void Read(int &n){
	static char ch;bool flag=0;
	while(!isdigit(ch=getchar()))(ch=='-')&&(flag=1);
	for(n=ch^48;isdigit(ch=getchar());n=(n<<1)+(n<<3)+(ch^48));
	flag&&(n=-n);
}

struct node{
	int val, mk;
	node(int val=0, int mk=0){
		this->val = val;
		this->mk = mk;
	}
}t[MAXN<<2];

int n, ans;
int h[MAXN];

inline int lc(int x){return x<<1;}
inline int rc(int x){return x<<1|1;}

inline void Point_Update(int x, int k){
	t[x].val += k;
	t[x].mk += k;
}

inline void Push_Up(int x){
	t[x].val = INT_MAX;
	if(t[lc(x)].val) t[x].val = min(t[x].val, t[lc(x)].val);
	if(t[rc(x)].val) t[x].val = min(t[x].val, t[rc(x)].val);
}

inline void Push_Down(int x){
	if(lc(x)) Point_Update(lc(x), t[x].mk);
	if(rc(x)) Point_Update(rc(x), t[x].mk);
	t[x].mk = 0;
}

inline void Build(int x, int head, int tail){
	if(head == tail){
		t[x] = node(h[head], 0);
		//printf("head:%d tail:%d min:%d\n", head, tail, t[x].val);
		return;
	}
	int mid = (head + tail) >> 1;
	Build(lc(x), head, mid);
	Build(rc(x), mid+1, tail);
	Push_Up(x);
	//printf("head:%d tail:%d min:%d\n", head, tail, t[x].val);
}

inline void Update(int x, int head, int tail, int l, int r, int k){
	if(head >= l && tail <= r){
		t[x].val -= k;
		t[x].mk -= k;
		return;
	}
	Push_Down(x);
	int mid = (head + tail) >> 1;
	if(l <= mid) Update(lc(x), head, mid, l, r, k);
	if(r > mid) Update(rc(x), mid+1, tail, l, r, k);
	Push_Up(x);
}

inline int Query(int x, int head, int tail, int l, int r){
	if(head >= l && tail <= r){
		return t[x].val;
	}
	Push_Down(x);
	int mid = (head + tail) >> 1;
	int temp1 = INT_MAX, temp2 = INT_MAX;
	if(l <= mid) temp1 = Query(lc(x), head, mid, l, r);
	if(r > mid) temp2 = Query(rc(x), mid+1, tail, l, r);
	return min(temp1, temp2);
}

struct kkk{
	int hei, ind;
}a[MAXN];

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	Read(n);
	for(register int i=1; i<=n; i++){
		Read(h[i]);
		a[i].ind = i;
	}
	bool tr = true;
	Build(1, 1, n);
	while(tr){
		tr = false;
		int l=-1, r=-1;
		for(register int i=1; i<=n+1; i++){
			if(h[i] && l==-1){
				tr = true;
				l=i;
			}
			if((!h[i])&&l!=-1){
				r=i-1;
				int Dis=Query(1, 1, n, l, r);
				Update(1, 1, n, l, r, Dis);
				ans += Dis;
				for(register int j=l; j<=r; j++)
					h[j] -= Dis;
				l=-1;
			}
		}
	}
	printf("%d\n", ans);
}
