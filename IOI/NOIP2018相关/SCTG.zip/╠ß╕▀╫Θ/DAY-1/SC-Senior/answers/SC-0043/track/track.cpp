#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;

typedef long long ll;
const int MAXN = 50005;

inline void Read(int &n){
	static char ch;bool flag=0;
	while(!isdigit(ch=getchar()))(ch=='-')&&(flag=1);
	for(n=ch^48;isdigit(ch=getchar());n=(n<<1)+(n<<3)+(ch^48));
	flag&&(n=-n);
}

int Next[MAXN<<1], To[MAXN<<1], Len[MAXN<<1], First[MAXN], tot;
int dep[MAXN], fa[MAXN], connect_edge_len[MAXN];
int top[MAXN], sz[MAXN], cd[MAXN];
ll f[MAXN][2], Max_Len, _dis[MAXN];
int n, m;

inline void Add_Edge(int _from, int _to, int _length){
	Next[++tot] = First[_from];
	First[_from] = tot;
	Len[tot] = _length;
	To[tot] = _to;
}

inline void Dfs(int x, int y, int _depth){
	fa[x] = y;
	dep[x] = _depth;
	sz[x] = 1;
	cd[x] = -1;
	int Max_Son=0, Second_Son=0, Num_Son=0;
	for(register int u=First[x]; u; u=Next[u]){
		int v=To[u];
		if(v != y){
			connect_edge_len[v] = Len[u];
			Dfs(v, x, _depth+1);
			sz[x] += sz[v];
			f[x][0] = max(f[x][0], f[v][0]);
			int temp = f[v][1];
			if(cd[x]==-1 || sz[v] > sz[cd[x]])
				cd[x] = v;
			if(temp > Max_Son) swap(temp, Max_Son);
			if(temp > Second_Son) swap(temp, Second_Son);
		}
	}
	f[x][0] = max(f[x][0], (ll)Max_Son + (ll)Second_Son);
	f[x][1] = (ll)Max_Son + (ll)connect_edge_len[x];
}

inline ll Find_Route(int x, int y){
	ll ans=0;
	while(dep[x] > dep[y]) {
		x = fa[x];
		ans += connect_edge_len[x];
	}
	while(dep[y] > dep[x]) {
		y = fa[y];
		ans += connect_edge_len[y];
	}
	while(x!=y){
		ans += connect_edge_len[x];
		ans += connect_edge_len[y];
		x = fa[x];
		y = fa[y];
	}
	return ans;
}

inline bool pd(int val){
	for(register int i=1; i<=n; i++){
		for(register int j=i+1; j<=n; j++){
			if(Find_Route(i, j)==val)
			 	return true;
		}
	}
	return false;
}

int main(){
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	Read(n); Read(m);
	for(register int i=1; i<n; i++){
		int _from, _to, _length;
		Read(_from); Read(_to); Read(_length);	
		Add_Edge(_from, _to, _length);
		Add_Edge(_to, _from, _length);
	}
	if(m==1){
		Dfs(1, 0, 1);
		printf("%lld\n", f[1][0]);
		return 0;
	}
	Max_Len = f[1][0] / m + 1;
	ll head=1, tail=Max_Len;
	ll mid = (head + tail) >> 1;
	while(head < tail){
		if(pd(mid))
			head = mid+1;
		else
			tail = mid;
		mid = (head + tail) >> 1;
	}
	printf("%lld\n", mid);
	return 0;
}
