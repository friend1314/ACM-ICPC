#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
using namespace std;
int read(){
	int f=1,x=0;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x = (x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}
const int MAXN = 105;
int A[MAXN];
inline void clone(int* A,int* B,int n){
	for(int i=1;i<=n;++i)A[i]=A[i];
}
int Work2(){
	if(A[1]>A[2])swap(A[1],A[2]);
	if(A[2]%A[1]==0)return 1;
	else return 2;
}
bool judge(int a,int b,int c){//Judge:whether c can be ax+by
	bool okay=false;
	int i,j;
	if(c>a*b-a-b)okay=true;
	else{
		for(i=0;;++i){
			for(j=0;;++j){
				if(a*i+b*j==c)
					okay=true;
				if(a*i+b*j>=c)
					break;
			}
			if(a*i>c)
				break;		
		}
	}
	return okay; 
}
int Work3(){
	sort(A+1,A+4);
	if(A[2]%A[1]==0){
		A[2]=A[3];
		return Work2();
	}
	else return judge(A[1],A[2],A[3])?2:3;
}
int Work(int n){
	sort(A+1,A+n+1);
	//for(int i=1;i<=n;++i)printf("%d ",A[i]);puts("");
	//clone(A,B,n);
	for(int i=1;i<=n;++i){
		for(int j=i+1;j<=n;++j){
			if(A[j]%A[i]==0){
//				if(A[j]==14)printf("%d\n",A[i]);
				A[j]=A[j-1];	
			}
		}
	}
//	for(int i=1;i<=n;++i)printf("%d ",A[i]);puts("");
	sort(A+1,A+n+1);
	unique(A+1,A+n+1);
	sort(A+1,A+n+1);
//	for(int i=1;i<=n;++i)printf("%d ",A[i]);puts("");
	A[n+1]=A[n];
	int m;
	for(m=1;A[m+1]!=A[m];++m);
//	printf("m=%d\n",m);
	//clone(B,C,m);
//	for(int i=1;i<=m;++i)printf("%d ",A[i]);puts("");
	if(m==1)return 1;
	if(m==2)return Work2();
	if(m==3)return Work3();
	else for(int i=1;i<=m;++i){
		for(int j=i+1;j<=m;++j){
			for(int k=j+1;k<=m;++k){
					if(judge(A[i],A[j],A[k])){
//					if(i==1&&j==3&&k==4)printf("!!");
					A[k]=A[k-1];
//					printf("i=%d j=%d k=%d\n",i,j,k);
				}
			}
		}
	}
//	for(int i=1;i<=m;++i)printf("%d ",A[i]);puts("");
	sort(A+1,A+m+1);
	unique(A+1,A+m+1);
	sort(A+1,A+m+1);
	A[m+1]=A[m];
	int ans;
	for(ans=1;A[ans+1]!=A[ans];++ans);
//	for(int i=1;i<=m;++i)printf("%d ",A[i]);puts("");
	return ans;
}
void Switch(int n){
	if(n==1)printf("1\n");
	else if(n==2)printf("%d\n",Work2());
	else if(n==3)printf("%d\n",Work3());
	else printf("%d\n",Work(n));
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t=read();
	for(int ii=0;ii<t;++ii){
		int n=read();
		memset(A,0,sizeof(A));
		for(int i=1;i<=n;++i)A[i]=read();
		Switch(n);
	}
	return 0;
}

