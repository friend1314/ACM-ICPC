#include<cstdio>
#include<cctype>
using namespace std;
int read(){
	int f=1,x=0;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x = (x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	return 0;
}
