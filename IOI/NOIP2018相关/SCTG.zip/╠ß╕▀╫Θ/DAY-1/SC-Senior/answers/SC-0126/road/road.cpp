#include<cstdio>
#include<cctype>
using namespace std;
int read(){
	int f=1,x=0;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x = (x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return x*f;
}
const int MAXN=100000+5;
int A[MAXN]={0},n;
long long cnt=0;
bool done=false;
void bld(int f,int t){
	if(f==t&&A[f]){
		--A[f];
		++cnt;
	}
	bool flag=false;//flag:Reach the first non-zero point?
	for(register int i=f;i<=t;++i){
		if(!flag&&A[i])flag=true;
		if(flag&&!A[i]){
			//printf("A[1]=%d A[2]=%d A[3]=%d\n",A[1],A[2],A[3]);
			bld(f,i-1);
			bld(i+1,t);
			return;
		}
	}
	if(flag){
		for(register int i=f;i<=t;++i){
			if(A[i])--A[i];
		}
		++cnt;
	}
	else{
		if(f==1&&t==n)done=true;
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i){
		A[i]=read();
	}
	while(!done){
		bld(1,n);
	}
	printf("%lld\n",cnt);
	return 0;
}
