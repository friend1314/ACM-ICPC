#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d[10001],num[10001];
	int i,j,s=0,flag=0,max=-1,min=10001;
	memset(num,0,sizeof(num));
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>d[i];
		if(d[i]<min) min=d[i];
		if(d[i]>max) max=d[i];
		s=min;
	}
	
		for(i=1;i<=n;i++)
	{
		while(d[i])
		{
			d[i]-=d[i];
			s++;
		}
	}
	for(i=1;i<=n;i++)
	{
		{
			for(j=i+1;j<=n;j++)
			{
				if(d[i]=d[j]) flag=1;
				else if(d[i]!=d[j]) flag=0;
			}
		}
	}
	if(flag==0)  cout<<s;
	else if(flag==1)cout<<max;
	return 0;
    fclose(stdin);
    fclose(stdout);
}
