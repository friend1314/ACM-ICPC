#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<queue>
#include<stack>
#define rint register int
#define ll long long
using namespace std;
const int maxn=50010;
int size=0,head[maxn],n,m,maxw=-1,dis[maxn][2];
struct edge
{
	int u,v,w,next;
}e[maxn*2];
void init()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
}
void adde(int u,int v,int w)
{
	e[size].u=u;
	e[size].v=v;
	e[size].w=w;
	e[size].next=head[u];
	head[u]=size++;
}
int dfs1(int u,int fa)
{
	for(int i=head[u];i!=-1;i=e[i].next)
	{
		int v=e[i].v;
		if(v==fa) continue;
		int f=dfs1(v,u);
		if(dis[u][0]<e[i].w+f)
		{
			dis[u][0]=e[i].w+f;
		}
		else if(dis[u][1]<e[i].w+f&&dis[u][0]>e[i].w+f)
		{
			dis[u][1]=e[i].w+f;
		}
		else if(dis[u][1]<dis[v][1]+e[i].w)
		{
			dis[u][1]=dis[v][1]+e[i].w;
		}
	}
	return dis[u][0];
}
void dfs2(int u,int fa)
{
	for(int i=head[u];i!=-1;i=e[i].next)
	{
		int v=e[i].v;
		if(v==fa) continue;
		dis[v][2]=max(dis[u][2],dis[u][1])+e[i].w;
		dfs2(v,u);
	}
}
int main()
{
	init();
	scanf("%d %d",&n,&m);
	memset(head,-1,sizeof(head));
	int u,v,w;
	for(rint i=1;i<n;i++)
	{
		scanf("%d %d %d",&u,&v,&w);
		adde(u,v,w);
		adde(v,u,w);
		maxw=max(maxw,w);
	}
	if(m==n-1)
	{
		printf("%d",maxw);
		return 0;
	}
	if(m==1)
	{
		int ans=-1;
		dfs1(1,1);
		dfs2(1,1);
		for(int i=1;i<=n;i++)
		{
			ans=max(ans,max(dis[i][0],dis[i][2]));
		}
		printf("%d",ans);
	}
	return 0;
}
