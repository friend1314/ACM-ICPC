#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<queue>
#include<stack>
#define rint register int
#define ll long long
using namespace std;
const int maxn=105;
int a[maxn];
void init()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
}
int gcd(int x,int y)
{
	if(y==0) return x;
	else return gcd(y,x%y);
}
int main()
{
	init();
	int T,n;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(rint i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		if(n==2)
		{
			if(gcd(a[1],a[2])==1)
			{
				printf("2");
			}
			else
			{
				printf("1");
			}
		}
		if(T>0) printf("\n");
	}
	return 0;
}
