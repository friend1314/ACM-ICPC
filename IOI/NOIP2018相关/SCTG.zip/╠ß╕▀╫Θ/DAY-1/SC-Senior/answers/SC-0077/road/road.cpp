#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<queue>
#include<stack>
#define rint register int
#define ll long long
using namespace std;
const int maxn=100010;
int a[maxn];
struct node
{
	int dep,num;
	bool operator<(const node &a) const
	{
		return dep>a.dep;
	}
}d;
priority_queue<node>q;
void init()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
}
ll ans=0;
int main()
{
	init();
	int n,x,mark=0,cnt=1;
	scanf("%d",&n);
	for(rint i=1;i<=n;i++) 
	{
		scanf("%d",&x);	
		if(x==0) cnt++;
		else
		{
		a[i]=x;
		d.dep=x;
		d.num=i;
		q.push(d);
		}
	}
	while(!q.empty())
	{
		node u=q.top();
		q.pop();
		ans+=(u.dep-mark)*cnt;
		mark=mark+(u.dep-mark);
		a[u.num]=0;
		if(a[u.num-1]!=0&&a[u.num+1]!=0&&u.num!=1&&u.num!=n) cnt++;
		if((a[u.num-1]==0&&a[u.num+1]==0)||(u.num==1&&a[u.num+1]==0)||(u.num==n&&a[u.num-1]==0)) cnt--;
		while(!q.empty()&&u.dep==q.top().dep) 
		{
			node u1=q.top();
			a[u1.num]=0;
			if(a[u1.num-1]!=0&&a[u1.num+1]!=0&&u1.num!=1&&u1.num!=n) cnt++;
			if((a[u1.num-1]==0&&a[u1.num+1]==0)||(u1.num==1&&a[u1.num+1]==0)||(u1.num==n&&a[u1.num-1]==0)) cnt--;
			q.pop();
		}
	}
	printf("%lld",ans);
	return 0;
}
