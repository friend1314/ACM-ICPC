#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<ctime>
#include<cstdlib>
#include<cstdio>
#include<cctype>
#include<iomanip>
#include<map>
#include<queue>
using namespace std;

inline int read()
{
	int sum=0,f=1;char ch;
	for(ch=getchar();(ch<'0'||ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-') {f=-1;ch=getchar();}
	for(;ch>='0'&&ch<='9';ch=getchar())
	sum=(sum<<3)+(sum<<1)+ch-48;
	return sum*f;
}

int n;
int Road[100050];
long long ans;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	n=read();
	for(int i=1;i<=n;++i)
		Road[i]=read();
		
	Road[0]=0;
	Road[n+1]=0;
	ans=0;
	for(int i=1;i<=n;++i)
	{
		int t=1;
		while(Road[i]==Road[i+t])
			++t;
		
		if(Road[i]>Road[i-1]&&Road[i+t-1]>Road[i+t])
			ans+=Road[i];
		
		if(Road[i]<Road[i-1]&&Road[i+t-1]<Road[i+t])
			ans-=Road[i];
			
		i=i+t-1;
	}
	
	printf("%d\n",ans);
	
	return 0;
}
