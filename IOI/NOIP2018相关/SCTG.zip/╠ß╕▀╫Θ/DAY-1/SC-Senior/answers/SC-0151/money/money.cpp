#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<ctime>
#include<cstdlib>
#include<cstdio>
#include<cctype>
#include<iomanip>
#include<map>
#include<queue>
using namespace std;

inline int read()
{
	int sum=0,f=1;char ch;
	for(ch=getchar();(ch<'0'||ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-') {f=-1;ch=getchar();}
	for(;ch>='0'&&ch<='9';ch=getchar())
	sum=(sum<<3)+(sum<<1)+ch-48;
	return sum*f;
}

int n;
int numod;
int a[110];
int ans;

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	
	numod=read();
	while(numod--)
	{
		n=read();
		ans=n;
		
		for(int i=1;i<=n;++i)
			a[i]=read();
		
		sort(a+1,a+n+1);
		for(int i=1;i<=n;++i)
		{
			if(a[i]!=0)
			{
				for(int j=i+1;j<=n;++j)
				{
					if(a[j]!=0)
					{
						if(a[j]%a[i]==0)
						{
							--ans;
							a[j]=0;
						}
					}
				}
			}
		}
		
		for(int i=1;i<=n;++i)
		{
			if(a[i]==0)
			{
				for(int j=i;j<=n-1;++j)
				{
					a[j]=a[j+1];
				}
			}
		}
		n=ans;
		
		if(n>=3)
		{
			for(int i=1;i<=n-2;++i)
				for(int j=i+1;j<=n-1;++j)
					for(int k=j+1;k<=n;++k)
					{
						bool ch=false;
						if(a[k]!=0)
						{
							
						for(int t=1;t<=1000;++t)
						{
							for(int q=1;q<=1000;++q)
							{
								if(t*a[i]+q*a[j]==a[k])
								{
									ch=true;
									--ans;
									a[k]=0;
									break;
								}
								if(t*a[i]>a[k]) {ch=true;break;}
								if(t*a[i]+q*a[j]>a[k]) break;
							}
							if(ch) break;
						}
						
						}
					}
		}
		
		printf("%d\n",ans);
	} 
	return 0;
}
