#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<ctime>
#include<cstdlib>
#include<cstdio>
#include<cctype>
#include<iomanip>
#include<map>
#include<queue>
using namespace std;

inline int read()
{
	int sum=0,f=1;char ch;
	for(ch=getchar();(ch<'0'||ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-') {f=-1;ch=getchar();}
	for(;ch>='0'&&ch<='9';ch=getchar())
	sum=(sum<<3)+(sum<<1)+ch-48;
	return sum*f;
}

const int kkk=50050;
int s1,s[kkk];
int t1,t[kkk];
int u,v,val,n,k;

struct node{
	int u,v,val,next;
}side[kkk*2];

int cnt=0;
int first[kkk];
inline void addedge(int u,int v,int val)
{
	side[cnt++].u=u;
	side[cnt].v=v;
	side[cnt].val=val;
	side[cnt].next=first[u];
	first[u]=cnt;
}

int dis[kkk];
bool visit[kkk];
inline void dijskra()
{
	memset(dis,127,sizeof(dis));
	memset(visit,0,sizeof(visit));
	priority_queue< pair<int,int> >que;
	for(int i=1;i<=s1;i++) que.push(make_pair(0,s[i])),dis[s[i]]=0;
	while(!que.empty())
	{
		u=que.top().second;
		que.pop();
		visit[u]=true;
		for(int i=first[u];i;i=side[i].next)
		{
			v=side[i].v;
			if(!visit[v]&&dis[v]<dis[u]+side[i].val)
			{
				dis[v]=dis[u]+side[i].val;
				que.push(make_pair(-dis[v],v));
			}
		}
	}
}

int anss[kkk];
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	
	k=read(),m=read();
	for(int i=1;i<=n;i++)
	{
		cin>>u>>v>>val;
		addedge(u,v,val);
		addedge(v,u,val);
	}
	
	int tt=0;
	for(int i=1;i<=n;i++)
	for(int j=i+1;j<=n;j++)
	{
		tt++;
		s1=1;
		s[1]=i;
		t1=1;
		t[1]=j;
		
		dijskra();
		anss[tt]=dis[n];
	}
	int ans;
	ans=anss[1];
	for(int i=1;i<=tt;i++)
	{
		ans=max(anss[i],ans);
	}
	
	cout<<ans<<endl;
}
