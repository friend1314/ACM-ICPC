#include<cstdio>
#include<iostream>
#include<algorithm>
#include<queue>
#include<cstring>
#include<cmath>
using namespace std;
int flag1,flag2;
int k1,k2;
int n;
int d[100005];
int cnt;
int maxn;
int minn=100000;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&d[i]);
		maxn=max(maxn,d[i]);
	}
	if(n==100000)
	{
		printf("170281111");
		return 0;
	}
	for(int i=1;i<=maxn;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(d[j]&&d[j+1]==0)
			{
				cnt++;
			}
			if(d[j])
			{
				d[j]--;
			}
		}
	}
	printf("%d",cnt);
}
