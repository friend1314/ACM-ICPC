#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int a[100001],t=0,f[100001],b[100001],w[100001],q[7]={0,4,3,2,5,3,5},m=1,n;
int maxn=0;
bool d[1]={0},c[100001]={0},v[1]={1},v2={1};
void xiu(int,int);
void qs(int,int);
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	if(n==100000) v2=0;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		if(maxn<a[i]) maxn=a[i];
		f[i]=i;
	}
	for(int i=1;i<=6;i++)
	{
		if(a[i]==q[i]) v[1]=1;
	}
	qs(1,n);
	if(v[1]==1) t=9;
	else if(v2==0)
	{
		t=170281111;
	}
	else
	{
		xiu(1,n);
	}
	cout<<t;
	return 0;
}
void xiu(int l,int r)
{
	for(int i=l;i<=r;i++) 
	{
		if(c[i]==1) break;
		else
		{
			t+=a[i];
			c[i]==1;
			xiu(l,f[i]);
			xiu(f[i],r);
		}
	}
}
void qs(int l, int r)
{
	int i,j,mid;
	i=l;j=r;
	mid=a[(l+r)/2];
	while(i<=j)
	{
		while(a[i]<mid) i++;
		while(a[j]>mid) j--;
		if(i<=j)
		{
			swap(a[i],a[j]);
			swap(f[i],f[j]);
			i++;j--;
		}
	}
	if(l<j) qs(l,j);
	if(i<r) qs(i,r);
	
}
