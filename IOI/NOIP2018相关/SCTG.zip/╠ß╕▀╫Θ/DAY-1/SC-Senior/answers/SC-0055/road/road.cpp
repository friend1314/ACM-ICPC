#include<bits/stdc++.h>
using namespace std;
int a[100005];
int n;
int ans=0;
void dfs(int i,int j,int used)
{
	if(i>j)return;
	int minn=20001,p;
	for(int k=i;k<=j;k++)
	{
		a[k]=a[k]-used;
	}
	for(int o=i;o<=j;o++)
	{
		if(a[o]<minn)
		{
			minn=a[o];
			p=o;
		}
	}
	ans+=minn;
	dfs(i,p-1,minn);
	dfs(p+1,j,minn);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	dfs(1,n,0);
	printf("%d",ans);
	return 0;
}
