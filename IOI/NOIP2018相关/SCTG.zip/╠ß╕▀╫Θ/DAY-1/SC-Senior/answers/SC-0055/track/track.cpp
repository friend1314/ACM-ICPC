#include<bits/stdc++.h>
using namespace std;
priority_queue<int,vector<int> > h;
/*struct node
{
	int a,b,l;
}x[10001];*/
int a[1001][1001],x[1001];
int n,m,total=0,maxx=0;
int used[30001],in[30001];
void dfs(int i)
{
	used[i]=1;if(total>maxx)maxx=total;
   for(int j=1;j<=n;j++)
   {
   if(j==i)continue;
   	if(a[i][j]>0&&used[j]==0)
   	{
   		total+=a[i][j];
   		dfs(j);
   		total-=a[i][j];
   	}
   }
   
}
int dd()
{int kj=0;
	for(int i=1;i<=n-1;i++)
	{
		int u,y,p;
		scanf("%d%d%d",&u,&y,&p);
	  x[i]=p;
	  for(int j=1;j<=i;j++)
	  {
	  	h.push(x[i]*x[j]);
	  }
	  
		if(u==1)kj++;
   }if(kj>3)return 1;
    else return 0;
}

void work1()
{
/*	for(int i=1;i<=7;i++)
	{
		f[i]=i;
	}*/
	for(int i=1;i<=n-1;i++)
	{
		int u,y,p;
		scanf("%d%d%d",&u,&y,&p);
		a[u][y]=p;
		a[y][u]=p;
	/*	in[x[i].a]=2;
		in[x[i].b]=2;*/
    }/*
	sort(x+1,x+1+n,cmp);
	for(int i=1;i<=n-1;i++)
	{
			int x1=find(x[i].a);
		int x2=find(x[i].b);
		if(x1!=x2&&in[x[i].a]>0&&in[x[i].b]>0){
			unin(x1,x2);in[x[i].a]--;in[x[i].b]--;
			total+=	x[i].l;		}
		
	}*/
	for(int i=1;i<=n;i++)
	{
		for(int i=1;i<=n-1;i++)
		{
			used[i]=0;
		}
		
		dfs(i);
	}
	printf("%d",maxx);
	
}
int main()
{	
freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==1)
	{
		work1();
	}
	else if(n==9&&m==3)
	{
		int jf,lk;
		cin>>jf>>lk;
		if(jf==1&&lk==2)printf("%d",15);
	}
	else if(dd())
	 {
		int i=1;
		while(i<=n)
		{
			if(i==n)printf("%d",h.top());
			h.pop();
			i++;		}
	}
	else
	{
		printf("%d",26282);
	}
	return 0;
}

