#include<bits/stdc++.h>
using namespace std;
int T,n;
int a[50000],b[101];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int l=1;l<=T;l++)
	{
		int ans=0;
		for(int i=1;i<=25000;i++)
		a[i]=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
		sort(b+1,b+1+n);
		if(b[1]==1)
		{
			printf("%d\n",1);continue;
		}
		int total=1;
		while(total!=n+1)
		{
			if(a[b[total]]==0)ans++;
			for(int i=1;i<=25000;i++)
				a[a[i]+b[total]]=a[i]+b[total];
				total++;
			
		}
		printf("%d\n",ans);
		
	}
	return 0;
}
