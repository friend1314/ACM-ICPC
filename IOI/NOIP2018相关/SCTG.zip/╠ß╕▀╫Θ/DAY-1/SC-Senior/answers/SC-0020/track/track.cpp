#include<bits/stdc++.h>
#define rg register
using namespace std;
typedef long long ll;
typedef pair<int,int>pii;
inline int read(){
	int t=0,q=1;char ch;
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')q=-1,ch=getchar();
	while(isdigit(ch))t=(t<<3)+(t<<1)+ch-'0',ch=getchar();
	return t*q;
}
int head[50001],to[100010],nxt[100010],dis[100010],cnt=1,n,fl1,fl2,m,tlen;
int dfn[50001],pf[50001],pt[50001],hs[50001],hss[50001],fa[50001],df[50001],siz[50001],dn,dep[50001];
void addedge(int f,int t,int d){
	cnt++;to[cnt]=t;nxt[cnt]=head[f],dis[cnt]=d,head[f]=cnt;
}
struct xianduan{
	int tree[400001],mark[400001],siz;
	inline void build(int sz){
		rg int i;
		siz=1;
		while(siz<sz)siz<<=1;
		for(i=siz;i<=siz+n-1;i++)
		tree[dfn[i-siz+1]+siz-1]=fa[i-siz+1];
		for(i=siz-1;i>=1;i--)
		tree[i]=tree[i<<1]+tree[(i<<1)+1];
	}
	void mmk(int pos,int v,int l,int r){
		tree[pos]+=v;
		mark[pos]+=v*(r-l+1);
	}
	void pushdown(int pos,int l,int r){
		if(!mark[pos])return;
		if(l!=r){
		mmk(pos<<1,mark[pos],l,(l+r)>>1);
		mmk((pos<<1)+1,mark[pos],((l+r)>>1)+1,r);
		}
		mark[pos]=0;
	}
	void pushup(int pos,int l,int r){
		if(l!=r)tree[pos]=min(tree[pos<<1],tree[(pos<<1)+1]);
	}
	void __change(int l,int r,int cl,int cr,int v,int pos){
		if(l==cl&&r==cr){
		mmk(pos,v,cl,cr);return;
		}
		if(cl==cr)return;
		if(l<=(cl+cr)>>1)__change(l,min(r,(cl+cr)>>1),cl,(cl+cr)>>1,v,pos<<1);
		if(r>=((cl+cr)>>1)+1)__change(max(l,((cl+cr)>>1)+1),r,((cl+cr)>>1)+1,cr,v,((pos)<<1)+1);
		pushup(pos,cl,cr);
	}
	int __query(int l,int r,int cl,int cr,int pos){
		int cur=0;
		pushdown(pos,cl,cr);
		if(l==cl&&r==cr){
			cur=tree[pos];
			return cur;
		}
		if(cl==cr)return 0;
		if(l<=(cl+cr)>>1)cur+=__query(l,min(r,(cl+cr)>>1),cl,(cl+cr)>>1,pos<<1);
		if(r>=((cl+cr)>>1)+1)cur+=__query(max(l,((cl+cr)>>1)+1),r,((cl+cr)>>1)+1,cr,((pos)<<1)+1);
		pushup(pos,cl,cr);
		return cur;
	}
	void change(int l,int r,int v){
		__change(l,r,1,siz,v,1);
	}
	int query(int l,int r){
		return __query(l,r,1,siz,1);
	}
}xdt;
void dfs1(int cur,int last){
	rg int i;
	dep[cur]=dep[last]+1;
	for(i=head[cur];i;i=nxt[i]){
		if(to[i]!=last){
		fa[to[i]]=dis[i];
		dfs1(to[i],cur);
		siz[cur]+=siz[to[i]];
		if(siz[to[i]]>hss[cur])hss[cur]=siz[to[i]],hs[cur]=i;
		}
	}
	siz[cur]++;
}
void dfs2(int cur,int last){
	rg int i;
	dfn[cur]=++dn;
	if(hs[cur]){
		pf[to[hs[cur]]]=pf[cur];		
		pt[to[hs[cur]]]=pt[cur];
		dfs2(to[hs[cur]],cur);
	}
	for(i=head[cur];i;i=nxt[i]){
		if(to[i]!=last&&i!=hs[cur]){
			pf[to[i]]=cur;
			pt[to[i]]=to[i];
			dfs2(to[i],cur);
		}
	}
}
int lca(int a,int b){
	int cur=0;
	while(pt[a]!=pt[b]){
		if(dep[pt[a]]>dep[pt[b]])swap(a,b);
		cur+=xdt.query(dfn[pt[b]],dfn[b]);
		b=pf[b];
	}
	if(dfn[a]>dfn[b])swap(a,b);
	if(a!=b)
	cur+=xdt.query(dfn[a],dfn[b]+1);
	return cur;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();m=read();
	int ff,tt,dd,l,r,mid,cur,ct,ans=0;
	rg int i,j;
	for(i=1;i<n;i++){
		ff=read(),tt=read(),dd=read();
		addedge(ff,tt,dd);addedge(tt,ff,dd);
		if(tt!=ff+1)fl1=1;
		if(!fl1)df[ff]=dd,tlen+=dd;
		if(dd!=1)fl2=1;
	}
	if(!fl1){
		l=1,r=tlen;
		while(l<r){
			mid=((l+r)>>1)+1;ct=0,cur=0;
			for(i=1;i<n;i++){
				ct+=df[i];
				if(ct>=mid)ct=0,cur++;
			}
			if(cur<m)r=mid-1;
			else l=mid;
		}
		cout<<l;
	}
	else{
		dep[1]=1;pt[1]=1;dfs1(1,0);dfs2(1,0);xdt.build(n);
		if(m==1){
			for(i=1;i<=n;i++)
				for(j=i+1;j<=n;j++)
				ans=max(ans,lca(i,j));
			cout<<ans;
		}
	}
	
}
