#include<bits/stdc++.h>
#define rg register
using namespace std;
typedef long long ll;
typedef pair<int,int>pii;
inline int read(){
	int t=0,q=1;char ch;
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')q=-1,ch=getchar();
	while(isdigit(ch))t=(t<<3)+(t<<1)+ch-'0',ch=getchar();
	return t*q;
}
int val[101],T,n,tot,biao[101];
vector<int> v;
/*int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
void exgcd(int a,int b,int &x,int &y){
	if(b==0){x=1,y=0;return;
	}
	else exgcd(b,a%b,x,y);
	int tmp=x;
	x=y,y=tmp-(a/b)*y;
}*/
bool check(int val,int cur,int sz){
	rg int i;
	bool ps=0;
	if(val==0&&cur!=sz)return false;
	if(cur==sz&&val==0)return true;
	if(cur==sz&&val!=0)return false;
	int g=val/v[cur];
	for(i=1;i<=g;i++){
		if(check(val-i*v[cur],cur+1,sz))ps=1;
	}
	return ps;
}
void dfs(int cur,int bs,int tot,int bi){
	if(tot>bs)return;
	if(biao[bi])return;
	if(!cur){	
		if(biao[bi])return;
		int sz=v.size();
		if(check(bs,0,sz)){
		::tot++,biao[bi]=1;
	
	}	return;
	}
	if(biao[bi])return;
	if(cur!=bi){
	v.push_back(val[cur]);
	dfs(cur-1,bs,tot+val[cur],bi);
	v.pop_back();
	}
	if(biao[bi])return;
	dfs(cur-1,bs,tot,bi);
}
int main(){
	rg int i;
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--){
		memset(biao,0,sizeof(biao));
		tot=0;
		n=read();
		for(i=1;i<=n;i++)val[i]=read();
		sort(val+1,val+n+1);
		for(i=n;i>=1;i--)
			dfs(i,val[i],0,i);
		cout<<n-tot<<'\n';
	}
	return 0;
}
