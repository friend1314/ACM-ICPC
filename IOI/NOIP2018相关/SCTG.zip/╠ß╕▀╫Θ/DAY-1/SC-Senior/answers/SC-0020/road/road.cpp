#include<bits/stdc++.h>
#define rg register
using namespace std;
typedef long long ll;
typedef pair<int,int>pii;
inline int read(){
	int t=0,q=1;char ch;
	while(!isdigit(ch)&&ch!='-')ch=getchar();
	if(ch=='-')q=-1,ch=getchar();
	while(isdigit(ch))t=(t<<3)+(t<<1)+ch-'0',ch=getchar();
	return t*q;
}
int n,ans,top;pii stk[100001];
struct point{
	int dep,lb,rb,siz,num;
	friend bool operator <(const point &a,const point &b){
		return a.siz<b.siz;
	}
}a[100001];
priority_queue<point>q;
struct xianduan{
	int tree[400001],mark[400001],siz;
	inline void build(int sz){
		rg int i;
		memset(tree,127,sizeof(tree));
		siz=1;
		while(siz<sz)siz<<=1;
		for(i=siz;i<=siz+n-1;i++)
		tree[i]=a[i-siz+1].dep;
		for(i=siz-1;i>=1;i--)
		tree[i]=min(tree[i<<1],tree[(i<<1)+1]);
	}
	void mmk(int pos,int v){
		tree[pos]+=v;
		mark[pos]+=v;
	}
	void pushdown(int pos,int l,int r){
		if(!mark[pos])return;
		if(l!=r){
		mmk(pos<<1,mark[pos]);
		mmk((pos<<1)+1,mark[pos]);
		}
		mark[pos]=0;
	}
	void pushup(int pos,int l,int r){
		if(l!=r)tree[pos]=min(tree[pos<<1],tree[(pos<<1)+1]);
	}
	void __change(int l,int r,int cl,int cr,int v,int pos){
		if(l==cl&&r==cr){
		mmk(pos,v);return;
		}
		if(cl==cr)return;
		if(l<=(cl+cr)>>1)__change(l,min(r,(cl+cr)>>1),cl,(cl+cr)>>1,v,pos<<1);
		if(r>=((cl+cr)>>1)+1)__change(max(l,((cl+cr)>>1)+1),r,((cl+cr)>>1)+1,cr,v,((pos)<<1)+1);
		pushup(pos,cl,cr);
	}
	int __query(int l,int r,int cl,int cr,int pos){
		int cur=999999999;
		pushdown(pos,cl,cr);
		if(l==cl&&r==cr){
			cur=min(cur,tree[pos]);
			return cur;
		}
		if(cl==cr)return 999999999;
		if(l<=(cl+cr)>>1)cur=min(cur,__query(l,min(r,(cl+cr)>>1),cl,(cl+cr)>>1,pos<<1));
		if(r>=((cl+cr)>>1)+1)cur=min(cur,__query(max(l,((cl+cr)>>1)+1),r,((cl+cr)>>1)+1,cr,((pos)<<1)+1));
		pushup(pos,cl,cr);
		return cur;
	}
	void change(int l,int r,int v){
		__change(l,r,1,siz,v,1);
	}
	int query(int l,int r){
		return __query(l,r,1,siz,1);
	}
}xdt;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	rg int i;
	point tmp;
	int cur;
	for(i=1;i<=n;i++){
	a[i].dep=read();
	a[i].lb=1,a[i].rb=n,a[i].num=i;
	}
	for(i=1;i<=n;i++){
		while(top&&stk[top].first>a[i].dep){
			a[stk[top].second].rb=i-1;
			top--;
		}
		stk[++top]=make_pair(a[i].dep,i);
	}
	top=0;
		for(i=n;i>=1;i--){
		while(top&&stk[top].first>a[i].dep){
			a[stk[top].second].lb=i+1;
			top--;
		}
		stk[++top]=make_pair(a[i].dep,i);
	}
	for(i=1;i<=n;i++){a[i].siz=a[i].rb-a[i].lb+1;q.push(a[i]);
	}
	xdt.build(n);
	while(!q.empty()){
		tmp=q.top();q.pop();
		xdt.query(1,3);xdt.query(4,6);
		cur=xdt.query(tmp.lb,tmp.rb);
		if(cur)
		ans+=cur;xdt.change(tmp.lb,tmp.rb,-cur);
	}
	cout<<ans;
	return 0;
}
