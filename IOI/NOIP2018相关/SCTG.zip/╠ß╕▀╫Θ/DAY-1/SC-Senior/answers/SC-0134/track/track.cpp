#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctime>
using namespace std;
const int MAXN=5e4+10;
const int MAXM=1e5+10;

int n,m,cnt,tot,ans;
int dis[MAXN];
int head[MAXN];
int fa[MAXN],depth[MAXN],maxx[MAXN],sec[MAXN];
int tp[MAXN];
int son1[MAXN],son2[MAXN];
int flag1=1,flag2=1,flag3=1;
struct Edge{
	int nxt,to,w;
	friend inline bool operator<(const Edge &a,const Edge &b){
		return a.w>b.w;
	}
}edge[MAXM];

int Read(){
	int i=0,f=1;
	char c;
	for(c=getchar();(c>'9'||c<'0')&&c!='-';c=getchar());
	if(c=='-')
	  f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())
	  i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

void add(int x,int y,int z){
	edge[cnt].nxt=head[x];
	head[x]=cnt;
	edge[cnt].to=y;
	edge[cnt].w=z;
	cnt++;
}

void solve1(){
	sort(edge,edge+cnt);
	int i;
	for(i=0;i<=cnt;i+=2){
		dis[i/2+1]=edge[i].w;
		if(i/2+1==m)
		  break;
	}
	int now=m;
	i+=2;
	for(;i<=min(cnt,m*4);i+=2){
		dis[now--]+=edge[i].w;
	}
	sort(dis+1,dis+m+1);
	cout<<dis[1];
	return ;
}

void dfs(int u,int f,int sum,int len,int last){
	if(sum>=len)
	  tot++,sum=last;
	for(int i=head[u];i!=-1;i=edge[i].nxt){
		int v=edge[i].to;
		if(v==f){
		  	continue;
		}
		dfs(v,u,sum+edge[i].w,len,edge[i].w);
	}
}

bool check(int x){
	cout<<x<<endl;
	tot=0;
	dfs(1,-1,0,x,0);
	return tot>=m;
}

void solve2(){
	int l=0,r=5e8,ans;
	while(l<r){
		int mid=l+r>>1;
		if(check(mid))
		  l=mid;
		else
		  r=mid-1;
	}
	cout<<l;
	return ;
}

void dfs1(int u,int f){
	for(int i=head[u];i!=-1;i=edge[i].nxt){
		int v=edge[i].to;
		if(v==f)
		  continue;
		fa[v]=u,depth[v]=depth[u]+1;
		dis[v]=dis[u]+edge[i].w;
		dfs1(v,u);
		if(maxx[v]+edge[i].w>maxx[u]){
			son2[u]=son1[u];
			sec[u]=maxx[u];
			son1[u]=v;
			tp[v]=u;
			maxx[u]=maxx[v]+edge[i].w;
			continue;
		}
		if(maxx[v]+edge[i].w>sec[u]){
			son2[u]=v;
			sec[u]=maxx[v]+edge[i].w;
		}
	}
}

void dfs2(int u,int top){
	tp[u]=top;
	for(int i=head[u];i!=-1;i=edge[i].nxt){
		int v=edge[i].to;
		if(v==fa[u])
		  continue;
		dfs2(v,top);
	}
}

void dfs3(int u,int type){
	if(type==1)
	  ans=max(ans,max(maxx[u]+sec[u],maxx[u]+dis[u]+sec[1]));
	else
	  ans=max(ans,max(maxx[u]+sec[u],maxx[u]+dis[u]+maxx[1]));
	for(int i=head[u];i!=-1;i=edge[i].nxt){
		int v=edge[i].to;
		if(v==fa[u])
		  continue;
		if(tp[u]==1)
		  dfs3(v,1);
		else
		  dfs3(v,0);
	}
}

void solve3(){
	tp[1]=1;
	dfs1(1,-1);
	dfs2(son1[1],1);
	dfs3(1,1);
	cout<<ans;
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	srand(time(0));
	memset(head,-1,sizeof(head));
	n=Read(),m=Read();
	if(m!=1)
	  flag3=0;
	for(int i=1;i<n;++i){
		int x=Read(),y=Read(),z=Read();
		if(x!=1&&y!=1)
		  flag1=0;
		if(y!=x+1&&x!=y+1)
		  flag2=0;
		add(x,y,z);
		add(y,x,z);
	}
	if(flag1){
		solve1();
		return 0;
	}
	if(flag2){
		solve2();
		return 0;
	}
	if(flag3){
		solve3();
		return 0;
	}
	cout<<rand()*rand()%rand();
	return 0;
}
