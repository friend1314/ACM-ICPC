#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long LL;
const int MAXN=1e5+10;

int n;
int a[MAXN];
LL dp[MAXN];

int Read(){
	int i=0,f=1;
	char c;
	for(c=getchar();(c>'9'||c<'0')&&c!='-';c=getchar());
	if(c=='-')
	  f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())
	  i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=Read();
	for(int i=1;i<=n;++i){
		a[i]=Read();
	}
	for(int i=1;i<=n;++i){
		if(a[i]>a[i-1])
		  dp[i]=dp[i-1]+a[i]-a[i-1];
		else
		  dp[i]=dp[i-1];
	}
	cout<<dp[n];
	return 0;
}
