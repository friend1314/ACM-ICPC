#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int MAXN=110;

int n,ans;
int mon[MAXN];
int vis[MAXN];

int Read(){
	int i=0,f=1;
	char c;
	for(c=getchar();(c>'9'||c<'0')&&c!='-';c=getchar());
	if(c=='-')
	  f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())
	  i=(i<<3)+(i<<1)+c-'0';
	return i*f;
}
int exgcd(int a,int b,int &x,int &y){
	if(b==0){
		x=1,y=0;
		return a;
	}
	int t=exgcd(b,a%b,y,x);
	y-=a/b*x;
	return t;
}

int gcd(int x,int y){
	return x%y?gcd(y,x%y):y;
}

bool check(int a,int b,int c){
	int gc=gcd(gcd(a,b),gcd(a,c));
	a/=gc,b/=gc,c/=gc;
	if(gcd(a,b)!=1){
		return 0;
	}
	int x,y;
	exgcd(a,b,x,y);
	x=(x*c%b+b)%b;
	y=(c-a*x)/b;
	if(x>=0&&y>=0){
	  	return 1;
	}
	return 0;
}

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T=Read();
	while(T--){
		memset(vis,0,sizeof(vis));
		n=Read();
		ans=n;
		for(int i=1;i<=n;++i){
			mon[i]=Read();
		}
		sort(mon+1,mon+n+1);
		for(int i=1;i<=n;++i){
		  	for(int j=i+1;j<=n;++j){
		  		if(mon[j]%mon[i]==0&&!vis[j])
		  		  ans--,vis[j]=1;
		  	}
		}
		for(int i=1;i<=n;++i){
			for(int j=i+1;j<=n;++j){
				for(int k=j+1;k<=n;++k){
					if(!vis[i]&&!vis[j]&&!vis[k]&&check(mon[i],mon[j],mon[k]))
					  ans--,vis[k]=1;
				}
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
