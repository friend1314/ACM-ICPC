#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void read(T&y){
	char x=' ';int flag=0;double num=0.1;
	while((x<'0'||x>'9')&&x!='-'&&(x=getchar()));
	if(x=='-')flag=1;else y=x-'0';
	while((x=getchar())&&x>='0'&&x<='9')
		y=y*10+x-'0';
	if(x=='.'){
		while((x=getchar())&&x>='0'&&x<='9')
		{
			y+=(x-'0')*num;num/=10;
		}
	}
	if(flag)y=-y;
}
template <typename T>inline void write(T y){
	if(y<0){putchar('-');write(-y);return;}
	if(y>9)write(y/10);putchar(y%10+'0');
}
int n,m;
struct edge{
	int u,v,w;
	bool operator<(const edge &t)const{
		return w<t.w;
	}
}l[50010];
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);int u,v,w;
	for(int i=1;i<=n-1;i++){
		read(l[i].u);read(l[i].v);read(l[i].w);
	}
	sort(l+1,l+n);
	write(l[n-2].w+l[n-1].w);putchar('\n');
	return 0;
}

