#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void read(T&y){
	char x=' ';int flag=0;double num=0.1;
	while((x<'0'||x>'9')&&x!='-'&&(x=getchar()));
	if(x=='-')flag=1;else y=x-'0';
	while((x=getchar())&&x>='0'&&x<='9')
		y=y*10+x-'0';
	if(x=='.'){
		while((x=getchar())&&x>='0'&&x<='9')
		{
			y+=(x-'0')*num;num/=10;
		}
	}
	if(flag)y=-y;
}
template <typename T>inline void write(T y){
	if(y<0){putchar('-');write(-y);return;}
	if(y>9)write(y/10);putchar(y%10+'0');
}
typedef long long ll;
int n,a[100010];ll ans=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++){
		read(a[i]);
	}
	for(int i=1;i<=n;i++){
		if(a[i]<=a[i-1])continue;
		else
			ans+=(ll)(a[i]-a[i-1]);
	}
	write(ans);putchar('\n');
	return 0;
}
