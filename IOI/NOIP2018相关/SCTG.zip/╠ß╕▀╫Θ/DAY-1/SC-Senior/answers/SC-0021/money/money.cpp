#include<bits/stdc++.h>
using namespace std;
template <typename T>inline void read(T&y){
	char x=' ';int flag=0;double num=0.1;
	while((x<'0'||x>'9')&&x!='-'&&(x=getchar()));
	if(x=='-')flag=1;else y=x-'0';
	while((x=getchar())&&x>='0'&&x<='9')
		y=y*10+x-'0';
	if(x=='.'){
		while((x=getchar())&&x>='0'&&x<='9')
		{
			y+=(x-'0')*num;num/=10;
		}
	}
	if(flag)y=-y;
}
template <typename T>inline void write(T y){
	if(y<0){putchar('-');write(-y);return;}
	if(y>9)write(y/10);putchar(y%10+'0');
}
int t,n,a[110],vis[110];
inline int gcd(int x,int y){
	return (!y)?(gcd(y,x%y)):(x);
}
int exgcd(int a,int b,int &x,int &y){
	if(!b){
		x=1,y=0;return a;
	}
	int ret=exgcd(b,a%b,x,y);
	int t1=x,t2=y;
	x=t2,y=t1-a/b*t2;
	return ret;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int x,y;
	read(t);
	while(t--){
		memset(a,0,sizeof(a));
		memset(vis,0,sizeof(vis));
		read(n);int ans=n;
		for(int i=1;i<=n;i++){
			read(a[i]);
		}
		if(n==2){
			if((!a[1]%a[2])||(!a[2]%a[1])){
				puts("1");continue;
			}
			puts("2");continue;
		}
		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++){
			if(vis[i])continue;
			for(int j=i;j<=n;j++){
				if(vis[j])continue;
				int f=exgcd(a[i],a[j],x,y);
				for(int k=j+1;k<=n;k++){
					if(vis[k])continue;
					//printf("i:%d j:%d k:%d\n",a[i],a[j],a[k]);
					//cout<<"-->f:"<<f<<endl;
					if((!(a[k]%f))){
						if(f==1&&a[i]!=1&&a[j]!=1&&a[k]<a[i]+a[j]){
							continue;
						}
						//cout<<"yes\n";
						ans--;
						vis[k]=1;
					}
				}
			}
		}
		write(ans);putchar('\n');
		/*for(int i=1;i<=n;i++)
			if(!vis[i])printf("%d ",a[i]);
			cout<<endl;*/
	}
	return 0;
}

