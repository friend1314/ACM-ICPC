#include<bits/stdc++.h>
using namespace std;
#define re register
inline void read(int &x){
	x=0;int zf=1;char c=getchar();
	while((c<'0'||c>'9')&&c!='-') c=getchar();
	if(c=='-'){zf=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	x*=zf;
}
inline void write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
int t,n,a[110];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(t);
	srand((unsigned)(time(NULL)));
	while(t--){
		read(n);
		bool flag=false;
		for(re int i=1;i<=n;i++){
			read(a[i]);
			if(a[i]==1) flag=true;
		}
		if(flag) putchar('1');
		else write(rand()%(1ll*n)+2);
		putchar('\n');
	}
	return 0;
}
