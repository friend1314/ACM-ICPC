#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
#define LL long long
#define re register
inline void read(LL &x){
	x=0;LL zf=1;char c=getchar();
	while((c<'0'||c>'9')&&c!='-') c=getchar();
	if(c=='-'){zf=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	x*=zf;
}
inline void write(LL x){
	if(x<0){putchar('-');x=-x;}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
LL mini,ans,n,d[100010],cf[100010],st,ed,tot;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	for(re int i=1;i<=n;i++){
		read(d[i]);
		tot+=d[i];
	}
	while(tot){
		for(re int i=1;i<=n;i++)
			if(d[i]){
				st=i;mini=d[i];
				for(re int j=i+1;j<=n+1;j++){
					if(!d[j]){ed=j-1;break;}
					mini=min(mini,d[j]);
				}
				for(re int j=st;j<=ed;j++) d[j]-=mini;
				tot-=mini*(ed-st+1);
				break;
			}
		ans+=mini;
	}
	write(ans);
	return 0;
}
