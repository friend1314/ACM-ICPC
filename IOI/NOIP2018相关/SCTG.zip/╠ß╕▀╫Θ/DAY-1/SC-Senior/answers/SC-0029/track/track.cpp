#include<bits/stdc++.h>
using namespace std;
#define re register
#define mp make_pair
inline void read(int &x){
	x=0;int zf=1;char c=getchar();
	while((c<'0'||c>'9')&&c!='-') c=getchar();
	if(c=='-'){zf=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+c-'0';c=getchar();}
	x*=zf;
}
inline void write(int x){
	if(x<0){putchar('-');x=-x;}
	if(x>9) write(x/10);
	putchar(x%10+'0');
}
const int N=50010;
int n,m,cnt,first[N],en[N];
bool used[N];
struct dij{
	int dis,dir;
}o[N];
bool cmp(dij a,dij b){
	return a.dis>b.dis;
}
struct edge{
	int v,w,next;
}e[N<<1];
inline void add(int u,int v,int w){
	e[++cnt]=(edge){v,w,first[u]};
	first[u]=cnt;
}
typedef pair<int,int> T;
priority_queue<T,vector<T>,greater<T> >q;
inline void dijkstra(int s){
	cnt=0;
	for(re int i=1;i<=n;i++) o[i].dis=0x3f3f3f3f;
	o[s].dis=0,o[s].dir=0;
	int u,v,d;
	for(re int i=first[s];i;i=e[i].next){
		v=e[i].v;
		o[v].dis=e[i].w,o[v].dir=++cnt;
		q.push(mp(o[v].dis,v));
	}
	while(!q.empty()){
		u=q.top().second,d=q.top().first;q.pop();
		for(re int i=first[u];i;i=e[i].next){
			v=e[i].v;
			if(d+e[i].w<o[v].dis){
				o[v].dis=d+e[i].w,o[v].dir=o[u].dir;
				q.push(mp(o[v].dis,v));
			}
		}
	}
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	srand((unsigned)(time(NULL)));
	read(n);read(m);
	int u,v,w,tot=0;
	for(re int i=1;i<n;i++){
		read(u);read(v);read(w);
		en[u]++;en[v]++;
		tot+=w;
		add(u,v,w);add(v,u,w);
	}
	if(m==1){
		int ans,num,maxi=0;
		for(re int t=1;t<=3;t++){
			while(int k=rand()%n+1)
				if(en[k]>2){
					dijkstra(k);break;
				}
			sort(o+1,o+n+1,cmp);
			ans=0,num=0;
			for(re int i=1;i<=n;i++){
				if(num==2) break;
					if(!used[o[i].dir]&&o[i].dis!=0x3f3f3f3f){
						ans+=o[i].dis;
						num++;
						used[o[i].dir]=true;
					}
			}
			maxi=max(maxi,ans);
		}
		write(maxi);
	}
	else write(rand()%(tot/m+1)+1);
	return 0;
}
