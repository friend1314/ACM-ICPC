#include<cstdio>
//#define LOC
int a[100010],n;
long long ans=0;
/*
one digit return its v
else each - vmin then dg

*/
void dg(int l ,int r,int j){

	if(l==r){
		ans+=a[l]-j;

		return ;
	}
	int minn=300000,minx,x1,x2;//v   xiabiao 
	//int maxa=-1,minx;
//	int num=0;
	for(int i=l;i<=r;i++){
		if(a[i]<minn){
			minn=a[i];
			minx=i;
	//		num=0;
		}
	//	if(a[i]==minn)num++;
	}
	ans+=minn-j;
	x1=minx-1;x2=minx+1;
	while(a[x1]==minn&&x1>l)x1--;
	while(a[x2]==minn&&x2<r)x2++;
	while(a[l]==minn&&l<minx)l++;
	while(a[r]==minn&&r>minx)r--;
	if(l<=x1){
		dg(l,x1,minn);
	}	
	
	if(r>=x2){
		dg(x2,r,minn);
	}
	
	
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	/*
		LOG[0]=-1;
	for(int i=1;i<100;i++){
		LOG[i]=LOG[i/2]+1;
	
	}*/
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	dg(1,n,0);
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
