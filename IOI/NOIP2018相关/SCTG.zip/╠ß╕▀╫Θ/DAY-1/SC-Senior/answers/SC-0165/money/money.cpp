#include<cstdio>
#include<cstring>
#include<algorithm>

int a[110];
bool pri[25009],vis[110];
int main(){
//	freopen("testout","w",stdout);
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int n,T;
	scanf("%d",&T);
	int prii=0;
	bool one=false; 
//	pri[1]=pri[2]=pri[3]=pri[5]=true;
	for(int i=2;i<=25000;i++){// is pri = 0 
		int t = 1 , j = i;
		if(!pri[i])for(int t=i*i;t<=25000;t=i*(++j))pri[t]=true; 
	}
//	for(int i=1;i<=25000;i++)printf("%d %d\n",i,pri[i]?1:0); 
	while(T--){
		one=false;prii=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			if(a[i]==1)one = true;
			if(!pri[a[i]])prii++;
		}
		if(one){
			printf("1\n");
			continue;
		}
		else if(n== prii ){
			printf("%d\n",n);
			continue;
		}

		else {
			int ans=n;
			memset(vis,false,sizeof(vis));
			std::sort(a+1,a+1+n);//int t ;
			for(int i=1;i<=n;i++){
				if(!vis[i])for(int j=i;j<=n;j++)
					if(a[j]!=a[i]&&a[j]%a[i]==0){
						ans--;
					//	printf("%d mod %d = %d v[%d ]=true \n",a[j],a[i],a[j]%a[i],j);
						vis[j]=true;
					}
				}
					printf("%d\n",ans);
					continue;
			}
		
		}
			/*	else if(n==2){
			if(a[1]%a[2]==0||a[2]%a[1]==0){
				printf("1\n");
			}
			else printf("2\n");
			continue;
		}
	else if(n==3){
			bool nd[4];
			nd[1]=nd[2]=nd[3]=true; 
			std::sort(a+1,a+1+n);
			if(a[3]%a[1]==0)nd[3]=false;
			if(a[2]%a[1]==0)nd[2]=false;
			if (a[3]%a[2]==0)nd[3]=false;
			int ans=0;
			for(int i=1;i<=3;i++)if(nd[i])ans++;
			printf("%d\n ",ans);
		}*/ 

	return 0;
}
