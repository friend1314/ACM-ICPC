#include<cstdio>
#include<cstring>
int w[1200][1200];
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(w,0x3f,sizeof(w));
	int n,a,b,c,m;
	scanf("%d%d",&n,&m);
	int maxx=-1;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&a,&b,&c);
		w[a][b]=w[b][a]=c;
		w[i][i]=0;
//		if(maxx<w[a][b])maxx=w[a][b];
	}
	w[n][n]=0;
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			if(i!=k)for(int j=1;j<=n;j++){
				if(j!=k&&w[i][k]<w[0][0]&&w[k][j]<w[0][0]&&w[i][j]<w[i][k]+w[k][j])w[i][j]=w[i][k]+w[k][j];
			
			}
		}
	}
/*	for(int k=1;k<=n;k++){
		
		for(int i=1;i<=n;i++){
			if(i!=k)for(int j=i;j<=n;j++){
				if(j!=k&&w[j][i]<w[0][0]&&w[k][i]<w[0][0]&&w[j][i]<w[j][k]+w[k][i])w[j][i]=w[j][k]+w[k][i];
			
			}
		}
	}*/
	
//	bool v[1200];memset(v,false,sizeof(v));

	for(int i=1;i<=n;i++)for(int j=1;j<=n;j++)if(w[i][j]<w[0][0]&&maxx<w[i][j])maxx=w[i][j];
	printf("%d\n",maxx);
//	printf("%d",&w[4][6]);
	
	
	return 0;
}
