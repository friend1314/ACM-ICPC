#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<cstring>
#include<algorithm>
#include<iomanip>
#include<cmath>
#include<cctype>

using namespace std;

int getint(){
	char c=getchar();
	int ans=0,f=1;
	while(c>'9'||c<'0'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		ans=ans*10+c-'0';
		c=getchar();
	}
	return ans*f;
}

const int N=110,A=25010;

bool f[A];
int a[N];

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t=getint();
	while(t--){
		int n=getint();
		if(n==2){
			int x=getint(),y=getint();
			if(x<y)swap(x,y);
			if(x%y==0)puts("1");
			else puts("2");
		}else{
			int ans=n;
			for(int i=0;i<n;i++)a[i]=getint();
			sort(a,a+n);
			memset(f,0,sizeof(f));
			f[0]=1;
			for(int i=0;i<n;i++){
				if(f[a[i]])--ans;
				else{
					for(int j=a[i];j<A;j++){
						if(f[j-a[i]])f[j]=1;
					}
				}
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
