#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<cstring>
#include<algorithm>
#include<iomanip>
#include<cmath>
#include<cctype>

using namespace std;

int getint(){
	char c=getchar();
	int ans=0,f=1;
	while(c>'9'||c<'0'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		ans=ans*10+c-'0';
		c=getchar();
	}
	return ans*f;
}

const int N=500010,M=N<<1;

struct bian{
	int l,e,n;
};
bian b[M];
int s[N],tot=0;
void add(int x,int y,int z){
	tot++;
	b[tot].l=z;
	b[tot].e=y;
	b[tot].n=s[x];
	s[x]=tot;
}

int n,m;

long long max1[N],max2[N];

void ss(int x,int f){
	for(int i=s[x];i;i=b[i].n){
		if(b[i].e==f)continue;
		ss(b[i].e,x);
		if(max1[b[i].e]+b[i].l>max1[x])max2[x]=max1[x],max1[x]=max1[b[i].e]+b[i].l;
		else if(max1[b[i].e]+b[i].l>max2[x])max2[x]=max1[b[i].e]+b[i].l;
	}
}

int len[N];

bool xz2_check(int mid){
	int cnt=0,sum=0;
	for(int i=0;i<n-1;i++){
		sum+=len[i];
		if(sum>=mid)cnt++,sum=0;
		if(cnt>=m)return 1;
	}
	return 0;
}

long long b_mid,b_cnt;
long long binary_ss(int x,int f){
	long long l=0,m=0;
	for(int i=s[x];i;i=b[i].n){
		if(b[i].e==f)continue;
		long long t=binary_ss(b[i].e,x)+b[i].l;
		if(t>=b_mid)b_cnt++;
		else m=max(m,t),l+=t;
	}
	if(l>=b_mid)b_cnt++,m=0;
	return m;
}

bool binary_check(int mid){
	b_mid=mid,b_cnt=0;
	binary_ss(1,0);
	return b_cnt>=m;
}
char sonscnt[N];


long long maxson[N];
long long sons[N];
int all_cnt=0;
long long all_mid;
void all_ss(int x,int f){
	int cnt=0;
	for(int i=s[x];i;i=b[i].n){
		if(b[i].e==f)continue;
		all_ss(b[i].e,x);
	}
	for(int i=s[x];i;i=b[i].n){
		if(b[i].e==f)continue;
		if(maxson[b[i].e]+b[i].l>=all_mid){
			all_cnt++;
			//cout<<"??"<<x<<" "<<b[i].e<<endl;
			continue;
		}
		sons[cnt++]=maxson[b[i].e]+b[i].l;
	}
	/*sort(sons,sons+cnt);
	int i=0,j=cnt-1;
	while(i<j){
		while(i<j&&sons[i]+sons[j]<all_mid)maxson[x]=max(maxson[x],sons[i]),++i;
		if(i<j)cout<<"???"<<sons[i]<<" "<<sons[j]<<" "<<x<<endl,--j,++i,++all_cnt;
	}
	cout<<"maxson "<<x<<" "<<maxson[x]<<endl;*/
	//n^2
	for(int i=0;i<cnt;i++){
		int minson=-1;
		for(int j=i+1;j<cnt;j++){
			if(sons[i]+sons[j]>=all_mid&&((minson==-1)||sons[j]<sons[minson])){
				minson=j;
			}
		}
		if(minson!=-1){
			sons[i]=0;
			sons[minson]=0;
			all_cnt++;
		}
		maxson[x]=max(maxson[x],sons[i]);
	}
}

bool all_check(int mid){
	memset(maxson,0,sizeof(maxson));
	//cout<<"---"<<mid<<"---"<<endl;
	all_cnt=0,all_mid=mid;
	all_ss(1,0);
	return all_cnt>=m;
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=getint(),m=getint();
	long long sum=0;
	bool xz2=true,binary_tree=true;
	for(int i=0;i<n-1;i++){
		int x=getint(),y=getint(),z=getint();
		if(sonscnt[x]==3||sonscnt[y]==3)binary_tree=0;
		else sonscnt[x]++,sonscnt[y]++;
		sum+=(len[x-1]=z);
		if(y!=x+1)xz2=false;
		add(x,y,z);
		add(y,x,z);
	}
	if(m==0){
		ss(1,0);
		long long ans=0;
		for(int i=1;i<=n;i++)ans=max(ans,max1[i]+max2[i]);
		cout<<ans;
		return 0;
	}
	if(xz2){
		long long l=0,r=sum/m,mid;
		while(l<r){
			mid=(l+r+1)>>1;
			if(xz2_check(mid))l=mid;
			else r=mid-1;
		}
		cout<<l;
		return 0;
	}
	if(binary_tree&&0){
		//binary
		long long l=0,r=sum/m,mid;
		while(l<r){
			mid=(l+r+1)>>1;
			if(binary_check(mid))l=mid;
			else r=mid-1;
		}
		cout<<l;
		return 0;
	}
	else{
		long long l=0,r=sum/m,mid;
		while(l<r){
			mid=(l+r+1)>>1;
			if(all_check(mid))l=mid;
			else r=mid-1;
		}
		cout<<l;
		return 0;
	}
	return 0;
}
