#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<cstring>
#include<algorithm>
#include<iomanip>
#include<cmath>
#include<cctype>

using namespace std;

int getint(){
	char c=getchar();
	int ans=0,f=1;
	while(c>'9'||c<'0'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		ans=ans*10+c-'0';
		c=getchar();
	}
	return ans*f;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n=getint();
	long long ans=0;
	int lst=0;
	for(int i=0;i<n;i++){
		int x=getint();
		if(x>lst)ans+=x-lst;
		lst=x;
	}
	cout<<ans;
	return 0;
}
