#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int s=0,f=1;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	while(isdigit(c))s=s*10+(c^'0'),c=getchar();
	return s*f;
}
inline void print(int x){
	if(x<0)x=-x,putchar('-');
	if(x>9)print(x/10);
	putchar(x%10+'0');
}
inline int gcd(int a,int b){return b?gcd(b,a%b):a;}
int t,n,ans;
int a[101];
bool f[101];
inline void clear(){for(register int i=1;i<=n;++i)f[i]=true,a[i]=0;}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	while(t--){
		ans=n=read();
		clear();
		for(register int i=1;i<=n;++i)a[i]=read();
		sort(a+1,a+1+n);
		for(register int i=1;i<=n;++i)
			for(register int j=i+1;j<=n;++j){
				if(!f[i]||!f[j])continue;
				if(gcd(a[i],a[j])!=1)ans-=1,f[j]=0;
			}
		for(register int i=1;i<=n;++i)
			for(register int j=i+1;j<=n;++j)
				for(register int k=j+1;k<=n;++k){
					if(!f[i]||!f[j]||!f[k])continue;
					if(gcd(a[k]-a[j],a[i])!=1)ans-=1,f[k]=0;
				}
		print(ans),putchar('\n');
	}
	return 0;
}
