#include<bits/stdc++.h>
#define N 100001
#define inf 0x7fffffff
using namespace std;
inline int read(){
	int s=0,f=1;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	while(isdigit(c))s=s*10+(c^'0'),c=getchar();
	return s*f;
}
inline void print(int x){
	if(x<0)x=-x,putchar('-');
	if(x>9)print(x/10);
	putchar(x%10+'0');
}
inline int max(int a,int b){return a>=b?a:b;}
struct node{int m,p;}a[N];
int n,ans;
inline int work(int l,int r,int w){
	if(l+1==r)return max(a[l].m,a[r].m)-w;
	if(l==r)return a[l].m-w;
	int mid,ans=0,M=inf;
	for(register int i=l;i<=r;++i)if(a[i].m<M)M=a[i].m,mid=i;
	ans+=work(l,mid-1,M);
	ans+=work(mid+1,r,M);
	return ans+M-w;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i)a[i].m=read(),a[i].p=i;
	print(work(1,n,0)),putchar('\n');
	return 0;
}
