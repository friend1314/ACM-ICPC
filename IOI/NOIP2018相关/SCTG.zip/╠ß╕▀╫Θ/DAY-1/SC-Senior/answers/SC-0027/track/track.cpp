#include<bits/stdc++.h>
#define N 30001
using namespace std;
inline int read(){
	int s=0,f=1;char c;
	for(c=getchar();!isdigit(c);c=getchar())if(c=='-')f=-1;
	while(isdigit(c))s=s*10+(c^'0'),c=getchar();
	return s*f;
}
inline void print(int x){
	if(x<0)x=-x,putchar('-');
	if(x>9)print(x/10);
	putchar(x%10+'0');
}
struct node{int nxt,pre,w;}e[N<<1];
int n,m,x,y,w;
int head[N],cnt;
int in[N],rt,en,max_w;
inline void add(int x,int y,int w){e[++cnt]=(node){head[x],y,w},head[x]=cnt;}
inline void dfs(int u,int fa,int w){
	if(max_w<w){max_w=w,en=u;}
	for(register int i=head[u];i;i=e[i].nxt){
		if(e[i].pre==fa)continue;
		dfs(e[i].pre,u,w+e[i].w);
	}
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<n;++i)x=read(),y=read(),w=read(),add(x,y,w),add(y,x,w),in[y]++;
	for(register int i=1;i<=n;++i)if(in[i]==0){rt=i;break;}
	dfs(rt,0,0);
	max_w=0;
	dfs(en,0,0);
	print(max_w),putchar('\n');
	return 0;
}
