#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cctype>
#include<cmath>
using namespace std;
#define mei
#define il inline
#define ll long long
#define ree register

const int maxnn=100010;
int n,tot;
int road[maxnn];
ll ans=0;

il int read(){
	ree int x=0,f=1; ree char c=getchar();
	while(!isdigit(c)){ if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)){ x=(x<<3)+(x<<1)+c-'0'; c=getchar();	}
	return x*f;
}
int main(void){
	#ifdef mei
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	#endif
	
	n=read();tot=n;
	for(int i=1;i<=n;++i)
		road[i]=read();
	while(1){
		int minn=999999;
		for(int j=1;j<=n+1;++j){
			if(road[j]!=0)
			minn=min(road[j],minn);
			else if(road[j]==0&&road[j-1]!=0){
				int l=j-1,r=j-1;
				for(;l>=1;l--)if(road[l]==0)break;
				l++;
				for(int k=l;k<=r;++k)road[k]-=minn;
				for(int k=l;k<=r;++k)if(road[k]==0)tot--;
				ans+=minn;
				minn=99999;
			}
		}
		if(minn==999999||!tot)break;
	}
	printf("%lld",ans);
	
	#ifdef mei
	fclose(stdin);
	fclose(stdout);
	#endif
	return 0;
}
