#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cctype>
using namespace std;
#define mei
#define il inline
#define ll long long
#define ree register

int n,money[105],m;
bool vis[105];

il int read(){
	ree int x=0,f=1; ree char c=getchar();
	while(!isdigit(c)){ if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)){ x=(x<<3)+(x<<1)+c-'0'; c=getchar();	}
	return x*f;
}
//������ϵ 
il void solve1(int x,int qian){
	int x1,f=0;
	for(int i=x-1;i>=1;--i){
		if(f)break;
		if(!vis[i]){
			x1=qian%money[i];
			for(int j=1;j<i;++j){
				if(x1<money[j])break;
				if(x1%money[j]==0){
					vis[x]=true;f=1;break;
				}
			}
		}
	}
}
//�͵Ĺ�ϵ 
il void solve2(int x,int qian){
	int x2=qian,ff=0;
	for(int i=x-1;i>=1;--i){
		if(ff)break;
		x2=qian;
		if(!vis[i]){
			while(x2>=money[1]){
				x2-=money[i];
				if(x2>=0)
				for(int j=1;j<i;++j){
					if(ff)break;
					if(x2%money[j]==0){
						vis[x]=true;ff=1;break;
					}
				}	
			}
		}
	}
}
int main(void){
	#ifdef mei
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	#endif
	
	int t;
	t=read();
	while(t--){
		m=0;
		memset(vis,0,sizeof(vis));
		memset(money,0,sizeof(money));
		n=read();
		for(int i=1;i<=n;++i)money[i]=read();
		sort(money+1,money+1+n);
		//ֱ�ӵı�����ϵ 
		for(int i=1;i<=n;++i){
			if(!vis[i]&&money[n]/money[i]>1){
				for(int j=i+1;j<=n;++j)
					if(money[j]%money[i]==0)vis[j]=true;
			}
		}
		for(int i=n;i>=1;--i)
			if(!vis[i])solve1(i,money[i]);
		for(int i=n;i>=1;--i)
			if(!vis[i])solve2(i,money[i]);
		for(int i=1;i<=n;++i)
			if(!vis[i])m++;//cout<<money[i]<<" ";
		printf("%d\n",m);
	}
	
	
	#ifdef mei
	fclose(stdin);
	fclose(stdout);
	#endif
	return 0;
}
