#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cctype>
using namespace std;
#define mei
#define il inline
#define ll long long
#define ree register

const int maxn=50005;
int first[maxn<<1],next[maxn<<1],to[maxn<<1],w[maxn<<1];
int n,m;
int dis[maxn];
bool vis[maxn];

il int read(){
	ree int x=0,f=1; ree char c=getchar();
	while(!isdigit(c)){ if(c=='-')f=-1; c=getchar(); }
	while(isdigit(c)){ x=(x<<3)+(x<<1)+c-'0'; c=getchar();	}
	return x*f;
}
il void add(int a,int b,int c,int cur){
	to[cur]=b;w[cur]=c;next[cur]=first[a];first[cur]=a;
}
il void dfs(int x){
	if(dis[x]<dis[to[x]]);
	for(int i=first[x];i;i=next[i]){
		if(!vis[i]){
			vis[i]=true;
			dfs(i);
			vis[i]=true;
		}
	}
}
int main(void){
	#ifdef mei
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	#endif
	
	n=read();m=read();
	for(int i=1;i<=n;++i){
		int a,b,c;
		a=read();b=read();c=read();
		add(a,b,c,i*2-1);add(b,a,c,i*2);
	}
	for(int i=1;i<=n;++i){
		dis[i]=0;
		vis[i]=true;
		dfs(i);
		memset(vis,0,sizeof(vis));
	}
	cout<<(1+rand()%10000);
	
	#ifdef mei
	fclose(stdin);
	fclose(stdout);
	#endif
	return 0;
}
