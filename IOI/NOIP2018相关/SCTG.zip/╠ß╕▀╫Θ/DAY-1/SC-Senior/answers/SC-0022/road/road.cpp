#include<iostream>
#include<cstdio>
using namespace std;
int n;
int d[100005];
int l[100005],r[100005];
int p;
int ans=0;
int main()
{
	freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
	cin>>n;
	int i;
	p=0;
	bool ll=0;
	for(i=1;i<=n;++i)
	  {
	   cin>>d[i];
	   if(d[i]!=0&&ll==0)
	     {p++;ll=1;
	      l[p]=i;} 
	   if(d[i]==0&&ll)
	     {ll=0;
	      r[p]=i-1;}
	  } 
	if(d[n]!=0)r[p]=n;              //�������ݣ�������������� 
	  

	int h=1;                        // ���� 
	while(h<=p)
	  {
	   int min=0x7ffffff;
	   for(i=l[h];i<=r[h];++i)
	     if(d[i]<min)min=d[i];
	   ans+=min;
	   
	   ll=0;
	   for(i=l[h];i<=r[h];++i)
	     {
	     	d[i]=d[i]-min;
	     	if(d[i]!=0&&ll==0)
	         {p++;ll=1;
	          l[p]=i;} 
	        if(d[i]==0&&ll)
	         {ll=0;
	          r[p]=i-1;}
	     }
	   if(d[r[h]]!=0)r[p]=r[h];     //�������������ݣ�������� 
	   
	   h++; 
	  }
	cout<<ans<<endl;
 
    fclose(stdin);
    fclose(stdout);
    return 0;
}
