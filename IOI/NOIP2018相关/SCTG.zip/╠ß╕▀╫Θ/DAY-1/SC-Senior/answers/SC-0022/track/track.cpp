#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m;
int a[50005],b[50005],l[50005];
int dis[10001][10001];
int main()
{
	freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    
    cin>>n>>m;
    int i;
    
	memset(dis,0x7f,sizeof(dis));     //��ʼ�� 
    for(i=1;i<=n;i++)
      dis[i][i]=0;
    for(i=1;i<=n-1;++i)               
      {
      	cin>>a[i]>>b[i]>>l[i];
      	dis[a[i]][b[i]]=l[i];
      	dis[b[i]][a[i]]=l[i];
      }
      
    if(m==n-1)                      //  m=n-1ʱ 
      {
      	int comp=0x7ffffff;
      	for(i=1;i<=n-1;++i)
      	  if(comp>l[i])
      	    comp=l[i];
      	cout<<comp<<endl;
      }
      
    if(m==1)                        //m=1ʱ 
      {
      	int comp=0;
      	int j,k;
      	for(i=1;i<=n;i++)
      	  for(j=1;j<=n;++j)
      	    for(k=1;k<=n;++k)
      	      if(i!=j&&i!=k&&j!=k&&dis[i][j]>dis[i][k]+dis[k][j])
		        dis[i][j]=dis[i][k]+dis[k][j];
		for(i=1;i<=n;i++)
      	  for(j=1;j<=n;++j)		  
      	    if(comp<dis[i][j])
      	            comp=dis[i][j];
		cout<<comp<<endl;         
      }
    fclose(stdin);
    fclose(stdout);
   return 0;
}
