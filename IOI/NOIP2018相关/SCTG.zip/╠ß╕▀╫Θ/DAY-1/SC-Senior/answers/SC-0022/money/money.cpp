#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,n;
int a[105],b[105];
int tot;
int comp;//��С���ܱ�ʾ���� 


bool check(int m)//�Ƿ��ܱ�ǰ�������ʾ 
{
	if(m>comp)
	  return false;
	int i,j;
	for(i=1;i<tot;++i)
	  for(j=i+1;j<=tot;++j)
	    if(m%b[i]==0||m%b[j]==0||(m%a[i])%b[j]==0||(m%b[j])%a[i]==0)
	      return false;
	return true;
}


int main()
{
	freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
	cin>>t;
	for(int k=1;k<=t;++k)
	  {
	  	cin>>n;
		if(n==1)
		  {cout<<"1"<<endl;
		   continue;} 
	  	int i,j;
	  	memset(a,0,sizeof(a));
	  	memset(b,0,sizeof(b));
	  	for(i=1;i<=n;++i)
	  	  cin>>a[i];
		sort(a+1,a+(n+1));//��ʼ�� 
		
		tot=1;
		b[tot]=a[1];comp=a[1];
		int h=1;
		do
		{
			h++;
			if(a[h]%comp!=0)
			  {tot++;
			   b[tot]=a[h];
			   comp=comp*a[h]-comp-a[h];}
		}while(tot!=2&&h!=n);//�� min��b[i]�ĳ�ʼ 
		
		for(i=h+1;i<=n;i++)//����Ƿ��ܽ���b[i] 
		  if(check(a[i]))
		    {tot++;
		     b[tot]=a[i];}
		     
		cout<<tot<<endl;
	  }

    fclose(stdin);
    fclose(stdout);
    return 0;
}
