#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
#include<cctype>
#include<iomanip>
using namespace std;
int n,mini,mini2,maxi,a[111111],ans,tmp;
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	mini=999999999;ans=0;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		if(a[i]<mini) mini=a[i];
		if(a[i]>maxi) maxi=a[i];
	}
	ans+=mini;
	for(int i=mini;i<maxi;++i){
		tmp=0;mini2=999999999;
		for(int j=1;j<=n;++j)
			if(a[j]!=0){
				a[j]-=mini;
				if(a[j]&&a[j+1]-mini<=0) ++tmp;
				if(a[j]) mini2=min(mini2,a[j]);
			}
		if(mini2!=999999999) ans+=mini2*tmp;
		if(mini2!=999999999) mini=mini2,i+=(mini-1);
	}
	printf("%d",ans);
	return 0;
}
