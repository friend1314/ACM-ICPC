#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
#include<cctype>
#include<iomanip>
using namespace std;
int first[55555],nxt[55555],goal[55555],dis[55555];
int n,m,a,b,c,ans;
int maxi1[55555],maxi2[55555],maxi0[55555];
void dfs(int u){
	int max1=0,max2=0,tmp;
	for(int p=first[u];p;p=nxt[p]){
		dfs(goal[p]);
		maxi0[u]=max(maxi0[u],max(max(maxi0[goal[p]],maxi2[goal[p]]),maxi1[goal[p]]));
		if(maxi1[u]<=maxi1[goal[p]]+dis[p]){
			if(maxi1[u]!=0) maxi2[u]=maxi1[u]+maxi1[goal[p]]+dis[p];
			maxi1[u]=maxi1[goal[p]]+dis[p];
		}
	}
	return;
}
bool tag1,tag2;
bool check2(int x){
	int temp2=0,cnt=0;
	for(int i=1;i<n;++i){
		if(temp2+dis[first[i]]>=x){
			++cnt;
			temp2=0;
		}else temp2+=dis[first[i]];
	}
	return cnt>=m;
}
bool check3(int x){
	int cnt=0,temp3=0;
	for(int i=n-1;i;--i){
		if(dis[i]>x) ++cnt;
		else{
			if(temp3==0) temp3=dis[i];
			else if(temp3+dis[i]>=x){
				++cnt;
				temp3=0;
			}else return cnt>=m;
		}
	}
	return cnt>=m;
}
signed main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	tag1=false;tag2=false;
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;++i){
		scanf("%d%d%d",&a,&b,&c);
		if(a>b) swap(a,b);
		if(a!=1) tag1=true;
		if(b!=a+1) tag2=true;
		nxt[i]=first[a];first[a]=i;goal[i]=b;dis[i]=c;
	}
	if(m==1){
		dfs(1);
		ans=max(max(maxi0[1],maxi1[1]),maxi2[1]);
		printf("%d",ans);
		return 0;
	}else if(!tag2){
		int lef=1,righ=999999999,mid;
		while(lef<=righ){
			mid=lef+righ>>1;
			if(check2(mid)) lef=mid+1;
			else righ=mid-1;
			/*cout<<"mid:"<<mid<<" "<<"check:"<<check2(mid)<<endl;
			cin>>c;*/
		}
		printf("%d",righ);
		return 0;
	}else if(!tag1){
		sort(dis+1,dis+n);
		int lef=1,righ=999999999,mid;
		while(lef<=righ){
			mid=lef+righ>>1;
			if(check3(mid)) lef=mid+1;
			else righ=mid-1;
			/*cout<<"mid:"<<mid<<" "<<"check:"<<check3(mid)<<endl;
			cin>>c;*/
		}
		printf("%d",righ);
		return 0;
	}
}
/* 5 1
   1 2 1
   1 3 1
   2 4 100
   2 5 100

	5 2
	1 2 3
	2 3 4
	3 4 5
	4 5 2
	
	9 3
	1 2 3
	1 3 4
	1 4 5
	1 5 6
	1 6 7
	1 7 8
	1 8 9
	1 9 10
*/
