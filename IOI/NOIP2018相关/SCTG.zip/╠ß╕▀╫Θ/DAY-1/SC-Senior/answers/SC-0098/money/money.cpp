#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<ctime>
#include<cmath>
#include<algorithm>
#include<cctype>
#include<iomanip>
using namespace std;
int T,n,a[1111],ans,maxai;
signed main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;++i){
			scanf("%d",&a[i]);
			maxai=max(maxai,a[i]);
		}
		sort(a+1,a+n+1);
		if(a[1]==1){
			puts("1");
		}else if(n==2){
			if(a[2]%a[1]) puts("2");
			else puts("1");
		}else if(n==3){
			ans=1;
			if(a[2]%a[1]){
				++ans;
				int temp_case2=a[3],tagi2=0;
				while(temp_case2>0){
					if(temp_case2%a[1]) temp_case2-=a[2];
					else{
						tagi2=1;
						break;
					}
				}
				if(!tagi2)++ans;
				printf("%d\n",ans);
			}else{
				if(a[3]%a[1]) puts("2");
				else puts("1");
			}
		}
	}
	return 0;
}
