#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read(){
	char ch=getchar();
	int res=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
const int N=100006;
int n,fa[N],pos[N];
struct road{
	int l,r,h;
}a[N];
ll ans;
inline bool comp(const road &a,const road &b){
	return a.h>b.h;
}
inline int find(int x){
	return fa[x]==x?x:fa[x]=find(fa[x]);
}
inline bool cmp(int x,int y){
	return a[x].h>a[y].h;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)a[i].h=read(),a[i].l=i,a[i].r=i,fa[i]=i,pos[i]=i;
	sort(pos+1,pos+n+1,cmp);
	for(int i=1;i<=n;++i){
		int f1=find(a[pos[i]].l-1),f2=find(a[pos[i]].r+1),k=find(pos[i]);
		if(a[f1].h>a[f2].h){
			fa[k]=f1,ans+=a[k].h-a[f1].h,a[f1].r=a[k].r;//
		}
		else {
			fa[k]=f2,ans+=a[k].h-a[f2].h,a[f2].l=a[k].l;
		}
	}
	cout<<ans;
}
