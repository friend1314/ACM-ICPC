#include<bits/stdc++.h>
using namespace std;
inline int read(){
	char ch=getchar();
	int res=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
const int N=50004;
int n,m,adj[N],l,r,nxt[N<<1],to[N<<1],val[N<<1],totp,eew[N],cnt,in[N],root,dis[N];
bool fl,fe,fr;
inline void addedge(int u,int v,int w){
	nxt[++cnt]=adj[u],adj[u]=cnt,to[cnt]=v,val[cnt]=w;
}
inline void dfs(int u,int fa){
	for(int e=adj[u];e;e=nxt[e]){
		int v=to[e];
		if(v==fa)continue;
		dis[v]=dis[u]+val[e];
		if(dis[v]>dis[root])root=v;
		dfs(v,u);
	}
}
int fpl;
inline void solve1(){
	dfs(1,0);
	memset(dis,0,sizeof(dis));
	dfs(root,0);cout<<dis[root];
}
inline void dfs(int u,int fa,int tot,int shx){
	for(int e=adj[u];e;e=nxt[e]){
		int v=to[e];
		if(v==fa)continue;
		tot+=val[e];
		if(tot>=shx)fpl++,tot=0;
		dfs(v,u,tot,shx);
	}
}
inline bool check(int k){
	fpl=0;
	dfs(1,0,0,k);
	return fpl>=m;
}
inline void solve3(){
	int ans=0;
	while(l<=r){
		int mid=(l+r)/2;
		if(check(mid))l=mid+1,ans=mid;
		else r=mid-1;
	}
	cout<<ans;
}
inline void dfss(int u,int fa,int shx){
	if(in[u]==1){dis[u]=0;return;}
	if(in[u]==2){
		for(int e=adj[u];e;e=nxt[e]){
			int v=to[e];
			if(v==fa)continue;
			dfss(v,u,shx);
			dis[u]=dis[v]+val[e];
			if(dis[u]>=shx)dis[u]=0,++fpl;
		}
	}
	else if(in[u]==3){
		int zp[2],cnt=0;
		for(int e=adj[u];e;e=nxt[e]){
			int v=to[e];
			if(v==fa)continue;
			dfss(v,u,shx);
			zp[cnt++]=dis[v]+val[e];
		}
		if(zp[0]<zp[1])swap(zp[0],zp[1]);
		if(zp[0]<shx){dis[u]=zp[0];return;}
		if(zp[0]>=shx&&zp[1]<shx){
			fpl++;dis[u]=zp[1];return;
		}
		if(zp[1]>shx&&zp[0]>=shx){
			fpl+=2;dis[u]=0;return;
		}
	}
}
inline bool checker(int k){
	memset(dis,0,sizeof(dis));
	fpl=0;dfss(root,0,k);
	return fpl>=m;
}
inline void solve4(){
	for(int i=1;i<=n;++i){
		if(in[i]==1){
			root=i;in[i]++;break;
		}
	}
	int ans=0;
	while(l<=r){
		int mid=(l+r)/2;
		if(checker(mid))l=mid+1,ans=mid;
		else r=mid-1;
	}
	cout<<ans;
}
inline void solve2(){
	sort(eew+1,eew+totp+1);
	int ans=100000000;
	for(int i=1;i<=(totp-m);i++){
		ans=min(ans,eew[i]+eew[totp+1-i]);
	}
	for(int i=totp-m+1;i<=m;i++){
		ans=min(ans,eew[i]);
	}
	cout<<ans;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	fl=fe=fr=true;
	for(int i=1;i<n;++i){
		int u=read(),v=read(),w=read();r+=w,eew[++totp]=w;
		if(u!=1)fl=false;
		if(v!=u+1)fe=false;
		++in[u],++in[v];
		if(in[u]>3||in[v]>3)fr=false;
		addedge(u,v,w),addedge(v,u,w);
	}	
	if(m==1){
		solve1();return 0;
	}
	if(fe){
		solve3();return 0;
	}
	if(fl){
		solve2();return 0;
	}
	if(fr){
		solve4();return 0;
	}
}
