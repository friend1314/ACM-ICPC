#include<bits/stdc++.h>
using namespace std;
inline int read(){
	char ch=getchar();
	int res=0,f=1;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
const int N=105;
int T,n,a[N],vis[N][25005],ans,x,y;
bool flag;
inline void dfs(int pos,int res){
	if(pos==0)return;
	if(vis[pos][res]){
		flag=true,++ans;return;
	}
	if(res<a[pos]){
		dfs(pos-1,res);return;
	}
	if(res%a[pos]==0){
		ans++,flag=true;return;
	}
	for(int i=0;i*a[pos]<=res&&(!flag);++i){
		dfs(pos-1,res-i*a[pos]);vis[pos][res]=flag;
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--){
		n=read();memset(vis,0,sizeof(vis)),ans=0;
		for(int i=1;i<=n;++i)a[i]=read();
		sort(a+1,a+n+1);
		for(int i=1;i<=n;++i){
			flag=false;dfs(i-1,a[i]);
		}
		cout<<n-ans;puts("");
	}
}
