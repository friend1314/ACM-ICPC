#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;

const int inf=2e9;
const int maxn=110;
const int maxa=25010;
int t,n;
int a[maxn];
int book[maxa*3];

int gcd(int a,int b) {
	return !b ? a : gcd(b,a%b);
}

bool cmp(const int x,const int y) {
	return x<y;
}

int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(int tt=1;tt<=t;tt++) {
		memset(a,0,sizeof(a));
		memset(book,0,sizeof(book));
		scanf("%d",&n);
		int cnt=n;
		
		int min1=inf,min2=inf;
		int flag=0;
		
		for(int i=1;i<=n;i++) {
			scanf("%d",&a[i]);
			
			min1=min(min1,a[i]);
			if(a[i]==1) {
				printf("1\n");
				flag=1;
				break;
			}
		}
		sort(a+1,a+n+1,cmp);
		
		if(n==2) {
			if(max(a[1],a[2])%min(a[1],a[2])==0) {
				printf("1\n");
				continue;
			}
			else {
				printf("2\n");
				continue;
			}
		}
		
		if(n==3) {
			if(a[2]%a[1]==0&&a[3]%a[1]==0) {
				printf("1\n");
				continue;
			}
			else if((a[2]%a[1]==0&&a[3]%a[1]!=0)||(a[2]%a[1]!=0&&a[3]%a[1]==0)||(a[2]%a[1]!=0&&a[3]%a[2]==0)) {
				printf("2\n");
				continue;
			}
			else if(a[2]%a[1]!=0&&a[3]%a[1]!=0&&a[3]%a[2]!=0) {
				printf("3\n");
				continue;
			}
		}
		if(flag) {
			continue;
		}
		

		for(int i=1;i<=n;i++) {
			if(book[a[i]]==0) { //ai is not available
				a[i]=0;
			}
			else { //ai is available,so make the other times of ai unavailable
				for(int j=2;a[i]*j<=maxa;j++) {
					book[j*a[i]]=0;
				}
				for(int j=1;j<i;j++) {
					for(int r=1;r*a[j]<=maxa&&a[j]!=0;r++)
						for(int q=1;r*a[j]+q*a[i]<=maxa;q++)
							book[r*a[j]+q*a[i]]=0;
				}
			}
		}
		
		for(int i=1;i<=n;i++) {
			if(book[i]==0)
				cnt--;
		}
		/*for(int i=1;i<=n;i++) {
			if(a[i]>min1&&a[i]<min2&&max(a[i],min1)%min1!=0)
				min2=a[i];
			if(a[i]%min1==0)
				a[i]=0;
		}	
		int tmp=min1*min2-min1-min2+1;
		for(int i=1;i<=n;i++) {
			if(a[i]>=tmp)
				a[i]=0;
		}
		for(int i=1;i<=n;i++) {
			if(a[i]==0)
				cnt--;
		}*/
		printf("%d\n",cnt);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

