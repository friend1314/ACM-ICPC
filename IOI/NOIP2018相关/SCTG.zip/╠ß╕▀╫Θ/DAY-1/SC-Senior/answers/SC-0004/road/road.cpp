#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;

const int maxn=100010;
int n,d,ans,minn,maxx;

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) {
		scanf("%d",&d);
		if(d<=minn) {
			minn=d;
		}
		else {
			ans+=maxx-minn;
			maxx=d;
			minn=d;
		}
	}
	ans+=maxx;
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

