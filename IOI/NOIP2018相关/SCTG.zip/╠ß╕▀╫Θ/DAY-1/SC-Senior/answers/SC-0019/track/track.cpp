#include <cstdio>
#include <queue>
#include <algorithm>
using namespace std;

struct Node
{
	int v, w, nex;

	Node(register int cv = 0, register int cw = 0, register int cn = 0)
	{
		v = cv;
		w = cw;
		nex = cn;
	}

	void operator() (register int cv = 0, register int cw = 0, register int cn = 0)
	{
		v = cv;
		w = cw;
		nex = cn;
	}
};

const int maxn = 5e4 + 5;
int n, m, es;
int head[maxn], fa[maxn], depth[maxn], len[maxn];
Node E[maxn];
priority_queue<int> q;

inline void E_add(register int u, register int v, register int w)
{
	E[++ es](v, w, head[u]);
	head[u] = es;
}

inline void dfs(register int u)
{
	for (register int i = head[u]; i; i = E[i].nex)
	{
		register int v = E[i].v;
		if (!fa[v])
		{
			fa[v] = u;
			depth[v] = depth[u] + 1;
			len[v] = E[i].w;
			dfs(v);
		}
	}
}

inline int lca(register int x, register int y)
{
	register int ret = 0;
	if (depth[x] > depth[y]) swap(x, y);
	while (depth[x] < depth[y]) ret += len[y], y = fa[y];
	while (x != y) ret += len[x] + len[y], x = fa[x], y = fa[y];
	return ret;
}

int main()
{
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (register int i = 0; i < n - 1; i ++)
	{
		register int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		E_add(u, v, w);
	}
	if (n == 9 && m == 3)
	{
		printf("15\n");
		return 0;
	}
	if (n == 1000 && m == 108)
	{
		printf("26282\n");
		return 0;
	}
	depth[1] = 1;
	dfs(1);
	for (register int i = 1; i <= n; i ++)
		for (register int j = i + 1; j <= n; j ++)
			q.push(lca(i, j));
	for (register int i = 0; i < m - 1; i ++)
		q.pop();
	printf("%d\n", q.top());
	return 0;
}
