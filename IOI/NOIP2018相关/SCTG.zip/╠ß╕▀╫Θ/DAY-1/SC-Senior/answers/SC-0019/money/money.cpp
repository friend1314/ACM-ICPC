#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std;

const int maxn = 105;
const int maxm = 25005;
int t, n, maxx, sum;
int a[maxn];
int b[maxm];

int main()
{
	freopen("money.in", "r",stdin);
	freopen("money.out", "w", stdout);
	scanf("%d", &t);
	while (t --)
	{
		scanf("%d", &n);
		maxx = 0;
		sum = 0;
		memset(b, 0, sizeof b);
		for (register int i = 0; i < n; i ++)
			scanf("%d", &a[i]),
			maxx = max(maxx, a[i]),
			b[a[i]] = 1;
		for (register int i = 0; i <= maxx; i ++)
			for (register int j = 0; j <= i; j ++)
				if (b[i] && b[j] && i + j <= maxx)
					b[i + j] = 2;
		for (register int i = 0; i < n; i ++)
			if (b[a[i]] < 2)
				sum ++;
		printf("%d\n", sum);
	}
	return 0;
}
