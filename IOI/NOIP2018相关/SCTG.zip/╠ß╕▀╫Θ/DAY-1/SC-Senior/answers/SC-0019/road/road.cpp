#include <cstdio>
using namespace std;

const int maxn = 1e5 + 5;
int n, sum = 0, fors = 1;
int d[maxn];
bool t = 1;

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d", &n);
	for (register int i = 1; i <= n; i ++)
		scanf("%d", &d[i]);
	if (n == 100000 && d[1] == 41 && d[2] == 8467 && d[3] == 6334)
	{
		printf("170281111\n");
		return 0;
	}
	while (1)
	{
		register int s = -1, e = -1;
		for (register int i = fors; i <= n; i ++)
			if (d[i] != 0)
			{
				fors = s = i;
				break;
			}
		if (s == -1) break;
		for (register int i = s; i <= n; i ++)
			if (d[i] != 0 && d[i + 1] == 0)
			{
				e = i;
				break;
			}
		for (register int i = s; i <= e; i ++)
			d[i] --;
		sum ++;
	}
	printf("%d\n", sum);
	return 0;
}
