#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
const int N=1e5+100;
int n,a[N],ans;
int search(int l,int r)
{
	int t=0,sum=0;
	for(int i=l;i<=r;i++)
	{
		if(a[i]>0)t++;
	}
	if(t==r-l+1)
	{
		for(int i=l;i<=r;i++)
		{
			a[i]=a[i]-1;
		}
		sum++;
	}
	return sum;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			ans+=search(i,j);
		}
	}
	printf("%d",ans);
	return 0;
}
