#include<iostream>
#include<cstdio>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;
const int N=1e3+100;
int n,m,ans[N],arr[N][N];
bool vis[N],flag[N];
struct Node{
	int root,w;
};
vector<int> vec[N];
queue<struct Node> que;
int search(int root)
{
	memset(vis,false,sizeof(vis));
	vis[root]=true;
	struct Node now;
	struct Node next;
	now.root=root;
	now.w=0;
	que.push(now);
	while(!que.empty())
	{
		now=que.front();
		que.pop();
		for(int i=0;i<vec[now.root].size();i++)
		{
			if(vis[vec[now.root][i]])continue;
			vis[vec[now.root][i]]=true;
			next.root=vec[now.root][i];
			next.w=now.w+arr[now.root][vec[now.root][i]];
			que.push(next);
		}
	}
	return next.w;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("tract.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++)
	{
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		arr[u][v]=w;
		arr[v][u]=w;
		vec[u].push_back(v);
		vec[v].push_back(u);
	}
	for(int i=1;i<=n;i++) ans[i]=search(i);
    sort(ans+1,ans+1+n);
    cout<<ans[n-m+1];
	return 0;
}

