#include<cstdio>
#include<cmath>
#include<queue>
#include<iostream>
#define N 100010
#define ll long long
using namespace std;

ll n,a[N],ans;

ll js(ll l,ll r,ll up)
{
	if(l>r) return 0;
	if(l==r) return a[l]-up;
	int res=0;
	int minn=0x3f3f3f3f,p;
	for(int i=l;i<=r;i++)
	{
		if(a[i]<minn)
		{
			minn=a[i];
			p=i;
		}
	}
	res+=a[p]-up;
	res+=js(l,p-1,a[p]);
	res+=js(p+1,r,a[p]);
	return res;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	printf("%lld",js(1,n,0));
	return 0;
}
