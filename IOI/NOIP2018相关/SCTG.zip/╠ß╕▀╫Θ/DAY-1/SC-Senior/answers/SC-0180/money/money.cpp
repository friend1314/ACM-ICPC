#include<cstdio>
#include<cmath>
#include<algorithm>
#include<iostream>
#define N 210
#define M 25010
#define ll long long
using namespace std;

int n,a[N],f[M],ans;

inline int camp(int x,int y)
{
	return x<y;
}

void Solve()
{		
	ans=n;
	sort(a+1,a+n+1,camp);
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;i++)
	{
		for(int k=a[i-1]+1;k<=a[i];k++)
		{
			for(int j=1;j<=i;j++)
			{
				if(f[k-a[j]]!=0||k-a[j]==0)
				f[k]=max(f[k],f[k-a[j]]+1);
			}
		}
		if(f[a[i]]>1) ans--;
	}
	return;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		Solve();
		printf("%d\n",ans);
		t--;
	}
	return 0;
}
