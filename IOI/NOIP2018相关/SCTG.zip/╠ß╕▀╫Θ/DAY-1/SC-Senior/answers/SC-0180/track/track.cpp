#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<queue>
#include<iostream>
#define NN 310
#define N 50010
#define inf 0x3f3f3f3f
#define ll long long
using namespace std;

struct fs
{
	int nxt,to,w;
}a[N<<1];

ll maxd;
int h[N],d[N],q[N],n,m,num,root;

inline void add(int x,int y,int v)
{
	a[++num].nxt=h[x];
	a[num].to=y;
	a[num].w=v;
	h[x]=num;
	return;
}

void DFS(int x,int fa,int dp)
{
	d[x]=dp;
	if(d[x]>maxd)
	{
		maxd=d[x];
		root=x;
	}
	for(int i=h[x];i;i=a[i].nxt)
	{
		int y=a[i].to;
		if(y==fa) continue;
		DFS(y,x,dp+a[i].w);
	}
	return;
}

int checkline(ll p)
{
	int cnt=0,x=1;
	ll sum=0;
	while(h[x])
	{
		sum+=a[h[x]].w;
		if(sum>=p)
		{
			sum=0;
			cnt++;
		}
		x=a[h[x]].to;
		if(cnt>=m) break;
	}
	if(cnt>=m) return 1;
	else return 0;
}

inline int camp(int x,int y)
{
	return x>y;
}

int check1(ll p)
{
	int cnt=0;
	int l=1,r=0;
	for(int i=h[1];i;i=a[i].nxt) q[++r]=a[i].w;
	sort(q+1,q+r+1,camp);
	while(l<r)
	{
		if(cnt>=m) break;
		ll frt=q[l];l++;
		if(frt>=p)
		{
			cnt++;
			continue;
		}
		while(l<r&&frt+q[r]<p) r--;
		if(frt+q[r]>=p) cnt++;
		r--;
	}
	if(cnt>=m) return 1;
	else return 0;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==1)
	{
		for(int i=1;i<n;i++)
		{
			int x,y,v;
			scanf("%d%d%d",&x,&y,&v);
			add(x,y,v);
			add(y,x,v);
		}
		DFS(1,0,0);
		DFS(root,0,0);
		printf("%lld\n",maxd);
		return 0;
	}
	else
	{
		ll sum=0;
		bool flag1=1;
		bool flagline=1;
		for(int i=1;i<n;i++)
		{
			int x,y,v;
			scanf("%d%d%d",&x,&y,&v);
			if(x!=1) flag1=0;
			if(x+1!=y) flagline=0;
			sum+=v;
			add(x,y,v);
		}
		if(flagline)
		{
			ll ans=0;
			ll l=0,r=sum;
			while(l<r)
			{
				ll mid=(l+r)>>1;
				if(checkline(mid))
				{
					ans=mid;
					l=mid+1;
				}
				else r=mid;
			}
			printf("%lld\n",ans);
			return 0;
		}
		if(flag1)
		{
			ll ans=0;
			ll l=0,r=sum;
			while(l<r)
			{
				ll mid=(l+r)>>1;
				if(check1(mid))
				{
					ans=mid;
					l=mid+1;
				}
				else r=mid;
			}
			printf("%lld\n",ans);
			return 0;
		}
		int MAXRAND=sum/m;
		printf("%d\n",MAXRAND);
	}
	return 0;
}
