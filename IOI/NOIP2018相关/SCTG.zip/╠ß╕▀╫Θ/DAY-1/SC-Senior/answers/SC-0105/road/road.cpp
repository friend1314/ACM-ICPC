#include <bits/stdc++.h>
const int N = 100010;
int n, a[N], mn[N][19], Lg[N];
int ans = 0;
int Get(int l, int r) {
  int k = Lg[r - l];
  int x = mn[l][k], y = mn[r - (1 << k) + 1][k];
  return a[x] <= a[y] ? x : y;
}
void Solve(int l, int r, int k) {
  if (l > r) return;
  int x = Get(l, r);
  ans += a[x] - k;
  Solve(l, x - 1, a[x]);
  Solve(x + 1, r, a[x]);
}
int main() {
  freopen("road.in", "r", stdin);
  freopen("road.out", "w", stdout);
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    scanf("%d", a + i);
    mn[i][0] = i;
  }
  for (int k = 1; k <= 18; k++) {
    for (int i = 1; i + (1 << k) - 1 <= n; i++) {
      int x = mn[i][k - 1], y = mn[i + (1 << (k - 1))][k - 1];
      mn[i][k] = a[x] <= a[y] ? x : y;
    }
  }
  Lg[1] = 0;
  for (int i = 2; i <= n; i++) {
    Lg[i] = Lg[i >> 1] + 1;
  }
  Solve(1, n, 0);
  printf("%d\n", ans);
}
