#include <bits/stdc++.h>
#define dbug(...) fprintf(stderr, __VA_ARGS__)
const int N = 50010;
int n, k, Mid, ans;
std::vector<std::pair<int, int> > G[N];
std::vector<int> S[N];

namespace Link {
  int cnt, L[N], R[N], V[N], pt = n + 1;
  void Clear() {
    R[0] = n + 1;
    L[n + 1] = 0;
    cnt = 0;
    pt = n + 1;
  }
  void Pushback(int x) {
    ++cnt;
    V[cnt] = x;
    L[cnt] = L[n + 1];
    R[cnt] = n + 1;
    R[L[n + 1]] = cnt;
    L[n + 1] = cnt;
  }
  void Erase(int p) {
    R[L[p]] = R[p];
    L[R[p]] = L[p];
  }
  void Check(int x) {
    while (L[pt] != 0 && V[L[pt]] >= Mid - x) {
      pt = L[pt];
    }
    if (pt == n + 1) {
      Pushback(x);
    } else {
      ans++;
      pt = R[pt];
      Erase(L[pt]);
    }
  }
  int Max() {
    return L[n + 1] == 0 ? 0 : V[L[n + 1]];
  }
}

int dfs(int x, int pre) {
  S[x].clear();
  for (std::vector<std::pair<int, int> >::iterator e = G[x].begin(); e != G[x].end(); e++) {
    if (e->first == pre) continue;
    int z = dfs(e->first, x) + e->second;
    if (z >= Mid) {
      ans++;
    } else {
      S[x].push_back(z);
    }
  }
  std::sort(S[x].begin(), S[x].end());
  Link::Clear();
  for (size_t i = 0; i < S[x].size(); i++) {
    int z = S[x][i];
    Link::Check(z);
  }
  return Link::Max();
}

int main() {
  freopen("track.in", "r", stdin);
  freopen("track.out", "w", stdout);
  scanf("%d%d", &n, &k);
  for (int i = 1; i < n; i++) {
    int x, y, z;
    scanf("%d%d%d", &x, &y, &z);
    G[x].push_back(std::make_pair(y, z));
    G[y].push_back(std::make_pair(x, z));
  }
  int L = 1, R = 500000000;
  while (L != R) {
    Mid = (L + R + 1) >> 1;
    ans = 0;
    dfs(1, 0);
    if (ans >= k) {
      L = Mid;
    } else {
      R = Mid - 1;
    }
  }
  printf("%d\n", L);
}
