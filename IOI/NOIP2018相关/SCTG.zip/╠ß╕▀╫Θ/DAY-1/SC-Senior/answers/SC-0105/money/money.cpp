#include <bits/stdc++.h>
const int N = 25020, M = 25000;
int n, a[N], f[N], ans;
void WXHAK() {
  scanf("%d", &n);
  ans = n;
  for (int i = 1; i <= M; i++) {
    f[i] = 0;
  }
  for (int i = 1; i <= n; i++) {
    scanf("%d", a + i);
  }
  f[0] = 1;
  for (int i = 0; i <= M; i++) if (f[i]) {
    for (int j = 0; j <= n; j++) {
      if (i + a[j] <= M) {
        f[i + a[j]] = 1;
      }
    }
  }
  std::sort(a + 1, a + 1 + n);
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j < i; j++) {
      if (f[a[i] - a[j]] == 1) {
        ans--;
        break;
      }
    }
  }
  printf("%d\n", ans);
}
int main() {
  freopen("money.in", "r", stdin);
  freopen("money.out", "w", stdout);
  int T; scanf("%d", &T);
  while (T--) {
    WXHAK();
  }
}
