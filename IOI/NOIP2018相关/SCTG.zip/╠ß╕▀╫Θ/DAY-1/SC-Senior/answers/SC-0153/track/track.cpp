#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,m;
int head[20000],next[20000],coux[20000],to[20000],cnt=1;
void insert(int u,int v,int w)
{
	to[cnt]=v;
	coux[cnt]=w;
	next[cnt]=head[u];
	head[u]=cnt++;
}
int dis[20000],vis[20000];
void spfa(int dp)
{
	memset(dis,0x3f3f3f,sizeof(dis));
	dis[dp]=0;
	vis[dp]=1;
	queue<int>q;
	q.push(dp);
	while(!q.empty())
	{
		int u=q.front();
		vis[u]=0;
		q.pop();
		for(int i=head[u];i;i=next[i])
		{
			if(dis[to[i]]>dis[u]+coux[i])
			{
				dis[to[i]]=dis[u]+coux[i];
				if(!vis[to[i]])
				{
					vis[to[i]]=1;
					q.push(to[i]);
				}
			}
		}
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		insert(a,b,c);
		insert(b,a,c);
	}
	int maxn=0;
	for(int i=1;i<=n;i++)
	{
		spfa(i);
		for(int j=1;j<=n;j++)
		{
			maxn=max(maxn,dis[j]);
		}
	}
	printf("%d",maxn);
	fclose(stdin); fclose(stdout);
	return 0;
}
