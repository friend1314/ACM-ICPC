#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n;
int a[200000],vis[200000];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	int sum=0,cnt=0;
	while(cnt!=n)
	{
		int minn;
		cnt=0;
		for(int i=1;i<=n;i++)
		{
			if(a[i]==0)
			cnt++;
		}
		int flag=0,l=1,r=0;
		minn=0x3f3f3f;
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=0&&flag==0)
			{
				l=i;
				flag=1;
			}
			if(flag==1&&a[i]<minn)
			minn=a[i];
			if(a[i+1]==0&&flag==1)
			r=i+1;
			if(l&&r)
			{
		    	sum=sum+minn;
		    	for(int i=l;i<r;i++)
		    	{
			    	a[i]=a[i]-minn;
		    	}
		    	flag=0;
		    	minn=0x3f3f3f;
		    	l=0,r=0;
			}
		}
	}
	printf("%d\n",sum);
	fclose(stdin); fclose(stdout);
	return 0;
}
