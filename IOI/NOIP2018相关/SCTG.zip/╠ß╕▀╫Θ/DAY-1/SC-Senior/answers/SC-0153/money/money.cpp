#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,n;
int q[200];
int gcd(int a,int b)
{
	if(b==0) return a;
	else 
	gcd(b,a%b);
}
int flag=0;
void dfs(int i,int j,int x,int k,int t)
{
	if(x==q[k])
	flag=-1;
	if(flag!=0)
	return;
	if(x>q[k])
	{
		if(t+1>i-j+1)
		{
			return;
		}
		dfs(i,j,x,k,t+1);
	}
	int g=i+t-1;
	for(int o=1;x+q[g]*o<q[k];o++)
	{
		dfs(i,j,x+q[g]*o,k,t);
	}
	return;
}
bool jud(int i,int j)
{
	int hsm,minn=0x3f3f3f;
	for(int k=i+1;k<=j;k++)
	{
		minn=min(minn,q[i]);
		hsm=gcd(q[k],q[k+1]);
	}
	for(int k=1;k<i;k++)
	{
		if(minn>q[k])
		return 0;
		if(q[k]%hsm!=0)
		continue;
		else
		{
			flag=0;
			dfs(i,j,0,k,1);
			if(flag==-1)
			return 1;
			else
			return 0;
		}
	}
	for(int k=j+1;k<=n;k++)
	{
		if(minn>q[k])
		return 0;
		if(q[k]%hsm!=0)
		continue;
		else
		{
			flag=0;
			dfs(i,j,0,k,1);
			if(flag==-1)
			return 1;
			else
			return 0;
		}
	}
	return 1;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		memset(q,0,sizeof(q));
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&q[i]);
		}
		if(n==2)
		{
			if(q[1]%q[2]==0||q[2]%q[1]==0)
			{
				printf("1\n");
				break;
			}
			else
			printf("2\n");
		}
		sort(q+1,q+1+n);
		int len=1;
		for(len=1;1+len-1<=n;len++)
		{
			int j=1+len-1;
			if(jud(1,j)==1)
			{
				printf("%d\n",len);
				break;
			}
		}
		if(len==1+len)
		printf("%d\n",n);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
