#include<bits/stdc++.h>
using namespace std;
int n;
struct hh{
	int id,xx;
}f[100010];
bool cmp(hh x,hh y){
	return x.xx<y.xx;
}
int ans=0,cnt;
int a[100010];
int hs(int l,int r,int x){
	if(l>r)return 0;
	ans=0;
	cnt=0;
	memset(a,0,sizeof(a));
	if(!f[n].xx)return 0;
	a[++cnt]=l-1;
	int xx=f[x].xx;
	for(int i=1;i<=n;i++){
		if(f[i].id<l||f[i].id>r)continue;
		f[i].xx-=xx;
		if(!f[i].xx){
			a[++cnt]=f[i].id;
			x++;
		}
	}
	a[++cnt]=r+1;
	ans+=xx;
	for(int i=2;i<=cnt;i++){
		ans+=hs(a[i-1]+1,a[i]-1,x);
	}	
	return ans;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&f[i].xx);
		f[i].id=i;
	}
	sort(f+1,f+n+1,cmp);
	printf("%d",hs(1,n,1));	
	return 0;
}
