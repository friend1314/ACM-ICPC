#include<bits/stdc++.h>
using namespace std;
int T,n;
int a[110];
int gcd(int x,int y){
	if(y!=0)
		return gcd(y,x%y);
	return x;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int flag=0;
	scanf("%d",&T);
	for(int i=1;i<=T;i++){
		flag=0;
		scanf("%d",&n);
		int m=n;
		memset(a,0,sizeof(a));
		for(int j=1;j<=n;j++){
			scanf("%d",&a[j]);
			if(a[j]==1){
				flag=1;
			}
		}
		if(flag==1){
			printf("1\n");
			continue;
		}
		if(n==2){
			int b;
			if(a[1]>a[2])
				b=a[1]%a[2];
			else b=a[2]%a[1];
			if(b==0){
				printf("1\n");
				continue;
			}
			else {
				printf("2\n");
				continue;
			}
		}
		if(n==3){
			if(a[1]>a[2]){
				if(!(a[1]%a[2]))m--;
				if(a[2]>a[3]){
					if(!(a[1]%a[3]))m--;
					if(!(a[2]%a[3]))m--;
				}
				else{
					if(!(a[3]%a[2]))m--;
					if(a[1]>a[3]){
						if(!(a[1]%a[3]))m--;
					}
					else{
						if(!(a[3]%a[1]))m--;
					}
				}
			}
			else{
				if(!(a[2]%a[1]))m--;
				if(a[1]>a[3]){			
					if(!(a[1]%a[3]))m--;
					if(!(a[2]%a[3]))m--;
				}
				else{
					if(!(a[3]%a[1]))m--;
					if(a[2]>a[3]){
						if(!(a[2]%a[3]))m--;
					}
					else{
						if(!(a[3]%a[2]))m--;
					}
				}
			}
			printf("%d\n",m);
			continue;
		}
		printf("%d\n",n);
	}
	return 0;
}
