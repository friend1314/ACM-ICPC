#include<cctype>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 105
#define M 25005
#define in(x) x=Read()
using namespace std;
int Read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c)&&c!='-')  c=getchar();
	if(c=='-')  f=-1,c=getchar();
	while(isdigit(c))  x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
	return f==1?x:-x;
}
int n,a[N],Times[M];
bool CCComp(int a,int b){return a>b;}
void Dfs(int x,int Sum,int Limit)
{
	if(Sum>Limit)
	  return;
	if(x>n)
	{
		Times[Sum]++;
		return;
	}
	int num=-1;
	while(Sum+(num+1)*a[x]<=Limit)
	{
		num++;
		Dfs(x+1,Sum+num*a[x],Limit);
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int i,T;
	in(T);
	while(T--)
	{
		int Max=0,ans=0;
		in(n);
		memset(Times,0,sizeof(Times));
		for(i=1;i<=n;++i)
		{
			in(a[i]);
			Max=max(Max,a[i]);
		}
		sort(a+1,a+n+1,CCComp);
		Dfs(1,0,Max);
		for(i=1;i<=n;++i)
		  if(Times[a[i]]==1)
		    ans++;
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
