#include<cctype>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 100005
#define in(x) x=Read()
#define Inf (1ll<<31ll)-1
using namespace std;
int Read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c)&&c!='-')  c=getchar();
	if(c=='-')  f=-1,c=getchar();
	while(isdigit(c))  x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
	return f==1?x:-x;
}
int n,a[N],f[N];
void work1()
{
	int i,j,ans=0;
	for(i=1;i<=n;++i)
	{
		int p,Min=Inf;
		for(j=1;j<=n;++j)
		  if(Min>a[j]&&a[j]!=0)
		    Min=a[j],p=j;
		for(j=p-1;j>=1;--j)
		{
			if(a[j]<a[p])
			  break;
			a[j]-=a[p];
		}
		for(j=p+1;j<=n;++j)
		{
			if(a[j]<a[p])
			  break;
			a[j]-=a[p];
		}
		ans+=a[p];
		a[p]=0;
	}
	printf("%d",ans);
}
void work2()
{
	int i;
	f[1]=a[1];
	for(i=2;i<=n;++i)
	{
		if(a[i]>a[i-1])  f[i]=f[i-1];
		else  f[i]=f[i-1]+a[i]-a[i-1];
	}
	printf("%d",f[n]);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i;
	in(n);
	for(i=1;i<=n;++i)
	  in(a[i]);
	if(n<=1000)  work1();
	else  work2();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
