#include<cctype>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 50005
#define M 100005
#define in(x) x=Read()
#define Inff (1ll<<31ll)-1
using namespace std;
int Read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c)&&c!='-')  c=getchar();
	if(c=='-')  f=-1,c=getchar();
	while(isdigit(c))  x=(x<<1)+(x<<3)+(c^'0'),c=getchar();
	return f==1?x:-x;
}
char xxx;
int n,m,t;
int d[N],f1[N],f2[N];
int first[N],v[M],w[M],nxt[M];
char yyy;
void add(int x,int y,int z)
{
	t++;
	nxt[t]=first[x];
	first[x]=t;
	v[t]=y;
	w[t]=z;
}
void DPPP(int x,int fatherrr)
{
	int i,j;
	for(i=first[x];i;i=nxt[i])
	{
		j=v[i];
		if(j!=fatherrr)
		{
			DPPP(j,x);
			if(f1[x]<f1[j]+w[i])
			{
				f2[x]=f1[x];
				f1[x]=f1[j]+w[i];
			}
			else  if(f2[x]<f1[j]+w[i])
			  f2[x]=f1[j]+w[i];
		}
	}
}
bool CcComp(int a,int b){return a>b;}
void work1()
{
	int i,ans=0;
	DPPP(1,0);
	for(i=1;i<=n;++i)
	  ans=max(ans,f1[i]+f2[i]);
	printf("%d",ans);
}
void work2()
{
	int i,SSSum=0,ans=Inff;
	for(i=first[1];i;i=nxt[i])
	  d[++SSSum]=w[i];
	sort(d+1,d+SSSum+1,CcComp);
	if(m<=(SSSum/2))
	{
		m<<=1;
		for(i=1;i<=m/2;++i)
		  ans=min(ans,d[i]+d[m-i+1]);
	}
	else
	{
		int num=SSSum-2*(SSSum-m);
		for(i=1;i<=num;++i)  ans=min(ans,d[i]);
		for(i=num+1;i<=SSSum;++i)  ans=min(ans,d[i]+d[num+SSSum+1-i]);
	}
	printf("%d",ans);
}
bool CCheck(long long MMid)
{
	int i,summ=0,divv=0;
	for(i=1;i<n;++i)
	{
		summ+=d[i];
		if(summ>=MMid)
		{
			divv++;
			summ=0;
		}
	}
	return divv>=m;
}
void work3()
{
	int i,j;
	for(i=1;i<=n;++i)
	  for(j=first[i];j;j=nxt[j])
	    if(v[j]==i+1)
	      d[i]=w[j];
	long long l=0,r=5e10;
	while(l<r)
	{
		long long Mmid=(l+r+1)>>1;
		if(CCheck(Mmid))  l=Mmid;
		else  r=Mmid-1;
	}
	printf("%lld",l);
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int x,y,z,i,Alll1=0,Alll2=0;
	in(n),in(m);
	for(i=1;i<n;++i)
	{
		in(x),in(y),in(z);
		if(x==1)  Alll1++;
		if(y==x+1)  Alll2++;
		add(x,y,z),add(y,x,z);
	}
	if(m==1)  work1();
	else  if(Alll1==n-1)  work2();
	else  if(Alll2==n-1)  work3();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
