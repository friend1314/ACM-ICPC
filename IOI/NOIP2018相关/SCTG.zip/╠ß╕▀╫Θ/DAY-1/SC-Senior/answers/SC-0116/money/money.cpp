#include<bits/stdc++.h>
using namespace std;
const int MAX=105;
const int NUMMAX=50005;
int T,n;
int a[MAX];
bool book[MAX];
bool num[NUMMAX];

void dfs(int k,int x,int maxi)
{
	num[x]=1;
	if(x>a[maxi]) return;
	if(book[k]==1) dfs(k+1,x,maxi);
	if(book[maxi]==1) return;
	if(x==a[maxi])
	{
		book[maxi]=1;
		return;
	}
	if(k==maxi) return;
	int xx=(a[maxi]-x)/a[k];
	for(int i=0;i<=xx;i++)
	{
		if(num[x+i*a[k]]==0||i==0)
			dfs(k+1,x+i*a[k],maxi);
	}
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int t=1;t<=T;t++)
	{
		int ans=0;
		memset(book,0,sizeof(book));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		for(int i=2;i<=n;i++)
			if(a[i]%a[1]==0) book[i]=1;
		for(int i=2;i<=n;i++)
		{
			memset(num,0,sizeof(num));
			if(book[i]==0) dfs(1,0,i);
			if(book[i]==0) ans++;
		}
		printf("%d\n",ans+1);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
