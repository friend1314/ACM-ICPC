#include<bits/stdc++.h>
using namespace std;
const int MAX=50005;
int n,m,ai,bi,li;
vector<int>e[MAX];
vector<int>w[MAX];
queue<int>q;
bool book[MAX];
int dis[MAX];

void spfa(int s)
{
	memset(dis,0x3f,sizeof(dis));
	dis[s]=0;
	book[s]=1;
	q.push(s);
	while(!q.empty())
	{
		int i=q.front();
		q.pop();
		book[i]=0;
		for(int jj=0;jj<e[i].size();jj++)
		{
			int j=e[i][jj],wj=w[i][jj];
			if(dis[j]>dis[i]+wj)
			{
				dis[j]=dis[i]+wj;
				if(book[j]==0)
				{
					book[j]=1;
					q.push(j);
				}
			}
		}
	}
}

int judge(int d)
{
	int re=0,last=0;
	for(int i=1;i<=n;i++)
	{
		if(dis[i]-dis[last]>=d) 
		{
			re++;
			last=i;
		}
	}
	return re;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n<=5&&m==1)
	{
		for(int i=1;i<n;i++)
		{
			scanf("%d%d%d",&ai,&bi,&li);
			e[ai].push_back(bi);
			e[bi].push_back(ai);
			w[ai].push_back(li);
			w[bi].push_back(li);
		}
		int ans=0;
		for(int i=1;i<=n;i++)
		{
			spfa(i);
			for(int i=1;i<=n;i++)
			{
				if(dis[i]>ans) ans=dis[i];
			}
		}
		printf("%d",ans);
		fclose(stdin);fclose(stdout);
		return 0;
	}
	int is_a1=0,is_ab=0;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&ai,&bi,&li);
		if(ai!=1) is_a1=1;
		if(bi!=ai+1) is_ab=1;
		e[ai].push_back(bi);
		e[bi].push_back(ai);
		w[ai].push_back(li);
		w[bi].push_back(li);
	}
	if(is_a1==0)
	{
		int cot=0;
		for(int i=0;i<e[1].size();i++)
		{
			dis[++cot]=w[1][i];
		}
		sort(dis+1,dis+n);
		int ans=dis[n-1]+dis[n-2];
		printf("%d",ans);
		fclose(stdin);fclose(stdout);
		return 0;
	}
	if(is_ab==0)
	{
		int cot=1;
		for(int i=1;i<n;i++)
		{
			if(i==1) dis[++cot]=w[i][0];
			else dis[++cot]=w[i][1];
			dis[cot]+=dis[cot-1];
		}
		int l=0,r=dis[n],mid,ans=0;
		while(l<=r)
		{
			mid=(l+r)>>1;
			if(judge(mid)<m) r=mid-1;
			else
			{
				l=mid+1;
				ans=mid;
			}
		}
		printf("%d",ans);
		fclose(stdin);fclose(stdout);
		return 0;
	}
	printf("1");
	fclose(stdin);fclose(stdout);
	return 0;
}
