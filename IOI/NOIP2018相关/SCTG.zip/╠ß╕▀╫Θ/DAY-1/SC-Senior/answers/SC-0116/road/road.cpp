#include<bits/stdc++.h>
using namespace std;
int n;
long long now,last,ans;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&now);
		if(now>=last) ans+=(now-last);
		last=now;
	}
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
