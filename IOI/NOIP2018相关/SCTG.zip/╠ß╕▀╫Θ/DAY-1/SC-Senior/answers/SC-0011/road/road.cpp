#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return f==1?x:-x;
}
#define N 100005
int n,a[N],mn[N][20],lg[N];
void prework(){
	lg[1]=0;
	for(int i=2;i<=n;i++)lg[i]=lg[i>>1]+1;
	for(int j=1;(1<<j)<=n;j++)
		for(int i=1;i+(1<<j)-1<=n;i++)
			mn[i][j]=(a[mn[i][j-1]]<a[mn[i+(1<<(j-1))][j-1]]?mn[i][j-1]:mn[i+(1<<(j-1))][j-1]);
	return;
}
long long ans=0;
inline int ask(int l,int r){
	int c=lg[r-l+1];
	return a[mn[l][c]]<a[mn[r-(1<<c)+1][c]]?mn[l][c]:mn[r-(1<<c)+1][c];
}
void solve(int l,int r,int p){
	int c=ask(l,r);
	ans+=a[c]-p;
	if(l!=c)solve(l,c-1,a[c]);
	if(c!=r)solve(c+1,r,a[c]);
	return;
}
void work_1(){
	for(int i=1;i<=n;i++){
		a[i]=read();
		mn[i][0]=i;
	}
	prework();
	solve(1,n,0);
	printf("%lld",ans);
	return;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	work_1(); 
	
	return 0;
}
