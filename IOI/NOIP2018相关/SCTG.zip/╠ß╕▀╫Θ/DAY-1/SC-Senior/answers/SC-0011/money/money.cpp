#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	return f==1?x:-x;
}
#define N 105
#define M 25005
int t,n,a[N],b[M];
void work_1(){
	int ans=0;
	vector<int>s;
	for(int i=1;i<=n;i++){
		a[i]=read();
		b[a[i]]=1;
	}
	sort(a+1,a+n+1);
	for(int i=1,len;i<=a[n];i++){
		if(b[i]!=1)continue;
		len=s.size();
		ans++;
		for(int j=1,r;j*i<=a[n];j++){
			r=i*j;
			if(b[r]!=2)s.push_back(r);
			b[r]=2;
			for(int k=0;k<len;k++){
				if(s[k]+r>a[n])continue;//
				if(b[s[k]+r]!=2)s.push_back(s[k]+r);
				b[s[k]+r]=2;
			}
		}
	}
	printf("%d\n",ans);
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	while(t--){
		n=read();
		memset(b,0,sizeof(b));
		work_1();
		
	}
	return 0;
}
