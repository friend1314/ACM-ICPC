#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=1e5+10;
int n,d[N];
inline int read() {
	int x=0,p=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') p=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();}
	return x*p;
}
ll solve(int l,int r) {
	if(l==r) return (ll)d[l];
	int pos=0;ll ret=0;
	for(int i=l;i<=r;++i)
	if(d[i]<d[pos]) pos=i;
	int cnt=d[pos];ret=(ll)cnt;
	for(int i=l;i<=r;++i) {
		d[i]-=cnt;
	}
	for(int i=l;i<=r;++i) {
		while(d[i]==0&&i<=r) ++i;
		if(i>r) break ;
		int t=i;
		while(d[t+1]!=0&&t+1<=r) ++t;
		ret+=solve(i,t);i=t;
	}
	return ret;
}
int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();d[0]=1e5;
	for(int i=1;i<=n;++i) d[i]=read();
	printf("%lld\n",solve(1,n));
	fclose(stdin);
	fclose(stdout);
	return 0;
}
