#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=110,M=25e3+10;
int n,m,d[N],f[M],vis[N];
inline int read() {
	int x=0,p=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') p=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();}
	return x*p;
}
int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t=read();
	while(t--) {
		n=read();m=0;
		for(int i=1;i<=n;++i) d[i]=read();
		memset(vis,0,sizeof vis);
		sort(d+1,d+n+1);
		n=unique(d+1,d+n+1)-d-1;
		for(int i=1;i<=n;++i)
		if(!vis[i])
		for(int j=i+1;j<=n;++j)
		if(d[j]%d[i]==0) vis[j]=1;
		for(int i=1;i<=n;++i)
		if(!vis[i]) d[++m]=d[i];
		memset(vis,0,sizeof vis);
		n=m;m=0;
		for(int i=2;i<=n;++i) {
			memset(f,0,sizeof f);f[0]=1;
			for(int j=1;j<i;++j)
			if(!vis[j]) {
				for(int k=d[j];k<=d[i];++k)
				if(f[k-d[j]]) f[k]=1;
				if(f[d[i]]) break ;
			}
			if(f[d[i]]) vis[i]=1;
		}
		for(int i=1;i<=n;++i)
		if(!vis[i]) ++m;
		printf("%d\n",m);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
