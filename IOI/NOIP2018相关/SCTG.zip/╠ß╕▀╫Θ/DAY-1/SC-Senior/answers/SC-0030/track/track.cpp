#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=5e4+10;
bool flag0,flag1;
int n,m,sum,cnt,head[N],f[N][2];
int p,dis[N],SUM[N];
int dp[N],son[2][N],dson[2][N];
inline int read() {
	int x=0,y=1;char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') y=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();}
	return x*y;
}
struct ROAD {
	int des,mte,last;
} road[N<<1];
void add(int u,int v,int c) {
	road[++sum].des=v;
	road[sum].mte=c;
	road[sum].last=head[u];
	head[u]=sum;
}
struct COMP {
	int fir,sec;
	void clear() {fir=sec=0;}
	void update(int x) {
		if(x>sec) sec=x;
		if(sec>fir) swap(sec,fir);
	}
	int get0() {return fir+sec;}
	int get1() {return fir;}
} ;
void dfs(int u,int fa) {
	COMP cmp;cmp.clear();int ls=0;
	for(int i=head[u];i;i=road[i].last)
	if(road[i].des!=fa) {
		int v=road[i].des;
		dfs(v,u);
		ls=max(ls,f[v][0]);
		cmp.update(f[v][1]+road[i].mte);
	}
	f[u][0]=max(ls,cmp.get0());
	f[u][1]=cmp.get1();
}
struct TREE {
	int tree[N],tim[N];
	int lowbit(int a) {return a&(-a);}
	void update(int a,int b) {
		for(int i=a;i<=n;i+=lowbit(i))
		if(tim[i]==p) tree[i]=max(tree[i],b);
		else {tim[i]=p;tree[i]=b;}
	}
	int query(int a) {
		int ret=0;
		for(int i=a;i;i-=lowbit(i))
		if(tim[i]==p) ret=max(ret,tree[i]);
		return ret;
	}
} zy;
bool check(int len) {
	++p;int t=0;
	for(int i=1;i<n;++i) {
		while(SUM[i]-SUM[t+1]>=len) ++t;
		int ret=zy.query(t);
		if(t>0) ++ret;
		if(ret>=m) return true ;
		zy.update(i,ret);
	}
	return false ;
}
int FSD(int u,int top,int len) {
	if(top>=len) return dp[u]+1;
	if(!son[0][u]) return 0;
	else if(!son[1][u]) return FSD(son[0][u],dson[0][u]+top,len);
	else return max(FSD(son[0][u],dson[0][u]+top,len)+dp[son[1][u]],
					FSD(son[1][u],dson[1][u]+top,len)+dp[son[0][u]]);
}
void DFS(int u,int fa,int len,int top) {
	if(!head[u]) {
		if(top>=len) dp[u]=1;
		return ;
	}
	int all=0;
	for(int i=head[u];i;i=road[i].last)
	if(road[i].des!=fa) {
		int v=road[i].des;
		DFS(v,u,len,road[i].mte);
		son[all][u]=v;dson[all++][u]=road[i].mte;
	}
	if(all==1) {
		dp[u]=FSD(son[0][u],dson[0][u],len);
	}
	else dp[u]=max(FSD(son[0][u],dson[0][u],len)+dp[son[1][u]],
					FSD(son[1][u],dson[1][u],len)+dp[son[0][u]]);
}
bool xnzy(int len) {
	memset(dp,0,sizeof dp);
	DFS(1,0,len,0);
	return dp[1]>=m;
}
int main() {
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();m=read();flag0=flag1=true ;
	for(int i=1;i<n;++i) {
		int u=read(),v=read(),c=read();
		add(u,v,c);add(v,u,c);
		if(max(u-v,v-u)!=1) flag0=false ;
		if(c!=1) flag1=false ;
		cnt+=c;dis[min(u,v)]=c;
	}
	if(m==1) {dfs(1,0);printf("%d\n",max(f[1][0],f[1][1]));}
	else if(flag0) {
		for(int i=1;i<n;++i) SUM[i]=SUM[i-1]+dis[i];
		int l=1,r=cnt,ans=1;
		while(l<=r) {
			int mid=l+r>>1;
			if(check(mid)) ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",ans);
	}
	else if(flag1) printf("%d\n",n/m);
	else {
		int l=1,r=cnt,ans=1;
		while(l<=r) {
			int mid=l+r>>1;
			if(xnzy(mid)) ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
}
