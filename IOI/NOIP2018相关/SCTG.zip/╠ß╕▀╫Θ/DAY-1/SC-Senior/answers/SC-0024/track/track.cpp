//���long long �����С ѭ���ڱ��� ��������
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<deque>
#include<set>
#include<map>
using namespace std;
inline void in(int &res)
{
	res=0;int f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) ch=='-' ? f=-1:f=f;
	for(;isdigit(ch);ch=getchar()) res=res*10+ch-'0';
	res*=f;
}
void print(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
int n,m,h[500001],cnt=1;
struct Edge
{
	int to,nxt,len;
} e[1000005];
int fa[1000005],val[1000005];
inline void biu(int x,int y,int z)
{
	e[++cnt].to=y;
	e[cnt].len=z;
	e[cnt].nxt=h[x];
	h[x]=cnt;
}
struct raw
{
	int pos,val;
	bool operator < (const raw x) const
	{
		return val>x.val;
	}
};
priority_queue<raw> q;
int st,dis[500001];
void bfs(int x)
{
	queue<int>qq;
	qq.push(x);
	while(!qq.empty())
	{
		int k=qq.front();qq.pop();
		for(int i=h[k];i;i=e[i].nxt)
		{
			if(dis[e[i].to]||e[i].to==x) continue;
			dis[e[i].to]=dis[k]+e[i].len;
			qq.push(e[i].to);
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(dis[st]<dis[i])
		st=i;
	}
}
int bfs2(int x)
{
	memset(dis,0,sizeof(dis));
	queue<int>qq;
	qq.push(x);
	int ans=0;
	while(!qq.empty())
	{
		int k=qq.front();qq.pop();
		for(int i=h[k];i;i=e[i].nxt)
		{
			if(dis[e[i].to]||e[i].to==x)continue;
			dis[e[i].to]=dis[k]+e[i].len;
			qq.push(e[i].to);
		}
	}
	for(int i=1;i<=n;i++)
	{
		ans=max(ans,dis[i]);
	}
	return ans;
}
signed main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);

	in(n);in(m);
	for(int i=1,x,y,z;i<n;i++)
	{
		in(x),in(y),in(z);
		biu(x,y,z);
		biu(y,x,z);
	}
	if(m==1)
	{
		bfs(1);
		cout<<bfs2(st);
	}
	else if(m==n-1)
	{
		int ans=0x3f3f3f3f;
		for(int i=2;i<=cnt;i++)
		ans=min(ans,e[i].len);
		cout<<ans;
	}
	else
	{
		cout<<15;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
raw tmp;
//		for(int i=2;i<=cnt;i+=2)
//		{
//			fa[i]=fa[i+1]=i;val[i]=val[i+1]=e[i].len;
//			h[i]=i;
//			t[i]=i+1;
//			tmp.pos=i;
//			tmp.val=e[i].len;
//			q.push(tmp);
//			tmp.pos++;
//			q.push(tmp);
//		}
//		int minn,ll,r1,r2;
//		while(!q.empty())
//		{
//			tmp=q.top();q.pop();
//			minn=0x3f3f3f3f;
//			r1=e[tmp.pos].to;
//			r2=e[tmp.pos^1].to;
//			for(int i=h[r1];i;i=e[i].nxt)
//			{
//				if(e[i].len<maxn)
//				{
//					
//				}
//			}
//		}
