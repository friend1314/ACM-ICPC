//���long long �����С ѭ���ڱ��� ��������
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<deque>
#include<set>
#include<map>
#define min(x,y) ((x)<(y)?(x):(y))
#define max(x,y) ((x)>(y)?(x):(y))
using namespace std;
struct Que
{
	int h,t,v[1000000],cnt;
	inline void push(int x){v[t++]=x;}
	inline int front(){return v[h];}
	inline void pop(){h++;}
	inline bool empty(){return h>=t;}
}q;
inline void read(int &res)
{
	res=0;int f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) ch=='-' ? f=-1:f=f;
	for(;isdigit(ch);ch=getchar()) res=res*10+ch-'0';
	res*=f;
}
void print(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
struct raw
{
	int dep,pos;
};
bool operator < (raw x,raw y)
{
	return x.dep<y.dep;
}
bool operator > (raw x,raw y)
{
	return x.dep>y.dep;
}
int n,ans;
int d[250000];
int tot=1,rt=1,up,low,top;
signed main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++)
	{
		read(d[i]);
		if(d[i]>d[i-1])low=1;
		if(d[i]<d[i-1])up=1;
	}
	if(low==0||up==0)
	{
		int ans=0;
		ans=max(d[1],d[n]);
		cout<<ans<<endl;
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	int l=1,r;
	raw x;
	q.h=q.t=0;
	q.push(1);q.push(n);
	while(!q.empty())
	{
		l=q.front();q.pop();
		r=q.front();q.pop();
		if(l>r)continue;
		int minn=0x3f3f3f3f,pos,flag=0;
		up=low=1;
		if(d[l-1]==0&&d[r+1]==0)up=low=0;
		for(int i=l;i<=r;i++)
		{	
			if(d[i]>d[i-1])low=1;
			if(d[i]<d[i-1])up=1;
			if(minn>d[i])
			{
				minn=d[i];
				pos=i;
			}
			if(minn==0)
			{
				q.push(l);q.push(i-1);
				q.push(i+1);q.push(r);
				flag=1;
				break;
			}
		}
		if(flag)continue;
		if(low==0||up==0)
		{
			ans+=max(d[l],d[r]);
		}
		else
		{
			for(int i=l;i<=r;i++)d[i]-=minn;
			q.push(l);q.push(pos-1);
			q.push(pos+1);q.push(r);
			ans+=minn;
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

//		x=Query(l,r,rt);
//		if(x.dep==0)
//		{
//			if(l<x.pos)
//			q.push(l,x.pos-1);
//			if(x.pos<r)
//			q.push(x.pos+1,r);
//		}
//		ans+=x.dep;
//		Change(l,r,-x.dep,rt);
