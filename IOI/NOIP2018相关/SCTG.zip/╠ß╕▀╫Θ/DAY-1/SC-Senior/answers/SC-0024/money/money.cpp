//���long long �����С ѭ���ڱ��� ��������
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<queue>
#include<deque>
#include<set>
#include<map>
using namespace std;
inline void in(int &res)
{
	res=0;int f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar()) ch=='-' ? f=-1:f=f;
	for(;isdigit(ch);ch=getchar()) res=res*10+ch-'0';
	res*=f;
}
void print(int x)
{
	if(x<0) putchar('-'),x=-x;
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
int T;
int n,top;
int a[1001];
int vis[25001];
int gcd(int x,int y)
{
	return y==0 ? x: gcd(y,x%y);
}
inline int check(int x,int y,int z)
{
	for(int i=1;i*y<=z;i++)
	{
		if((z-i*y)%x==0) return 1;
	}
	return 0;
}
inline void Get(int x,int y)
{
	int tmp;
	int res=0;
	for(int i=1;i*x<=top;i++)
	{
		tmp=i*x;
		for(int j=1;j*y+tmp<=top;j++)
		{
			res+=(!vis[j*y+x*i]);
			vis[j*y+x*i]=1;
		}
	}
	if(res==0) vis[y]=1;
}
signed main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);

	in(T);
	while(T--)
	{
		in(n);
		for(int i=1;i<=n;i++)
		{
			in(a[i]);
		}
		sort(a+1,a+n+1);
		top=a[1]*a[2]-a[1]-a[2];
		int flag;
		if(gcd(a[1],a[2])==1)flag=1;
		else flag=0;
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=n;i++)
		{
			if(a[i]>top&&flag&&n!=1) vis[a[i]]=1;
			if(!vis[a[i]])
			for(int j=2;j*a[i]<=25000;j++)
			{
				vis[a[i]*j]=1;
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(vis[a[i]])
			{
				continue;
			}
			if(a[i]==a[i-1])continue;
			for(int j=i+1;j<=n;j++)
			{
				if(vis[a[j]])
				{
					continue;
				}
				for(int k=j+1;k<=n;k++)
				{
					if(vis[a[k]])
					{
						continue;
					}
					if(check(a[i],a[j],a[k]))vis[a[k]]=1;
				}
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++)
		{
			if(!vis[a[i]])ans++;
		}
		cout<<ans<<endl;
	}

	fclose(stdin);
	fclose(stdout);
	return 0;
}

