#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <bits/stdc++.h>
using namespace std;
int a[50001];
int k=0,b,n,m;
void dfs(int x,int y)
{   
    m=a[x];   
	for(int i=x;i<=y;i++)
	   if(a[i]<=m)
	   {m=a[i];b=i;}
	for(int i=x;i<=y;i++)
	a[i]=a[i]-m;
	k=k+m;
	if(x>=1&&b-1>=1&&x<=b-1)dfs(x,b-1);
	if(y>=1&&b+1>=1&&y>=b+1)dfs(b+1,y);
	
}
int main()
{   
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	dfs(1,n);
	cout<<k;
	return 0;
}

