#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <bits/stdc++.h>
using namespace std;
int a[10001],n,T;
int main()
{   
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    cin>>T;
	for(int i=1;i<=T;i++)
	{   cin>>n;
		for(int j=1;j<=n;j++)
		cin>>a[i];
		for(int i=1;i<=n;i++)
		if(b[i]==1&&m!=1)cout<<'1'<<endl;
		if(m==1)cout<<n<<endl;
	}
    return 0;
}

