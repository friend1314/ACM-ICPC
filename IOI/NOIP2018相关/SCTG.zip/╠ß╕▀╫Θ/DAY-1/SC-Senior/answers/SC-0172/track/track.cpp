#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define FILE_IO
using namespace std;
int N,M,U[100005],V[100005],W[100005],First[50005],Next[100005];
int S1=1,S2=1,S3=1;
int Que[50005],Head=1,Tail=0,Father[50005];
int Numbers[50005],F[50005][3];

int Input(void);
void Solve1(void);
void Solve2(void);
void Solve3(void);
int Check(int len);
void DP(int now);

int main(void)
{
	#ifdef FILE_IO
		freopen("track.in","r",stdin);
		freopen("track.out","w",stdout);
	#endif
	memset(First,-1,sizeof(First));
	memset(Next,-1,sizeof(Next));
	N=Input();M=Input();
	if(M!=1)
		S1=0;
	for(int i=1;i<=2*N-2;i+=2)
	{
		U[i]=V[i+1]=Input();V[i]=U[i+1]=Input();W[i]=W[i+1]=Input();
		Next[i]=First[U[i]];First[U[i]]=i;
		Next[i+1]=First[U[i+1]];First[U[i+1]]=i+1;
		if(U[i]!=1) S2=0;
		if(V[i]!=U[i]+1) S3=0;
	}
	if(S1)
		Solve1();
	else if(S2)
		Solve2();
	else if(S3)
		Solve3();
	#ifdef FILE_IO
		fclose(stdin);
		fclose(stdout);
	#endif
	return 0;
}

void Solve1(void)
{
	memset(F,0,sizeof(F));
	memset(Father,-1,sizeof(Father));
	Tail++;
	Que[Tail]=1;
	while(Head<=Tail)
	{
		int k=First[Que[Head]];
		while(k!=-1)
		{
			if(Father[U[k]]!=V[k])
			{
				Father[V[k]]=U[k];
				Tail++;
				Que[Tail]=V[k];
			}
			k=Next[k];
		}
		Head++;
	}
	DP(1);
	int Ans=0;
	for(int i=1;i<=N;i++)
		Ans=max(Ans,F[i][1]);
	cout<<Ans<<endl;
}

void Solve2(void)
{
	for(int i=1;i<=2*N-2;i+=2)
		Numbers[(i+1)/2]=W[i];
	sort(Numbers+1,Numbers+N);
	if(M*2>=N)
	{
		int mini=0x3f3f3f3f;
		for(int i=1;i<=N-M-1;i++)
			mini=min(mini,Numbers[i]+Numbers[2*N-2*M-2-i+1]);
		for(int i=2*N-2*M-1;i<=N-1;i++)
			mini=min(mini,Numbers[i]);
		cout<<mini<<endl;
	}
	else
	{
		int mini=0x3f3f3f3f;
		for(int i=N-1;i>=N-M;i--)
			mini=min(mini,Numbers[i]+Numbers[N-2*M+(N-i)-1]);
		cout<<mini<<endl;
	}
}

void Solve3(void)
{
	int sum=0;
	for(int i=1;i<=2*N-2;i+=2)
		Numbers[U[i]]=W[i],sum+=W[i];
	int l=1,r=sum,mid=(1+sum)/2,best=0;
	while(l<=r)
	{
		if(Check(mid))
		{
			best=max(best,mid);
			l=mid+1;
		}
		else
			r=mid-1;
		mid=(l+r)/2;
	}
	cout<<best<<endl;
}

int Check(int len)
{
	int num=0,cur=0;
	for(int i=1;i<=N-1;i++)
	{
		cur+=Numbers[i];
		if(cur>=len)
		{
			num++;
			cur=0;
		}
	}
	if(num<M)
		return 0;
	return 1;
}

void DP(int now)
{
	int k=First[now];
	while(k!=-1)
	{
		if(Father[U[k]]!=V[k])
			DP(V[k]);
		k=Next[k];
	}
	int maxi1=0,maxi2=0;
	k=First[now];
	while(k!=-1)
	{
		if(Father[U[k]]!=V[k])
			if(F[V[k]][2]+W[k]>maxi2)
			{
				if(F[V[k]][2]+W[k]>maxi1)
				{
					maxi2=maxi1;
					maxi1=F[V[k]][2]+W[k];
				}
				else
					maxi2=F[V[k]][2]+W[k];
			}
		k=Next[k];
	}
	F[now][1]=maxi1+maxi2;
	F[now][2]=maxi1;
}

int Input(void)
{
	int rets=0,flags=1;
	char cs=getchar();
	while(cs==' '||cs=='\n')
		cs=getchar();
	while(cs=='-'||(cs<='9'&&cs>='0'))
	{
		if(cs=='-')
			flags=-1;
		else
			rets=rets*10+(int)(cs-'0');
		cs=getchar();
	}
	return rets*flags;
}
