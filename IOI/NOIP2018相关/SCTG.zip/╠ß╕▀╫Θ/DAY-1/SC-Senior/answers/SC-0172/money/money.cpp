#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define FILE_IO
using namespace std;
int T,N,Numbers[105]={-1,0};
int Dp[25005]={0},Ans=0;

int Input(void);

int main(void)
{
	#ifdef FILE_IO
		freopen("money.in","r",stdin);
		freopen("money.out","w",stdout);
	#endif
	T=Input();
	while(T--)
	{
		Ans=0;memset(Dp,0,sizeof(Dp));
		N=Input();
		for(int i=1;i<=N;i++)
		{
			Numbers[i]=Input();
			Dp[Numbers[i]]=1;
		}
		sort(Numbers+1,Numbers+N+1);
		for(int i=1;i<=Numbers[N];i++)
			for(int j=1;j<=N;j++)
			{
				if(Numbers[j]>=i)
					break;
				if(Dp[i-Numbers[j]])
				{
					Dp[i]++;
					break;
				}
			}
		for(int i=1;i<=N;i++)
			if(Numbers[i]!=Numbers[i-1]&&Dp[Numbers[i]]==1)
				Ans++;
		cout<<Ans<<endl;
	}
	#ifdef FILE_IO
		fclose(stdin);
		fclose(stdout);
	#endif
	return 0;
}

int Input(void)
{
	int rets=0,flags=1;
	char cs=getchar();
	while(cs==' '||cs=='\n')
		cs=getchar();
	while(cs=='-'||(cs<='9'&&cs>='0'))
	{
		if(cs=='-')
			flags=-1;
		else
			rets=rets*10+(int)(cs-'0');
		cs=getchar();
	}
	return rets*flags;
}
