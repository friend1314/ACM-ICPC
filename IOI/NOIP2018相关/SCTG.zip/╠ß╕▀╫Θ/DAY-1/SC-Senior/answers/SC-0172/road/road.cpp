#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define FILE_IO
#define lll long long
using namespace std;
lll N,Numbers[100005],Ans=0;
lll Fa[100005][20]={0},Lo[100005]={0};

lll Input(void);
void Solve(lll l,lll r,lll here);

int main(void)
{
	#ifdef FILE_IO
		freopen("road.in","r",stdin);
		freopen("road.out","w",stdout);
	#endif
	Numbers[0]=0x3f3f3f3f;
	for(lll i=0;i<100005;i++)
	{
		lll ii=i;
		while(ii>=2)
		{
			Lo[i]++;
			ii/=2;
		}
	}
	N=Input();
	for(lll i=1;i<=N;i++)
	{
		Numbers[i]=Input();
		Fa[i][0]=i;
	}
	for(lll i=1;i<=20;i++)
		for(lll j=1;j<=N;j++)
			if(j+(1<<i)-1<=N)
			{
				if(Numbers[Fa[j][i-1]]<Numbers[Fa[j+(1<<(i-1))][i-1]])
					Fa[j][i]=Fa[j][i-1];
				else
					Fa[j][i]=Fa[j+(1<<(i-1))][i-1];
			}
	Solve(1,N,0);
	cout<<Ans<<endl;
	#ifdef FILE_IO
		fclose(stdin);
		fclose(stdout);
	#endif
	return 0;
}

void Solve(lll l,lll r,lll here)
{
	if(l>r)
		return;
	lll mini=0,len=Lo[r-l];
	if(Numbers[Fa[l][len]]<Numbers[Fa[r-(1<<len)+1][len]])
		mini=Fa[l][len];
	else
		mini=Fa[r-(1<<len)+1][len];
	Ans+=Numbers[mini]-here;
	Solve(l,mini-1,Numbers[mini]);
	Solve(mini+1,r,Numbers[mini]);
	return;
}

lll Input(void)
{
	lll rets=0,flags=1;
	char cs=getchar();
	while(cs==' '||cs=='\n')
		cs=getchar();
	while(cs=='-'||(cs<='9'&&cs>='0'))
	{
		if(cs=='-')
			flags=-1;
		else
			rets=rets*10+(lll)(cs-'0');
		cs=getchar();
	}
	return rets*flags;
}
