#include<bits/stdc++.h>
using namespace std;
#define P pair<int,int>
const int N=1e5+5;
int n,m,cnt,head[2*N],num[N];
int maxn1=0,maxn2=0,minn1=N;
priority_queue<P,vector<P>,greater<P> > q;
bool flag=true;
bool vis[2*N];
long long ans=0;
struct sd{
	int to,next,val;
}node[2*N];
void add_edge(int u,int v,int w){
	node[++cnt].to=v;
	node[cnt].next=head[u];
	node[cnt].val=w;
	head[u]=cnt;
}
void dfs1(int u,int fa,long long sum){
	for(int i=head[u];i;i=node[i].next){
		if(node[i].to!=fa)
		dfs1(node[i].to,u,sum+node[i].val);
	}
	if(ans<sum) ans=sum;
}
void dfs2(int v){
	while(v--){
		int s=q.top().first;
		int x=q.top().second;
		for(int i=head[x];i;i=node[i].next){
			if(node[i].val==s){
				vis[i]=true;
				break;
			}
		}
		q.pop();
		int minn=N,pos;
		while(minn==N){
		for(int i=head[x];i;i=node[i].next){
			if(minn>node[i].val&&!vis[i]){
			    minn=node[i].val;
				pos=i;
			}
		}
		if(minn==N) x=node[head[x]].to;
		else {
			s+=minn;
			vis[pos]=true;
			q.push(make_pair(s,x));
		}
	   }	
	}
	ans=q.top().first;
	return;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int u,v,w,i=1;i<n;++i){
		scanf("%d%d%d",&u,&v,&w);
		q.push(make_pair(w,u));
		if(maxn1<w){
			maxn2=maxn1;
			maxn1=w;
		}
		else if(maxn2<w) maxn2=w;
		if(w<minn1) minn1=w;
		if(u!=1) flag=false;
		add_edge(u,v,w);
		add_edge(v,u,w);
		num[u]++;num[v]++;
	}
	if(m==1){
	ans=0;
	if(flag) ans=maxn1+maxn2;
	else
	 for(int i=1;i<=n;++i){
		if(num[i]==1)
		dfs1(i,0,0);
	 } 	
    }
    else{
    	if(m==n-1) ans=minn1;
    	else{
    		dfs2(n-1-m);
    	}
    }
    printf("%lld",ans);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
