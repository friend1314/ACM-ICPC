#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,d[N];
int Log[N];
long long ans=0;
int dp[N][55],pos[N][55];
void solveit(int l,int r,long long laz){
	if(l>r) return;
	int k=Log[r-l+1],s,v;
	if(dp[l][k]<=dp[r-(1<<k)+1][k]){
		s=dp[l][k];
		v=pos[l][k];
	}
	else {
		s=dp[r-(1<<k)+1][k];
		v=pos[r-(1<<k)+1][k];
	}
	s-=laz;
	ans+=s;
	solveit(l,v-1,laz+s);
	solveit(v+1,r,laz+s);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	memset(dp,0x3f,sizeof(dp));
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&d[i]);
		dp[i][0]=d[i];
		pos[i][0]=i;
	}
	Log[0]=-1;
	for(int i=1;i<=n;++i) Log[i]=Log[i>>1]+1;
	int i=1;
	for(int j=1;(1<<j)<=n;++j)
	for(int i=1;i<=n;++i){
	if(i+(1<<j)-1>n) break;
	dp[i][j]=min(dp[i][j-1],dp[i+(1<<j-1)][j-1]);
	if(dp[i][j]==dp[i][j-1]) pos[i][j]=pos[i][j-1];
	else pos[i][j]=pos[i+(1<<j-1)][j-1]; 
    }
    solveit(1,n,0);
    printf("%lld",ans);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
