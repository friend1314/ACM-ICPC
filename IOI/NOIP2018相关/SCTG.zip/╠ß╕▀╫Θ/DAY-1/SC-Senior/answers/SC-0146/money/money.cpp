#include<bits/stdc++.h>
using namespace std;
int n,a[155];
bool vis[155];
int dp[25505];
int ans;
void DPit(int n){
	int v=0;
	for(int i=1;i<=a[n];++i) dp[i]=0;
	dp[0]=1;
	for(int i=1;i<=n;++i){
		if(!vis[i]) continue;
		if(dp[a[i]]){
			ans--;
			continue;
		}
		for(int j=0;j<=v&&j<=a[n];++j){
			if(dp[j]){
				dp[j+a[i]]++;
				if(v<j+a[i]) v=j+a[i];
			}
		}
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		ans=n;
		for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
	    vis[i]=true;
		}
		sort(a+1,a+1+n);
		for(int i=1;i<n;++i){
		if(!vis[i]) continue;
		for(int j=i+1;j<=n;++j){
		if(!vis[j]) continue;
			if(a[j]%a[i]==0){
				ans--;
				vis[j]=false;
			}
		}
	   }
        DPit(n);
	    printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
