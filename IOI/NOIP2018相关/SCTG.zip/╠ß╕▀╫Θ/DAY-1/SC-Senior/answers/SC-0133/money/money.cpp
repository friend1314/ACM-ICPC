#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int T;
int n;
int a[110];
bool cmp(int x,int y){return x<y;}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(a,0x7f,sizeof(a));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+n+1,cmp);
		int atm=n;
		for(int i=1;i<=n;i++){
			for(int j=1;j<i;j++){
				if(a[i]%a[j]==0){
					--n,a[i]=0x7f7f7f7f;
					break;
				}
			}
		}	
		sort(a+1,a+n+1,cmp);
		if(n==1){
			printf("1\n");
			continue;
		}
		if(n==2){
			if(a[2]%a[1]==0)printf("1\n");
			else printf("2\n");
			continue;
		}
		else if(n==3){
			bool flag=false;
			for(int i=0;i*a[1]<=a[3];++i){
				if((a[3]-i*a[1])%a[2]==0){
					flag=true;
					break;
				}
			}
			if(flag==true)printf("2\n");
			else printf("3\n");
			continue;
		}
		else if(n==4){
			bool flag=false;
			for(int i=0;i*a[1]<=a[3];++i){
				if((a[3]-i*a[1])%a[2]==0){
					flag=true;
					break;
				}
			}
			if(flag==true){
				flag=false;
				for(int i=0;i*a[1]<=a[4];++i){
					if((a[4]-i*a[1])%a[2]==0){
						flag=true;
						break;
					}
				}
				if(flag==true)printf("2\n");
				else printf("3\n");
			}
			else{
				for(int i=0;i*a[1]<=a[4];++i){
					for(int j=0;j*a[2]<=a[4]-i*a[1];++j){
						if((a[3]-i*a[1]-j*a[2])%a[3]==0){
							flag=true;
							break;
						}		
					}
					if(flag==true)break;
				}
				if(flag==true)printf("3\n");
				else printf("4\n");
			}
		}
		else printf("5\n");
	}
	return 0;
}
