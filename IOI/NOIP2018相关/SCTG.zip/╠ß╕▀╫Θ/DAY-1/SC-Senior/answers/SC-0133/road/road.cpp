#include<cstdio>
#include<algorithm>
#include<cstring>
#include<stack>
#include<queue>
#include<set>
#include<vector>
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define re register
#define il inline
#define ll long long
using namespace std;
int n;
int a[100010];
int ans;
struct node{
	int l,r,minx,id;
}tree[800010];
void build(int now,int l,int r){
	tree[now].l=l;
	tree[now].r=r;
	if(l==r){tree[now].minx=a[l];tree[now].id=l;return ;}
	int mid=(l+r)>>1;
	build(now<<1,l,mid);
	build(now<<1|1,mid+1,r);
	tree[now].minx=min(tree[now<<1].minx,tree[now<<1|1].minx);
	tree[now].id=(tree[now<<1].minx<=tree[now<<1|1].minx?tree[now<<1].id:tree[now<<1|1].id);
}
int find(int now,int l,int r){
	if(tree[now].l>=l&tree[now].r<=r)return tree[now].id;
	int mid=(tree[now].l+tree[now].r)>>1;
	if(r<=mid)return find(now<<1,l,r);
	else if(l>mid)return find(now<<1|1,l,r);
	else {
		int x=find(now<<1,l,mid);
		int y=find(now<<1|1,mid+1,r);
		if(a[x]<=a[y])return x;
		return y;
	}
}
void dfs(int l,int r,int deep){
	if(l>r)return ;
	if(l==r){
		ans+=a[l]-deep;
		return ;
	}
	int temp=find(1,l,r);
	ans+=a[temp]-deep;
	dfs(l,temp-1,deep+a[temp]-deep);
	dfs(temp+1,r,deep+a[temp]-deep);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(re int i=1;i<=n;i++)scanf("%d",&a[i]);
	build(1,1,n);
	dfs(1,n,0);
	printf("%d",ans);
	return 0;
}
