#include<queue>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m;
struct node{
	int to,next,w;
}edge[100010];
int head[100010];
int val[100100];
int deep[100100];
int dist[100010];
int u,v,w;
int k;
int now;
bool cmp(int x,int y){return x<y;}
void adde(int u,int v,int w){
	edge[++k].to=v;
	edge[k].next=head[u];
	edge[k].w=w;
	head[u]=k;
	edge[++k].to=u;
	edge[k].next=head[v];
	edge[k].w=w;
	head[v]=k;
}
void bfs(int s){
	memset(deep,0,sizeof(deep));
	memset(dist,0,sizeof(dist));
	queue<int> q;
	q.push(s);
	deep[s]=1;
	while(!q.empty()){
		int rp=q.front();
		q.pop();
		for(int i=head[rp];i;i=edge[i].next){
			int mp=edge[i].to;
			if(!deep[mp])deep[mp]=deep[rp]+1,dist[mp]=dist[rp]+edge[i].w,q.push(mp);
		}
	}
} 
bool check(int mid){
	int cnt=0;
	int sum=0;
	for(int i=1;i<n;i++){
		sum+=val[i];
		if(sum>mid)++cnt,sum=0;
	}return cnt>=m;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)scanf("%d%d%d",&u,&v,&w),adde(u,v,w),val[i]=w;
	sort(val+1,val+n,cmp);
	bfs(1); 		
	if(n==m-1)printf("%d",val[1]); 
	else if(deep[n]==n){//�� 20 true
		int l=1,r=dist[n]/m+1;
		while(l<=r){
			int mid=l+r>>1;
			if(check(mid))r=mid-1;
			else l=mid+1;
		}
		printf("%d",l);
	}
	else if(m==1){//ֻҪ1��·����� 20 true 	
		for(int i=1;i<=n;i++)if(dist[i]>dist[now])now=i;
		bfs(now);
		int ans=-1;
		for(int i=1;i<=n;i++)if(dist[i]>ans)ans=dist[i];
		printf("%d",ans);
	}
	else printf("%d",rand()%233);
	return 0;
}
