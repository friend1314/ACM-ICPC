#include <bits/stdc++.h>
using namespace std;
#define LL long long 
LL n=0;
bool up=0;
LL ans=0;
LL res=0;
LL sto=0;
LL last=0;//��¼�½����е���Сֵ 
inline LL read(){
	LL x=0,w=0;
	char ch=0;
	while(!isdigit(ch)){
		w|=ch=='-';
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return w?-x:x;
} 
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(LL i=1;i<=n;i++){
		sto=read();
		if(sto<=last){
		   last=sto;
		}
		else{
			ans+=(sto-last);
			last=sto;
		}
	}
	printf("%lld\n",ans);
}
