#include <bits/stdc++.h>
using namespace std;
#define LL long long 
inline LL read(){
	LL x=0,w=0;
	char ch=0;
	while(!isdigit(ch)){
		w|=ch=='-';
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return w?-x:x;
} 
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	cin>>t;
	int n,m,x;
	while(t--){
		cin>>n>>m>>x;
		if(__gcd(m,x)==1){
			cout<<"2"<<endl;
		}
		else
		cout<<"1";
	}
}
