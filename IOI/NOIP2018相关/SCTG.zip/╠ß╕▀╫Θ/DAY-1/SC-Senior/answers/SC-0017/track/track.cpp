#include <bits/stdc++.h>
using namespace std;
#define LL long long 
inline LL read(){
	LL x=0,w=0;
	char ch=0;
	while(!isdigit(ch)){
		w|=ch=='-';
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return w?-x:x;
} 
int n,m;
struct node{
	int next;
	int to;
	int w;
}eg[50000];
int cnt=0;
int head[50000];
void add(int next,int to,int w){
	cnt++;
	eg[cnt].next=head[next];
	eg[cnt].to=to;
	eg[cnt].w=w;
	head[next]=cnt;
}
int x,y,z;
struct tr{
	int p,d;
	bool operator <(const tr& a)const{
    	return d>a.d;
	}
};
int dis[50000];
int dijistra(int s){
	for(int i=1;i<=n;i++)dis[i]=0;
	priority_queue <tr> q;
	dis[s]=0;
	q.push((tr){s,0});
	while(!q.empty()){
		tr sto=q.top();
		int u=sto.p;
		int d=sto.d;
		q.pop();
		if(dis[u]!=d)continue;
		for(int i=head[u];i;i=eg[i].next){
			int to=eg[i].to;
			if(dis[to]<dis[u]+eg[i].w){
				dis[to]=dis[u]+eg[i].w;
				q.push((tr){to,dis[to]});
			}
		}
	}
	int ma=-99;
	for(int i=1;i<=n;i++){
		ma=max(ma,dis[i]);
	}
	return ma;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();
	m=read();
	for(int i=1;i<n;i++){
		x=read(),y=read(),z=read();
		add(x,y,z);
		add(y,x,z);
	}
	cout<<rand()<<endl;
}
