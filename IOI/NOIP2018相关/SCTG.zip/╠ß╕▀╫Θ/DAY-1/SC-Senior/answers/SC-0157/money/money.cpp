#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll read(){
	ll x=0,f=1;char ch;
	do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');
	do{x=x*10+ch-'0';ch=getchar();}while(ch<='9'&&ch>='0');
	return f*x;
}
int t,n,a[1001];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	for(int i=1;i<=t;++i){
		n=read();
		memset(a,0,sizeof(a));
		for(int j=1;j<=n;++j)a[i]=read();
		printf("%d\n",n);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
