#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll read(){
	ll x=0,f=1;char ch;
	do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');
	do{x=x*10+ch-'0';ch=getchar();}while(ch<='9'&&ch>='0');
	return f*x;
}
int n,m,maps[100][100],dp[100][100],ans;
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++){
		int u=read(),v=read(),w=read();
		maps[u][v]=w;maps[v][u]=w;
		//dp[u][v]=w;dp[v][u]=w;
	}
	for(int k=1;k<=n;k++)
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++){
		if(dp[i][j]<dp[i][k]+maps[k][j]){
			dp[i][j]=dp[i][k]+maps[k][j];
		}
	}
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++){
		ans=max(ans,dp[i][j]);
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
