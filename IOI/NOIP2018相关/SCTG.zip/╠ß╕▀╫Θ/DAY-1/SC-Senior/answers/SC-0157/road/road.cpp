#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0,f=1;char ch;
	do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');
	do{x=x*10+ch-'0';ch=getchar();}while(ch<='9'&&ch>='0');
	return f*x;
}
int n,a[100001],cnt,p[100001],opt,minn=100001;
ll ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i) a[i]=read(),minn=min(minn,a[i]);
	for(int i=1;i<=n;++i) a[i]-=minn;
	for(int i=1;i<=n;++i)if(a[i]>a[i-1])p[cnt++]=i;
	p[cnt]=n;ans+=minn;
	for(int i=0;i<cnt;++i){
		if(a[p[i]]<=0) continue;
			ans+=a[p[i]];
			opt=a[p[i+1]-1];
		for(int j=i+1;j<cnt;++j){
			if(p[j]!=p[j+1]-1){
				a[p[j]]-=opt;
				if(a[p[j+1]-1]<opt){
					opt=a[p[j+1]-1];
					a[p[j+1]-1]=0;
				}
				else{
					a[p[j+1]-1]-=opt;
				}
			}
			else{
				if(a[p[j]]<opt){
					opt=a[p[j]];
					a[p[j]]=0;
				}
				else{
					a[p[j]]-=opt;
				}
			}
			if(opt<=0)break;
		}
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
