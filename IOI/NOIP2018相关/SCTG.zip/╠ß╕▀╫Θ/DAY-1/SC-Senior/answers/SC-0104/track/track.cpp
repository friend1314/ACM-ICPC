#include<cstdio>
#include<cstdlib>
using namespace std;
typedef long long ll;
const int maxn=50010;
const int maxm=100010;
int head[maxn],ver[maxm],nxt[maxm],tot;
ll cost[maxm];
int fr;
ll frv;
int n,m;
inline int read(){
    char ch;
    int res=0,si=1;
    while((ch=getchar())>'9'||ch<'0'){
        if(ch=='-') si=-1;
    }
    res=ch-48;
    while((ch=getchar())>='0'&&ch<='9'){
        res=(res<<3)+(res<<1)+ch-48;
    }
    return res*si;
}
void addedge(int x,int y,ll z){
    tot++;ver[tot]=y;
    cost[tot]=(ll)z;
    nxt[tot]=head[x];
    head[x]=tot;
}
void dfs1(int x,int f,ll dep){
    if(frv<dep){
        fr=x;
        frv=dep;
    }
    for(int i=head[x];i;i=nxt[i]){
        if(ver[i]==f) continue;
        dfs1(ver[i],x,dep+cost[i]);
    }
}
void dfs2(int x,int f,ll dep){
    if(dep>frv){
        frv=dep;
    }
    for(int i=head[x];i;i=nxt[i]){
        if(ver[i]==f) continue;
        dfs2(ver[i],x,dep+cost[i]);
    }
}
int main(){
    freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    n=read();m=read();
    int a,b,c;
    tot=0;fr=0;frv=0LL;
    for(int i=1;i<=n-1;i++){
        a=read();b=read();c=read();
        addedge(a,b,c);
        addedge(b,a,c);
    }
    dfs1(1,0,0LL);
    dfs2(fr,0,0LL);
    printf("%lld",frv);
    fclose(stdin);fclose(stdout);
    return 0;
}
