#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
const int maxn=100101;
const int maxm=400101;
struct SERT{
    int k,l,r,Min,add;
}t[maxm];
int N,ans=0;
int a[maxn];
inline int read(){
    char ch;
    int res=0,si=1;
    while((ch=getchar())>'9'||ch<'0'){
        if(ch=='-') si=-1;
    }
    res=ch-48;
    while((ch=getchar())>='0'&&ch<='9'){
        res=(res<<3)+(res<<1)+ch-48;
    }
    return res*si;
}
void build(int k,int l,int r){
    t[k].l=l;t[k].r=r;
    t[k].add=0;
    if(l==r){
        t[k].Min=a[l];
        return;
    }
    int mid=(l+r)/2;
    build(k<<1,l,mid);
    build(k<<1|1,mid+1,r);
    t[k].Min=min(t[k<<1].Min,t[k<<1|1].Min);
}
void pushdown(int k){
    t[k<<1].Min-=t[k].add;
    t[k<<1|1].Min-=t[k].add;
    t[k<<1].add+=t[k].add;
    t[k<<1|1].add+=t[k].add;
    t[k].add=0;
    t[k].Min=min(t[k<<1].Min,t[k<<1|1].Min);
}
void modify(int k,int l,int r,int v){
    if(l<=t[k].l&&t[k].r<=r){
        t[k].add+=v;
        t[k].Min-=v;
        return;
    }
    pushdown(k);
    int mid=(t[k].l+t[k].r)/2;
    if(l<=mid) modify(k<<1,l,r,v);
    if(mid+1<=r) modify(k<<1|1,l,r,v);
    t[k].Min=min(t[k<<1].Min,t[k<<1|1].Min);

}
int query(int k,int l,int r){
    if(l<=t[k].l&&t[k].r<=r){
        return t[k].Min;
    }
    pushdown(k);
    int ret=2100000000;
    int mid=(t[k].l+t[k].r)/2;
    if(l<=mid) ret=min(ret,query(k<<1,l,r));
    if(mid+1<=r) ret=min(ret,query(k<<1|1,l,r));
    t[k].Min=min(t[k<<1].Min,t[k<<1|1].Min);
    return ret;
}
int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    N=read();
    for(int i=1;i<=N;i++){
        a[i]=read();
    }
    build(1,1,N);
    for(int i=1;i<=N;i++){
        while(1){
            if(query(1,i,i)==0) break;
            int l=i,r=N+1,q;
            while(l<r){
                int mid=(l+r)/2;
                q=query(1,i,mid);
                if(q>0){
                    l=mid+1;
                }
                else{
                    r=mid;
                }
            }
            q=query(1,i,l-1);
            ans+=q;
            modify(1,i,l-1,q);
        }
    }
    printf("%d",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
