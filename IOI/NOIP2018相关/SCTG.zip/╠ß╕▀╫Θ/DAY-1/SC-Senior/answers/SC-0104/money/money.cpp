#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
using namespace std;
int T,N,a[110];
int vis[110],ans,num[25005];
inline int read(){
    char ch;
    int res=0,si=1;
    while((ch=getchar())>'9'||ch<'0'){
        if(ch=='-') si=-1;
    }
    res=ch-48;
    while((ch=getchar())>='0'&&ch<='9'){
        res=(res<<3)+(res<<1)+ch-48;
    }
    return res*si;
}
void dfs(int x){
    if(x>N) return;
    for(int i=0;i<=a[N];i++){
        if(i+a[x]>a[N]) break;
        if(num[i]) num[i+a[x]]++;
    }
    dfs(x+1);
}
int main(){
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    T=read();
    while(T--){
        memset(vis,0,sizeof(vis));
        memset(num,0,sizeof(num));
        N=read();
        num[0]=1;
        for(int i=1;i<=N;i++){
            a[i]=read();
        }
        sort(a+1,a+N+1);
        dfs(1);
        ans=0;
        for(int i=1;i<=N;i++){
            if(num[a[i]]==1) ans++;
        }
        printf("%d\n",ans);
    }
    fclose(stdin);fclose(stdout);
    return 0;
}
