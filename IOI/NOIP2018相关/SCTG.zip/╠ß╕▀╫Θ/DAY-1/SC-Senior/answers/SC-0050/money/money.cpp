#include<cstdio>
#define easy 1
#define real 1
#define MAXN 105
int main()
{
	#ifdef real
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	#endif
	int t,n,a[MAXN],ans=0;
	scanf("%d",&t);
	for(int ijk=0;ijk<t;ijk++){
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d",a+i);
		}
		#ifdef easy
		int i,j;
		ans=n;
		bool out[25001]={0};
		bool yu[25001]={1};
		for(i=0;i<n;i++){//paixu
			for(j=i+1;j<n;j++){
				if(a[i]>a[j]){
					a[i]^=a[j];
					a[j]^=a[i];
					a[i]^=a[j];
				}
			}
		}
		int max=a[n-1];
		for(i=0;i<n;i++){
			if(out[a[i]]){
				ans--;
				continue;
			}
			out[a[i]]=1;
			for(j=1;j<n;j++){
				yu[j]=0;
			}
			for(j=1;j<=max;j++){
				if(out[j]){
					yu[j%a[i]]=1;
				}else{
					if(yu[j%a[i]]){
						out[j]=1;
					}
				}
			}
		}
		#else
		
		#endif
		printf("%d\n",ans);
	}
	return 0;
}
