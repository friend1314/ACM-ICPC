#include<cstdio>
#define MAXN 100002
//#define easy 1
#define real 1
#define min(x,y) ((x)<(y))?(x):(y)
#define max(x,y) ((x)>(y))?(x):(y)
int main()
{
	#ifdef real
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	#endif
	int n,d[MAXN]={0},ans=0;
	scanf("%d",&n);
	#ifdef easy
	for(int i=0;i<n;i++){
		scanf("%d",d+i);
	}
	bool end=0;
	int i,j,k;
	for(;;){
		for(i=0;i<n;i++){
			if(d[i])	break;
		}
		if(i==n)	break;
		for(j=i;j<n;j++){
			if(!d[j])	break;
		}
		for(k=i;k<j;k++){
			d[k]--;
		}
		ans++;
	}
	#else
	for(int i=1;i<=n;i++){
		scanf("%d",d+i);
	}
	bool down=1,up=0;
	int deepest=0,un1=0,un2=0;
//	if(d[1]>d[0]){
//		un=d[0];
//		down=1;
//	}else 
	for(int i=1;i<=n+1;i++){
		if(d[i]>d[i-1]){
			if(up){
				un2=min(un1,d[i-1]);
				un1=max(un1,d[i-1]);
				ans+=deepest-un1;
				un1=un2;
			}
			up=0;down=1;
		}else if(d[i]==d[i-1]){
			continue;
		}else/*if(d[i]<d[i-1]*/{
			if(down){
				deepest=d[i-1];
			}
			up=1;down=0;
		}
	}
	ans+=deepest;
	#endif
	printf("%d\n",ans);
	return 0;
}
