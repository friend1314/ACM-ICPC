#include<cstdio>
#include<queue>
using namespace std;
#define real 1
#define MAXN 55
#define part 1

bool used1[MAXN];
int partf1(int spot);
queue<int>lu[MAXN],length[MAXN];
int main()
{
	#ifdef real
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	#endif
	bool isa1=1,isb1=1;
	int length1[MAXN];
	int n,m;
	int a,aa,b,l;
	int ans=0;
	scanf("%d%d",&n,&m);
	for(int i=0;i<n-1;i++){
		scanf("%d%d%d",&a,&b,&l);
		length1[i]=l;
		lu[a].push(b);
		lu[b].push(a);
		length[a].push(l);
		length[b].push(l);
		if(a!=1)	isa1=0;
		if(b!=a+1)	isb1=0;
	}
	#ifdef part
	if(m==1){
		int f;
		int start=1;
		for(int t=1;t<=n;t++){
			start=t;
			for(int i=1;i<=n;i++){
				used1[i]=0;
			}
			used1[start]=1;
			ans=partf1(start);
		}
	}
	else if(isa1){
		int sumlength=0;
		for(int i=0;i<n;i++){
			sumlength+=length1[i];
		}
		printf("%d\n",sumlength/m-1);
	}
	else if(isb1){
		int sumlength=0,ans;
		for(int i=0;i<n-1;i++){
			sumlength+=length1[i];
		}
		ans=sumlength/m;
		sumlength=0;
		int i,j;
		for(;ans;ans--){
			j=0;
			sumlength=0;
			for(i=0;i<m;i++){
				for(;j<n;j++){
					sumlength+=length1[j];
					if(sumlength>=ans){
						sumlength=0;
						j++;
						break;
					}
				}
				if(j==n)	break;
			}
			if(i<m)	continue;
			printf("%d\n",ans);
			return 0;
		}
	}
	#else
	
	#endif
	printf("%d\n",ans);
	return 0;
}
int partf1(int spot){
	int ret=0,rett,f1,f2;
	for(int i=0;i<lu[spot].size();i++){
		f1=lu[spot].front();
		f2=length[spot].front();
		if(used1[f1]){
			lu[spot].pop();lu[spot].push(f1);
			length[spot].pop();length[spot].push(f2);
			continue;
		}
		used1[f1]=1;
		rett=partf1(f1)+f2;
		if(rett>ret)	ret=rett;
	}
	return ret;
}
