#include<map>
#include<cmath>
#include<ctime>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define re register
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int maxn=5e4+10;

ll ans,tmp;
int n,m,num;
int head[maxn],du[maxn],w[maxn],x[maxn],y[maxn];

struct edge{
	int last,to,dis;
}d[maxn<<1];

inline void read(int &x)
{
	x=0;int f=1;char s=getchar();
	while(s<'0'||s>'9') {if(s=='-')f=-1;s=getchar();}
	while(s>='0'&&s<='9') {x=x*10+s-'0';s=getchar();}
	x*=f;
}

void add(int from,int to,int dis)
{
	d[++num].last=head[from];
	d[num].to=to;
	d[num].dis=dis;
	head[from]=num;
}

void dfs1(int u,int fa,ll l)
{
	bool flag=1;
	for(re int t=head[u];t;t=d[t].last)
	{
		int v=d[t].to;
		if(v==fa) continue;
		flag=0;
		dfs1(v,u,l+(ll)d[t].dis);
	}
	if(flag&&l>tmp) tmp=l;
}

inline void work1()
{
	for(re int i=1;i<=n;i++)
	if(du[i]==1)
	{
		tmp=0;
		dfs1(i,0,0);
		if(tmp>ans) ans=tmp;
	}
	printf("%lld\n",ans);
}

inline void work2()
{
	
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);
	bool flag=1;
	for(re int i=1;i<n;i++)
	{
		read(x[i]);read(y[i]);read(w[i]);
		du[x[i]]++;du[y[i]]++;
		add(x[i],y[i],w[i]);add(y[i],x[i],w[i]);
		if(x[i]!=y[i]-1) flag=0;
	}
	if(du[1]==n-1)
	{
		sort(w+1,w+n);
		ans=0x7fffffff;
		int l=n-2*m,r=n-1;
		while(m--)
		{
			if(w[l]+w[r]<ans) ans=(ll)w[l]+(ll)w[r];
			l++;r--;
		}
		printf("%lld\n",ans);
	}
	else if(m==1) work1();
	else if(flag) work2();
	else
	{
		ans=0x7fffffff;
		for(int i=1;i<n;i++) ans=min(ans,(ll)w[i]);
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

