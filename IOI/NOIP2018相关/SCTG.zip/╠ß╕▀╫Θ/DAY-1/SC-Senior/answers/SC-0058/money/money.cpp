#include<map>
#include<cmath>
#include<ctime>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define re register
using namespace std;
typedef long long ll;
typedef unsigned long long ull;

int n,T,cnt;
bool FLAG;
int a[110],d[110];

inline void read(int &x)
{
	x=0;int f=1;char s=getchar();
	while(s<'0'||s>'9') {if(s=='-')f=-1;s=getchar();}
	while(s>='0'&&s<='9') {x=x*10+s-'0';s=getchar();}
	x*=f;
}

bool find(int x,int num)
{
	if(FLAG) return 1;
//	cout<<x<<endl;
	if(x==0)
	{
		FLAG=1;
		return 1;
	}
	if(x<a[1]) return 0;
	int flag=0;
	for(int i=1;i<=n&&a[i]<=x;i++)
	if(!d[i]&&i!=num) flag|=find(x-a[i],num);
	return flag;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(T);
	while(T--)
	{
		cnt=0;
		read(n);
		for(int i=1;i<=n;i++)
		{
			read(a[i]);
//			used[a[i]]=1;
		}
		sort(a+1,a+1+n);
		memset(d,0,sizeof d);
		for(int i=n;i>=1;i--)
		{
			FLAG=0;
			if(find(a[i],i))
			{
				d[i]=1;
//				cout<<i<<" "<<endl;
				cnt++;
			}
		}
		printf("%d\n",n-cnt);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

