#include<map>
#include<cmath>
#include<ctime>
#include<queue>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define re register
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int maxn=1e5+10;

int n;
ll ans;
int d[maxn];

inline void read(int &x)
{
	x=0;int f=1;char s=getchar();
	while(s<'0'||s>'9') {if(s=='-')f=-1;s=getchar();}
	while(s>='0'&&s<='9') {x=x*10+s-'0';s=getchar();}
	x*=f;
}

void dfs(int l,int r)
{
	int minn=10001;
	for(int i=l;i<=r;i++)
	if(d[i]<minn) minn=d[i];
	ans+=(ll)minn;
	int p=l;
	for(int i=l;i<=r;i++)
	{
		d[i]-=minn;
		if(!d[i])
		{
			if(i-1>=p) dfs(p,i-1);
			p=i+1;
		}
	}
	if(p<=r) dfs(p,r);
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) read(d[i]);
	dfs(1,n);
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
