#include <iostream>
#include <cstdio>
#include <ifstream>
#include <fstream>
#include <string>
#include <ofstream>
#include <cstring>
#include <conio.h>
using namespace std;
int a[100000+5]={0};
int main() {
	ifstream fin"road.in";
	ofstream fout"road.out";
	int n;fin >> n;
	int k=0,deep=0;
	for(int i=1;i<=n;i=i+1)
	 {
	 	fin >> a[i];
	 	k=k+1;
	 	if(k==3)
	 	 {
	 	 	int L=a[i];
	 	 	if(L<a[i-1])L=a[i-1];
	 	 	if(L<a[i-2])L=a[i-2];
			if(a[i-1]<a[i]&&a[i-1]<a[i-2])deep=deep+a[i]+a[i-2]-a[i-1];
			else deep=deep+L;
	 	 	k=0;
	 	 }
	 }
	fout << deep << endl;
	return 0;
}
