#include<cstdio>
#include<algorithm>
#define N 100010
using namespace std;
int d[N],n,minn,ans=0,tot;
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')
	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	tot=n;
	for(int i=1;i<=n;i++)
	d[i]=read();
	while(1)
	{
		minn=1e9;
		int s=1;
		for(int i=1;i<=n+1;i++)
		{
			if(d[i]==0)
			{
				for(int j=s;j<i;j++)
				d[j]-=minn;
				if(minn!=1e9)
				ans+=minn;
				s=i+1;
				minn=1e9;
				continue;
			}
			minn=min(minn,d[i]);
		}
		int f=1;
		for(int i=1;i<=n;i++)
		if(d[i]!=0) f=0;
		if(f) break;
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
