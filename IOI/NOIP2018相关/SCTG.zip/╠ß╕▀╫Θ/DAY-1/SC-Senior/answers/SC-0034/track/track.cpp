#include<cstdio>
#include<algorithm>
#define N 50010
using namespace std;
int frt[N],nxt[N<<1],v[N<<1],w[N<<1],a[N];
int n,m,tot,ans,fur,f1,f2,maxx;
bool cmp(const int x,const int y)
{
	return x>y;
}
int read()
{
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')
	ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x;
}
void add(int x,int y,int z)
{
	v[++tot]=y;w[tot]=z;
	nxt[tot]=frt[x];frt[x]=tot;
	v[++tot]=x;w[tot]=z;
	nxt[tot]=frt[y];frt[y]=tot;
	return;
}
void dfs1(int x,int father,int dis)
{
	for(int i=frt[x];i;i=nxt[i])
	if(v[i]!=father)
	dfs1(v[i],x,dis+w[i]);
	if(dis>ans) fur=x,ans=dis;
	return;
}
void dfs2(int x,int father,int dis)
{
	for(int i=frt[x];i;i=nxt[i])
	if(v[i]!=father)
	dfs2(v[i],x,dis+w[i]);
	ans=max(ans,dis);
	return;
}
bool ok(int x)
{
	int sum=0,cnt=0;
	for(int i=1;i<n;i++)
	{
		sum+=a[i];
		if(sum>x)
		cnt++,sum=0;
	}
	if(cnt>=m) return true;
	return false;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();m=read();
	f1=f2=1;
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read(),z=read();
		if(x!=1) f1=0;
		if(y!=x+1) f2=0;
		add(x,y,z);
		a[y-1]=z;maxx+=z;
	}
	if(m==1)
	{
		dfs1(1,0,0);
		dfs2(fur,0,0);
		printf("%d",ans);
	}
	else if(f1)
	{
		ans=1e9;
		sort(a+1,a+n);
		if(m<<1<=n)
		{
			int x=n-(m<<1);
			for(int i=x,j=n-1;i<=j;i++,j--)
			ans=min(ans,a[i]+a[j]);
		}
		else
		{
			sort(a+1,a+n,cmp);
			int x=2*m-n+1;
			ans=a[x];
			for(int i=x+1,j=n-1;i<=j;i++,j--)
			ans=min(ans,a[i]+a[j]);
		}
		printf("%d",ans);
	}
	else if(f2)
	{
		int l=1,r=maxx;
		while(l<r)
		{
			int mid=l+r>>1;
			if(ok(mid)) l=mid+1;
			else r=mid;
		}
		printf("%d",l);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
