#include<cstdio>
#include<algorithm>
using namespace std;
int T,sum;
bool f;
int a[110],book[110],cnt[110];
void choose(int x,int s,int sum)
{
	if(sum==a[s])
	{
		f=true;
		return;
	}
	if(x==s) return;
	if(sum>a[s]) return;
	for(register int i=0;i<=a[s]/a[x];i++)
	{
		choose(x+1,s,sum+i*a[x]);
		if(f) return;
	}
	return;
}
bool ok(int x,int s)
{
	f=false;
	choose(1,s,0);
	return f;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		int n;
		scanf("%d",&n);
		int ans=n;
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		for(int i=2;i<=n;i++)
		if(ok(a[i],i)) ans--;
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
