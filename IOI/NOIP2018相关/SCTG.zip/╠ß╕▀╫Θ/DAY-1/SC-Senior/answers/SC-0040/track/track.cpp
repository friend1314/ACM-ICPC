#include<bits/stdc++.h>
#define maxn 50000
#define inf 2147483647
#define ac rp++
using namespace std;
int tot=0,head[maxn],n=0,m=0,mark=1,a,b,l,ans[maxn*2],cnt=1;
long long num=0;
struct A
{int v,w,next;
}lu[maxn];
void input()
{freopen("track.in","r",stdin);
freopen("track.out","w",stdout);
}
bool cmp(A xx,A yy)
{return xx.w<yy.w;
}
void add(int x,int y,int z)
{lu[++tot].v=y;
lu[tot].w=z;
lu[tot].next=head[x];
head[x]=tot;
}
void read()
{scanf("%d%d",&n,&m);
if(m==1)mark=2;
for(int i=1;i<n;i++)
{scanf("%d%d%d",&a,&b,&l);
add(a,b,l);
num+=l;
if(a!=1&&mark!=2)mark=0;
}
}
void work()
{if(mark==1)
{sort(lu+1,lu+n,cmp);
ans[1]=lu[1].w;
for(int i=2;i<n;i++)
{ans[++cnt]=lu[i-1].w+lu[i].w;
ans[++cnt]=lu[i].w;
}
sort(ans+1,ans+cnt+1);
printf("%d\n",ans[cnt-m+1]);
}
else if(mark==2)
printf("%lld\n",num);
else 
{sort(lu+1,lu+n+1,cmp);
srand(time(NULL));
printf("%lld\n",rand()%(num/88));
}
}
int main()
{input();
read();
work();
return 0;
}
