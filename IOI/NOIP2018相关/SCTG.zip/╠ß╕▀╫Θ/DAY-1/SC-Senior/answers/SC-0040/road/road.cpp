#include<bits/stdc++.h>
#define maxn 100005
#define inf 2147483647
#define ac rp++
using namespace std;
int n,d[maxn];
long long ans=0;
struct A
{int v,w,next;
}lu[maxn];
void input()
{freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
}
void read()
{scanf("%d",&n);
for(int i=1;i<=n;i++)
scanf("%d",&d[i]);
}
void work()
{ans=d[1];
int last=d[1];
for(int i=2;i<=n;i++)
{if(d[i]>last)
ans+=(d[i]-last);
last=d[i];
}
printf("%lld",ans);
}
int main()
{input();
read();
work();
return 0;
}
