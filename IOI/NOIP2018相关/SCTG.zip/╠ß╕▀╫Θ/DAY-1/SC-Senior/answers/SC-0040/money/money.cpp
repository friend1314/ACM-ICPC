#include<bits/stdc++.h>
#define maxn 25005
#define inf 2147483647
#define ac rp++
using namespace std;
int a[maxn],n,t,ans;
void input()
{freopen("money.in","r",stdin);
freopen("money.out","w",stdout);
}
void work1()
{int i=a[1];
int j=a[2];
if(i>j)swap(i,j);
if(j%i==0)
ans=1;
else 
ans=2;
printf("%d\n",ans);
}
void work2()
{srand(time(NULL));
printf("%d\n",rand()%(n+1));
}
int main()
{input();
scanf("%d",&t);
for(int i=1;i<=t;i++)
{scanf("%d",&n);
for(int i=1;i<=n;i++)
scanf("%d",&a[i]);
if(n==2)
work1();
else work2();
}
return 0;
}
