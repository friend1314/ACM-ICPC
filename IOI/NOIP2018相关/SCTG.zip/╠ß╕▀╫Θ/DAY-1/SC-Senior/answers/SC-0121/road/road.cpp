#include<map>
#include<queue>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
template<class T>inline void read(T &x)
{
	int f=1;char k=getchar();x=0;
	for(;k>'9'||k<'0';k=getchar()) if(k=='-') f=-1;
	for(;k>='0'&&k<='9';k=getchar()) x=x*10+k-'0';
	x*=f;
}
int n,d[100005],ans=0;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	for(int i=1;i<=n;i++) read(d[i]);
	for(int i=1;i<=n;i++)
		if(d[i]>d[i-1]) ans+=d[i]-d[i-1];
	printf("%d",ans);
	return 0;
}
