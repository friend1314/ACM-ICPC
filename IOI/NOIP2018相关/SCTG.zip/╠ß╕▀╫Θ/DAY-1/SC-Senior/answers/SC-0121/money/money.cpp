#include<map>
#include<queue>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<windows.h>
#define ll long long
using namespace std;
template<class T>inline void read(T &x)
{
	int f=1;char k=getchar();x=0;
	for(;k>'9'||k<'0';k=getchar()) if(k=='-') f=-1;
	for(;k>='0'&&k<='9';k=getchar()) x=x*10+k-'0';
	x*=f;
}
int T,n,a[105],ans;
int b[105];
bool f[2500005];
inline int pd(int n)
{
	if(f[n]==true) return 0;
	else return 1;
}
inline void down(int k)
{
	f[k]=true;
	for(int i=1;i<=a[n-1];i++)
		if(f[i]) f[i+k]=true;
}
inline void joinb(int k)
{
	if(ans==1)
	{
		if(k%b[0]!=0)
		{
			b[ans++]=k;
			down(k);
		}
		return ;
	}
	if(f[k]) return ;
	b[ans++]=k;
	down(k);
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(T);
	while(T--)
	{
		ans=0;
		memset(f,0,sizeof(f));
		read(n);
		for(int i=0;i<n;i++) read(a[i]);
		sort(a,a+n);
		b[ans++]=a[0];
		down(a[0]);
		for(int i=1;i<n;i++)
			joinb(a[i]);
		printf("%d\n",ans);
	}
	return 0;
}
