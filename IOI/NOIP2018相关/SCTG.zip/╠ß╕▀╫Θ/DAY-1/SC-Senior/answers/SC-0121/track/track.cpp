#include<map>
#include<queue>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
template<class T>inline void read(T &x)
{
	int f=1;char k=getchar();x=0;
	for(;k>'9'||k<'0';k=getchar()) if(k=='-') f=-1;
	for(;k>='0'&&k<='9';k=getchar()) x=x*10+k-'0';
	x*=f;
}
int n,m,x,y,l;
int maxlen=0;
struct lt
{
	int fa,w,s[2];
	int to;
	bool ch;
}a[50005];
void dfs(int k,int len)
{
	int kfa=a[k].fa;
	if(kfa==0) return ;
	bool fla=false;
	for(int i=0;i<2;i++)
		if(a[kfa].s[i]==0)
		{
			a[kfa].s[i]=a[k].w+a[kfa].w,fla=true;
			break;
		}
	if(!fla)
	{
		if(a[kfa].s[0]>a[kfa].s[1]) swap(a[kfa].s[0],a[kfa].s[1]);
		if(a[k].w>a[kfa].s[0]) a[kfa].s[0]=a[k].w;
	}
	dfs(kfa,len+max(a[kfa].s[0],a[kfa].s[1]));
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);
	for(int i=0;i<n-1;i++)
	{
		read(x);read(y);read(l);
		maxlen+=l;
		if(x>y) swap(x,y);
		a[y].fa=x,a[y].s[0]=l;
		a[x].ch=true;
	}
	for(int i=1;i<=n;i++)
		if(!a[i].ch) dfs(i,0);
	printf("%d",maxlen);
	return 0;
}
