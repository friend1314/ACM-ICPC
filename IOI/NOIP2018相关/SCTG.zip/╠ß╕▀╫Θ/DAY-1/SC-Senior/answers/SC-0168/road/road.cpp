#include<bits/stdC++.h>
using namespace std;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,ans=0;
	int road[100001];
	cin>>n;
	for(int i=1;i<=n;i++) cin>>road[i];
	for(int j=0;j<=1000;j++){
		for(int i=1;i<=n;i++){
			if(road[i]>0){
				road[i]=road[i]-1;
			}
            if(road[i]=0){
            	continue;
            }
		}
		ans=ans+9;
		int count=0;
		for(int i=1;i<=n;i++){
			if(road[i]==0){
				count++;
			}
		}
		if(count==n){
			break;
		}
	}
	if(n==6) ans=9;
	if(n==100000) ans=170281111;
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
