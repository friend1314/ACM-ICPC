#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define endl ('\n')
#define USING_R(fn,n,gc) n n##R;n fn(){static char c;static bool f;f=0;c=gc();n##R=0;while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=0,c=gc();while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(s) int __INDEX=0;const char *__DATA=s;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl
#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define R Read()
#define ll long long
#define ull unsigned long long

#define nmax 50004
#define mmax 100004
#define lmax 16
using namespace std;

//USING_T("7 1 1 2 10 1 3 5 2 4 9 2 5 8 3 6 6 3 7 7")
//USING_T("9 3 1 2 6 2 3 3 3 4 5 4 5 10 6 2 4 7 2 9 8 4 7 9 4 4")
//USING_T("5 2 2 3 7 3 1 8 3 5 6 2 4 4")
USING_R(Read,int,getchar)
int n,m;
int last[nmax];
int pre[mmax],tar[mmax],wei[mmax];
int dis[nmax];
//int depth[nmax];
int tot=1;
void addLine(int x, int y, int z) {
	pre[++tot]=last[x],last[x]=tot,tar[tot]=y,wei[tot]=z;
}
bool vis[nmax+5];
int m1tmp;
int dfsm1(int x) {
	int ss=0;
	vis[x]=1;
	for (int b=last[x];b;b=pre[b]) {
		if (vis[b|1]) continue;
		vis[b|1]=1;
		m1tmp=wei[b]+dfsm1(tar[b]);
		if (m1tmp>ss) ss=m1tmp;
		vis[b|1]=0;
	}
	vis[x]=0;
	return ss;
}
//int fa[nmax][lmax+1];
//int fa[nmax];
void dfs1(int x, int f) {
	int v;
	register int b;
	for (b=last[x];b;b=pre[b]) {
		if ((v=tar[b])==f) continue;
		//fa[v]=x;
		dis[v]=dis[x]+wei[b];
		//depth[v]=depth[x]+1;
		dfs1(v,x);
	}
	//for (b=1;b<=lmax;b++)
	//	if (!(fa[x][b]=fa[fa[x][b-1]][b-1])) return;
}
/*int n2[lmax+1];
int lca(int a, int b) {
	if (depth[a]<depth[b]) swap(a,b);
	register int i;
	if (depth[a]!=depth[b])
		for (i=lmax;i>=0;i--)
			if (depth[a]-n2[i]>=depth[b])
			if (depth[a=fa[a][i]]==depth[b]) break;
	if (a==b) return a;
	for (i=lmax;i>=0;i--)
		if (fa[a][i]!=fa[b][i])
			a=fa[a][i],b=fa[b][i];
	return fa[a][0];
}*/
int main() {
	IO(track);
	n=R,m=R;
	register int i,x,y,z;
	int sum=0;
	for (i=1;i<n;i++) {
		x=R;y=R;z=R;
		addLine(x,y,z);
		addLine(y,x,z);
		sum+=z;
	}
	if (m==1) { // Longest road
		int s1=0,s2=0;
		for (i=last[1];i;i=pre[i]) {
			if (vis[i|1]) continue;
			vis[i|1]=1;
			m1tmp=wei[i]+dfsm1(tar[i]);
			if (m1tmp>s1) s2=s1,s1=m1tmp;
			else s2=m1tmp;
			vis[i|1]=0;
		}
		cout<<s1+s2<<endl;
		return 0;
	}
	int root;
	for (root=1;root<=n;root++) if(!pre[last[root]]) break;
	//depth[root]=1;
	dfs1(root,0);
	int ex=sum/m+1;
	int ans=0;
	for (i=1;i<=n;i++) if(i!=root&&!pre[last[i]]&&dis[i]<ex&&dis[i]>ans) ans=dis[i];
	cout<<ans<<endl;
	return 0;
}
