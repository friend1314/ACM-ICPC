#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define endl ('\n')
#define USING_R(fn,n,gc) n n##R;n fn(){static char c;static bool f;f=0;c=gc();n##R=0;while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=0,c=gc();while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(s) int __INDEX=0;const char *__DATA=s;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl
#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define R Read()
#define ll long long
#define ull unsigned long long

#define nmax 105
#define smax 25002
using namespace std;

//USING_T("2 4 3 19 10 6 5 11 29 13 19 17")
//USING_T("1 19 31 32 30 19 35 29 8 26 25 24 11 20 33 4 28 27 15 9 34")
USING_R(Read,int,getchar)
int a[nmax];
int n;
int qwe;
bool Search(int x, int cur) {
	//cout<<"Search:"<<x<<' '<<a[x]<<' '<<cur<<endl;
	if (x==qwe) return 0;
	if (!(cur%a[x])) return 1;
	for (;cur>0;cur-=a[x])
		if (Search(x+1,cur)) return 1;
	return 0;
}
int main() {
	IO(money);
	int T=R;
	register int i,j,last,ans;
	while (T--) {
		ans=n=R;
		for (i=1;i<=n;i++) a[i]=R;
		sort(a+1,a+n+1);
		last=INT_MAX;
		for (qwe=i=1;i<=n;i++) {
			//P(a[i]);
			if (a[i]>last) ans--/*,cout<<"Bigger\n"*/;
			else if (Search(1,a[i])) ans--/*,cout<<"Search\n"*/;
			else if ((qwe=i+1)==3) last=a[1]*a[i]-a[1]-a[i];
		}
		cout<<ans<<endl;
	}
	return 0;
}
