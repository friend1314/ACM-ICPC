#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define endl ('\n')
#define USING_R(fn,n,gc) n n##R;n fn(){static char c;static bool f;f=0;c=gc();n##R=0;while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=0,c=gc();while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(s) int __INDEX=0;const char *__DATA=s;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl
#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define R Read()
#define ll long long
#define ull unsigned long long
using namespace std;

//USING_T("6 4 3 2 5 3 5")
USING_R(Read,int,getchar)
int n;
ll ans=0;
int main() {
	IO(road);
	n=R;
	register int i;
	register int last=0;
	for (i=1;i<=n;i++) {
		if (R>last) ans+=(intR-last);
		last=intR;
	}
	return cout<<ans<<endl,0;
}
