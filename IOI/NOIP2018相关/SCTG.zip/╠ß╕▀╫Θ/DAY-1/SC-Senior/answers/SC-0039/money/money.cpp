#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cstdlib>
using namespace std;
int T,t;
int n;
int a[200],u[200];
int ans;
bool flag;
inline int read()
{
	int flag=1;
	int res=0;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			flag=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		res=res*10+ch-'0';
		ch=getchar();
	}
	return res*flag;
}
inline void print(register int x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
		print(x/10);
	putchar(x%10+'0');
}
inline void ddfs(register int x,register int sum)
{
	if(x==1)
	{
		if(sum%a[x]==0)
			flag=1;
		return ;
	}
	else
	{
		for(register int i=0;i<=sum/a[x];i++)
		{
			ddfs(x-1,sum-i*a[x]);
			if(flag==1)
				return ;
		}	
	}
}
inline bool pd()
{
	for(register int i=1;i<=n;i++)
	{
		if(u[i]!=t)
		{
			flag=0;
			ddfs(i-1,a[i]);
			if(flag==0)
				return 0;
		}
	}
	return 1;
}
inline void dfs(register int x,register int num)
{
	if(num>=ans)
		return ;
	if(x==n+1)
	{
		if(pd())
			ans=min(ans,num);
		return ;
	}
	if((a[x]%a[1])!=0)
	{
		u[x]=t;
		dfs(x+1,num+1);
		u[x]=0;
		dfs(x+1,num);
	}
	else
		dfs(x+1,num);
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	for(t=1;t<=T;t++)
	{
		n=read();
		for(register int i=1;i<=n;i++)
			a[i]=read();
		ans=n;
		sort(a+1,a+1+n);
		u[1]=t;
		dfs(2,1);
		print(ans);
		putchar('\n');
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
