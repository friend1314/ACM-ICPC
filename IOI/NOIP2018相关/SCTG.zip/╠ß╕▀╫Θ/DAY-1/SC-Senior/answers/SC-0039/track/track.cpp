#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cstdlib>
using namespace std;
int n,m;
int cnt,root;
long long maxx;
int to[200010],head[200010],la[200010],co[200010];
inline int read()
{
	int flag=1;
	int res=0;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			flag=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		res=res*10+ch-'0';
		ch=getchar();
	}
	return res*flag;
}
inline void print(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
		print(x/10);
	putchar(x%10+'0');
}
void dfs1(int x,int zu,long long len)
{
	if(len>maxx)
	{
		maxx=len;
		root=x;
	}
	for(int i=head[x];i;i=la[i])
	{
		if(to[i]==zu)
			continue;
		dfs1(to[i],x,len+co[i]);
	}
}
void dfs2(int x,int zu,long long len)
{
	maxx=max(maxx,len);
	for(int i=head[x];i;i=la[i])
	{
		if(to[i]==zu)
			continue;
		dfs2(to[i],x,len+co[i]);
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();
	m=read();
	int x,y,z;
	for(int i=1;i<=n-1;i++)
	{
		x=read();
		y=read();
		z=read();
		cnt++;
		to[cnt]=y;
		la[cnt]=head[x];
		head[x]=cnt;
		co[cnt]=z;
		cnt++;
		to[cnt]=x;
		la[cnt]=head[y];
		head[y]=cnt;
		co[cnt]=z;
	}
	dfs1(1,0,0);
	dfs2(root,0,0);
	print(maxx);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
