#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cstdlib>
using namespace std;
long long ans;
int n;
int tem,wwz;
int a[100010],minn[400010],wz[400010],add[400010];
inline int read()
{
	int flag=1;
	int res=0;
	char ch;
	ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
			flag=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		res=res*10+ch-'0';
		ch=getchar();
	}
	return res*flag;
}
inline void print(long long x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>=10)
		print(x/10);
	putchar(x%10+'0');
}
void build(int k,int l,int r)
{
	if(l==r)
	{
		minn[k]=a[l];
		wz[k]=l;
		return ;
	}	
	int mid=(l+r)>>1;
	build(k<<1,l,mid);
	build(k<<1|1,mid+1,r);
	if(minn[k<<1]<=minn[k<<1|1])
	{
		minn[k]=minn[k<<1];
		wz[k]=wz[k<<1];
	}
	else
	{
		minn[k]=minn[k<<1|1];
		wz[k]=wz[k<<1|1];
	}
}
void ad(int k,int l,int r,int v)
{
	add[k]+=v;
	minn[k]=minn[k]-v;
}
void pushdown(int k,int l,int r,int mid)
{
	if(add[k]==0)
		return;
	ad(k<<1,l,mid,add[k]);
	ad(k<<1|1,mid+1,r,add[k]);
	add[k]=0;
}
void as(int k,int l,int r,int x,int y,int &tem,int &wwz)
{
	if(x<=l&&y>=r)
	{
		if(tem>=minn[k])
		{
			tem=minn[k];
			wwz=wz[k];	
		}
		return ;
	}
	int mid=(l+r)>>1;
	pushdown(k,l,r,mid);
	if(x<=mid)
		as(k<<1,l,mid,x,y,tem,wwz);
	if(mid+1<=y)
		as(k<<1|1,mid+1,r,x,y,tem,wwz);
	return ;
}
void c(int k,int l,int r,int x,int y,int v)
{
	if(x<=l&&y>=r)
	{
		ad(k,l,r,v);
		return ;
	}
	int mid=(l+r)>>1;
	pushdown(k,l,r,mid);
	if(x<=mid)
		c(k<<1,l,mid,x,y,v);
	if(mid+1<=y)
		c(k<<1|1,mid+1,r,x,y,v);
	if(minn[k<<1]<=minn[k<<1|1])
	{
		minn[k]=minn[k<<1];
		wz[k]=wz[k<<1];
	}
	else
	{
		minn[k]=minn[k<<1|1];
		wz[k]=wz[k<<1|1];
	}
}
void find(int x,int y)
{
	int tem=100010;
	int wwz=0;
	as(1,1,n,x,y,tem,wwz);
	if(tem==0)
	{
		if(wz!=0)
		{
			if(x<=wwz-1)
				find(x,wwz-1);
			if(y>=wwz+1)
				find(wwz+1,y);
		}
	}
	else if(tem!=100010)
	{
		c(1,1,n,x,y,tem);
		ans+=tem;
		if(wz!=0)
		{
			if(x<=wwz-1)
				find(x,wwz-1);
			if(y>=wwz+1)
				find(wwz+1,y);
		}
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	build(1,1,n);
	find(1,n);
	print(ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
