#include<cstdio>
const int MAXN = 100010;
int a[MAXN];
int d[MAXN];
inline int dhy_min(int a,int b){return a<b?a:b;}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	scanf("%d",&n);
	int ans = 0;
	int minn = 999999;
	for(int i = 1;i<=n;i++){
		scanf("%d",&a[i]);
		d[i] = a[i]-a[i-1];	
	}
	for(int i = 1;i<=n;i++){
		if(d[i]>0)ans+=d[i];
	}
	printf("%d\n",ans);
	return 0;
}
