#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int MAXN =  25100;
int a[MAXN];
bool exist[MAXN];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;scanf("%d",&T);
	while(T--){
		memset(a,0,sizeof(a));
		memset(exist,false,sizeof(exist));
		int n;
		scanf("%d",&n);
		for(int i = 1;i<=n;i++){
			scanf("%d",&a[i]);
			for(int j = 1;j*a[i]<=MAXN;j++)exist[j*a[i]] = true;
		}
		int ans =n;
		sort(a+1,a+n+1);
		for(int i = 2;i<=n;i++){
			bool flag = false;
			for(int j = 1;j<i&&flag==false;j++){
				for(int k = 1;k*a[j]<=a[i];k++){
					if(exist[a[i]-k*a[j]]){
						ans--;
						flag = true;
						break;
					}
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
