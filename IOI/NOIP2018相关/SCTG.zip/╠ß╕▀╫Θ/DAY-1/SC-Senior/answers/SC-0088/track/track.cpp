#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int MAXN = 50010;
const int MAXM = MAXN-1;
int read(){
	int x= 0,f = 1;
	char c = getchar();
	while(c<'0'||c>'9') c = getchar();
	while(c>='0'&&c<='9'){
		x = (x<<1)+(x<<3)+c-'0';
		c =  getchar();
	}
	return x*f;
}
struct edge{
	int f,t,w,next;
}edges[MAXM*2];
int head[MAXN];
int top;
void add(int f,int t,int w){
	edges[++top].next = head[f];
	edges[top].t = t;
	edges[top].f = f;
	edges[top].w = w;
	head[f] = top;
}
int dis[MAXN];
bool vis[MAXN];
void dfs(int x,int w){
	vis[x] = true;
	dis[x] = w;
	for(int i = head[x];i!=0;i = edges[i].next){
		int t = edges[i].t;
		if(!vis[t]){
			dfs(t,w+edges[i].w);
		}
	}
}
int main(){
	int n,m;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n = read();
	m = read();
	int f,t,w;
	for(int i = 1;i<n;i++){
		f =read(),t = read(),w = read();
		add(f,t,w);
		add(t,f,w);
	}
	int ans = 0;
	if(m==1){
		int temp = 0;
		for(int i = 1;i<=n;i++){
			memset(vis,false,sizeof(vis));
			memset(dis,0,sizeof(dis));
			dfs(i,0);
			for(int j = 1;j<=n;j++){
				temp = max(temp,dis[j]);
			}
			ans = max(ans,temp);
		}
		printf("%d",ans);
	}
	return 0;
}
