#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<queue>
using namespace std;
typedef long long ll;
int n;
ll num[100010],ans=0LL;
template <typename T> inline void in(T &a)
{
	T ch=getchar(),f=1;
	for(a=0;!isdigit(ch);ch=getchar()) ch=='-'?f=-1:f=f;
	for(;isdigit(ch);ch=getchar()) a=(a<<3)+(a<<1)+ch-'0';
	a*=f;
}
int main()
{
	freopen("road.in","r",stdin); freopen("road.out","w",stdout);
	scanf("%d",&n);
	num[0]=0LL;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&num[i]);
		if(num[i]>num[i-1]) ans+=num[i]-num[i-1];
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
