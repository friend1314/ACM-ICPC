#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int t;
int n,a[110],mark[25100],maxn,ans;
void pre()
{
	memset(a,0,sizeof(a));
	memset(mark,0,sizeof(mark));
	maxn=0;ans=0;
}
int main()
{
	freopen("money.in","r",stdin); freopen("money.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		pre();
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		maxn=a[n];
		for(int i=1;i<=n;i++)
		{
			if(mark[a[i]]>=1) continue;
			mark[a[i]]=1;
			for(int j=1;j<=maxn;j++)
			{
				if(j+a[i]>maxn) break;
				if(mark[j])	mark[a[i]+j]=max(mark[a[i]+j],mark[j]+1);
			}
		}
		for(int i=1;i<=maxn;i++)
		{
		//	cout<<i<<" "<<mark[i]<<endl;
			if(mark[i]==1) ans++;
		}
		printf("%d\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
