#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
int n,m,cnt,maxlen,minlen,sumlen,tot;
int head[50010],nxt[100010],to[100010],cost[100010],dep[50010];
int dui[50010];
template <typename T> inline void in(T &a)
{
	T ch=getchar(),f=1;
	for(a=0;!isdigit(ch);ch=getchar()) ch=='-'?f=-1:f=f;
	for(;isdigit(ch);ch=getchar()) a=(a<<3)+(a<<1)+ch-'0';
	a*=f;
}
void add(int fa,int too,int val)
{
	cnt++;
	nxt[cnt]=head[fa];
	head[fa]=cnt;
	to[cnt]=too;
	cost[cnt]=val;
}
void dfs1(int x,int fa)
{
	int res1=0,res2=0;
	for(int j=head[x];j;j=nxt[j])
	{
		if(to[j]==fa) continue;
		dfs1(to[j],x);
		dep[x]=max(dep[x],dep[to[j]]+cost[j]);
		if(dep[to[j]]+cost[j]>=res1) res2=res1,res1=dep[to[j]]+cost[j];
		else if(dep[to[j]]+cost[j]>res2 && dep[to[j]]+cost[j]<res1)
		{
			res2=dep[to[j]]+cost[j];
		}
	}
	maxlen=max(maxlen,res1+res2);
}
void work1()
{
	dfs1(1,0);
	printf("%d\n",maxlen);
}
void dfs2(int x,int fa)
{
	for(int j=head[x];j;j=nxt[j])
	{
		if(to[j]==fa) continue;
		dui[++tot]=cost[j];
		dfs2(to[j],x);
	}
}
bool pd(int x)
{
	int tim=0,res=0;
	for(int i=1;i<n;i++)
	{
		res+=dui[i];
		if(res>=x) tim++,res=0;
	}
	if(tim>=m) return 1;
	return 0;
}
void work2()
{
	dfs2(1,0);
	int l=1,r=sumlen;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(pd(mid)) l=mid+1;
		else r=mid-1;
	}
	printf("%d\n",r);
}
void work3()
{
	for(int j=head[1];j;j=nxt[j])
	{
		dui[++tot]=cost[j];
	}
	sort(dui+1,dui+tot+1);
	for(int i=m,l,r;i>=0;i--)
	{
		if(2*m-i>n-1) break;
		l=n-2*m+i,r=n-i-1;
		minlen=0x7fffffff;
		if(i!=0) minlen=dui[n-i];
		while(l<=r)
		{
			minlen=min(minlen,dui[l]+dui[r]);
			l++;r--;
		}
		maxlen=max(maxlen,minlen);
	}
	printf("%d\n",maxlen);
}
int main()
{
	freopen("track.in","r",stdin); freopen("track.out","w",stdout);
	in(n),in(m);
	int jd1=1,jd2=1;
	for(int i=1;i<n;i++)
	{
		int x,y,z;
		in(x),in(y),in(z);
		sumlen+=z;
		if(x!=y+1 && y!=x+1) jd1=0;
		if(x!=1 && y!=1) jd2=0;
		add(x,y,z),add(y,x,z);
	}
	if(m==1) work1();
	else if(jd1) work2();
	else if(jd2) work3();
	fclose(stdin); fclose(stdout);
	return 0;
}
