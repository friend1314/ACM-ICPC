#include<bits/stdc++.h>
using namespace std;

const int maxn=100000+10;
int n;
int num[maxn];
long long sum;
int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d",&n);
	scanf("%d",&num[1]);
	sum+=num[1];
	for(int i=2;i<=n;i++) {
		scanf("%d",&num[i]);
		sum+=num[i];
		sum-=min(num[i],num[i-1]);
	}
	printf("%lld",sum);
	
	
	
	return 0;
}
