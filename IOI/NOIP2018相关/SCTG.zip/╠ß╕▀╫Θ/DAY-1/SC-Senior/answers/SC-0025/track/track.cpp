#include<bits/stdc++.h>
using namespace std;

const int maxn=50000+10;

struct line {
	int v,w,next;
}e[maxn<<1];
int head[maxn],cnt;
void link(int u,int v,int w) {e[++cnt]=(line){v,w,head[u]};head[u]=cnt;}

int n,m;
int from[maxn];
int dfs(int u,int fa) {
	int maxx=0;
	for(int i=head[u];i;i=e[i].next) {
		int v=e[i].v;
		if(v==fa) continue;
		int tmp=dfs(v,u);
		if(tmp+e[i].w>maxx) {
			maxx=tmp+e[i].w;
			from[u]=v;
		}
	}
	return maxx;
}

void longestString() {
	dfs(1,0);
	int st=1;
	while(from[st]) st=from[st];
	printf("%d\n",dfs(st,0));
}

long long frt[50001];

bool check(int x) {
	int las=0,cunt=0;
	for(int i=1;i<n;i++) {
		if(frt[i]-frt[las]>=x) {
			cunt++;
			las=i;
		}
	}
	return cunt>=m;
}

void erfen() {
	for(int i=1;i<n;i++) {
		int a=head[i];
		while(e[a].v!=i+1) a=e[a].next;
		frt[i]=frt[i-1]+e[a].w;
	}
	long long l=0,r=frt[n-1],ans=0;
	
	while(r>=l) {
//		printf("%lld %lld \n",l,r);
		long long mid=(l+r)>>1;
		if(check(mid)) l=mid+1,ans=mid;
		else r=mid-1;
	}
	printf("%d",l);
}

void ssss() {
	int ccnt=0;
//	printf("adfsa\n");
	for(int i=head[1];i;i=e[i].next) frt[++ccnt]=e[i].w;
	sort(frt+1,frt+n);
	for(int i=1;i<n;i++) frt[i]+=frt[i-1];
	long long l=0,r=frt[n-1];
	int ans;
	while(r>=l) {
//		printf("l:%lld r:%lld %d\n",l,r,(int)r>l);
		long long mid=(l+r)>>1;
		if(check(mid)) l=mid+1,ans=mid;
		else r=mid-1;
	}
	printf("%d",ans);
}

int main() {
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	bool shiyitiaolian=1,juhuatu=1;
	for(int i=1;i<n;i++) {
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		if(u!=v+1&&v!=u+1) shiyitiaolian=0;
		if(u!=1&&v!=1) juhuatu=0;
		link(u,v,w);link(v,u,w);
	}
	
	if(m==1) longestString();
	else if(shiyitiaolian) erfen();
	else if(juhuatu) ssss();
	return 0;
}
/*
5 2
1 2 1
1 3 2
1 4 3
1 5 4
*/
