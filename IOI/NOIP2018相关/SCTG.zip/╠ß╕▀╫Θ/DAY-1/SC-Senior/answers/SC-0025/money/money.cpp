#include<bits/stdc++.h>
using namespace std;

int n;

int num[201];
int dp[50001];

int ans;

void work() {
	ans=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&num[i]);
	
	sort(num+1,num+1+n);
	
	dp[0]=1;
	for(int i=1;i<=num[n];i++) dp[i]=0;
	
	for(int i=1;i<=n;i++) {
		if(!dp[num[i]]) {
			ans++;
			for(int j=0;j+num[i]<=num[n];j++)
				if(dp[j])
					dp[j+num[i]]=1;
		}
	}
	
	printf("%d\n",ans);
	
}

int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	
	int T;
	scanf("%d",&T);
	while(T--) work();
	return 0;
}
