#include <bits/stdc++.h>
#define ll long long
#define R(a,b,c) for(int a=b;a<=c;a++)
#define rg register 
using namespace std;
const int maxn=100005;
const int maxm=10005;
int d[maxn],sum,done;
bool  flag[maxn];
template <typename TT> inline void read (TT & x)
{
	x=0;rg char c=getchar();int f=1;
	while(c>'9' || c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0' && c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x=x*f;
}
inline void print(ll x)
{
	if(x<0){putchar('-');x=-x;}
	if(x>=10){print(x/10);}
	putchar(x%10+'0');
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	read(n);
	R(i,1,n)read(d[i]);
	while(done<n)
	{
		int tot=1,minn=maxm;
		for(int i=1;i<=n;i++)//��ɨ�м������� �� ��������minnֵ 
		{
			if(!d[i])
			{
				while(!d[i]&& i<=n)
				{
					if(!flag[i])done++,flag[i]=1;
					i++;
				}
				tot++;minn=min(minn,d[i]);
//				cout<<"done="<<done<<" ";
			}
			else minn=min(minn,d[i]);
		}
		if(!d[1])tot--;if(!d[n])tot--;
		sum+=minn*tot;//�ۼ����� 
////		cout<<"minn="<<minn<<"tot="<<tot<<" ";
		for(int i=1;i<=n;i++)//��ȥminn 
		{
			if(d[i])d[i]-=minn;
//			print(d[i]);cout<<" "; 
		}
//		cout<<endl;
	}
	print(sum);
//	print(done);
}/*6
4 3 2 5 3 5
*/
