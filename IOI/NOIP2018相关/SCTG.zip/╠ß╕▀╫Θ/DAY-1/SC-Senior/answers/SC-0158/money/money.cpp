#include <bits/stdc++.h>
#define ll long long
#define R(a,b,c) for(int a=b;a<=c;a++)
#define rg register 
using namespace std;
int a[1005];
bool check[1005];

template <typename TT> inline void read (TT & x)
{
	x=0;rg char c=getchar();int f=1;
	while(c>'9' || c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0' && c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x=x*f;
}
inline void print(ll x)
{
	if(x<0){putchar('-');x=-x;}
	if(x>=10){print(x/10);}
	putchar(x%10+'0');
}
int main()
{
//	freopen("money.in","r",stdin);
//	freopen("money.out","w",stdout);
	int T,n;read(T);
	while(T--)
	{
		read(n);
		if(n==2)//�Ƚ��Ƿ����� 
		{
			for(int i=1;i<=2;i++)read(a[i]);
			printf("%d\n",(!a[1]%a[2] || !a[2]%a[1])? 1:2);
		}
		else if(n>2 && n<=5)
		{
			for(int i=1;i<=n;i++)read(a[i]);
			stable_sort(a+1,a+n+1);
			int tot=0;
			for(int i=1;i<=n-1;i++)//ȥ�������� 
			{
				for(int j=i+1;j<=n;j++)
					if(a[j]%a[i]==0)
						a[j]=0;
			}
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=n;j++)
				{
					for(int k=1;k<=5;k++)
					{
						for(int l=1;l<=5;l++)
						{
							int now=k*a[i]+l*a[j];
							if(now<1005)check[now]=1;
						}
					}
				}
			}
			for(int i=1;i<=n;i++)
			{
				if(check[a[i]])a[i]=0;
			}
			R(i,1,n)
			{
				if(a[i])tot++;
			}
			printf("%d\n",tot);
	 	}
	}
}/*2
4
3 19 10 6
5
11 29 13 19 17*/
