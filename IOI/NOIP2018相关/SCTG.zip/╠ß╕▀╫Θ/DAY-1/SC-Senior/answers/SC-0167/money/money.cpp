#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;

template <class T_>inline void read(T_&x_){
	int t_;bool flag_=0;
	while((t_=getchar())!='-'&&(t_<'0'||t_>'9'));
	if(t_=='-')flag_=1,t_=getchar();x_=t_-'0';
	while((t_=getchar())<='9'&&t_>='0')x_=x_*10+t_-'0';
	if(flag_)x_=-x_;
}
const int maxn=100+10;
int a[maxn];
int t,n,tot,max_;
int flag[250000];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(t);
	for(int i=1;i<=t;++i){
		tot=0;
		read(n);
		for(int j=1;j<=n;++j)read(a[j]);
		sort(a+1,a+n+1);
		max_=a[n];
		for(int j=1;j<=max_;++j)flag[j]=0;
		for(int j=1;j<=n;++j){
			int h=1;
			while(a[j]*h<=max_){
				flag[a[j]*h]++;
				h++;
			}
			for(int j=1;j<=max_;++j){
				for(int k=1;k<j;++k){
					if(flag[j]&&flag[k])flag[j+k]++;
				}
			}
		}
		for(int j=1;j<=n;++j){
			if(flag[a[j]]>1){
				tot++;
			}
		}
		printf("%d\n",n-tot);
	}
	
	return 0;
}
