#include<cstdio>
#include<queue>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;

template <class T_>inline void read(T_&x_){
	int t_;bool flag_=0;
	while((t_=getchar())!='-'&&(t_<'0'||t_>'9'));
	if(t_=='-')flag_=1,t_=getchar();x_=t_-'0';
	while((t_=getchar())<='9'&&t_>='0')x_=x_*10+t_-'0';
	if(flag_)x_=-x_;
}
const int maxn=50000+10;
struct node{
	int v,c;
	node(){}
	node(int v,int c):v(v),c(c){};
};
vector<node>e[maxn];
int n,m;
int a,b,c[maxn],h[maxn];
int max_,min_=1000000,st,tot1,tot3;

void dfs(int u,int f,int s){
	if(s>max_){
		max_=s;
		st=u;
	}
	int t,sz=e[u].size();
	for(int i=0;i<sz;++i){
		t=e[u][i].v;
		if(t==f)continue;
		dfs(t,u,s+e[u][i].c);
	}
}

void dfs_(int u,int f,int s){
	if(s>max_){
		max_=s;
	}
	int t,sz=e[u].size();
	for(int i=0;i<sz;++i){
		t=e[u][i].v;
		if(t==f)continue;
		dfs_(t,u,s+e[u][i].c);
	}
}

bool cmd(int aa,int bb){
	return aa>=bb;
}

bool check(int mid){
	int tem=0,hh=0;
	for(int i=1;i<n;++i){
		tem+=h[i];
		if(tem>=mid){
			hh++;
			tem=0;
		}
	}
	if(hh>=m)return 1;
	return 0;
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<n;++i){
		read(a),read(b),read(c[i]);
		e[a].push_back(node(b,c[i]));
		e[b].push_back(node(a,c[i]));
		h[a]=c[i];
		tot3+=c[i];
		if(a==1)tot1++;
	}
	if(m==1){
		dfs(1,-1,0);
		max_=0;
		dfs_(st,-1,0);
		printf("%d",max_);	
	}else if(tot1==n-1){
		sort(c+1,c+n,cmd);
		int nn=n,h=0;
		if(m*2>n)while(m*2<nn){
			nn++;
			h++;
		}
		for(int i=1;i<=m;++i){
			min_=min(min_,c[i+h]+c[m*2-i+1+h]);
		}
		printf("%d",min_);
	}else{
		int l=1,r=tot3,mid;
		while(l+1<r){
			mid=(l+r)>>1;
			if(check(mid))l=mid;
			else r=mid; 
		}
		printf("%d",l);
	}
	return 0;
}
