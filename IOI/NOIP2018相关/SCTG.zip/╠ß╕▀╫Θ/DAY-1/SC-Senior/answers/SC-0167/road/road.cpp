#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>

using namespace std;

template <class T_>inline void read(T_&x_){
	int t_;bool flag_=0;
	while((t_=getchar())!='-'&&(t_<'0'||t_>'9'));
	if(t_=='-')flag_=1,t_=getchar();x_=t_-'0';
	while((t_=getchar())<='9'&&t_>='0')x_=x_*10+t_-'0';
	if(flag_)x_=-x_;
}

const int maxn=100000+10;
const int inf_=999999;

int a_[maxn];
int n_,cnt_,ans_,min_=inf_;

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n_);
	for(int i=1;i<=n_;++i){
		read(a_[i]);
		min_=min(min_,a_[i]);
	}
	for(int i=1;i<=n_;++i){
		a_[i]-=min_;
	}
	ans_+=min_;
	for(int i=1;i<=n_;++i){
		min_=inf_;
		int j=i;
		while(a_[j]>0){
			while(a_[j]>0){
				min_=min(min_,a_[j]);
				j++;
			}
			for(int k=i;k<=j;++k){
				a_[k]-=min_;
			}
			ans_+=min_;
			j=i;
		}
	}
	printf("%d",ans_);
	return 0;
}
