#include <iostream>
#include <algorithm>
#include <cstdio>
#define N 100100
using namespace std;
int n,ans,pos;
int num[N]={0};
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d",&n);
    for(int i = 1;i <= n;i++)
        scanf("%d",&num[i]);
    ans=num[1];
    for(int i = 2;i <= n;i++)
    {
       if(num[i]>num[i-1])
       {
           pos=num[i]-num[i-1];
           ans+=pos;
       }
    }
    printf("%d",ans);
    return 0;
}
