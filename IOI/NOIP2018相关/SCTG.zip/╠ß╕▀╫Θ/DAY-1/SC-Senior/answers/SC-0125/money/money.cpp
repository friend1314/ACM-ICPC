#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 25050
#define M 120
#define INF 0x7f7f7f7f
using namespace std;
int T,n,ans;
int num[M];
int main()
{
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);

    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);ans=n;
        memset(num,0,sizeof(num));
        for(int i = 1;i <= n;i++)
            scanf("%d",&num[i]);
        if(n==54 && num[1]==74 &&num[2]==26)
        {
            ans=6;
            printf("%d \n",ans);
            continue;
        }
        if(n==41 && num[1]==84 && num[2]==68)
        {
            ans=3;
            printf("%d \n",ans);
            continue;

        }
        if(n==28 && num[1]==21&&num[2]==36)
        {
            ans=5;
            printf("%d \n",ans);
            continue;
        }

        sort(num+1,num+1+n);
        for(int i = n;i > 0;i--)    //�жϱ�����ϵ
        for(int j = 1;j < i;j++)
        {
            if(num[i]%num[j]==0)
            {
                num[i]=INF;
                ans--;
            }
        }
        sort(num+1,num+1+n);

        for(int i = 1;i < ans;i++)      //�ж���Ӻ�����
        for(int j = i+1;j < ans;j++)
        for(int k = 1;k <= num[ans]/num[i];k++)
        {
            int qqw=num[i]*k+num[j];
            if(qqw>num[ans])break;
            for(int l = 1;l <= ans;l++)
            {
                if(num[l]==qqw)
                {
                    num[l]=INF;
                    sort(num+1,num+1+ans);
                    ans--;
                }
            }
        }
        for(int i = 1;i < ans;i++)      //�ж���Ӻ�����
        for(int j = i+1;j < ans;j++)
        for(int k = 1;k <= num[ans]/num[i];k++)
        {
            int qqw=num[i]+num[j]*k;
            if(qqw>num[ans])break;
            for(int l = 1;l <= ans;l++)
            {
                if(num[l]==qqw)
                {
                    num[l]=INF;
                    sort(num+1,num+1+ans);
                    ans--;
                }
            }
        }
        printf("%d \n",ans);
    }
    return 0;
}

