#include<iostream>
using namespace std;
int main()
{	int answer,check(1),check0;
	int num;
	cin>>num;
	int c[10000];
	for(int i=0;i<num;i++){
		cin>>c[i];
	}
	for(int i=0;check!=num;i++){
		check=0;
		for(int hj=0;i<num;hj++){
			if(c[hj]!=0){
				c[hj]--;
				check0=0;
			}
			else 
			{
				if(c[hj]==0){
				if(check0==0)
				{
				answer++;
				check0=1;
			}
				}
			}
		}
	for(int ch=0;ch<num;ch++){
		{
		check++;	
		}
	}
	check0=1;
	}
	cout<<answer;
}

