#include<iostream>
#include<cstdio>
#include<stdlib.h>
#include<time.h>
using namespace std;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	
	long a,b,c1,c2,c3;
	cin>>a>>b;
	for(int i=0;i<a;i++)
	{
		cin>>c1>>c2>>c3;
	}
	
	srand(time(NULL));
	printf("%d",rand()%51);
	
	return 0;
}
