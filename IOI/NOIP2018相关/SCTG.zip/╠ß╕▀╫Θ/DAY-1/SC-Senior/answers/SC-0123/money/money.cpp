#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	
	long hbxts,hbxt[101][101],mes[101],daan[101],px,qy,ecqy;
	cin>>hbxts;
	for(int i=0;i<hbxts;i++)
	{
		cin>>mes[i];
		daan[i]=mes[i];
		for(int j=0;j<mes[i];j++)
		{
			cin>>hbxt[i][j];
		}
	}
	
	for(int i=0;i<hbxts;i++)
	{
		for(int j=0;j<mes[i];j++)
		{
			for(int k=j+1;k<mes[i];k++)
			{
				if(hbxt[i][k]<hbxt[i][j])
				{
					px=hbxt[i][j];
					hbxt[i][j]=hbxt[i][k];
					hbxt[i][k]=px;
				}
			}
		}
	}
	
	for(int i=0;i<hbxts;i++)
	{
		for(int j=mes[i]-1;j>=0;j--)
		{
			if(j==0) break;
			for(int k=0;k<j;k++)
			{
			    qy=hbxt[i][j]%hbxt[i][k];
				if(qy!=0)
				{
					for(int l=0;l<j;l++)
					{
						ecqy=qy%hbxt[i][l];
						if(ecqy==0) break;
					}
				}
				if(qy==0||ecqy==0)
				{
					daan[i]--;
					break;
				}
			}
		}
	}
	
	for(int i=0;i<hbxts;i++)
	{
		if(i==hbxts-1) cout<<daan[i];
		else cout<<daan[i]<<endl;
	}
	
	return 0;
}
