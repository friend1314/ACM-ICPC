#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long qys,qy[100001],xzmax,daan=0;
	cin>>qys;
	for(int i=0;i<qys;i++)
	{
		cin>>qy[i];
	}
	xzmax=qy[0];
	daan+=xzmax;
	for(int i=1;i<qys;i++)
	{
		if(qy[i]<xzmax) xzmax=qy[i];
		else if(qy[i]>xzmax)
		{
			daan+=qy[i]-xzmax;
			xzmax=qy[i];
		}
	}
	cout<<daan;
	return 0;
}
