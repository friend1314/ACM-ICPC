#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<cmath>
#include<ctime>
#include<cctype>
#include<algorithm>
#define N 200005
#define inf 0x3fffffff 
#define LL long long 
using namespace std;
int n,a[N],pos[N<<2]; LL ans;
struct Node{
	int l,r,val,tag;
}t[N<<2];
int read(){
	int cnt=0,f=1;char ch=0;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))cnt=cnt*10+(ch-'0'),ch=getchar();
	return cnt;
}
void Pushdown(int x){
	if(t[x].tag){
		t[x<<1].val += t[x].tag;
		t[x<<1|1].val += t[x].tag;
		t[x<<1].tag += t[x].tag;
		t[x<<1|1].tag += t[x].tag;
		t[x].tag=0;
	}
}
void Pushup(int x){
	if(t[x<<1].val < t[x<<1|1].val) t[x].val = t[x<<1].val , pos[x]=pos[x<<1];
	else t[x].val = t[x<<1|1].val , pos[x]=pos[x<<1|1];
}
void build(int x,int l,int r){
	t[x].l=l,t[x].r=r;
	if(l==r){t[x].val=a[l],pos[x]=l;return;}
	int mid=(l+r)>>1;
	build(x<<1,l,mid),build(x<<1|1,mid+1,r);
	Pushup(x);
}
int quary(int x,int L,int R,int &P){
	if(L<=t[x].l && t[x].r<=R){
		if(a[pos[x]]<a[P]) P=pos[x];
		return t[x].val;
	}
	Pushdown(x);
	int mid=(t[x].l+t[x].r)>>1 , ans=inf;
	if(L<=mid) ans=min(ans,quary(x<<1,L,R,P));
	if(R>mid) ans=min(ans,quary(x<<1|1,L,R,P));
	return ans;
}
void Update(int x,int L,int R,int val){
	if(L<=t[x].l && t[x].r<=R){
		t[x].val += val; t[x].tag += val;
		return;
	}
	int mid=(t[x].l+t[x].r)>>1;
	if(L<=mid) Update(x<<1,L,R,val);
	if(R>mid) Update(x<<1|1,L,R,val);
	Pushup(x);
}
void divide(int L,int R){
	if(L>R) return;
	int Pos=0 , x=quary(1,L,R,Pos); 
	ans += x;
	Update(1,L,R,-x);
	divide(L,Pos-1);
	divide(Pos+1,R);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n=read(); a[0]=inf;
	for(int i=1;i<=n;i++) a[i]=read();
	build(1,1,n); divide(1,n); 
	printf("%lld",ans);
	return 0;
}
