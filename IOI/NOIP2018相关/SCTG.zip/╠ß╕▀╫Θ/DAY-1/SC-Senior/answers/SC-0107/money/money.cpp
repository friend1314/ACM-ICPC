#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<cmath>
#include<ctime>
#include<cctype>
#include<algorithm>
#define N 205
using namespace std;
int T,n,a[N],s[N],ans,top,flag;
int read(){
	int cnt=0,f=1;char ch=0;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))cnt=cnt*10+(ch-'0'),ch=getchar();
	return cnt;
}
void dfs(int x){
	if(flag) return;
	if(x<0) return;
	if(x==0){flag=1;return;}
	for(int i=top;i>=1;i--){
		if(x%s[i]==0){flag=1;return;}
		dfs(x-s[i]);
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--){
		n=read(); top=0; ans=0;
		for(int i=1;i<=n;i++) a[i]=read();
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++){
			flag=0,dfs(a[i]);
			if(!flag) ans++,s[++top]=a[i];
		}
		printf("%d\n",ans);
	}
	return 0;
}
