#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<string>
#include<cmath>
#include<ctime>
#include<cctype>
#include<algorithm>
#define N 100005
#define M N*2
#define inf 0x3fffffff
using namespace std;
int first[N],nxt[M],to[M],w[M],tot;//***nxt
int n,m,Min=inf;
int dis[N],p1,p2,ans,vis[N];//Solve1
int flag1=1,flag2=1;//Solve2 Solve3
int read(){
	int cnt=0,f=1;char ch=0;
	while(!isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(isdigit(ch))cnt=cnt*10+(ch-'0'),ch=getchar();
	return cnt;
}
void add(int x,int y,int z){
	nxt[++tot]=first[x],first[x]=tot,to[tot]=y,w[tot]=z;
}
void dfs(int u,int f){
	for(int i=first[u];i;i=nxt[i]){
		int t=to[i]; if(t==f) continue;
		dis[t]=dis[u]+w[i];
		if(dis[t]>dis[p1]) p1=t;
		dfs(t,u);
	}
}
void dfs2(int u,int D){
	vis[u]=1; ans=max(ans,D);
	for(int i=first[u];i;i=nxt[i]){
		int t=to[i]; if(vis[t]) continue;
		dfs2(t,D+w[i]);
	}
}
void Solve1(){
	dfs(1,0); dfs2(p1,0); printf("%d",ans);
}
void Solve2(){
	dfs(1,0); 
	sort(dis+1,dis+n+1);
	int ans=inf;
	if(m*2<=n-1){
		for(int i=n-m*2+1;i<=n;i++) 
			ans=min(ans,dis[i]+dis[n*2-m*2+1-i]);
	}
	else{
		int len=m*2-n+1;//alone 
		int pair=n-len-1;
		for(int i=2;i<=pair+1;i++) ans=min(ans,dis[i]+dis[pair+3-i]);
		ans=min(ans,dis[pair+2]);
	}
	printf("%d",ans);
}
bool pd(int x){
	int last=0,cnt=0,now=1;
	while(now<=n){
		for(now=last+1;now<=n;now++){
			if(dis[now]-dis[last]>=x) {last=now,cnt++;break;}
		}
	}
	return cnt>=m;
}
void Solve3(){
	dfs(1,0);
	int l=1,r=50000*10000;
	while(l<r){
		int mid=(l+r+1)>>1;
		if(pd(mid)) l=mid;
		else r=mid-1;
	}printf("%d",l);
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++){
		int x=read(),y=read(),z=read();
		Min=min(Min,z); 
		if(x!=1) flag1=0;
		if(y!=x+1) flag2=0;
		add(x,y,z),add(y,x,z);
	}
	if(m==n-1) {printf("%d",Min);return 0;}
	if(m==1) {Solve1(); return 0;}
	if(flag1==1) {Solve2();return 0;}
	if(flag2==1) {Solve3();return 0;} 
	cout<<"223206";//loving you forever 
	return 0;
}
