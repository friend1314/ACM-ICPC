#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<map>
using namespace std;
int d[100005]={0};
int n;
int Min(int x,int y);
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int v=1;v<=n;v=v+1)
	{
		cin>>d[v];
	}
	cout<<Min(1,n);
	return 0;
}
int Min(int x,int y)
{
	int z;
	int min=20000;
	for(int v=x;v<=y;v=v+1)
	{
		if(d[v]<=min)
		{
			min=d[v];
			z=v;
		}
	}
	for(int w=x;w<=y;w=w+1)
	d[w]=d[w]-min;
	if(x==z)
	{
		if(x==y) return min;
		else return Min(z+1,y)+min;
	}
	else if(y==z)
	{
		return Min(x,z-1)+min;
	}
	else return Min(x,z-1)+Min(z+1,y)+min;
}
