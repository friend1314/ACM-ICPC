#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<map>
using namespace std;
int n;
int a[110];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	cin>>T;
	for(int v=1;v<=T;v=v+1)
	{
		memset(a,0,sizeof(a));
		cin>>n;
		for(int w=1;w<=n;w=w+1)
		cin>>a[w];
		if(n==2)
		{
			if(a[2]>=a[1]&&a[2]%a[1]==0) cout<<1<<endl;
			else if(a[1]>=a[2]&&a[1]%a[2]==0) cout<<1<<endl;
			else cout<<2<<endl;
		}
	}
	return 0;
}
