#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<map>
using namespace std;
int a[50005],b[50005],c[50005];
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<=n-1;i=i+1)
	{
		cin>>a[i]>>b[i]>>c[i];
	}
	cout<<a[1]+a[2]+a[3];
	return 0;
}
