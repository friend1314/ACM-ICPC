#include <bits/stdc++.h>
using namespace std;
#define N 110
#define M 1000010
int a[N];
int f[M],is[M];
void work() {
    memset(f,0,sizeof(f));
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    sort(a+1,a+n+1);
    int Max=a[n],ans=n;
    f[0]=1;
    for(int i=1;i<=n;i++) {
        if(f[a[i]]) {
            ans--;
            continue;
        }
        for(int j=0;j<=Max-a[i];j++) {
            if(f[j]) f[j+a[i]]=1;
        }
    }
    printf("%d\n",ans);
}
int main() {
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    int T;
    scanf("%d",&T);
    while(T--) work();
}
