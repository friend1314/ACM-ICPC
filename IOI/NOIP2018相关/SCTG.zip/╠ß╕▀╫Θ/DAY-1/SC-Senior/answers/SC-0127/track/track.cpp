#include <bits/stdc++.h>
using namespace std;
#define N 100010
struct Edge {
    int u,v,w,nxt;
    Edge(int _u=0,int _v=0,int _w=0) : u(_u),v(_v),w(_w) {}
}e[N];
int cnt=0,head[N];
void add(int u,int v,int w) {
    e[++cnt].u=u,e[cnt].v=v,e[cnt].w=w,e[cnt].nxt=head[u],head[u]=cnt;
    e[++cnt].v=u,e[cnt].u=v,e[cnt].w=w,e[cnt].nxt=head[v],head[v]=cnt;
}
int S[N],tot,Use[N];
void dfs(int pos,int pre,int sum) {
    S[pos]=0;
    int son=-1;
    vector<int> tmp;
    for(int i=head[pos];i!=-1;i=e[i].nxt) {
        if(e[i].v==pre) continue;
        dfs(e[i].v,pos,sum);
        son++;
        tmp.push_back(S[e[i].v]+e[i].w);

    }
    for(int i=0;i<=son;i++) Use[i]=0;
    sort(tmp.begin(),tmp.end());
    if(son==-1) return;
    int l=0,r=son;
    for(int j=son;j>=0;j--) {
        if(tmp[j]>=sum) {
            tot++,Use[j]=1;
        }
    }
    for(int i=0;i<=son;i++) {
        if(Use[i]) continue;
        for(int j=i+1;j<=son;j++) {
            if(Use[j]) continue;
            if(tmp[i]+tmp[j]>=sum) {
                tot++,Use[i]=Use[j]=1;
                break;
            }
        }
    }
    for(int i=son;i>=0;i--) {
        if(Use[i]) continue;
        S[pos]=tmp[i];
        break;
    }

}
int check(int sum,int m) {
    tot=0;
    dfs(1,1,sum);
    if(tot>=m) return 1;
    return 0;
}
int main() {
    freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    int n,m;
    scanf("%d%d",&n,&m);
    memset(head,-1,sizeof(head));
    int l=0,r=0;
    for(int i=1;i<n;i++) {
        int u,v,w;
        scanf("%d%d%d",&u,&v,&w);
        r+=w;
        add(u,v,w);
    }
    //check(26282,108);
    //return 0;
    r++;
    int mid=(l+r)>>1;
    while(r>(l+1)) {
        mid=(l+r)>>1;
        if(check(mid,m)) {
            l=mid;
        } else r=mid;
    }
    printf("%d\n",l);
}
