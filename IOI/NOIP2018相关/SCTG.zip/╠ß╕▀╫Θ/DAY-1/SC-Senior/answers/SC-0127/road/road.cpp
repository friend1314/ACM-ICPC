#include <bits/stdc++.h>
using namespace std;
#define N 100010
pair<int,int> a[N];
int is[N];
int main() {
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n;
    scanf("%d",&n);
    is[0]=is[n+1]=1;
    a[0]=make_pair(0,0);
    for(int i=1;i<=n;i++) scanf("%d",&a[i].first),a[i].second=i;
    sort(a,a+n+1);
    int ans=0,num=1;
    for(int i=1;i<=n;i++) {
        ans+=num*(a[i].first-a[i-1].first);
        is[a[i].second]=1;
        if(is[a[i].second-1]&&is[a[i].second+1]) {num--;continue;};
        if(is[a[i].second-1]||is[a[i].second+1]) continue;
        num++;
    }
    printf("%d",ans);
}
