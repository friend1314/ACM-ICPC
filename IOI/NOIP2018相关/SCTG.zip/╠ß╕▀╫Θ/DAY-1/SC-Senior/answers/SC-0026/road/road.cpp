#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstdio>
using namespace std;
int n,ini,inj,ans=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	cin>>ini;
	for(int i=1;i<n;i++){
		cin>>inj;
		if(inj<ini)	ans+=ini-inj;
		ini=inj;
	}
	cout<<ans+ini;
	return 0;
	fclose(stdin);
	fclose(stdout);
}

