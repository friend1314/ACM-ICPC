#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstdio>
using namespace std;
#define MAXN 103
#define MAXA 25001
int determination,n,toriel,cls=0;
int x[MAXA]={0},cs[MAXN];
int ajm(int a,int b){
	int m=a,n=b,k;
	do{
		k=m%n;
		m=n;n=k;
	}while(k!=0);
	return m;
}
void qc(){
	int alphys,undyne;
	for(int i=2;i<=MAXA/cs[cls-1];i++)	x[cs[cls-1]*i]=-1;
	if(cls>1)	for(int i=0;i<cls-1;i++){
		alphys=ajm(cs[cls-1],cs[i]);
		undyne=(cs[cls-1]/alphys-1)*(cs[i]/alphys-1)-1;
		for(int frisk=undyne;frisk<=MAXA/alphys;frisk++)	x[frisk*alphys]=-1;
		for(int frisk=0;frisk<undyne*alphys;frisk++){
			if(x[frisk]==1||x[frisk]==-1)	for(int i=2;(i-1)*frisk+cs[cls-1]<undyne*alphys;i++)	for(int j=1;j<i;j++)	x[j*frisk+(i-j)*cs[cls-1]]=-1;
		}
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>determination;
	for(int dth=0;dth<determination;dth++){
		cin>>n;
		for(int i=0;i<n;i++){
			cin>>toriel;
			x[toriel]=1;
		}
		for(int i=1;i<MAXA;i++){
			if(x[i]==1){
				cs[cls]=i;
				cls++;
				qc();
			}
		}
		cout<<cls<<endl;
		for(int i=0;i<MAXA;i++) x[i]=0;
		cls=0;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
