#include <iostream>
#include <cstdio>
using namespace std;
int graph[2000][2000];
int main()
{
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	int m, n;
	int ans = 0;
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n-1; i++)
	{
		int a, b, c;
		scanf("%d%d", &a, &b);
		scanf("%d", &c);
		graph[a][b] = c;
		ans+= c;
	}
	printf("%d", ans-10);
	return 0;
}
