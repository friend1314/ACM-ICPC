#include <iostream>
#include <cstdio>
#include <vector>
using namespace std;
int a[100007];
vector<int> rea[10007];
int main()
{
	int buf = 0;
	int ans = 0;
	int maxn = -99;
	int room = 1;
	
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n;
	scanf("%d", &n);
	a[0] = 0;
	a[n+1] = 0;
	for(int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
		if(a[i] >= maxn)
		{
			maxn = a[i];
		}
		rea[a[i]].push_back(i);
	}
	for(int i = 1; i <= maxn; i++)
	{
		if(rea[i].empty()) continue;
		ans+=room*(i-buf);
		buf = i;
		int sizea = rea[i].size();
		for(int j = 0; j < sizea; j++)
		{
			a[rea[i][j]] = 0;
			if(a[rea[i][j] - 1] != 0 && a[rea[i][j] + 1] != 0)
				room++;
			if(a[rea[i][j] - 1] == 0 && a[rea[i][j] + 1] == 0)
				room--;
		}
	}
	printf("%d", ans);
	return 0;
}

