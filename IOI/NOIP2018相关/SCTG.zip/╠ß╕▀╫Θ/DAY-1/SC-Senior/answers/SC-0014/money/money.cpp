#include <cstdio>
#include <iostream>
#include <algorithm>
using namespace std;
int a[105] = {0};
int n;
int k;
int flag = 0;
int sum = 0;
void find(int now, int pre, int value)
{
	int times = value/a[now];
	for(int i = 0; i <= times; i++)
	{
		if(pre + a[now]*i > value) break;
		if(pre + a[now]*i == value) flag = 1;	
	}
	for(int i = 0; i <= times; i++)
	{
		if(now+1 < k)
			find(now+1, pre+a[now]*i, value);
	}	
}
int main()
{
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--)
	{
		sum = 0;
		scanf("%d", &n);
		for(int i = 1; i <= n; i++)
		{
			scanf("%d", &a[i]);
		}
		sort(a+1, a+1+n);
		for(k = n; k >= 2; k--)
		{
			flag = 0;
			find(1, 0, a[k]);
			if(flag) sum++;
		}
		n-=sum;
		printf("%d\n", n);
	}
	return 0;
}
