#include<iostream>
#include<cstdio>
using namespace std; 
inline int read(int &x)
{
	int f=1;
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1,c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+(c^48),c=getchar();}
	return f*x;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t,a[10001],b[1001];
	read(t);
	for(int i=0;i<t;i++)
	{read(b[i]);
	for(int j=0;j<b[i];j++)
	read(a[j]);
	}
	for(int i=0;i<t;i++)
	printf("%d",b[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
