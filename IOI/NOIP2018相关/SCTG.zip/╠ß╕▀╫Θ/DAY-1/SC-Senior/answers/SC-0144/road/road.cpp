#include<cstdio>
int n,a[100001],cont=0;
inline int read(int &x)
{
	int f=1;
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1,c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+(c^48),c=getchar();}
	return f*x;
}
int main()
{
freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
	read(n);
	for(int i=0;i<n;i++)
	{
	read(a[i]);
	}
	for(int i=0;i<n;i++)
	{
		while(a[i])
		{
		cont++;
		for(int j=i;j<n;j++)
		if(a[j])
		a[j]--;
		else
		break;
		}
	}
	printf("%d\n",cont);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
