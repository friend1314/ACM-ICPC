#include<cstdio>
inline int read(int &x)
{
	int f=1;
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1,c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+(c^48),c=getchar();}
	return f*x;
}
int n,m,max=0;

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n); read(m);
	for(int i=0;i<n-2;i++)
	{int q,w,l;
		read(q);read(w);read[l];
		max+=l;
	}
	printf("%d",max);
	fclose(stdin);
	fclose(stdout);
	return 0;
}


