#include<bits/stdc++.h>
using namespace std;
typedef long long ll; 
inline int read(){
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')ch=getchar();
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
	return x;
}
int a[100011],n;
ll dfs(int l,int r,int m){
	if(l>=r){return a[l]-m;}
	int minn=0x7fffffff;
	for(int i=l;i<=r;i++){
		if(minn>a[i])minn=a[i];
	}
	ll ans=minn-m,lt=l;
	for(int i=l;i<=r;i++){
		if(a[i]==minn){
			ans+=dfs(lt,i-1,minn);
			lt=i+1;
		}
	}
	if(a[r]==minn)return ans;
	ans+=dfs(lt,r,minn);
	return ans;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)a[i]=read();
	printf("%lld",dfs(1,n,0));
	return 0;
}
/*6
4 3 2 5 3 5*/
