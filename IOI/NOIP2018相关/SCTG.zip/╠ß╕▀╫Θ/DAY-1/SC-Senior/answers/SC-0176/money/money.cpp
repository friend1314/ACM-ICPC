#include<bits/stdc++.h>
using namespace std;
int t,n;
int a[105];
bool f[105];
bool check(int k,int id){
	if(k==0)return true;
	bool ans=false;
	for(int i=1;a[i]<=k&&i<id;i++){
		ans|=check(k-a[i],id);
	}
	return ans;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t--){
		memset(f,0,sizeof(f));
		cin>>n;
		int tot=n;
		for(int i=1;i<=n;i++)cin>>a[i];
		sort(a+1,a+n+1);
		for(int k=2;k<=n;k++)
			if(!f[k]&&check(a[k],k)){
				tot--;
				f[k]=true;
			}
		cout<<tot<<"\n";
	}
	return 0;
}
/*2
4
3 19 10 6
5
11 29 13 19 17
*/
