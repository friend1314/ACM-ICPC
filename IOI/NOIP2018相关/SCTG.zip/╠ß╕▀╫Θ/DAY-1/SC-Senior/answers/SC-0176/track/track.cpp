#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0;
	char ch=getchar();
	while(ch>'9'||ch<'0')ch=getchar();
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+ch-'0';ch=getchar();}
	return x;
}
int n,m,cnt,flag;
struct edge{
	int v,w,nxt;
}e[100100];
int first[50010];
bool f[50010];
inline void add(int u,int v,int w){
	e[++cnt]=(edge){v,w,first[u]};first[u]=cnt;
}
int dfs(int s){
	int ans=0;
	f[s]=true;
	for(int i=first[s];i;i=e[i].nxt){
		int v=e[i].v;
		if(!f[v]){
			ans=max(ans,dfs(v)+e[i].w);
		}
	}
	f[s]=false;
	return ans;
}
bool g[100100];
int dfs2(int remain,int tot){
	int ans=0;
	if(remain==tot){
		int minn=0x7fffffff;
		for(int i=1;i<=cnt;i+=2){
			if(!g[i]){
				minn=min(minn,e[i].w);
			}
		}
		return minn;
	}
	if(remain==1){
		int maxn=0;
		for(int i=1;i<=cnt;i+=2){
			for(int j=i;j<=cnt;j+=2){
				if(!g[i]&&!g[j]&&i!=j){
					maxn=max(maxn,e[i].w+e[j].w);
				}
			}
		}
		return maxn;
	}
	else {
		for(int i=1;i<=cnt;i+=2){
			for(int j=i;j<=cnt;j+=2){
				if(!g[i]&&!g[j]){
					g[i]=1;g[j]=1;
					ans=max(ans,min(i==j?e[i].w:e[i].w+e[j].w,dfs2(remain-1,tot-2)));
					g[i]=0;g[j]=0;
				}
			}
		}
	}
	return ans;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n-1;i++){
		int u,v,w;
		u=read();v=read();w=read();
		add(u,v,w);add(v,u,w);
		if(u!=1)flag=1;
	}
	if(m==1){
		int maxn=0;
		for(int i=1;i<=n;i++){
			maxn=max(maxn,dfs(i));
		}
		cout<<maxn;
	}
	else if(!flag){
		cout<<dfs2(m,cnt/2);
	}
	else{
		int victini=15;
		cout<<victini;
	}
	return 0;
}
/*7 1
1 2 10
1 3 5
2 4 9
2 5 8
3 6 6
3 7 7*/
