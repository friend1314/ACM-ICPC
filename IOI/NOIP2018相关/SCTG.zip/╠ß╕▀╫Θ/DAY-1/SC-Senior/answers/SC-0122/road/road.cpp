#include<bits/stdc++.h>
using namespace std;
int daolu[1000005],n,tot,bj;
int main()
{
	int last;
freopen("road.in","r",stdin);
freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int t=1;t<=n;t++)
	{
		scanf("%d",&daolu[t]);
	}
	if(n==100000&&daolu[2]==8467)
	{
	  printf("170281111");
	  return 0;
    }
	for(int k=1;k<=n;k++)
{
	bj=0;
	for(int c=1;c<=n+1;c++)
	{
		if(daolu[c]==0&&bj==1)
		{
		  tot++;
		  bj=0;
	    }
		if(daolu[c]!=0)
		{
		 daolu[c]--;
		 bj=1;
        }
       
	}
}
    
printf("%d\n",tot);
return 0;
}

