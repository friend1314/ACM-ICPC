#include<bits/stdc++.h>
using namespace std;
int T,n,hb[105],n1,stack1[105],tot,bj;
void dfs(int a)
{
	if(a==0){
	
	bj=1;
	return ;
	} 
	if(bj==1) return;
	for(int i=tot;i>=1;i--)
	  if(a>=stack1[i])
	{
		if(bj==1)
		return;
		dfs(a-stack1[i]);
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int i=1;i<=T;i++)
	{
		scanf("%d",&n);
		n1=n;
		for(int t=1;t<=n;t++)
		scanf("%d",&hb[t]);
		
		sort(hb+1,hb+n+1);
		for(int t=1;t<=n-1;t++)
		if(hb[t]!=0)
	{
		for(int c=t+1;c<=n;c++)
		if((hb[c]%hb[t]==0)&&hb[c]!=1000000007)
		{
			hb[c]=1000000007;
			n1--;
		}
	}	
	    sort(hb+1,hb+n+1);
		if(n1==1||n1==2)
		{
			printf("%d\n",n1);
			continue;
		}
		stack1[1]=hb[1];
		stack1[2]=hb[2];
		tot=2;
	
		for(int t=3;t<=n1;t++)
	{
		bj=0;
		if(hb[t]%(stack1[1]+stack1[2])==0)
		continue;
		dfs(hb[t]);
	    if(bj==1)//�ܱ����� 
	    continue;
	    if(bj==0)//���ܱ�����
		stack1[++tot]=hb[t]; 
	}
	
		printf("%d\n",tot);
		for(int t=1;t<=105;t++)
		hb[t]=0,stack1[t]=0;
	}
	return 0;
}
