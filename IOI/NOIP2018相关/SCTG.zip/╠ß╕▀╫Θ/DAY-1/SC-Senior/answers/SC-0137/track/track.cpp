#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
#define pir pair<int,int>
#define pb push_back
#define fy second
#define fx first
const int N=50001;
int n,m;
vector<pir> edge[N];
//solveping
int quan[N];
//solvem1
int dpmax[N];//the max length between its sons and itself
int dpscd[N];//the scd longest length
int f[N];
//solveba1
int lian[N];
inline bool lesscpr(int a,int b){
	return a>b;
}
//solveping
void solveping(){
	int num=edge[1].size();
	for(int i=0;i<num;i++)
		quan[i+1]=edge[1][i].fy;
	sort(&quan[1],&quan[num]+1,lesscpr);
	int ans=10000000;
	int temp;
	if(num >= m*2){//use the biggest weights and match min and max
		int j=2*m;
		for(int i=1;i<=m;i++){
			temp=quan[i] + quan[j--];
			ans=min(ans,temp);
		}
	}
	else{//the biggest ones go themselves,the others are matched min and max
		int mustalone;
		mustalone=2*m-num;
		for(int i=1;i<=mustalone;i++)
			ans=min(ans,quan[i]);
		int j=num;
		for(int i=mustalone+1;i<=m;i++){
			temp=quan[i] + quan[j--];
			ans=min(ans,temp);
		}
	}
	printf("%d\n",ans);
	return;
}
//solvem1
void dfs(int now,int father){
	f[now]=father;
	int temp=0;
	for(int i=0;i<edge[now].size();i++){
		if(edge[now][i].fx == father)	continue;
		dfs(edge[now][i].fx,now);
		temp=dpmax[edge[now][i].fx] + edge[now][i].fy;
		if(temp > dpmax[now]) dpscd[now]=dpmax[now],dpmax[now]=temp;
		else if(temp > dpscd[now]) dpscd[now]=temp;
	}
	return;
}
void solvem1(){//find the longest rout
	dfs(1,0);
	int ans=0;
	if(edge[1].size()==1)	ans=dpmax[1];
	else	ans=dpmax[1] + dpscd[1];
	for(int i=2;i<=n;i++)
		if(edge[i].size() <= 2)	ans=max(ans,dpmax[i]);
		else	ans=max(ans,dpmax[i] + dpscd[i]);
	printf("%d\n",ans);
	return;
}
//solvemnm1
void solvemnm1(){
	int ans=1000000;
	for(int i=1;i<=n;i++)
		for(int j=0;j<edge[i].size();j++)
			ans=min(ans,edge[i][j].fy);
	printf("%d\n",ans);
	return;
}
//solveba1
bool check(int ask){
	int able=0;
	int have=0;
	for(int i=1;i<=n-1;i++){
		have+=lian[i];
		if(have>=ask){
			able++;
			have=0;
		}
	}
	if(able>=m)	return true;
	else	return false;
}
void solveba1(){//the length of lian is n-1 which means lian[1.....n-1]
	int sum=0;
	for(int i=1;i<=n-1;i++){
		for(int j=0;j<edge[i].size();j++)
			if(edge[i][j].fx==i+1){
				lian[i]=edge[i][j].fy;
				sum+=lian[i];
				break;
			}
	}
	//lian is got
	int l=1,r= sum/m + 1;//choose[l,r]
	while(l!=r){//[l,r]  there is obviously a bug here.[l,r]=[1,2] and check(1)==true
		int mid=(l+r)/2;
		if(l==r-1)	mid++;
		if(check(mid)) l=mid;
		else	r=mid-1;
	}
	printf("%d\n",l);
	return;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d %d",&n,&m);
	bool flagping=true;//flag of ai==1
	bool flagba1=true;
	int ai,bi,li;
	for(int i=1;i<=n-1;i++){
		scanf("%d %d %d",&ai,&bi,&li);
		edge[ai].pb(make_pair(bi,li));
		edge[bi].pb(make_pair(ai,li));
		if(ai!=1)	flagping=false;
		if(bi!=ai+1)	flagba1=false;
	}
	if(flagping)	solveping();
	else if(m==1)	solvem1();
	else if(m==n-1)	solvemnm1();
	else if(flagba1)	solveba1();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
