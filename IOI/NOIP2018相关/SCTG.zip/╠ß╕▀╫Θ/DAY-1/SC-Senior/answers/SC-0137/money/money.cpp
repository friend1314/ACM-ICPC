#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
int a[200];
bool dp[25500];
int T;
int n;
void solve(){
	int ans=n;
	sort(&a[1],&a[n]+1);
	int amax=a[n]+10;
	for(int i=1;i<=n;i++){
		if(dp[a[i]])	ans--;
		else{
			dp[a[i]]=true;
			int lim=amax+5-a[i];
			for(int j=1;j<=lim;j++)
				if(dp[j])
					dp[j + a[i]]=true;
		}
	}
	printf("%d\n",ans);
	return;
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int task=1;task<=T;task++){
		memset(a,0,sizeof(a));
		memset(dp,0,sizeof(dp));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		solve();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
