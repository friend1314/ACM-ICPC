#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
long long ans=0;
int n;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	int last=0,now;
	for(int i=1;i<=n;i++){
		scanf("%d",&now);
		if(now > last)	ans+=now-last;
		last=now;
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
