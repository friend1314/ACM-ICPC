#include<bits/stdc++.h>
using namespace std;
int t,n,w[101],nn;
bool l[101],bl;
int yanzheng1(int ii,int ww)
{
	for(int i=1;i<ii;i++)
	if(ww%w[i]==0)return 1;
	return 0;
}
void yanzheng2(int ii,int ww)
{
	if(bl)return;
	if(ww<0)return;
	if(ww==0){bl=true;return;}
	for(int i=1;i<ii;i++)
	if(ww-w[i]<0)break;
	else yanzheng2(ii,ww-w[i]);
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t--)
	{
		memset(l,1,sizeof l);
		cin>>n;
		nn=n;
		for(int i=1;i<=n;i++)
		cin>>w[i];
		sort(w+1,w+1+n);
		for(int i=n;i>1;i--)
		{
			if(yanzheng1(i,w[i]))nn--;
			else
			{
			bl=false;
			yanzheng2(i,w[i]);
			if(bl)nn--;
			}
		}
		cout<<nn<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
