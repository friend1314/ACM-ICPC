#include<bits/stdc++.h>
using namespace std;
int cnt,headd,tail,head[100001],a,b,c,n,m,q[100001],f[100001],maxn=-1000;
bool l[100001];
struct node
{
	int pre,next,w;
}edge[1000001];
void add(int x,int y,int z)
{
	cnt++;
	edge[cnt].pre=y;
	edge[cnt].next=head[x];
	edge[cnt].w=z;
	head[x]=cnt;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<n;i++)
	{
		cin>>a>>b>>c;
		add(a,b,c);
		add(b,a,c);
	}
	for(int j=1;j<=n;j++)
	{
	for(int i=1;i<=n;i++)f[i]=1111111;
	for(int i=1;i<=n;i++)l[i]=0;
	for(int i=1;i<=100000;i++)q[i]=0;
	headd=1;
	tail=2;
	f[j]=0;
	l[j]=1;
	q[1]=j;
	while(headd<tail)
	{
		int x=q[headd];
		int temp=head[x];
		while(temp)
		{
			int y=edge[temp].pre;
			if(f[y]>f[x]+edge[x].w)
			{
				f[y]=f[x]+edge[x].w;
				if(!l[y])
				{
					l[y]=1;
					q[tail]=y;
					tail++;
				}
			}
			temp=edge[temp].next;
		}
		l[x]=0;
		headd++;
	}
	for(int i=1;i<=n;i++)
	if(f[i]!=1111111)maxn=max(maxn,f[i]);
    }
	cout<<maxn;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
