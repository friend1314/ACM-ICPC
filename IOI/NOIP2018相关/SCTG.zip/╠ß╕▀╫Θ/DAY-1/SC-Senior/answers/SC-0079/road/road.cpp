#include<bits/stdc++.h>
using namespace std;
int n,t,p,a[100001];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	t=a[1];
	p=a[1];
	for(int i=2;i<=n;i++)
	{
		if(p>a[i])p=a[i];
		if(p<a[i])
		{
			t+=a[i]-p;
			p=a[i];
		}
	}
	cout<<t;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
