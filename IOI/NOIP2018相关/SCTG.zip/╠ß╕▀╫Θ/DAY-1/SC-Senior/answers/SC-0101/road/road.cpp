#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
ll read()
{
	ll x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return x*f;
}
const int maxn=100010;
ll n,d[maxn],ans,tmp;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(ll i=1;i<=n;++i)d[i]=read();
	for(ll i=1;i<=n;++i)
	{
		if(tmp>d[i])ans+=tmp-d[i];
		tmp=d[i];
	}
	ans+=tmp;
	printf("%lld\n",ans);
	return 0;
}
