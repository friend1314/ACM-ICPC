#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long
#define Rand() (rand()<<15|rand())
using namespace std;
int read()
{
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return x*f;
}
const int maxn=100010,inf=1000000000;
int n,m,cnt,head[maxn],len,f[maxn],tot,ans;
vector<int>G[maxn];
struct Edge{
	int v,w,nxt;
}E[maxn<<1];
void addedge(int u,int v,int w)
{
	E[++cnt].v=v;
	E[cnt].w=w;
	E[cnt].nxt=head[u];
	head[u]=cnt;
	return ;
}
void dfs(int u,int fa,int w)
{
	for(int i=head[u];i;i=E[i].nxt)
	{
		int v=E[i].v;
		if(v==fa)continue;
		dfs(v,u,E[i].w);
		G[u].push_back(f[v]);
	}
	sort(G[u].begin(),G[u].end());
	int l=0,r=G[u].size()-1;
	if(r>=0)
	{
		while(G[u][r]>=len)
		{
			tot++,r--;
			if(r<0)break;
		}
	}
	while(l<r)
	{
		if(G[u][l]+G[u][r]>=len)tot++,l++,r--;
		else f[u]=max(f[u],G[u][l]),l++;
	}
	if(l==r)f[u]=max(G[u][l],f[u]);
	f[u]+=w;G[u].clear();
	return ;
}
bool check(int mid)
{
	int tag=0;len=mid;
	memset(f,0,sizeof f);tot=0;
	dfs(1,0,0);
	tag=max(tag,tot);
	int up;
	if(n<10000)up=20;
	else if(n>30000)up=15;
	else up=5;
	for(int i=1;i<=up;++i)
	{
		memset(f,0,sizeof f);tot=0;
		int s=Rand()%n+1;
		dfs(s,0,0);
		tag=max(tag,tot);
	}
	return max(tot,tag)>=m;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	srand(19260817);
	n=read();m=read();
	int l=inf,r=0;
	for(int i=1;i<n;++i)
	{
		int a=read(),b=read(),c=read();
		addedge(a,b,c);
		addedge(b,a,c);
		r+=c;l=min(l,c);
	}
	while(l<=r)
	{
		ll mid=(l+r)>>1;
		if(check(mid))ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d\n",ans);
	return 0;
}
