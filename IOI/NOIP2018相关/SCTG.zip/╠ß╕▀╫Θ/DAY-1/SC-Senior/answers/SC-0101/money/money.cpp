#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
int read()
{
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return x*f;
}
int T,n,a[1010],ans;
bool used[250010];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--)
	{
		memset(a,0,sizeof a);
		memset(used,0,sizeof used);
		n=read();ans=0;
		for(int i=1;i<=n;++i)a[i]=read();
		sort(a+1,a+1+n);used[0]=true;
		for(int i=1;i<=n;++i)
		{
			if(!used[a[i]])used[a[i]]=true,ans++;
			else continue;
			for(int j=0;j<=a[n]-a[i];++j)
				if(used[j])
					used[j+a[i]]=true;
		}
		printf("%d\n",ans);
	}
	return 0;
}
