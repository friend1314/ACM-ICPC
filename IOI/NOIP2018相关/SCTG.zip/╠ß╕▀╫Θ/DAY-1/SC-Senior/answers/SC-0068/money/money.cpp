#include<bits/stdc++.h>
using namespace std;
int t,n,a[105],m,c,num,ans;
bool cmp(int x,int y)
{
	return x>y;
}
void process(int m)
{
	while(1)
	{
	if(m==0){ans--;break;}
	else
	{
	c=*lower_bound(a+1,a+n+1,m,cmp);
	if(c==a[1])return;
	m-=a[num-1];
	process(m);
	if(num==1)break;
	num--;
	}
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
    cin>>t;
    for(int pianfen=1;pianfen<=t;pianfen++)
    {
    	memset(a,0,sizeof(a));
    	cin>>n;
    	ans=n;
    	for(int i=1;i<=n;i++)
		cin>>a[i];
    		stable_sort(a+1,a+n+1);
    		if(a[1]==1){cout<<"1"<<endl;break;}
    	for(int i=2;i<=n;i++)
    	{
    		num=i;
    		m=a[i];
    		if(m>=2*a[1])
    		process(m);
    	}
        cout<<ans<<endl;
    }
	return 0;
}
