#include<bits/stdc++.h>
using namespace std;
int n,f[100005],a[100005],i;
int find(int x)
{
	if(f[x]!=x)return find(f[i-1]);
	return x;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
    int ans;
    ans=0;
	cin>>n;
	for(i =1;i<=n;i++)
	{
		cin>>a[i];
	}
	f[1]=1;ans=a[1];
	for(i=2;i<=n;i++)
	{
		if(a[i]<=a[i-1]){f[i]=f[i-1];}
		if(a[i]>a[i-1]){f[i]=i;}
	}
	for(i=2;i<=n;i++)
	{
		if(f[i]==f[i-1])continue;
		else{ans+=a[i]-a[i-1];}
	}
	cout<<ans;
	return 0;
}
