#include<bits/stdc++.h>
using namespace std;
int c,r,x,y,z,st[500005],en[500005],length[500005],f[500005];
long long ans;
void find(int x)
{
	if(f[x]!=x)return find(f[x]);
	return x;
}
int main()
{
	freopen("track.in","r",stdin);
//	freopen("track.out","w",stdout);
    cin>>c>>r;
    for(int i=1;i<=c-1;i++)
    {
    	cin>>x>>y>>z;
    	f[y]=x;
    }
    for(int i=1;i<=c;i++)
    if(f[i]==0){f[i]=i;break;}
    for(int i=2;i<=c;i++)
    {
    	f[i]=find(i);
    }
    for(int i=1;i<=c;i++)
      for(int j=1;j<=c;j++)
      {
      	if()
      }
	return 0;
}
