#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<bits/stdc++.h>
using namespace std;
int m,n,p[50001]={},sta[50001]={};
struct lu
{
	int a,b,l;
}r[50001];
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<n;i++)
	{
	   cin>>r[i].a>>r[i].b>>r[i].l;	
	   p[r[i].b]++;
	}
	int o=0;
	for(int i=1;i<=n;i++)
	if(p[i]==0)sta[++o]=i;
    cout<<51;
	return 0;
}

