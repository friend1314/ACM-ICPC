#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<bits/stdc++.h>
using namespace std;
int n[21]={},a[21][101]={},m[21]={},t;
bool c[21]={};
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		cin>>n[i];
		for(int j=1;j<=n[i];j++)
		{
			cin>>a[i][j];
			if(a[i][j]==1)c[i]=1;
		}
	}
	for(int i=1;i<=t;i++)
	{
		if(c[i])m[i]=1;
		else m[i]=n[i];
	}
	for(int i=1;i<=t;i++)
	cout<<m[i]<<endl;
	return 0;
}
