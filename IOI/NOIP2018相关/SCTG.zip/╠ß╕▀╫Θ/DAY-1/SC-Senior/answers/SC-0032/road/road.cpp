#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<bits/stdc++.h>
using namespace std;
long long n,t=0,m=0;
int d[100005]={};
int f()
{ 
   int sum=0;
   for(int i=1;i<=n;i++)
   if(d[i]!=0&&d[i-1]==0)sum++;
   return sum;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>d[i];
		if(d[i]==0)m++;
	}
	d[0]=0;
	while(m!=n)
	{
		t+=f();
		for(int i=1;i<=n;i++)
		if(d[i]!=0)
		{
		   d[i]--;
		   if(d[i]==0)m++;
		}
	}
	cout<<t;
	return 0;
}
