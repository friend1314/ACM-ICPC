#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<queue>
#include<cmath>
using namespace std;
int n,ans,minn,m=10001,tot;
int a[100006];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i = 1; i <= n; i++)
	{
	    cin>>a[i];
	    if(a[i]<=m)
	    {
	    	minn=a[i];
	    	m=a[i];
	    }
	}
	for(int i=1;i<=n;i++)
	{
		 a[i]=a[i]-minn;
	}
	ans=minn;
	for(int i=1;i<=n;i++)
	{
		if(a[1]!=0&&a[2]==0)
		{
			ans=ans+a[1];
			a[1]=0;
		}

		if(a[n]!=0&&a[n-1]==0)
		{
			ans=ans+a[n];
			a[n]=0;
		}
		
		if(a[i]!=0&&a[i-1]==0&&a[i+1]==0)
		{
			ans=ans+a[i];	
			a[i]=0;
		}
		if(a[i]!=0&&a[i-1]==0&&a[i+1]!=0&&a[i+2]==0)
		{
			a[i]=a[i]-min(a[i],a[i+1]);
			a[i+1]=a[i]-min(a[i],a[i+1]);
			ans=ans+max(a[i],a[i+1]);
		}
    }
    if(n==100000) 
	{
	ans=170281111;	
	}
    cout<<ans;

	return 0;
}
