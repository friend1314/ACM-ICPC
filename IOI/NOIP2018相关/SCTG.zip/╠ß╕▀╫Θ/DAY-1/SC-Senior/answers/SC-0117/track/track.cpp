#include<algorithm>
#include<cstring>
#include<cstdio>
#include<vector>
using namespace std;
const int M=50050;
int m,n,ans,tot,wt,cnt,fuck;
int head[M],dp[M],qu[M];
int ts1=1,ts11[M];//1��Բ�� 2������ 3����һ������ 
int ts2=1,ts22[M];

struct node
{
	int v,c,next;
}mp[M*2];

void add(int a,int b,int c)
{
	mp[cnt].v=b;
	mp[cnt].c=c;
	mp[cnt].next=head[a];
	head[a]=cnt++;
}

void dfs1(int now,int fa)
{
	int max1=0,max2=0;
	for(int i=head[now];i!=-1;i=mp[i].next)
	{
		int v=mp[i].v,c=mp[i].c;
		if(v==fa) continue;
		dfs1(v,now);
		if(dp[v]+c>max1) max2=max1,max1=dp[v]+c;
		else if(dp[v]+c>max2) max2=dp[v]+c;
	}
	dp[now]=max1;
	fuck=max(fuck,max1+max2);
}

void dfs(int now,int fa)
{
	vector <int> son;
	for(int i=head[now];i!=-1;i=mp[i].next)
	{
		int v=mp[i].v,c=mp[i].c;
		if(v==fa) continue;
		dfs(v,now);
		if(dp[v]+c>=wt)
		{
			tot++;
			continue;
		}
		son.push_back(dp[v]+c);
	}
	
	int h=son.size();
	for(int i=0;i<h;i++)
	qu[i+1]=son[i];
	sort(qu+1,qu+1+h);
	
	int j=1,t=h,maxn=0;
	while(j<t)
	{
		if(qu[j]+qu[t]>=wt) tot++,t--;
		else maxn=qu[j];
		j++;
	}
	if(j==t) dp[now]=qu[t];
	else dp[now]=maxn;
}

bool check(int x)
{
	memset(dp,0,sizeof(dp));
	tot=0;wt=x;
	dfs(1,0);
	if(tot>=n) return true;
	else return false;
}

bool check1(int x)
{
	tot=0;
	int t=m-1;
	while(ts11[t]>=x && t>=1) tot++,t--;
	for(int i=1;i<t;i++)
	if(ts11[i]+ts11[t]>=x) tot++,t--;
	if(tot>=n) return true;
	else return false;
}

bool check2(int x)
{
	tot=0;
	int sum=0;
	for(int i=1;i<m;i++)
	{
		sum+=ts22[i];
		if(sum>=x)
		{
			sum=0;
			tot++;
		}
	}
	if(tot>=n) return true;
	else return false;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	int a,b,c;
	int l=1,r=0;
	scanf("%d%d",&m,&n);
	for(int i=1;i<m;i++)
	{
		scanf("%d%d%d",&a,&b,&c);
		add(a,b,c);add(b,a,c);
		r+=c;
		
		if(a!=1) ts1=0;
		if(b!=a+1) ts2=0;
		ts11[i]=c;
		ts22[a]=c;
	}
	if(ts1)
	{
		sort(ts11+1,ts11+m);
		while(l<=r)
		{
			int mid=(l+r)/2;
			if(check1(mid)) ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d",ans);
		return 0;
	}
	if(ts2)
	{
		while(l<=r)
		{
			int mid=(l+r)/2;
			if(check2(mid)) ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d",ans);
		return 0;
	}
	if(n==1)
	{
		dfs1(1,0);
		printf("%d",fuck);
		return 0;
	}
	while(l<=r)
	{
		int mid=(l+r)/2;
		if(check(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d",ans);
	return 0;
}
