#include<algorithm>
#include<cstring>
#include<cstdio>
using namespace std;
int T,n,ans;
int cin1[150],vis[25050],mp[25050],cnt;

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int a;
	scanf("%d",&T);
	while(T--)
	{
		cnt=0;ans=0;
		memset(vis,0,sizeof(vis));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&cin1[i]);
		sort(cin1+1,cin1+1+n);
		for(int i=1;i<=n;i++)
		{
			a=cin1[i];
			if(vis[a]) continue;
			for(int i=0;i<=cnt;i++)
			{
				int j=1;
				while(mp[i]+a*j<=25000)
				{
					if(vis[mp[i]+a*j]) break;
					vis[mp[i]+a*j]=1;
					mp[++cnt]=mp[i]+a*j;
					j++;
				}
			}
			ans++;
 		}
 		printf("%d\n",ans);
	}
	return 0;
}
