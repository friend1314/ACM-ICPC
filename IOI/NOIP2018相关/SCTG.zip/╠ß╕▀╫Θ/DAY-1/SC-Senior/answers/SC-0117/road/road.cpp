#include<cstring>
#include<cstdio>
using namespace std;
long long cnt=0;
int n;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	int a,la=0;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		if(a>la) cnt+=(a-la);
		la=a;
	}
	printf("%lld",cnt);
	return 0;
}
