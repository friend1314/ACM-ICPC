/*
	Copyright: CC-BY-SA-NC
	Author: Duanyll
	Date: 10/11/18 08:23
	RP++;
*/

#include <iostream>
#include <algorithm>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <bitset>
using namespace std;

#define rint register int
typedef long long int64;

const int INF = 0x3f3f3f3f;
const double EPS = 1e-14;
const int MAXN = 110;
const int MAXA = 25010;

#include <cctype>

inline int read(){
	int x = 0,d = 1;
	char c;
	while(!isdigit(c = getchar())){
		if(c=='-'){
			d = -1;
		}
	}
	do{
		x *= 10;
		x += c - '0';
	}while(isdigit(c = getchar()));
	return x*d;
}

int a[MAXN];
bitset<MAXA> mark;

int main(){
	//ifstream cin("money.in");
	//ofstream cout("money.ans");
	freopen("money.in","r",stdin);
	freopen("money.ans","w",stdout);
	
	int tcnt = read();
	for(int T = 1;T<=tcnt;T++){
		memset(a,0,sizeof a);
		int n = read();
		for(int i = 1;i<=n;i++){
			a[i] = read();
		}
		
		sort(a+1,a+n+1);
		mark.reset();
		int ans = 0;
		for(int i = 1;i<=n;i++){
			if(mark[a[i]]){
				continue;
			}
			ans++;
			mark[a[i]] = 1;
			for(int j = 1;j<=25000;j++){
				if(mark[j]){
					if(j+a[i]>25000 || mark[j+a[i]]){
						continue;
					}
					for(int k = 1;j+k*a[i]<=25000;k++){
						mark[j+k*a[i]] = 1;
					}
				}
			}
		}
		cout << ans << endl;
	}
	
	return 0;
}
