/*
	Copyright: CC-BY-SA-NC
	Author: Duanyll
	Date: 10/11/18 08:23
	RP++;
*/

#include <iostream>
#include <algorithm>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <queue>
using namespace std;

#define rint register int
typedef long long int64;

const int INF = 0x3f3f3f3f;
const double EPS = 1e-14;
const int MAXN = 50010;

#include <cctype>

inline int read(){
	int x = 0,d = 1;
	char c;
	while(!isdigit(c = getchar())){
		if(c=='-'){
			d = -1;
		}
	}
	do{
		x *= 10;
		x += c - '0';
	}while(isdigit(c = getchar()));
	return x*d;
}

namespace map{
	struct edge{
		int to,next,w;
	}e[MAXN*2];
	int head[MAXN];
	int ecnt;
	void adde(int from,int to,int w){
		e[ecnt].to = to;
		e[ecnt].w = w;
		e[ecnt].next = head[from];
		head[from] = ecnt++;
	}
	
	int ans;
	int dfs(int u,int fa){
		int mxch = 0;
		int secch = 0;
		for(int i = head[u];i!=-1;i = e[i].next){
			int v = e[i].to;
			if(v!=fa){
				int dis = dfs(v,u)+e[i].w;
				if(dis>mxch){
					secch = mxch;
					mxch = dis;
				}else if(dis>secch){
					secch = dis;
				}
			}
		}
		ans = max(ans,mxch+secch);
		return mxch;
	}
}

int n,m;
bool check(int x,int sum[MAXN]){
	int i;
	for(i = 1;i<n;i++){
		if(sum[i]>=x){
			break;
		}
	}
	if(i==n){
		return false;
	}
	int last = sum[i];
	for(int j = 1;j<=m-1;j++){
		for(;i<n;i++){
			if(sum[i]-last >= last){
				last = sum[i]-last;
				break;
			}
		}
		if(i==n){
			return false;
		}
	}
	return true;
}

int main(){
	//ifstream cin("track.in");
	//ofstream cout("track.ans");
	freopen("track.in","r",stdin);
	freopen("track.ans","w",stdout);
	
	n = read();
	m = read();
	memset(map::head,-1,sizeof map::head);
	bool islink = true;
	for(int i = 1;i<n;i++){
		int a,b,w;
		a = read();
		b = read();
		w = read();
		map::adde(a,b,w);
		map::adde(b,a,w);
		if(b!=a+1){
			islink = false;
		}
	}	
	
	if(m==1){
		map::ans = 0;
		map::dfs(1,0);
		cout << map::ans << endl;
	}else if(islink){
		int* sum = new int[MAXN];
		memset(sum,0,(sizeof 1)*MAXN);
		for(int i = 1;i<n;i++){
			sum[i] = sum[i-1] + map::e[(i-1)*2].w;
		}
		int l = 0,r = sum[n-1];
		while(l<r){
			int mid = (l+r)>>1;
			if(check(mid,sum)){
				l = mid;
			}else{
				r = mid;
			}
		}
		cout << l << endl;
		delete[] sum;
	}
	
	return 0;
}
