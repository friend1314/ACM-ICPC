/*
	Copyright: CC-BY-SA-NC
	Author: Duanyll
	Date: 10/11/18 08:23
	RP++;
*/

#include <iostream>
#include <algorithm>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <fstream>
#include <cstdlib>
#include <cmath>
using namespace std;

#define rint register int
typedef long long int64;

const int INF = 0x3f3f3f3f;
const double EPS = 1e-14;
const int MAXN = 100010;

#include <cctype>

inline int read(){
	int x = 0,d = 1;
	char c;
	while(!isdigit(c = getchar())){
		if(c=='-'){
			d = -1;
		}
	}
	do{
		x *= 10;
		x += c - '0';
	}while(isdigit(c = getchar()));
	return x*d;
}

int a[MAXN];

int main(){
	//ifstream cin("road.in");
	//ofstream cout("road.ans");
	freopen("road.in","r",stdin);
	freopen("road.ans","w",stdout);
	
	int n = read();
	for(int i = 1;i<=n;i++){
		a[i] = read();
	}	
	
	a[0] = 0;
	a[n+1] = 0;
	int ans = 0;
	for(int i = 1;i<=n;i++){
		if(a[i]>a[i-1]){
			ans += a[i]-a[i-1];
		}
	}
	cout << ans << endl;
	
	return 0;
}
