#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int a[100001];
	int n=0,c=0,k=0;
	cin>>n;
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++)
	  {
	  	cin>>a[i];
	  	if(i>=2)
          {
           c=a[i]-a[i-1];
           k+=abs(c);
          }          
      }
    cout<<k+1;
    return 0;
    fclose(stdin);
    fclose(stdout);
}
