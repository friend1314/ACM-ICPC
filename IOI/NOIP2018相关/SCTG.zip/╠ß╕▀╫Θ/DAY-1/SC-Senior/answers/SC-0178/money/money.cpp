#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	int k[10];
	int a[10][100];
	cin>>t;
	for(int j=1;j<=t;j++)
	  {
	  	cin>>k[j];
	  	for(int i=1;i<=k[j];i++)
	  	  cin>>a[j][i];
	  }	
	for(int i=2;i<=t;i++)
	  {
	  	cout<<2<<" "<<k[i]*k[i]-1;
	  }
	return 0;
	fclose(stdin);
	fclose(stdout);
}
