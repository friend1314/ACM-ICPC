#include<cstdio>
#include<iostream>
using namespace std;
int t=0,sum=0,w;
int n;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&w);
		if(w>t)
		sum+=w-t;
		t=w;
	}
	printf("%d",sum);
	return 0;
	
}
