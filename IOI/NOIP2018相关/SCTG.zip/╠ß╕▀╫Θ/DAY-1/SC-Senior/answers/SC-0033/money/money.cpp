#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int a[25030],b[120],n,t,w,ans;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		ans=n;
		a[0]=1;
		for(int i=1;i<=n;i++)
		scanf("%d",&b[i]);
		sort(b+1,b+1+n);
		if(b[1]==1)
		{
			printf("1\n");
			continue;
		}
		for(int i=1;i<=n;i++)
		{
			if(a[b[i]])
			{
				--ans;
				continue;
			}
			for(int j=b[i];j<=b[n];j++)
			{
				if(a[j-b[i]])
				a[j]=1;
			}
		}
		printf("%d\n",ans);
	}   
		
	return 0;
}
