#include <bits/stdc++.h>
#define ll long long
#define lf double
#define l(x) (x<<1)
#define r(x) (x<<1|1)
#define pa pair<int,int>
#define mp make_pair
#define pb push_back
#define E complex<lf>
#define ms(a,b) memset(a,b,sizeof(a))
#define inf 0x3f3f3f3f
#define eps 1e-10
#define mod 1000000007
#define F "road"
#define N 100010
using namespace std;
inline int read() {
   int x=0,f=1;char c=getchar();
   while (c<'0'||c>'9') f=(c=='-')?-1:1,c=getchar();
   while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
   return x*f;
}
inline void fre() {
	freopen(F".in","r",stdin);
	freopen(F".out","w",stdout);
}
int n,a[N],ans=0;
int main() {
	fre();
	n=read();
	for (int i=1; i<=n; i++) a[i]=read(),ans+=max(0,a[i]-a[i-1]);
	cout << ans << endl;
}

