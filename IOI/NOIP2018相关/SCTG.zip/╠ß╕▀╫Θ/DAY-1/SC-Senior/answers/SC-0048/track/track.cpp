#include <bits/stdc++.h>
#define ll long long
#define lf double
#define pa pair<int,int>
#define mp make_pair
#define pb push_back
#define E complex<lf>
#define ms(a,b) memset(a,b,sizeof(a))
#define inf 0x3f3f3f3f
#define eps 1e-10
#define mod 1000000007
#define F "track"
#define N 50010
using namespace std;
inline ll read() {
   ll x=0,f=1;char c=getchar();
   while (c<'0'||c>'9') f=(c=='-')?-1:1,c=getchar();
   while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
   return x*f;
}
inline void fre() {
	freopen(F".in","r",stdin);
	freopen(F".out","w",stdout);
}
int n,m;
int head[N],nxt[N<<1],to[N<<1],len[N<<1],tot=0,du[N],md=0;
inline void link(int x,int y,int z) {
	nxt[++tot]=head[x],head[x]=tot,to[tot]=y,len[tot]=z,du[x]++,md=max(md,du[x]);
}
//-------------------Work_1---------------------------------
int ans_1=0;
int fa_1[N],mx_1[N];
inline int dfs_1(int x) {
	for (int i=head[x]; i; i=nxt[i]) {
		int j=to[i];
		if (j==fa_1[x]) continue;
		fa_1[j]=x,dfs_1(j);
		ans_1=max(ans_1,mx_1[x]+mx_1[j]+len[i]);
		mx_1[x]=max(mx_1[x],mx_1[j]+len[i]);
	}
}
inline void work_1() {
	dfs_1(1);
	cout << ans_1 << endl;
}
//------------------------Work_1_End--------------------------
int dis[N],s[N];
//------------------------Work_2---------------------------
inline bool cmp_2(int x,int y) {
	return x>y;
}
inline void work_2(){
	sort(dis+1,dis+n,cmp_2);
	int ans_2=min(dis[m-1],dis[m]+dis[m+1]);
	cout << ans_2 << endl;
}
//------------------------Work_2_End---------------------------

//------------------------Work_3-------------------------------
int a_3[N],sum_3=0;
inline bool check_3(int x) {
	int tot=0,t=0;
	for (int i=1; i<=n; i++) {
		tot+=a_3[i];
		if (tot>=x) tot=0,t++;
	}
	if (t>=x) return 1;
	else return 0;
}
inline void work_3() {
	for (int i=1; i<n; i++) a_3[s[i]]=dis[i],sum_3+=dis[i];
	int l=1,r=sum_3/m,ans=1;
	while (l<r) {
		int mid=l+r>>1;
		if (check_3(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	if (check_3(l)) ans=l;
	cout << ans << endl;
}
//------------------------Work_3_End---------------------------

//------------------------Work_4_End---------------------------
int fa_4[N],mx_4[N],bz_4,tot_4;
inline void dfs_4(int x) {
	mx_4[x]=0;
	int s1=0,s2=0,l1=0,l2=0;
	for (int i=head[x]; i; i=nxt[i]) {
		int j=to[i];
		if (j==fa_4[x]) continue;
		fa_4[j]=x,dfs_4(j);
		if (s1==0) s1=j,l1=len[i];
		else s2=j,l2=len[i];
	}
	if (s1==0&&s2==0) return ;
	if (mx_4[s1]+l1>=bz_4) tot_4++,s1=l1=0;
	if (mx_4[s2]+l2>=bz_4) tot_4++,s2=l2=0;
	if (mx_4[s1]+mx_4[s2]+l1+l2>=bz_4) s1=l1=l2=s2=0,tot_4++;
	else mx_4[x]=max(mx_4[x],max(mx_4[s1]+l1,mx_4[s2]+l2));
}
int sum_4=0;
inline bool check_4(int x) {
	bz_4=x,tot_4=0;
	dfs_4(1);
	if (tot_4>=m) return 1;
	else return 0;
}
inline void work_4() {
	for (int i=1; i<n; i++) sum_4+=dis[i];
	int l=1,r=sum_4/m,ans=1;
	while (l<r) {
		int mid=l+r>>1;
		if (check_4(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	if (check_4(l)) ans=l;
	cout << ans << endl;
}
//------------------------Work_4_End---------------------------

//------------------------Work_5-------------------------------
int sum,bz,t,mx[N],fa[N];
int sta[N],top=0,vis[N];
inline void dfs(int x) {
	mx[x]=0;top=0;
	int s1=0,s2=0,l1=0,l2=0;
	for (int i=head[x]; i; i=nxt[i]) {
		int j=to[i];
		if (j==fa[x]) continue;
		fa[j]=x,dfs(j);
		if (mx[j]+len[i]>=bz) t++;
		else sta[++top]=mx[j]+len[i];
	}
	sort(sta+1,sta+1+top);
	int p=top;
	for (int i=1; i<=top; i++) {
		if (vis[i]) continue;
		while (p>i&&(sta[i]+sta[p]>=bz||vis[p])) p--;
		p++;
		if (sta[i]+sta[p]>=bz) vis[i]=1,vis[p]=1,t++;
	}
	for (int i=top; i; i--) if (!vis[i]) {
		mx[x]=sta[i];
		break;
	}
	for (int i=1; i<=top; i++) vis[i]=0,sta[i]=0;
}
inline bool check(int x) {
	bz=x,t=0;
	dfs(1);
	if (tot>=m) return 1;
	else return 0;
}
inline void work_5() {
	for (int i=1; i<n; i++) sum+=dis[i];
	int l=1,r=sum/m,ans=1;
	while (l<r) {
		int mid=l+r>>1;
		if (check(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	if (check(l)) ans=l;
	cout << ans << endl;
}
//------------------------Work_5_End---------------------------
bool flag_a_1,flag_b_a1;
int main() {
	fre();
	n=read(),m=read();
	for (int i=1; i<n; i++) {
		int x=read(),y=read(),z=read();
		dis[i]=z,s[i]=x;
		link(x,y,z),link(y,x,z);
		if (x!=1) flag_a_1=1;
		if (y!=x+1) flag_b_a1=1;
	}
	if (m==1) { //20 ֱ�� 
		work_1();
		return 0;
	}
	if (!flag_a_1) { //15 �ջ�ͼ ���� 
		work_2();
		return 0;
	}
	if (!flag_b_a1) { //20 �� ���ִ� 
		work_3();
		return 0;
	}
	if (md<=3) { //25 ������ ����dp 
		work_4();
		return 0;
	}
	//tot=80 WXHAKIOI2019
	//���� ÿ����ά��set 
	work_5(); 
}

