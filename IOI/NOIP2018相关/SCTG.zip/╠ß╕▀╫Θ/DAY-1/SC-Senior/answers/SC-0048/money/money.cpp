#include <bits/stdc++.h>
#define ll long long
#define lf double
#define pa pair<int,int>
#define mp make_pair
#define pb push_back
#define E complex<lf>
#define ms(a,b) memset(a,b,sizeof(a))
#define inf 0x3f3f3f3f
#define eps 1e-10
#define mod 1000000007
#define F "money"
#define N 110
using namespace std;
inline ll read() {
   ll x=0,f=1;char c=getchar();
   while (c<'0'||c>'9') f=(c=='-')?-1:1,c=getchar();
   while (c>='0'&&c<='9') x=x*10+c-'0',c=getchar();
   return x*f;
}
inline void fre() {
	freopen(F".in","r",stdin);
	freopen(F".out","w",stdout);
}
inline int gcd(int a,int b) {
	if (a%b==0) return b;
	else return gcd(b,a%b);
}
int n,a[N];
int num[25001];
bool vis[25001],tag[N];
int main() {
	fre();
	int T=read();
	while (T--) {
		n=read(),ms(vis,0),ms(tag,0);
		for (int i=1; i<=n; i++) a[i]=read();
		sort(a+1,a+1+n);
		vis[0]=1;
		for (int i=1; i<=n; i++) {
			if (vis[a[i]]) {
				tag[i]=1;
				continue;
			}
			for (int j=0; j<=a[n]-a[i]; j++) if (vis[j]) vis[j+a[i]]=1;
		}
		int ans=n;
		for (int i=1; i<=n; i++) if (tag[i]) ans--;
		cout << ans << endl;
	}
}

