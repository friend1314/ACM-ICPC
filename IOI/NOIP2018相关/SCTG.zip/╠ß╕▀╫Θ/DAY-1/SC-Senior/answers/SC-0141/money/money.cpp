#include <iostream>
#include <cstdio>
#include <vector>
#define maxn 150
using namespace std;

int t,n;
int a[maxn],leftt,maxv;
bool nouse[maxn],apd[25050];
vector<int>coin;

inline int read()
{
	int f=1,x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return f*x;
}

int gcd(int a,int b)
{
	if(b==0)return a;
	else return gcd(b,a%b);
}

void initt()
{
	n=read();leftt=n;maxv=0;
	memset(apd,false,sizeof(apd));
	memset(nouse,false,sizeof(nouse));
	coin.clear();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
}

void dT1()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j)continue;
			if(!nouse[i]&&a[i]%a[j]==0)
			{
				nouse[i]=true;
				leftt--;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(!nouse[i])coin.push_back(a[i]);
	}
}

void dT2_D3()
{
	memset(nouse,false,sizeof(nouse));
	for(int i=0;i<3;i++)
	{
		if(i==0)
		{
			if(coin[i]>coin[1]*coin[2]-coin[1]-coin[2]&&!nouse[i])
			{
				leftt--;
				nouse[i]=true;
			}
		}
		if(i==1)
		{
			if(coin[i]>coin[0]*coin[2]-coin[0]-coin[2]&&!nouse[i])
			{
				leftt--;
				nouse[i]=true;
			}
		}
		if(i==2)
		{
			if(coin[i]>coin[0]*coin[1]-coin[0]-coin[1]&&!nouse[i])
			{
				leftt--;
				nouse[i]=true;
			}
		}
	}
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	
	t=read();
	while(t--)
	{
		initt();
		dT1();
		if(coin.size()==3)
		{
			dT2_D3();
		}
		printf("%d\n",leftt);
	}
	return 0;
}
