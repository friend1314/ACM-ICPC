#include <iostream>
#include <cstdio>
#define maxn 100050
#define ll long long
using namespace std;

int n,a[maxn];
ll ans=0;

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=n;i>=1;i--)
	{
		if(a[i]-a[i+1]>0)ans+=a[i]-a[i+1];
	}
	cout<<ans;
	
	return 0;
}
