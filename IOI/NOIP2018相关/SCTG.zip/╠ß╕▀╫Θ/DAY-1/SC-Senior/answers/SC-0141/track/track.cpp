#include <iostream>
#include <cstdio>
#define maxn 50050
using namespace std;

int n,m;
int head[maxn],cnt;
int maxw=0;
bool ischain=true,allone=true;
int dis[maxn];
int dep[maxn],siz[maxn],son[maxn],fa[maxn];
int top[maxn];
int pf_1,pf_2,df;
int ans=0;

struct EDGE
{
	int next,to,w;
}edge[maxn<<1];

inline int read()
{
	int f=1,x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';
		ch=getchar();
	}
	return f*x;
}

void add(int u,int v,int w)
{
	edge[++cnt].next=head[u];
	edge[cnt].to=v;
	edge[cnt].w=w;
	head[u]=cnt;
}

void dfs1(int root)
{
	siz[root]=1;
	son[root]=0;
	for(int i=head[root];i;i=edge[i].next)
	{
		int v=edge[i].to;
		if(v==fa[root])continue;
		fa[v]=root;
		dep[v]=dep[root]+1;
		dis[v]=dis[root]+edge[i].w;
		dfs1(v);
		if(siz[son[root]]<siz[v])son[root]=v;
		siz[root]+=siz[v];
	}
}

void dfs2(int root,int tp)
{
	top[root]=tp;
	if(son[root])dfs2(son[root],tp);
	for(int i=head[root];i;i=edge[i].next)
	{
		int v=edge[i].to;
		if(v==fa[root]||v==son[root])continue;
		dfs2(v,v);
	}
}

int lca(int u,int v)
{
	int fu=top[u],fv=top[v];
	while(fu!=fv)
	{
		if(dep[fu]<dep[fv])
		{
			swap(fu,fv);
			swap(u,v);
		}
		u=fa[fu];
		fu=top[u];
	}
	if(dep[u]<dep[v])swap(u,v);
	return v;
}

int calDis(int u,int v)
{
	int lc=lca(u,v);
	return dis[u]+dis[v]-2*dis[lc];
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	
	n=read();m=read();
	for(int i=1;i<=n-1;i++)
	{
		int u=read(),v=read(),w=read();
		add(u,v,w);add(v,u,w);
		if(v!=u+1)ischain=false;
		if(u!=1)allone=false;
		maxw=max(maxw,w);
	}
	dis[1]=0;dep[1]=1;
	dfs1(1);dfs2(1,1);
	if(m==n-1)
	{
		printf("%d",maxw);
		return 0;
	}
	if(m==1)
	{
		for(int i=2;i<=n;i++)
		{
			if(dis[i]>df)
			{
				pf_1=i;df=dis[i];
			}
		}
		df=0;
		for(int i=1;i<=n;i++)
		{
			if(i==pf_1)continue;
			int d=calDis(pf_1,i);
			if(d>df)
			{
				df=d;
				pf_2=i;
			}
		}
		printf("%d",calDis(pf_1,pf_2));
		return 0;
	}
	if(ischain)
	{
		if(m==2)
		{
			for(int i=1;i<=n;i++)
			{
				int tmp=min(dis[i],dis[n]-dis[i]);
				ans=max(ans,tmp);
			}
			printf("%d",ans);
			return 0;
		}
		else
		{
			ans=dis[n]/m;
			printf("%d",ans);
			return 0;
		}
	}
	if(allone)
	{
		
	}
	
	return 0;
}
