#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<iomanip>
#include<algorithm>
using namespace std;
inline int qread()
{
	int t=0;char s=getchar();
	while(s<'0'||s>'9')s=getchar();
	while(s>='0'&&s<='9'){t=t*10+s-'0';s=getchar();}
	return t;
}
int lowbit(int t)
{
	return t&(-t);
}
struct node
{
	int data;
	node *next;
};
int n,m,a,b,l;
int head[50011],next[1000011],end[1000011],cost[1000011],tot;
int jud1,jud2,jud3,lian[50011];
int downans,upans,midans,trueans,zhanans[50011],ifused[50011],exist[50011];
int toroot[50011],fa[50011],visit[50011];
void build(int now)
{
	visit[now]=1;
	for(int e=head[now];e;e=next[e])if(visit[end[e]]==0)
	{
		fa[end[e]]=now;
		build(end[e]);
	}
	return ;
}
void dfs2(int now,int last)
{
	for(int e=head[now];e;e=next[e])if(fa[end[e]]==now)
	{
		last=last+cost[e];
		if(last>=midans)
		{
			trueans++;last=0;
		}
		dfs2(end[e],last);
	}
	return ;
}
void dfs3(int now)
{
	int max1=0,max2=0;
	for(int e=head[now];e;e=next[e])if(fa[end[e]]==now)
	{
		dfs3(end[e]);
		if(toroot[end[e]]+cost[e]>max1)
		{
			max2=max1;
			max1=toroot[end[e]]+cost[e];
		}else
		max2=max(max2,toroot[end[e]]+cost[e]);
	}
	if(max1+max2>=midans)
	{
		trueans++;toroot[now]=0;return ;
	}
	toroot[now]=max1;return ;
}
int trueplace(int t)
{
	int al=1,br=zhanans[0];
	while(al<=br)
	{
		int mid=(al+br)/2,num=0;
		for(int i=mid;i>0;i=i-lowbit(i))
		{
			num=num+ifused[i];
		}
		if(num<t)al=mid+1;else
		br=mid-1;
	}
	return al;
}
int fnd(int now)
{
	int al=1,br=0;
	for(int i=zhanans[0];i>0;i=i-lowbit(i))
	{
		br=br+ifused[i];
	}
	while(al<=br)
	{
		int mid=(al+br)/2;
		if(zhanans[trueplace(mid)]>=now)br=mid-1;else
		al=mid+1;
	}
	al=trueplace(al);if(al>zhanans[0])return 0;
	return al;
}
void dfs(int now)
{
	int tt=0;node *lian=new node;lian->next=NULL;
	for(int e=head[now];e;e=next[e])if(fa[end[e]]==now)
	{
		dfs(end[e]);tt++;
		node *nw=new node;
		nw->next=lian->next;
		nw->data=cost[e]+toroot[end[e]];
		lian->next=nw;
	}
	for(int i=1;i<=tt;i++)
	{
		lian=lian->next;
		zhanans[i]=lian->data;
		ifused[i]=lowbit(i);
	}
	memset(exist,0,sizeof(exist));
	zhanans[0]=tt;
	sort(zhanans+1,zhanans+tt+1);
	//for(int i=1;i<=tt;i++)cout<<now<<' '<<zhanans[i]<<endl;
	for(int i=1;i<=tt;i++)if(exist[i]==0)
	{
		if(zhanans[i]>=midans)
		{
			exist[i]=1;trueans++;
			for(int t=i;t<=zhanans[0];t=t+lowbit(t))
			{
				ifused[t]--;
			}
			continue;
		}
		int pl=fnd(midans-zhanans[i]);
		if(pl!=0&&pl!=i&&pl<=zhanans[0])
		{
			exist[pl]=1;trueans++;
			for(int t=pl;t<=tt;t=t+lowbit(t))
			{
				ifused[t]--;
			}
			exist[i]=1;
			for(int t=i;t<=tt;t=t+lowbit(t))
			{
				ifused[t]--;
			}
		}
	}
	int mxx=0;
	for(int i=1;i<=tt;i++)if(exist[i]==0)
	{
		mxx=max(mxx,zhanans[i]);
	}
	toroot[now]=mxx;
	return ;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		a=qread();b=qread();l=qread();
		upans=upans+l;lian[a]++;lian[b]++;
		if(a!=1)jud1=1;if(b!=a+1)jud2=1;if(lian[a]>3||lian[b]>3)jud3=1;
		next[++tot]=head[a];end[tot]=b;cost[tot]=l;head[a]=tot;
		next[++tot]=head[b];end[tot]=a;cost[tot]=l;head[b]=tot;
	}
	build(1);
	if(jud1==0)
	{
		zhanans[0]=0;
		for(int e=head[1];e;e=next[e])
		{
			zhanans[++zhanans[0]]=cost[e];
		}
		sort(zhanans+1,zhanans+zhanans[0]+1);
	}
	while(downans<=upans)
	{
		midans=(upans+downans)/2;trueans=0;
		if(jud1==0)
		{
			memset(exist,0,sizeof(exist));
			for(int i=1;i<=zhanans[0];i++)
			{
				ifused[i]=lowbit(i);
			}
			for(int i=1;i<=zhanans[0];i++)if(exist[i]==0)
			{
				if(zhanans[i]>=midans)
				{
					exist[i]=1;trueans++;
					for(int t=i;t<=zhanans[0];t=t+lowbit(t))
					{
						ifused[t]--;
					}
					continue;
				}
				int pl=fnd(midans-zhanans[i]);
				if(pl!=0&&pl!=i)
				{
					exist[pl]=1;trueans++;
					for(int t=pl;t<=zhanans[0];t=t+lowbit(t))
					{
						ifused[t]--;
					}
					exist[i]=1;
					for(int t=i;t<=zhanans[0];t=t+lowbit(t))
					{
						ifused[t]--;
					}
				}
			}
		}else
		if(jud2==0)
		{
			dfs2(1,0);
		}else
		if(jud3==0)
		{
			dfs3(1);
		}else
		{
			dfs(1);
		}
		//cout<<midans<<' '<<trueans<<endl;
		if(trueans>=m)
		{
			downans=midans+1;
		}else
		{
			upans=midans-1;
		}
	}
	printf("%d",upans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
