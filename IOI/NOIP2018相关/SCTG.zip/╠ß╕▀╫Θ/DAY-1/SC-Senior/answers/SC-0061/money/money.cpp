#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<iomanip>
#include<algorithm>
using namespace std;
int T,n,a[111],line[25011],ans;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int t=1;t<=T;t++)
	{
		memset(line,0,sizeof(line));
		scanf("%d",&n);ans=n;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
		{
			if(line[a[i]]==1)
			{
				ans--;continue;
			}
			line[a[i]]=1;
			for(int q=a[i]+1;q<=25000;q++)
			{
				if(line[q-a[i]]==1)
				{
					line[q]=1;
				}
			}
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
