#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,d[100011],ans;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&d[i]);
		if(d[i]>d[i-1])ans=ans+d[i]-d[i-1];
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
