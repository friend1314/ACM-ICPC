#include <bits/stdc++.h>
#define oo 6e9
using namespace std;

typedef long long ll;
const int N = 1e5 + 5;
int n, m, tot, nex[2 * N], head[N], tov[2 * N], val[2 * N];
ll w[N], dis[N], ans;
bool vis[N];

struct edge {
	int u, v, w;
}e[N];

bool cmp(const edge & a, const edge & b) {
	return a.w < b.w;
}

int read( ) {
	
	int t = 1, ans = 0;
	char x; x = getchar( );
	while(x < '0' || x > '9') {
		if(x == '-') t = -1;
		x = getchar( );
	}
	while(x >= '0' && x <= '9') {
		ans = ans * 10 + x - '0';
		x = getchar( );
	}
	return ans * t;
}

void add(int u, int v, int w) {
	
	tot ++; nex[tot] = head[u];
	tov[tot] = v; val[tot] = w; head[u] = tot;
}
//------------------------------
bool check2(ll mid) {
	
	memset(vis, 0, sizeof(vis));
	int cnt = 0, us = 0;
	for(int i = n - 1; i >= 1; i --) {
		if(us == n - 1) return cnt >= m;
		if(vis[i]) continue;
		if(w[i] >= mid) vis[i] = true, cnt ++, us ++;
		else {
			ll del = mid - w[i];
			int pos = lower_bound(w + 1, w + n, del) - w;
			if(pos == i) return cnt >= m;
			while(vis[pos]) pos ++;
			if(pos >= n) return cnt >= m;
			vis[pos] = true; vis[i] = true; cnt ++; us += 2;
		}
	}
}

void solve2( ) {
	
	sort(e + 1, e + n, cmp);
	for(int i = 1; i < n; i ++) w[i] = 1ll * e[i].w;
	ll l = 0, r = oo, ans = 0;
	while(l <= r) {
		ll mid = l + r >> 1;
		if(check2(mid)) ans = mid, l = mid + 1;
		else r = mid - 1;
	}
	printf("%lld\n", ans);
}
//-------------------------
void dfs(int u, int fa, int id) {
	
	for(int i = head[u]; i; i = nex[i]) {
		int v = tov[i];
		if(v == fa) continue;
		w[id] = val[i];
		dfs(v, u, id + 1);
	}
}

bool check3(ll mid) {
	
	int cnt = 0; ll now = 0;
	for(int i = 1; i < n; i ++) {
		now += w[i];
		if(now >= mid) now = 0, cnt ++;
	}
	return cnt >= m;
}

void solve3( ) {
	
	dfs(1, 0, 1);
	ll l = 0, r = oo, ans = 0;
	while(l <= r) {
		ll mid = l + r >> 1;	
		if(check3(mid)) ans = mid, l = mid + 1;
		else r = mid - 1;
	}
	printf("%lld\n", ans);
}

void Dfs(int u, int fa) {
	
	dis[u] = 0;
	ll Ma = 0, cMa = 0;
	for(int i = head[u]; i; i = nex[i]) {
		int v = tov[i];
		if(v == fa) continue;
		Dfs(v, u);
		if(dis[v] + 1ll * val[i] > Ma) cMa = max(cMa, Ma), Ma = dis[v] + val[i];
		else if(dis[v] + 1ll * val[i] > cMa) cMa = dis[v] + val[i];
	}
	ans = max(ans, Ma + cMa);
	dis[u] = Ma;
}

void solve1( ) {
	
	Dfs(1, 0);
	printf("%lld\n", ans);
}

int main( ) {
	
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	n = read( ), m = read( );
	int M = 1000000;
	bool tag1 = true, tag2 = true;
	for(int i = 1; i < n; i ++) {
		e[i].u = read( ), e[i].v = read( ), e[i].w = read( );
		M = min(e[i].w, M);
		if(e[i].u > e[i].v) swap(e[i].u, e[i].v); 
		add(e[i].u, e[i].v, e[i].w); add(e[i].v, e[i].u, e[i].w);
		if(e[i].u != 1) tag1 = false;
		if(e[i].v != e[i].u + 1) tag2 = false;
	}
	if(m == n - 1) {
		printf("%d\n", M); return 0;
	}
	else if(m == 1) solve1( );
	else if(tag1) solve2( );
	else if(tag2) solve3( );
}
