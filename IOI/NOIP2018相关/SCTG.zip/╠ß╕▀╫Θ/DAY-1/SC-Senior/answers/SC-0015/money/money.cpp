#include <bits/stdc++.h>
using namespace std;

const int N = 1e3 + 5;
int n, a[N], b[N], tot, T;
bool vis[N];

int read( ) {
	
	int t = 1, ans = 0;
	char x; x = getchar( );
	while(x < '0' || x > '9') {
		if(x == '-') t = -1;
		x = getchar( );
	}
	while(x >= '0' && x <= '9') {
		ans = ans * 10 + x - '0';
		x = getchar( );
	}
	return ans * t;
}

int exgcd(int a, int b, int & x, int & y) {
	
	if(! b) {
		x = 1; y = 0;
		return a;
	}
	int x0, y0;
	int p = exgcd(b, a % b, x0, y0);
	x = y0; y = x0 - (a / b) * y0;
	return p;
}

int gcd(int a, int b) {
	return b == 0 ? a : gcd(b, a % b);
}

void Init( ) {
	
	T = read( );
}

void clear( ) {
	
	memset(a, 0, sizeof(a)); memset(b, 0, sizeof(b));
	tot = 0; memset(vis, 0, sizeof(vis));
}

void Solve( ) {
	
	while(T --) {
		clear( ); n = read( );
		for(int i = 1; i <= n; i ++) a[i] = read( );
		sort(a + 1, a + n + 1);
		for(int i = 2; i <= n; i ++)
			for(int j = 1; j < i; j ++) {
				if(a[i] % a[j] == 0) {
					vis[i] = true;
				}
			}
		for(int i = 1; i <= n; i ++)
			if(! vis[i]) b[++ tot] = a[i];
		int ans = min(2, tot);
		for(int i = 3; i <= tot; i ++) {
			int tag = 1;
			for(int h = 1; h < i; h ++) {
				if(! tag) break;
				for(int k = 1; k < h; k ++) {
					if(! tag) break;
					int x, y; int p = exgcd(b[h], b[k], x, y);
					if(b[i] % p) {continue;}
					else {
						int M = b[i] / p; x *= M; y *= M;
						int del1 = b[h] / gcd(b[h], b[k]);
						int del2 = b[k] / gcd(b[h], b[k]);
						if(x < 0) {
							int t = (-x + del2 - 1) / del2;
							x += t * del2, y -= t * del1;
						}
						if(y < 0) {
							int t = (-y + del1 - 1) / del1;
							x -= t * del2, y += t * del1;
						}
						if(x < 0 || y < 0) {continue;}
						else tag = false;
					}
				}
			}
			ans += tag;	
		}
		printf("%d\n", ans);
	}
	
}

int main( ) {
	
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	Init( );
	Solve( );
}
