#include <bits/stdc++.h>
#define oo 1e9
using namespace std;

typedef long long ll;
const int N = 1e5 + 5;
int n, a[N];
ll ans = 0;

int read( ) {
	
	int t = 1, ans = 0;
	char x; x = getchar( );
	while(x < '0' || x > '9') {
		if(x == '-') t = -1;
		x = getchar( );
	}
	while(x >= '0' && x <= '9') {
		ans = ans * 10 + x - '0';
		x = getchar( );
	}
	return ans * t;
}

void Init( ) {
	
	n = read( );
	for(int i = 1; i <= n; i ++) a[i] = read( );
}

void Solve( ) {
	
	while(1) {
		int ma = 0, pos = 0, st = 0, ed = 0;
		for(int i = 1; i <= n; i ++) 
			if(ma < a[i]) ma = a[i], pos = i;
		if(ma == 0) break;
		ans += 1ll * ma;
		int mi = oo;
		for(int i = pos - 1; i >= 0; i --) 
			if(! a[i]) break;
			else {
				if(a[i] <= mi) mi = a[i], a[i] = 0;
				else a[i] -= mi;
			}
		mi = oo;
		for(int i = pos + 1; i <= n + 1; i ++)
			if(! a[i]) break;
			else {
				if(a[i] <= mi) mi = a[i], a[i] = 0;
				else a[i] -= mi;
			}
		a[pos] = 0;
	} 
	printf("%lld\n", ans);
}

int main( ) {
	
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	Init( );
	Solve( );
}
