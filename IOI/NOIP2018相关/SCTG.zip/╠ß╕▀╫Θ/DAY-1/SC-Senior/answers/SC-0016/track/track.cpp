#define fre yes

#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

const int MAXN_INT = 50005;
int Deep[MAXN_INT], ansC[MAXN_INT], Nico[MAXN_INT];

const int MAXN_BOOL = 50005;
bool Vis[MAXN_BOOL], cur[MAXN_BOOL];

const int MAXN_ADDEDGE = 50005 * 2;
int head[MAXN_ADDEDGE], ver[MAXN_ADDEDGE], to[MAXN_ADDEDGE], edge[MAXN_ADDEDGE];

template<typename T>inline void read(T&x) {
	x = 0; char c; int lenp = 1;
	do { c = getchar(); if(c == '-') lenp = -1; } while(!std::isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); } while(std::isdigit(c));
	x *= lenp;
}

int tot = 0;
void addedge(int x, int y, int z) {
	ver[tot] = y;
	edge[tot] = z;
	to[tot] = head[x];
	head[x] = tot++;
}

int maxx = 0, ans = 0, poi = 0;
void dfs1(int x) {
	for (int i = head[x]; ~i; i = to[i]) {
		int now = ver[i];
		if(Vis[now] == 0) {
			Vis[now] = 1;
			maxx += edge[i];
			dfs1(now);
			Vis[now] = 0;
			if(ans < maxx) {
				poi = i;
				ans = maxx;
			} maxx -= edge[i];
		}
	}
}

void dfsn(int x) {
	for (int i = head[x]; ~i; i = to[i]) {
		int now = ver[i];
		if(Vis[now] == 0) {
			Vis[now] = 1;
		}
	}
}

bool cmp(int x, int y) {
	return x > y;
}

int main() {
#ifdef fre
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
#endif
	
	memset(head, -1, sizeof(head));
	
	static int n, m, date, cc;
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n - 1; i++) {
		int x, y, z;
		scanf("%d %d %d", &x, &y, &z);
		addedge(x, y, z);
		addedge(y, x, z);
		Nico[++cc] = z;
		Deep[x]++; Deep[y]++;	
		date = std::max(date, z);
	}
	
	if(Deep[1] == n - 1) {
		std::sort(Nico + 1, Nico + 1 + cc, cmp);
		for (int i = 1; i <= 2; i++) {
			ans += Nico[i];
		} printf("%d\n", ans);
		return 0;
	}
	
	int tnt = 0, cnt = 0;
	for (int i = 1; i <= n; i++) {
		if(Deep[i] == 1) tnt++;
		else if(Deep[i] == 2) cnt++;
		else break;
	}
	
	if(tnt == 2 && cnt == n - 2) {
		for (int i = 1; i <= n; i++) {
			Vis[i] = 1;
			for (int j = head[i]; ~j; j = to[j]) {
				int v = ver[j];
				if(Vis[v] == 0) {
					ansC[i] = ansC[i - 1] + edge[j];
					Vis[v] = 1;	
				}
			}
			
		}
		
		if(m == 1) {
			printf("%d\n", ansC[n - 1]);
			return 0;
		} if(m == n - 1) {
			printf("%d\n", date);
			return 0;
		} else {
			for (int i = 0; i < m; i++) {
				ans = std::max(ansC[n + i - m] - ansC[i], ans);
			}
			printf("%d\n", ans);
			return 0;
		}
	}
	
	if(m == 1) {
		for (int i = 1; i <= n; i++) {
			if(Deep[i] == 1 && cur[i] == 0) {
				cur[i] = 1;
				maxx = 0; poi = 0;
				Vis[i] = 1;
				dfs1(i);
				cur[poi] = 1;
			}
		} printf("%d\n", ans);	
		return 0;
	} 
	
	return 0;
}
