#define fre yes

#include <cstdio>
#include <iostream>

const int MAXN_INT = 100005;
int arr[MAXN_INT];

template<typename T>inline void read(T&x) {
	x = 0; char c; int lenp = 1;
	do { c = getchar(); if(c == '-') lenp = -1; } while(!std::isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); } while(std::isdigit(c));
	x *= lenp;
}

int main() {
#ifdef fre
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
#endif
	
	static int n, ans; int minn = 1e9;
	read(n);
	for (int i = 1; i <= n; i++) {
		read(arr[i]);
		minn = std::min(arr[i], minn);
	}
	
	bool flag = false;
	for (int i = 1; i <= n; i++) {
		arr[i] -= minn;
		if(arr[i] == 0 && flag == false) {
			ans += minn;
			flag = true;	
		}
	}
	
	int maxx = arr[1], tot = 0;
	for (int i = 2; i <= n; i++) {
		if(arr[i] > arr[i - 1]) {
			ans += maxx - tot;
			maxx = arr[i];
			tot = arr[i - 1];
			continue;
		}
	} 
	
	ans += maxx - tot;
	printf("%d\n", ans);
	return 0;
}


