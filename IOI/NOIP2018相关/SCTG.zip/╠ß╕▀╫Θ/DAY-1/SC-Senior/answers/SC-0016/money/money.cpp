#define fre yes

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>

const int MAXN_INT = 100005;
int arr[MAXN_INT];

template<typename T>inline void read(T&x) {
	x = 0; char c; int lenp = 1;
	do { c = getchar(); if(c == '-') lenp = -1; } while(!std::isdigit(c));
	do { x = x * 10 + c - '0'; c = getchar(); } while(std::isdigit(c));
	x *= lenp;
}

int main() {
#ifdef fre
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
#endif
	
	static int T, n;
	scanf("%d", &T);
	while(T--) {
		scanf("%d", &n);
		if(n == 1) {
			puts("1");
		}
		if(n == 2) {
			int maxx = 0, minn = 1e9;
			for (int i = 1; i <= n; i++) {
				scanf("%d", &arr[i]);
				maxx = std::max(arr[i], maxx);
				minn = std::min(arr[i], minn);
			}
			
			if(maxx % minn == 0) {
				puts("1");
			}
			
			if(maxx % minn != 0) {
				puts("2");
			}
		}
		
		if(n == 3) {
			int a = 0, b = 1e9, c = 0;
			for (int i = 1; i <= n; i++) {
				scanf("%d", &arr[i]);
				a = std::max(arr[i], a);
				b = std::min(arr[i], b);
			}
			
			for (int i = 1; i <= n; i++) {
				if(arr[i] != a && arr[i] != b) {
					c = arr[i];
					break;	
				}	
			}
			
//			printf("%d %d %d", a, b, c);
			if(a % b == 0 && c % b == 0) puts("1");
			else if(a % c == 0 && a % b == 0 && c % b != 0) puts("2");
			else if(a % b != 0 && a % c == 0) puts("2");
			else if(a % c != 0 && a % b == 0 && c % b != 0) puts("2");
			else if(a % c != 0 && a % b == 0 && c % b == 0) puts("1");
			else if(a % c != 0 && a % b != 0 && c % b == 0) puts("2");
			else if((a - c) % b == 0 || (a - b) % c == 0) puts("2");
			else if(a % c != 0 && a % b != 0 && c % b != 0) puts("3");
			else puts("2");
		}
		
		if(n == 4) {
			int a = 0, b = 0, c = 0, d = 0;
			for (int i = 1; i <= n; i++) {
				scanf("%d", &arr[i]);
			} std::sort(arr + 1, arr + 1 + n);
			a = arr[4]; b = arr[1];
			c = arr[3]; d = arr[2];
			
			if(a % b == 0 && c % b == 0) puts("1");
			else if(d % b == 0 && ((a - c) % d == 0 || (a - c) % b == 0)) puts("2");
			else if(a % c == 0 && a % b == 0 && c % b != 0) puts("2");
			else if(a % b != 0 && a % c == 0) puts("2");
			else if(a % c != 0 && a % b == 0 && c % b == 0) puts("1");
			else if(a % c != 0 && a % b == 0) puts("2");
			else if(a % c != 0 && a % b != 0 && c % b == 0) puts("2");
			else if((a - c) % b == 0 || (a - b) % c == 0) puts("2");
			else if(a % c != 0 && a % b != 0 && c % b != 0 && a % d != 0) puts("4");
			else puts("2");
		}
		
		if(n == 5) {
			for (int i = 1; i <= n; i++) {
				scanf("%d", &arr[i]);
			}
			
			int a = rand() % (n - 1) + 1;
			printf("%d\n", a);
		}
		
		if(n > 5) {
			for (int i = 1; i <= n; i++) {
				scanf("%d", &arr[i]);
			}
			
			int a = rand() % (n - 1) + 1;
			printf("%d\n", a);
		}
	} return 0;
}


