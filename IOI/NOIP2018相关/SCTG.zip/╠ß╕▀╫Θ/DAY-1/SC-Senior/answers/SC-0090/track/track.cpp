#include<bits/stdc++.h>
using namespace std;
int n,m;
struct node{
	int to;
	int wi;
};
vector<node> maps[50001];
int deep[50001],sum[50001],fa[50001][21],ans,summary,pos[50001],cnt=1;
inline void dfs(int x,int fax)
{
	for(register int i=0;i<maps[x].size();i++)
	{
		int v=maps[x][i].to;
		if(v!=fax)
		{
			deep[v]=deep[x]+1;
			fa[v][0]=x;
			sum[v]=sum[x]+maps[x][i].wi;
			dfs(v,x);
		}
	}
}
inline void dfs2(int x,int fax)
{
	for(int i=0;i<maps[x].size();i++)
	{
		int v=maps[x][i].to;
		if(v!=fax)
		{
		summary+=maps[x][i].wi,dfs(v,x);
		pos[++cnt]=pos[cnt-1]+maps[x][i].wi;
	    }
	}
}
bool check(int x){
	int w=0,ret=x;
	for(int i=1;i<=n;++i)
	{
		if(pos[i]>=ret)
		ret=pos[i]+x,w++;
	}
	
	if(w>=m) return 0;
	else return 1;
}
inline int get_lca(int x,int y){
	if(deep[x]<deep[y])
	swap(x,y);
	
	int mi=deep[x]-deep[y],cnt=0;
	
	while(mi)
	{
		if(mi%2==1)
		x=fa[x][cnt];
		
		mi/=2,cnt++;
	}
	if(x==y)
	return x;
	
	
	for(int i=20;i>=0;i--)
	if(fa[x][i]!=fa[y][i])
	x=fa[x][i],y=fa[y][i];
	
	return fa[x][0];
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==1)
	{
		bool flag=0;
	   for(int i=1;i<n;++i)
    	{
	    	int x,y,z;
	    	node x1;
		    scanf("%d%d%d",&x,&y,&z);
		    if(x!=1) flag=1;
		    x1.to=y,x1.wi=z;
		    maps[x].push_back(x1);
		    x1.to=x;
		    maps[y].push_back(x1);
		}
		if(flag==0)
		{
			int maxx1,maxx2;
			for(int i=0;i<maps[1].size();i++)
			{
				if(maps[1][i].wi>=maxx1)
				maxx2=maxx1,maxx1=maps[1][i].wi;
				else if(maps[1][i].wi>maxx2&&maps[1][i].wi<maxx1)
				maxx2=maps[1][i].wi;
			}
			printf("%d",maxx2+maxx1);
			fclose(stdin);fclose(stdout);
			return 0;
		}
		
		deep[1]=1,fa[1][0]=1;
		dfs(1,1);
		
		for(int i=1;i<=20;i++)
		for(int j=1;j<=n;j++)
		fa[j][i]=fa[fa[j][i-1]][i-1];
		
		for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
		{
			int lca=get_lca(i,j);
			ans=max(ans,sum[i]+sum[j]-sum[lca]-sum[fa[lca][0]]);
		}
		printf("%d",ans);
		fclose(stdin);fclose(stdout);
		return 0;
	}
	bool flag=0;
	for(int i=1;i<n;++i)
	{

		int x,y,z;
		node x1;
		scanf("%d%d%d",&x,&y,&z);
		if(y!=x+1)
		flag=1;
		
		x1.to=y,x1.wi=z;
		maps[x].push_back(x1);
		x1.to=x;
		maps[y].push_back(x1);
	}
	
	if(flag==1)
	{
		for(int i=1;i<=n;++i)
		if(maps[i].size()==1)
		{
			dfs2(i,0);
		}
		int l=1,r=summary;
		
		while(l<=r)
		{
			int mid=(l+r)>>1;
			if(check(mid)) r=mid-1,ans=max(ans,mid);
			else l=mid+1;
		}
		
		printf("%d",ans);
		fclose(stdin);fclose(stdout);
		return 0;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
