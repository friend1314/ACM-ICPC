#include<bits/stdc++.h>
using namespace std;
int t,n,a[100001],ans;
inline int gcd(int x,int y)
{
	if(y==0) return x;
	else gcd(y,x%y);
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		bool pd=0;
		ans=0;
		scanf("%d",&n);
		if(n==2)
		{
		for(int i=1;i<=n;++i)
		{
		scanf("%d",&a[i]);
		if(a[i]==1) { printf("1\n");pd=1;}
	    }
		if(pd==1)
		continue;
		
		if(gcd(a[1],a[2])!=1)
		printf("1\n");
		else
		printf("3\n");
	    }
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
