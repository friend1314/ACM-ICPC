#include<bits/stdc++.h>
using namespace std;
int deep[100001],n,maxn,ans;
int now[100001];
bool flag;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
	scanf("%d",&deep[i]),maxn=max(maxn,deep[i]);
	
	for(int i=0;i<=maxn;i++)
	{
	   flag=1;
	for(int j=1;j<=n;++j)
	{
		if(deep[j]==now[j]&&flag==0)
	    ans++,flag=1;
	    
		if(deep[j]>now[j])
		now[j]++,flag=0;
	}
	   if(flag==0)
	   ans++;
    }
	printf("%d",ans);
	
	fclose(stdin);fclose(stdout);
	return 0;
}
