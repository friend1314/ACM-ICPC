#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<string>
using namespace std;
long long t,n,a[120],m,b[120],c,x,y;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%lld",&t);
	for (int i=1;i<=t;i++)
	{
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		n=0;m=0;
		scanf("%lld",&n);
		for (int i=1;i<=n;i++)
		    scanf("%lld",&a[i]);
		sort(a,a+n+1);
		if (n==2)
		{
			if (a[2]%a[1]==0) printf("1\n");
			else printf("2\n");
		}
		if (n==3)
		{
			if (a[1]==1) printf("1\n");
			else 
			{
				m=3;
				if (a[2]%a[1]==0) m--;
			    if (a[3]%a[1]==0) m--;
			    else
			    {
			        if (a[3]%a[2]==0) m--;
				    else 
				    {
				    	int c=a[3],x=a[1]+a[2];
				    	while (c>=x)
				    	{
						    if ((c%x)%a[1]==0||(c%x)%a[2]==0) 
						    {
						    	m--;
						    	break;
						    }
				    		x+=a[1]+a[2];	
				    	}
				    }
		       	} 
				printf("%lld\n",m);
			}
	
		}
		if (n==4)
		{
			if (a[1]==1) printf("1\n");
			else 
			{
				m=4;
				if (a[2]%a[1]==0) m--;
				if (a[3]%a[1]==0) m--;
				else 
				{
					if (a[3]%a[2]==0) m--;
					else 
					{
					    int c=a[3],x=a[1]+a[2];
				        while (c>=x)
				        {
				    		if ((c%x)%a[1]==0||(c%x)%a[2]==0) 
				    		{
					    	    m--;
					    	   	break;
					    	}
				        	x+=a[1]+a[2];
				        }
					}
				}
				if (a[4]%a[1]==0) m--;			
				else 
			    {
				    if (a[4]%a[2]==0) m--;
			    	else 
				    {
				  	    if (a[4]%a[3]==0) m--;
				  	    else
				  	    {
				  	       c=a[4],x=a[1]+a[2]+a[3];
						   while (c>x)
							{
								if ((c%x)%a[1]==0||(c%x)%a[2]==0||(c%x)%a[3]==0)
								{
									m--;
									break;
								}
								x+=a[1]+a[2]+a[3];
							}
							x=a[1]+a[2];
						   while (c>x)
							{
								if ((c%x)%a[1]==0||(c%x)%a[2]==0||(c%x)%a[3]==0)
								{
								
									m--;
								}
								x+=a[1]+a[2];
							}
							x=a[1]+a[3];
						   while (c>x)
							{
								if ((c%x)%a[1]==0||(c%x)%a[2]==0||(c%x)%a[3]==0)
								{
									m--;
									break;
								}
								x+=a[1]+a[3];
							}
							x=a[2]+a[3];
						   while (c>x)
							{
								if ((c%x)%a[1]==0||(c%x)%a[2]==0||(c%x)%a[3]==0)
								{
									m--;
									break;
								}
								x+=a[2]+a[3];
							}
							x=a[1];
							while (c>x)
							{
								if ((c%x)%a[2]==0||(c%x)%a[3]==0)
								{
									m--;
									break;
								}
								x+=a[1];
							}
							x=a[2];
						   while (c>x)
							{
								if ((c%x)%a[1]==0||(c%x)%a[3]==0)
								{
									m--;
									break;
								}
								x+=a[2];
							}
							x=a[3];
						   while (c>x)
							{
								if ((c%x)%a[1]==0||(c%x)%a[2]==0)
								{
									m--;
									break;
								}
								x+=a[3];
							}							
				  	    }
			    	}
		    	}
				printf("%lld\n",m);
			} 
			
		}
		if (n>4)
		{
			if (a[1]==1) printf("1\n");
			else printf("%lld\n",n);
		}
	}
	return 0;
}
