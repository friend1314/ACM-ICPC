#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<string>
using namespace std;
long long n,d[200000],ans=0;
long long maxi=0,minx=9999999;
void tc(int z,int y)
{
	if (z==y)
	{
		ans+=d[z];
		return ;
	}
	if (d[z]==0) ans--;
 	int flag=0,mid=0;
	while (flag==0)
	{
		for (int i=z;i<=y;i++)
		{	
		    if (d[i]==0)
		    {
		    	mid=i;
		    	flag=1;
		    	break;
		    }
			d[i]--;
		    if (d[i]==0)
			{
				mid=i;
				flag=1;
			}
		}
		ans++;
	}
	if (z<=mid-1) tc(z,mid-1);
	if (mid+1<=y) tc(mid+1,y); 
	return ;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%lld",&d[i]);
	}
	tc(1,n);
	cout<<ans;
	return 0;
}

