#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<string>
using namespace std;
long long n,m,maxx;	
long long x,y,z,ans;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for (int i=1;i<n;i++)
	{
		scanf("%lld%lld%lld",&x,&y,&z);
		ans+=z;
    }
    cout<<ans/m-m;
    /*long long ans=0,k=0;
    for (int i=1;i<=n;i++)
    {
    	for (int j=1;j<=n;j++)
    	{
    		if (i!=j&&a[j][i]!=0&&i!=k)
    		{
    			ans+=a[j][i];
    			k=i;i=j;j=1;
    		}
    	}
    }*/
	return 0;
}
