#include<vector>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

const int inf = 0x3f3f3f3f;
const int Maxn = 100005;
typedef long long ll;
using namespace std;

int read(){
	int f=1,x=0;
	char s=getchar();
	while(s<'0'||s>'9'){
		if(s=='-')
			f=-1;
		s=getchar();
	}
	while(s>='0'&&s<='9'){
		x=x*10+s-'0';
		s=getchar();
	}
	return x*f;
}

ll ans;
int n,k;
int a[Maxn];
int tg[Maxn];
int b[Maxn];

vector <int> vec[Maxn];

int minn,maxx,cnt;
int zk[Maxn];

int zz(int x){
	int tmp=0;
	for(int i=0;i<vec[x].size();i++){
		int num=vec[x][i];
		if(a[num-1]>=a[num]&&a[num+1]>=a[num])
			tmp++;
		if(a[num-1]==-1&&a[num+1]==-1)
			tmp--;
		a[num]=-1;
	}
	return tmp;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	a[0]=a[n+1]=-1;
	for(int i=1;i<=n;i++){
		a[i]=read();
		b[i]=a[i];
		vec[a[i]].push_back(i);
		maxx=max(a[i],maxx);
	}
	sort(b+1,b+n+1);
	cnt = 1;
	zk[1]=b[1];
	for(int i=2;i<=n;i++)
		if(b[i]!=b[i-1])
			zk[++cnt]=b[i];
	cnt = 1;
	while(zk[cnt]==0)
		cnt++;
	k=zz(0)+1;
	for(int i=1;i<=maxx;i++){
		ans+=k;
		if(i==zk[cnt]){
			cnt++;
			k+=zz(i);
		}
	}
	printf("%lld",ans);
	return 0;
}
