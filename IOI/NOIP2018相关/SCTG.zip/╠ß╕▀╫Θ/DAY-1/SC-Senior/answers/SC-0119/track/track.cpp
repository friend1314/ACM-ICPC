#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>

const int Maxn = 50005;
using namespace std;

int read(){
	int f=1,x=0;
	char s=getchar();
	while(s<'0'||s>'9'){
		if(s=='-')
			f=-1;
		s=getchar();
	}
	while(s>='0'&&s<='9'){
		x=x*10+s-'0';
		s=getchar();
	}
	return x*f;
}

int cnt;
int head[Maxn];
struct edge{
	int v,w,next;
}e[Maxn<<1];

void adde(int u,int v,int w){
	e[cnt].w=w;
	e[cnt].v=v;
	e[cnt].next=head[u];
	head[u]=cnt++;
}

int n,m;
int sum = 0;
int max1,max2;
bool flag1=1,flag2=1;

bool cmp(edge a,edge b){
	return a.w>b.w;
}

int main(){
	int u,v,w;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++){
		u=read();v=read();w=read();
		if(v!=u+1)
			flag1=0;
		if(u!=1)
			flag2=0;
		sum+=w;
		adde(u,v,w);
	}
	if(flag1){
		printf("%d",sum);
		return 0;
	}
	if(flag2){
		int ans = 0;
		sort(e,e+cnt,cmp);
		for(int i=0;i<m*2;i++)
			ans+=e[i].w;
		printf("%d",ans);
		return 0;
	}
	cout<<20030222;
	return 0;
}
