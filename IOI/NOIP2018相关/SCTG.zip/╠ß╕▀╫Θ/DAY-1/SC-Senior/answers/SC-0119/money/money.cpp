#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

const int Maxn = 105;
using namespace std;

int n,cnt;
int a[Maxn];
int b[Maxn];
int maxx;

bool zz;
bool flag;
bool vis[Maxn];
bool dp[Maxn];

int k[Maxn];

bool check2(){
	for(int i=1;i<=cnt;i++)
		if(!dp[b[i]])
			return false;
	return true;
}

void dfs2(int x,int sum){
	if(sum>maxx)
		return;
	if(zz)
		return;
	if(dp[sum])
		return;
	dp[sum]=1;
	if(check2()){
		zz=1;
		return;
	}
	for(int i=1;i<=x;i++){
		dfs2(x,sum+k[i]);
	}
}

void dfs1(int x,int step,int j){
	if(flag)
		return;
	if(x-step>cnt-j)
		return;
	if(step==x){
		memset(dp,0,sizeof(dp));
		zz=0;
		dfs2(x,0);
		if(zz)
			flag=1;
		return;
	}
	for(int i=j+1;i<=cnt;i++){
		if(vis[i])
			continue;
		k[step+1]=b[i];
		vis[i]=1;
		dfs1(x,step+1,i);
		vis[i]=0;
	}
}

bool check(int mid){
	flag = 0;
	dfs1(mid,0,0);
	if(flag==1)
		return true;
	return false;
}

int getans(){
	int ans;
	int l=1,r=cnt;
	while(l<=r){
		int mid=(l+r)>>1;
		if(check(mid)){
			r=mid-1;
			ans=mid;
		}
		else
			l=mid+1;
	}
	return ans;
}

int main(){
	int T;
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		maxx = cnt = 0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++){		
				if(a[j]==-1||a[i]==-1)
					continue;
				if(a[j]%a[i]==0)
					a[j]=-1;
			}
		for(int i=1;i<=n;i++){
			if(a[i]==-1)
				continue;
			maxx=max(maxx,a[i]);
			b[++cnt]=a[i];
		}
 		printf("%d\n",getans());
	}
}
