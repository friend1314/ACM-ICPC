#include<iostream>
#include<algorithm>
#include<cstdio>
#define rg register

using namespace std;
int T,n,ans,a[110],use[110];
bool f;

inline bool dfs(int now,int k)
{
    if(k==ans+1) return 0;
    if(!now || !(now%use[k])) return 1;
    for(int j=1;use[k]*j<=now;j++)
    {
        if(dfs(now-use[k]*j,k+1)) return 1;
    }
    return dfs(now,k+1);
}
int main()
{
    freopen("money.in","r",stdin),freopen("money.out","w",stdout);
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);
        for(rg int i=1;i<=n;i++) scanf("%d",&a[i]);
        sort(a+1,a+n+1);
        if(a[1]==1)
        {
            puts("1");
            continue;
        }
        ans=1;
        use[1]=a[1];
        for(rg int i=2;i<=n;i++)
        {
            f=0;
            for(int j=1;j<=ans;j++)
            {
                if(!(a[i]%use[j]))
                {
                    f=1;
                    break;
                }
            }
            if(f || dfs(a[i],1)) continue;
            use[++ans]=a[i];
        }
        printf("%d\n",ans);
    }

    return 0;
}
