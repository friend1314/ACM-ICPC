#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;
typedef long long ll;
const int maxn=105;

ll a[maxn],n,b[maxn],cnt;

inline ll read()
{
    ll x=0,f=1;char c=getchar();
    for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
    for(;isdigit(c);x=(x<<3)+(x<<1)+c-'0',c=getchar());
    return x*f;
}

inline bool check(int step,int le)
{
    if(step==0 && le>0) return false;
    if(le==0) return true;
    for(int i=0;le-i*b[step]>=0;++i)
        if(check(step-1,le-i*b[step])) return true;
    return false;
}

int main()
{
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    int t=read();
    while(t--)
    {
        n=read();
        cnt=0;
        for(int i=1;i<=n;++i) a[i]=read();
        sort(a+1,a+n+1);
        for(int i=1;i<=n;++i)
            if(!check(cnt,a[i])) b[++cnt]=a[i];
        printf("%lld\n",cnt);
    }
    return 0;
}

/*
3
4
3 19 10 6
5
11 29 13 19 17
8
13 11 19 16 3 15 20 17

2
5
3
*/
