#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;
typedef long long ll;
const int maxn=50005;

struct e{
    int u,v,nxt,w;
}edge[maxn<<1];
int head[maxn],edge_len;
ll n,m,sum[maxn];
int qwq[maxn];

inline ll read()
{
    ll x=0,f=1;char c=getchar();
    for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
    for(;isdigit(c);x=(x<<3)+(x<<1)+c-'0',c=getchar());
    return x*f;
}

inline void edge_add(int u,int v,int w)
{
    edge[edge_len].u=u;edge[edge_len].v=v;
    edge[edge_len].w=w;edge[edge_len].nxt=head[u];
    head[u]=edge_len++;
}
//40sub_stack
struct node{
    int u,dis;
};
bool vis[maxn];
inline node bfs(int x)
{
    memset(vis,0,sizeof(vis));
    queue<node> q;
    int res=0,mdis=0;
    q.push((node){x,0});
    while(!q.empty())
    {
        node now=q.front();q.pop();
        if(vis[now.u]) continue;
        if(now.dis>mdis) mdis=now.dis,res=now.u;
        vis[now.u]=true;
        for(int i=head[now.u],v;~i;i=edge[i].nxt)
        {
            v=edge[i].v;
            if(!vis[v]) q.push((node){v,now.dis+edge[i].w});
        }
    }
    return (node){res,mdis};
}
//40sub_stack end

//40sub_stack
inline void init()
{
    for(int k=1;k!=n;++k)
        for(int i=head[k],v;~i;i=edge[i].nxt)
        {
            v=edge[i].v;
            if(v==k+1) sum[k]=sum[k-1]+edge[i].w;
        }
}

inline bool check(int tot)
{
    int l=1,r=1,cnt=0;
    while(r<n)
    {
        if(sum[r]-sum[l-1]>=tot) cnt++,l=r+1;
        r++;
    }
    return cnt>=m;
}
//40sub_stack end

int main()
{
    freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    memset(head,-1,sizeof(head));
    edge_len=0;
    n=read(),m=read();
    bool flag1=true,flag2=true;;
    for(int i=1,a,b,c;i!=n;++i)
    {
        a=read(),b=read(),c=read();
        qwq[i]=c;
        if(b!=a+1) flag1=false;
        if(a!=1) flag2=false;

        edge_add(a,b,c),edge_add(b,a,c);
    }


    if(m==1)
    {
        node tmp=bfs(1);
        printf("%d\n",bfs(tmp.u).dis);
    }
    else if(flag1) //b=a
    {
        init();
        int L=0,R=sum[n-1],ans=0;
        while(L<R)
        {
            int mid=(L+R)>>1;
            if(check(mid)) ans=mid,L=mid+1;
            else R=mid;
        }
        printf("%d\n",ans);
    }
    else if(flag2)  // a=1 15sub_stack
    {
        sort(qwq+1,qwq+n);
        printf("%d",min(qwq[3],qwq[1]+qwq[2]));
    }
    else printf("%d\n",edge[1].w+edge[3].w);
    return 0;
}

/*
7 1
1 2 10
1 3 5
2 4 9
2 5 8
3 6 6
3 7 7

5 3
2 3 7
1 2 2
3 4 4
4 5 6
*/
