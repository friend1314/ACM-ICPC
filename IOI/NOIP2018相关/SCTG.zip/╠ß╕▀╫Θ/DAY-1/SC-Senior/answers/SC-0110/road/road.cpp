#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <queue>
#include <set>
#include <map>
#include <vector>

using namespace std;
typedef long long ll;
const int maxn=100000+5;

ll n,a[maxn],ans;

inline ll read()
{
    ll x=0,f=1;char c=getchar();
    for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
    for(;isdigit(c);x=(x<<3)+(x<<1)+c-'0',c=getchar());
    return x*f;
}

int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    n=read();
    for(int i=1;i<=n;++i)
    {
        a[i]=read();
        if(a[i]>a[i-1]) ans+=a[i]-a[i-1];
    }
    printf("%lld\n",ans);
    return 0;
}
