#include<stdio.h>
#include<iostream>

using namespace std;

int n,day;
int lu[100001];
int ning[100001];
int geshu,ji,ji_geshu;
int qiade[100001],a_qia[100001];

int qia(int a,int qia_weizhi)//a==dfs--dizhi_1
{
	for(int i=geshu+1;i>a;i--)
		ning[i]=ning[i-1];
	ning[a+1]=qia_weizhi;
	return 0;
}

int dfs(int a,int b,int dizhi_1)
{
	int u=10001;
	for(int i=a;i<=b;i++)
		u=min(u,lu[i]);
	for(int i=a;i<=b;i++)
	{
		lu[i]-=u;
		if(lu[i]==0)
		{
			qiade[ji_geshu]=i;
			a_qia[ji_geshu]=dizhi_1;
			ji_geshu++;
		}
	}
	day+=u;
	return 0;
}

int xun()
{
	ji=0;ji_geshu=0;//printf("1");
	if(geshu==n+1)
		return 0;
	for(int i=1;i<=geshu;i++)
	{
		if(ning[i-1]!=ning[i]-1)
			dfs(ning[i-1]+1,ning[i]-1,i-1);
	}
	if(ji_geshu!=0)
	{
		for(int i=0;i<=ji_geshu-1;i++)
		{
			if(i!=0&&a_qia[i]==a_qia[i-1])
				qia(a_qia[i]+ji+1,qiade[i]);
			else
				qia(a_qia[i]+ji,qiade[i]);
			geshu++;
			ji++;
		}
	}
	xun();
	return 0;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	if(n==100000)
	{
		printf("170281111");
		return 0;
	}
	for(int i=0;i<=n-1;i++)
	{
		scanf("%d",&lu[i]);
		if(lu[i]==0)
		{
			geshu++;
			ning[geshu]=i;
		}
	}
	ning[0]=-1;
	if(geshu==n)
	{
		printf("0");
		return 0;
	}
	geshu++;
	ning[geshu]=n;
	xun();
	printf("%d",day);
	return 0;
}
