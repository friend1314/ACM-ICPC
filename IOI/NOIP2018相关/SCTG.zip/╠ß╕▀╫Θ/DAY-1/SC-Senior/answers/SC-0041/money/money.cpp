#include<stdio.h>
#include<iostream>

using namespace std;

struct Money{
	int money[25001];
	int geshu;
	int ans;
}zu[21];

int n;//ji zu

int shu(int i)
{
	printf("%d\n",zu[i].ans);
	return 0;
}

int shuang(int ge,int num,int level,int he,int into,int all)
{
	int q=0;
	if(level==ge)
	{
		if(num%he!=0)
			return 1;
		else	
			return 0;
	}
	for(int i=1;i<=into;i++)
	{
		he+=zu[all].money[i];
		q=(q+shuang(ge,num,level+1,he,into,all))%100;
		he-=zu[all].money[i];
	}
	return q;
}

bool pan(int ge,int num,int all)
{
	for(int i=1;i<=ge;i++)
	{
		if(shuang(i,num,0,0,ge,all)!=0)
			return true;
	}
	return false;
}

bool dfs(int into,int zu_who)
{
	for(int i=into+1;i<=zu[zu_who].geshu;i++)
	{
		if(pan(into,zu[zu_who].money[i],zu_who))
			return false;
	}
	return true;
}

int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&zu[i].geshu);
		for(int j=1;j<=zu[i].geshu;j++)
			scanf("%d",&zu[i].money[j]);
		for(int j=1;j<=zu[i].geshu;j++)
		{
			if(dfs(j,i))
			{
				zu[i].ans=j;
				break;
			}	
		}
		shu(i);
	}
	return 0;
}
