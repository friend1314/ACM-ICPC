#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
const int maxn=2e4+5e3+10;
int dis[maxn],vis[maxn];
int n,T;
int tmp;
typedef pair<int,int> pii;
int a[maxn];
void dij(int lim)
{
	memset(dis,0x3f3f3f3f,sizeof(dis));
	memset(vis,0,sizeof(vis));
	priority_queue<pii>q;
	dis[0]=0;
	q.push(make_pair(0,0));
	while(!q.empty())
	{
		pii node=q.top();
		q.pop();
		int u=node.second;
		if(vis[u]==1)continue;
		vis[u]=1;
		for(int i=2;i<=lim;i++)
		{
			int v=(u+a[i])%tmp;
			//if(v>a[lim+1])continue;
			if(dis[v]>dis[u]+a[i])
			{
				dis[v]=dis[u]+a[i];
				q.push(make_pair(-dis[v],v));
			}
		}
		
	}
}
//int dp[maxn];
//int MAX=0;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		tmp=a[1];
		int del=0;
		for(int i=2;i<=n;i++)
		{
			dij(i-1);
			/*
			memset(dp,0,sizeof(dp));
			dp[0]=1;
			for(int j=0;j<=a[i];j++)
			{
				for(int k=1;k<i;k++)
				if(j-a[k]>=0&&dp[j-a[k]])
				{
					dp[j]=1;
					break;	
				}
			}
			if(dp[a[i]])del++;
			*/
			if(dis[a[i]%tmp]<=a[i])del++;
		}
		printf("%d\n",n-del);	
	}
	return 0;
}
