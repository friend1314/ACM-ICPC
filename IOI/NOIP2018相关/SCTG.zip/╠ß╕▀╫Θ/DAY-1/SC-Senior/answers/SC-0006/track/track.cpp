#include<iostream>
#include<cstring>
#include<cstdio>
#include<queue>
#include<algorithm>
using namespace std;
const int maxn=5e4+10;
struct edge
{
	int v,next,w;
}e[maxn<<1];
int head[maxn],cnt=0;
int stack[maxn],top=0;
void add(int u,int v,int w)
{
	e[++cnt]=(edge){v,head[u],w};
	head[u]=cnt;
	e[++cnt]=(edge){u,head[v],w};
	head[v]=cnt;
}
int n,m;
int u,v,w;
int tot=0;
namespace baoli_ai_1
{
	bool check(int mid)
	{
		int now=0;
		priority_queue<int>q;
		for(int i=1;i<=top;i++)
		{
			if(stack[i]>=mid)now++;
			else 
			{
				if(!q.empty()&&stack[i]+q.top()>=mid)q.pop(),now++;
				else q.push(stack[i]);
			}
			
		}
		return now>=m;
	}
	void solve()
	{
		sort(stack+1,stack+1+top);
		int MAX=stack[top];
		if(top!=1)MAX+=stack[top-1];
		int l=0,r=MAX,ans=0;
		while(l<=r)
		{
			int mid=l+r>>1;
			if(check(mid))ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",ans);
	}
}
namespace baoli_ai_bi
{
	int now=0;
	void dfs(int u,int fa,int mid,int sum)
	{
		if(sum>=mid)sum=0,now++;
		for(int i=head[u];~i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==fa)continue;
			dfs(v,u,mid,sum+e[i].w);
		}
	}
	bool check(int mid)
	{
		now=0;
		dfs(1,0,mid,0);
		return now>=m;
	}
	void solve()
	{
		int l=0,r=tot,ans;
		while(l<=r)
		{
			int mid=l+r>>1;
			if(check(mid))ans=mid,l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",ans);
	}
}
namespace m_1
{
	int ans=0;
	int dp[maxn][2],down[maxn];
	int up[maxn];
	const int inf=-1<<29;
	void dfs(int u,int fa)
	{
		dp[u][0]=0;
		dp[u][1]=inf;
		for(int i=head[u];~i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==fa)continue;
			dfs(v,u);
			if(dp[u][0]<e[i].w+dp[v][0])
			{
				dp[u][0]=e[i].w+dp[v][0];
				down[u]=v;
			}
			else dp[u][1]=max(dp[u][1],dp[v][0]+e[i].w);
		}
	}
	void dfs2(int u,int fa,int dist)
	{
		if(u==1)ans=max(ans,dp[u][0]);
		else 
		{
			if(down[fa]==u)up[u]=max(up[fa],dp[fa][1])+dist;
			else up[u]=max(up[fa],dp[fa][0])+dist;
		}
		ans=max(ans,dp[u][0]+up[u]);
		for(int i=head[u];~i;i=e[i].next)
		{
			int v=e[i].v;
			if(v==fa)continue;
			dfs2(v,u,e[i].w);
		}
	}
	void solve()
	{
		dfs(1,0);
		dfs2(1,0,0);
		printf("%d\n",ans);
	}	
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	cnt=0;
	scanf("%d%d",&n,&m);
	int flag=1;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&u,&v,&w),tot+=w;
		stack[++top]=w;
		add(u,v,w);
		if(min(u,v)!=1)flag=0;
	}
	if(m==1)m_1::solve();
	else if(flag)baoli_ai_1::solve();
	else baoli_ai_bi::solve();
	return 0;
}
