#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=1e5+5;
const int inf=1<<30;
int val[maxn];
int n;
inline int read()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch<='9'&&ch>='0')x=x*10+(ch^'0'),ch=getchar();
	return x;
}
int sum[maxn<<2],pos[maxn<<2];
int lazy[maxn<<2];
bool flag[maxn<<2];
inline void pushup(int rt)
{
    if(sum[rt<<1]>sum[rt<<1|1])pos[rt]=pos[rt<<1|1],sum[rt]=sum[rt<<1|1];
    else pos[rt]=pos[rt<<1],sum[rt]=sum[rt<<1];
    flag[rt]=flag[rt<<1]|flag[rt<<1|1];
}
inline void build(int l,int r,int rt)
{
    if(l==r)
    {
        sum[rt]=val[l];
        pos[rt]=l;
        return ;
    }
    int mid=l+r>>1;
    build(l,mid,rt<<1);
    build(mid+1,r,rt<<1|1);
    pushup(rt);
}
inline void pushdown(int rt)
{
    if(lazy[rt])
    {
        sum[rt<<1]+=lazy[rt];
        sum[rt<<1|1]+=lazy[rt];
        lazy[rt<<1]+=lazy[rt];
        lazy[rt<<1|1]+=lazy[rt];
        lazy[rt]=0;
    }
}
void update(int L,int R,int l,int r,int rt,int v)
{
    if(L<=l&&r<=R)
    {
        lazy[rt]+=v;
        sum[rt]+=v;
        return ;
    }
    int mid=l+r>>1;
    pushdown(rt);
    if(L<=mid)update(L,R,l,mid,rt<<1,v);
    if(R>mid)update(L,R,mid+1,r,rt<<1|1,v);
    pushup(rt);
}
void change(int poss,int l,int r,int rt)
{
    if(l==r)
    {
        sum[rt]=inf;
        flag[rt]=1;
        return ;
    }
    int mid=l+r>>1;
    pushdown(rt);
    if(poss<=mid)change(poss,l,mid,rt<<1);
    else change(poss,mid+1,r,rt<<1|1);
    pushup(rt);
}
int check(int L,int R,int l,int r,int rt)
{
    if(L<=l&&r<=R)return flag[rt];
    int mid=l+r>>1;
    pushdown(rt);
    int ans=0;
    if(L<=mid)ans|=check(L,R,l,mid,rt<<1);
    if(R>mid)ans|=check(L,R,mid+1,r,rt<<1|1);
    return ans;
}
inline int queryl(int pos)
{
	int l=1,r=pos,ans=pos;
	while(l<=r)
	{
		int mid=l+r>>1;
		if(check(mid,pos,1,n,1)!=1)ans=mid,r=mid-1;
		else l=mid+1;
	}
	return ans;
}
inline int queryr(int pos)
{
	int l=pos,r=n,ans=pos;
	while(l<=r)
	{
		int mid=l+r>>1;
		if(check(pos,mid,1,n,1)!=1)ans=mid,l=mid+1;
		else r=mid-1;
	}
	return ans;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)val[i]=read();
	long long ans=0;
	int cnt=0;
	build(1,n,1);
	while(cnt<n)
	{
		int poss=pos[1],num=sum[1];
		while(num==0)
		{
			cnt++;
			change(poss,1,n,1);
			poss=pos[1],num=sum[1];
		}
		if(cnt==n)break;
		int l=queryl(poss),r=queryr(poss);
		update(l,r,1,n,1,-num);
		ans+=num;
	}
	printf("%lld\n",ans);
	return 0;
}

