#include<stack>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<queue>
#include<string>
#include<cstring>
#include<iostream>
#include<sstream>
#include<cmath>
#include<ctime>
using namespace std;
int n;
unsigned long long  a[1000010];
unsigned long long ans=0;
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%d",&n);
    for(int i=1; i<=n; i++)
      scanf("%d",&a[i]);
    for(int i=1; i<=n; i++)
        if(a[i]>a[i-1])
            ans+=a[i]-a[i-1];
    printf("%d",ans);
    return 0;
}


