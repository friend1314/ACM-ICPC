#include<stack>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<queue>
#include<string>
#include<cstring>
#include<iostream>
#include<sstream>
#include<cmath>
#include<ctime>
using namespace std;
int n,m;
int a[1000][1000];
int t1,t2,t3;
int main()
{
    freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    cin>>n>>m;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            if(i==j)
                a[i][j]=0;
            else
                a[i][j]=9999;
    for(int i=1; i<=n-1; i++)
    {
        cin>>t1>>t2>>t3;
        a[t1][t2]=t3;
        a[t2][t1]=t3;
    }
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            for(int k=1; k<=n; k++)
                if(a[i][j]>a[i][k]+a[k][j])
                    a[i][j]=a[i][k]+a[k][j];

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            if(a[i][j]==9999)
                a[i][j]=0;
    }
    int tmin=-1;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            if(a[i][j]>tmin)
                tmin=a[i][j];
    cout<<tmin;
}

