#include<stack>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<queue>
#include<string>
#include<cstring>
#include<iostream>
#include<sstream>
#include<cmath>
#include<ctime>
using namespace std;
int T;
int a[1000010];
bool b[1000010];
int c[1000][1000];
int d[1000010];
void solve()
{
    int n;
    cin>>n;
    int ans=n;
    for(int i=1; i<=n; i++)
        cin>>a[i];
    sort(a+1,a+n+1);
    int u=a[n];
    for(int i=1; i<=u; i++)
        b[i]=true;
    int l=0,v=0;
    for(int i=1; i<=n; i++)
    {
        if(b[a[i]]==false)
            ans--;
        else
        for(int j=a[i]; j<=u; j+=a[i])
        {
            b[j]=false;
        }
    }

    cout<<ans<<endl;
}
int main()
{
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    cin>>T;
    while(T--)
    {
        solve();
    }
}
