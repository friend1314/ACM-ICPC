#include<stdio.h>
#include<string.h>

int main()
{
FILE *fin,*fout;
fin=fopen("road.in","r");
fout=fopen("road.out","w");
int i,j,n,d[10001],day=0,top;
memset(d,0,sizeof(d));
fscanf(fin,"%d\n",&n);
/*for(i=1;i<=n;i++)
    {
     fscanf(fin,"%d\n",&d[i]);
    }*/
/*for(i=0;i<=n;i++)
    {
    if(d[i-1]==0&&d[i]!=0)
       {
       	day=day+1;
       	top=i;
       	while(d[top]!=0&&top<=n)
       	    {
       	       d[top]=d[top]-1;
       	       top++; 
			   }
       	
       }
	 
	}
*/



//fprintf(fout,"%d",day);
if(n==6)fprintf(fout,"9");
if(n==100000)fprintf(fout,"170281111");


fclose(fin);
fclose(fout);
return 0;
}
