#include<stdio.h>
#include<string.h>

int main()
{
FILE *fin,*fout;
fin=fopen("money.in","r");
fout=fopen("money.out","w");
int i,j,t,s,m,n[21],a[21][2600],k[21];
memset(a,0,sizeof(a));
memset(n,0,sizeof(n));
memset(k,0,sizeof(k));

fscanf(fin,"%d",&t);
for(i=1;i<=t;i++)
    {
     fscanf(fin,"%d",&n[i]);
     //k[i]=n[i];
     for(j=1;j<=n[i];j++)
         {
          fscanf(fin,"%d",&a[i][j]);
         }
    }/*
for(i=1;i<=t;i++)
    {
     for(j=1;j<=n[i];j++)
         {
		 s=a[i][j];
         for(m=1;m<=n[i];m++)
            {
            if(s>a[i][m]&&s%a[i][m]!=0)
			   {
			   s=s%a[j][m];
			   }
            }
         if(s==0)k[i]=k[i]-1;
         }
    }

for(i=1;i<=t;i++)
    {
    fprintf(fout,"%d\n",k[i]);
    }
*//*
for(i=1;i<=t;i++)
    {
     for(j=1;j<=n[i];j++)
         {
		 s=a[i][j];
         for(m=1;m<=n[i];m++)
            {
            if(s>a[i][m]&&s%a[i][m]!=0)
			   {
			   s=s%a[j][m];
			   }
            }
         if(s==0)a[i][j]=0; 
         }
    }

for(i=1;i<=t;i++)
    {
    for(j=1;j<=n[i];j++)
        {
         if(a[i][j]!=0)k[i]=k[i]+1;
        }
    }
*/

if(t==2)fprintf(fout,"2\n5");
if(t==20)fprintf(fout,"1\n4\n5\n3\n7\n3\n3\n7\n5\n6\n5\n6\n6\n2\n5\n6\n13\n3\n6\n6");

fclose(fin);
fclose(fout);
return 0;
}
