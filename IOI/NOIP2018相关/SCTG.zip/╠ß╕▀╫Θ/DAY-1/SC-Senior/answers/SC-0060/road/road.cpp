#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <queue>
#define ll long long
#define MAXN 100005
using namespace std;
typedef pair<int,int> pii;
int n,a[MAXN],sum[MAXN];ll ans;
inline int Max(int x,int y){return x > y ? x : y;}
inline int Min(int x,int y){return x < y ? x : y;}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i(1);i <= n;i++)
		scanf("%d",a + i);	
	int mi,pos,f,l,r,tmp;
	while(1)
	{
		f = 1;
		for(int i(1);i <= n;i++)
			if(a[i]){f = 0;break;}
		if(f) break;
		pos = 1,tmp = 0;
		/*while(pos <= n)
		{
			tmp += sum[pos];
			while(a[pos] + tmp == 0 && pos <= n) ++pos,tmp += sum[pos];
			l = pos,mi = 1e9;
			while(a[pos] + tmp != 0 && pos <= n)
				mi = Min(mi,a[pos] + tmp),tmp += sum[++pos];
			r = pos,sum[l] -= mi,sum[r] += mi,ans += mi;
		}*/
		while(pos <= n)
		{
			while(a[pos] == 0 && pos <= n) ++pos;
			if(pos > n) break;
			l = pos,mi = 1e9;
			while(a[pos] != 0 && pos <= n)
				mi = Min(mi,a[pos]),++pos;
			for(int i(l);i < pos;i++) a[i] -= mi;
			//printf("%d %d %d\n",l,pos,mi);
			ans += mi;
		}
	}
	printf("%lld",ans);
	return 0;
}
