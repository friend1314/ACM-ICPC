//panzer vor!
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#define MAXN 105
using namespace std;
int n,a[MAXN],t[MAXN],vis[MAXN];
int dfs(int x,int pos,int lit)
{
	if(x == lit + 1)
	{
		int te,f(1);
		for(int i(1);i <= n;i++)
		{
			if(vis[i]) continue;
			te = a[i];
			for(int k(lit);k >= 1;k--) te %= t[k];
			if(te) {f = 0;break;}
		}
		return f;
	}
	for(int i(pos);i <= n;i++)
	{
		if(vis[i]) continue;
		vis[i] = 1,t[x] = a[i];
		if(dfs(x + 1,i + 1,lit)) return 1;
		vis[i] = 0;
	}
	return 0;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);	
	int T,mx,f,ans;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		memset(vis,0,sizeof(vis));
		for(int i(1);i <= n;i++)
			scanf("%d",a + i);
		sort(a + 1,a + n + 1);
		f = 1;
		for(int i(2);i <= n;i++)
			if(a[i] % a[1] != 0){f = 0;break;}
		if(f) {printf("1\n");continue;}
		int d = a[2] - a[1];f = 1;
		for(int i(3);i <= n;i++)
			if(a[i] - a[i - 1] != d){f = 0;break;}
		if(f) {printf("2\n");continue;}
		ans = n;
		for(int i(2);i < n;i++)
			if(dfs(1,1,i)) {ans = i;break;}
		printf("%d\n",ans);
	}
	return 0;
}
