#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <queue>
#define ll long long
#define MAXN 50005
using namespace std;
int n,m,k,nd,head[MAXN],vis[MAXN];ll d,dis[MAXN];
struct edge{int v,nxt;ll w;}e[MAXN << 1 | 1];
inline void add_edge(int u,int v,ll w)
{
	e[++k].v = v,e[k].w = w;
	e[k].nxt = head[u],head[u] = k;
}
void dfs(int u,int fa,ll td)
{
	if(td > d) d = td,nd = u;
	int v;
	for(int i(head[u]);i;i = e[i].nxt)
		if((v = e[i].v) != fa) dfs(v,u,td + e[i].w);
}
inline int check(ll mid)
{
	int ret(1);ll sum(0);
	for(int i(1);i < n;i++)
	{
		if(dis[i] > mid) return 0;
		if(sum + dis[i] > mid) ++ret,sum = dis[i];
		else sum += dis[i];
	}
	if(sum < mid) return 0;
	return ret >= m;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int u,v,ts1(1),ts2(1);ll w;
	scanf("%d%d",&n,&m);
	for(int i(1);i < n;i++)
	{
		scanf("%d%d%lld",&u,&v,&w),add_edge(u,v,w),add_edge(v,u,w);
		if(u != 1) ts1 = 0;
		if(v != u + 1) ts2 = 0;
	}
	if(m == 1) 
	{
		dfs(1,0,0),d = 0,dfs(nd,0,0);
		printf("%lld",d);
	}
	else if(ts2)
	{
		int cnt(0);
		for(int i(1);i <= k;i += 2)
			dis[++cnt] = e[i].w;
		ll l(0),r(1ll << 50),mid,ans;
		while(l <= r)
		{
			mid = l + r >> 1;
			if(check(mid)) ans = mid,l = mid + 1;
			else r = mid - 1;
		}
		printf("%lld",ans);
	}
	else printf("0");
	return 0;
}
