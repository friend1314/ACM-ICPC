#include <cmath>
#include <cstdio>
#include <algorithm>
#define rg register
#define llint long long
using namespace std;
const int N=1008611;

template <typename _tp>
inline void read(_tp &x)
{
	x = 0;int f = 1;char c = getchar();
	for(;c>'9'||c<'0';c=getchar()) if(c=='-') f = -1;
	for(;c>='0'&&c<='9';c=getchar()) x = (x<<1)+(x<<3)+(c^48);
	x *= f;
}
template <typename _tp>
inline void write(_tp x)
{
	int www[66],ws=0;
	if(x<0) putchar('-'),x = -x;
	if(x==0) putchar('0');
	while(x>0)
	{
		++ws,www[ws] = x%10;
		x/=10;
	}
	for(rg int i=ws;i>=1;--i)
		putchar((char)(www[i]+'0'));
}

int t,n,mon[N];
inline bool dfs(int wl,int las,int nl)
{
	if(nl!=0&&wl%nl==0)
		return 1;
	for(rg int i=las;i>=1;--i)
	{
		if(nl+mon[i]>wl) continue;
		if(dfs(wl,i,nl+mon[i]))
			return 1;
	}
	return 0;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);
		for(rg int i=1;i<=n;++i)
			read(mon[i]);
		stable_sort(mon+1,mon+n+1);
		int ans = n;
		for(rg int i=2;i<=n;++i)
			if(dfs(mon[i],i-1,0))
			{
				--ans;
			}
		printf("%d\n",ans);
	}
	return 0;
}
