#include <cmath>
#include <cstdio>
#include <algorithm>
#define rg register
#define llint long long
using namespace std;
const int N=1008611;

struct edge
{
	int tow,nxt,val;
}e[N<<1];
int e_tot,e_head[N];

struct edge2
{
	int frm,tow,val;
	inline bool operator < (const edge2 a)const
	{
		return a.val > val;
	}
}e2[N];

int n,m,tot,minlen = 0x7f7f7f7f;
int noode1,deeep1,noode2,deeep2;

inline void e_add(int x,int y,int z)
{
	++e_tot,e[e_tot].tow = y,e[e_tot].nxt = e_head[x],e[e_tot].val = z,e_head[x] = e_tot;
}
inline void dfs1(int now,int las,int dep)
{
	if(dep>deeep1)
		deeep1 = dep,noode1 = now;
	for(rg int i=e_head[now];i;i=e[i].nxt)
		if(e[i].tow!=las)
			dfs1(e[i].tow,now,dep+e[i].val);
}
inline void dfs2(int now,int las,int dep)
{
	if(dep>deeep2)
		deeep2 = dep,noode2 = now;
	for(rg int i=e_head[now];i;i=e[i].nxt)
		if(e[i].tow!=las)
			dfs2(e[i].tow,now,dep+e[i].val);
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int invar1,invar2,invar3;
	scanf("%d%d",&n,&m);
	if(m==1)
	{
		for(rg int i=1;i<n;++i)
			scanf("%d%d%d",&invar1,&invar2,&invar3),e_add(invar1,invar2,invar3),e_add(invar2,invar1,invar3);
		dfs1(1,1,0);
		dfs2(noode1,noode1,0);
		printf("%d",deeep2);
	}
	else
	{
		for(rg int i=1;i<n;++i)
		scanf("%d%d%d",&e2[i].frm,&e2[i].tow,&e2[i].val);
		for(rg int i=n-1;i>m;--i)
		{
			stable_sort(e2+1,e2+i+1);
			bool hr = 0;
			for(rg int j=i-1;j>=1;--j)
			{
				if(e2[1].frm==e2[j].frm)
				{
					e2[1].frm = e2[j].tow;
					e2[1].val += e2[j].val;
					hr = 1;
					break;
				}
				else if(e2[1].frm==e2[j].tow)
				{
					e2[1].tow = e2[j].tow;
					e2[1].val += e2[j].val;
					hr = 1;
					break;
				}
				else if(e2[1].tow==e2[j].tow)
				{
					e2[1].tow = e2[j].frm;
					e2[1].val += e2[j].val;
					hr = 1;
					break;
				}
				else if(e2[1].tow==e2[j].frm)
				{
					e2[1].frm = e2[j].frm;
					e2[1].val += e2[j].val;
					hr = 1;
					break;
				}
			}
			if(hr==0)
				swap(e2[1],e2[i]);
		}
		stable_sort(e2+1,e2+m+1);
		printf("%d",e2[m].val);
	}
	return 0;
}
