#include <cmath>
#include <cstdio>
#include <algorithm>
#define rg register
#define llint long long
using namespace std;
const int N=1008611;

int n;
llint dep[N],ans;

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(rg int i=1;i<=n;++i)
		scanf("%lld",&dep[i]);
	for(rg int i=1;i<=n;++i)
		if(dep[i]>dep[i-1])
			ans += dep[i]-dep[i-1];
	printf("%lld",ans);
	return 0;
}
