#include<iostream>
#include<bits/stdc++.h>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#define rd read()
#define gc getchar()
#define ll long long
#define maxn 100001 
using namespace std;
ll read()
{
	ll x=0;int w=1;char ch=gc;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=gc;}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch-'0');ch=gc;}
	return x*w;
}
int n;
int d[maxn],dt;
ll ans;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=rd;
	ans=0;
	for(int i=1;i<=n;++i)
	{
		d[i]=rd;
	}
	for(int i=1;i<=n;++i)
	{
		if(d[i]==0) continue;
		dt=d[i];
		ans+=dt;
		for(int j=i+1;j<=n;++j)
		{
			if(d[j]==0) break;
			else 
			{
				if(d[j]>dt) d[j]-=dt;
				else 
				{
					dt=d[j];
					d[j]=0;
				}
			}
		}	
	}
	cout << ans;
	return 0;
}
/*
freopen("text.in","r",stdin);
freopen("text.out","w",stdout);
*/	
