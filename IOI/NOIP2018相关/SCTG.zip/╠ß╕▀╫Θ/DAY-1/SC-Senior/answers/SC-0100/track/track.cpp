#include<iostream>
#include<bits/stdc++.h>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#define rd read()
#define gc getchar()
#define ll long long
#define maxn 1000001
using namespace std;
ll read()
{
	ll x=0;int w=1;char ch=gc;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=gc;}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch-'0');ch=gc;}
	return x*w;
}
int n,m,ans,a[50001],b[50001],l[50001],check;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=rd;
	m=rd;
	ans=0;
	check=0;
	for(int i=1;i<n;++i)
	{
		a[i]=rd;
		b[i]=rd;
		l[i]=rd;
		ans+=l[i];
		if(check<a[i]) check=a[i];
	}
	if(check==1)
	{
		sort(l+1,l+n);
		if((m<<1)<=n-1)
		{
			int sum=20001;
			for(int i=1;i<=m;++i)
			{
				if(sum>l[i]+l[n-i]) sum=l[i]+l[n-i];
			}
			cout << sum;
			return 0;
		}
		else
		{
			int sum=20001;
			int len;
			len=n-m-1;
			for(int i=2*n-2*m-1;i<n;++i) 
			{
				if(sum>l[i]) sum=l[i];
			} 
			for(int i=1;i<=len;++i)
			{
				if(sum>l[i]+l[2*len-i+1]) sum=l[i]+l[2*len-i+1];
			}
			cout << sum;
			return 0;
		}
	}
	cout << ans/m;
	return 0;
}
