#include<iostream>
#include<bits/stdc++.h>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#define rd read()
#define gc getchar()
#define ll long long
#define maxn 1000001
using namespace std;
ll read()
{
	ll x=0;int w=1;char ch=gc;
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=gc;}
	while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch-'0');ch=gc;}
	return x*w;
}
int t;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=rd;
	while(t--)
	{
		int a[101]={0};
		int n,pos,check;
		n=rd;
		pos=1;
		check=0;
		for(int i=1;i<=n;++i)
		{
			a[i]=rd;
		}
		sort(a+1,a+n+1);
		if(a[1]==1||n==1) cout << 1 << endl;
		else
		{
			if(n==2)
			{
				if(a[2]%a[1]==0) cout << 1 << endl;
				else cout << 2 << endl;
			}
			else if(n==3)
			{
				if(a[2]%a[1]!=0) ++pos;
				if(a[3]%a[1]!=0&&a[3]%a[2]!=0)
				{
					for(int i=0;i*a[1]<a[3];++i)
					{
						for(int j=0;j*a[2]<a[3];++j)
						{
							if(i*a[1]+j*a[2]==a[3]) check=1;
						}
					}
					if(!check) ++pos;
				}
				cout << pos << endl;
			}
			else if(n==4)
			{
				if(a[2]%a[1]!=0) ++pos;
				if(a[3]%a[1]!=0&&a[3]%a[2]!=0)
				{
					for(int i=0;i*a[1]<a[3];++i)
					{
						for(int j=0;j*a[2]<a[3];++j)
						{
							if(i*a[1]+j*a[2]==a[3]) check=1;
						}
					}
					if(!check) ++pos;
				}
				check=0;
				if(a[4]%a[1]!=0&&a[4]%a[2]!=0&&a[4]%a[3]!=0)
				{
					for(int i=0;i*a[1]<a[4];++i)
					{
						for(int j=0;j*a[2]<a[4];++j)
						{
							for(int k=0;k*a[3]<a[4];++k)
							if(i*a[1]+j*a[2]+k*a[3]==a[4]) check=1;
						}
					}
					if(!check) ++pos;
				}
				cout << pos << endl;
			}
			else if(n==5)
			{
				if(a[2]%a[1]!=0) ++pos;
				if(a[3]%a[1]!=0&&a[3]%a[2]!=0)
				{
					for(int i=0;i*a[1]<a[3];++i)
					{
						for(int j=0;j*a[2]<a[3];++j)
						{
							if(i*a[1]+j*a[2]==a[3]) check=1;
						}
					}
					if(!check) ++pos;
				}
				check=0;
				if(a[4]%a[1]!=0&&a[4]%a[2]!=0&&a[4]%a[3]!=0)
				{
					for(int i=0;i*a[1]<a[4];++i)
					{
						for(int j=0;j*a[2]<a[4];++j)
						{
							for(int k=0;k*a[3]<a[4];++k)
							{
								if(i*a[1]+j*a[2]+k*a[3]==a[4]) check=1;
							}
						}
					}
					if(!check) ++pos;
				}
				check=0;
				if(a[5]%a[1]!=0&&a[5]%a[2]!=0&&a[5]%a[3]!=0&&a[5]%a[4]!=0)
				{
					for(int i=0;i*a[1]<a[5];++i)
					{
						for(int j=0;j*a[2]<a[5];++j)
						{
							for(int k=0;k*a[3]<a[5];++k)
							{
								for(int l=0;l*a[4]<a[5];++l)
								{
									if(i*a[1]+j*a[2]+k*a[3]+l*a[4]==a[5]) check=1;
								}
							}
						}
					}
					if(!check) ++pos;
				}
				cout << pos << endl;
			}
		}
	}
	return 0;
}
