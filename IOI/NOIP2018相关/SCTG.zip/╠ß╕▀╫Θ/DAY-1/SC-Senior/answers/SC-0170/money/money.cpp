#include<bits/stdc++.h>
using namespace std;
int T,n,mmax,ans;
int a[110];
bool used[25100];
void solve(int x)
{
	for(int i=0;i<=mmax-x;i++)
	if(used[i]&&i+x<=mmax)
	used[i+x]=1;
	return;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		memset(used,0,sizeof(used));
		used[0]=1;
		ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		mmax=a[n];
		if(a[1]==1)
		{
			printf("1\n");
			continue;
		}
		for(int i=1;i<=n;i++)
		if(!used[a[i]])
		{
			ans++,solve(a[i]);
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
