#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c,tot,mid,sum,pp;
int head[50010],ans[50010],son[50010],d[50010][3],z[50010];
bool used[50010];
struct ss{
	int next,to,val;
}f[100100];
int solve(int l,int r)
{
	int t=0;
	for(int i=l;i<=r;i++)
	ans[++t]=d[i][2];
	sort(ans+1,ans+1+t);
	for(int i=1;i<=t;i++)
	{
		if(ans[i]>=mid)
		{
			sum++;
			used[i]=1; 
			continue;
		}
		for(int j=i+1;j<=t;j++)
		if(!used[i]&&ans[i]+ans[j]>=mid)
		{
			sum++;
			used[i]=1,used[j]=1;
			break;
		}	
	}
	for(int i=t;i>=1;i++)
	if(used[t])
	return ans[t];
	return 0;
}
int  bfs(int x)
{
	int he=0,en=1;
	d[1][1]=1;
	while(he<en)
	{
		int now=d[++he][1];
		used[now]=1;
		for(int i=head[now];i;i=f[i].next)
		{
			int to=f[i].to;
			if(!used[to])
			{
				d[++en][1]=to;
				d[en][0]=he;
				d[en][2]=f[i].val;
			}
		}
	}
	int lastnum=d[en][0],lastpos=en;
	
	for(int i=en-1;i>=1;i--)
	{
		if(d[i][0]!=lastnum)
		{
			memset(used,0,sizeof(used));
			d[lastnum][2]+=solve(i+1,lastpos);

			lastpos=i;
			lastnum=d[i][0];
		}
	}
}
int  dfs(int x,int fa)
{
	int d1=0,d2=0;
	for(int i=head[x];i;i=f[i].next)
	{
		int to=f[i].to;
		if(to==fa)continue;
		int s=dfs(to,x)+f[i].val;
		if(s>d1)d2=d1,d1=s;
		else if(s>d2)d2=s;
	}
	pp=max(d1+d2,pp);
	return d1;
}
bool gg(int x)
{
	for(int i=1;i<=x;i++)
	{
		if(ans[i]>=mid)
		{
			used[i]=1;
			sum++;continue;
		}
		for(int k=i+1;k<=x;k++)
		{
			if(!used[i]&&!used[k]&&ans[i]+ans[k]>=mid)
			{
				sum++;used[k]=1;
				break;
			}
		}
	}
	if(sum>=m)
	return 1;
	return 0;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==n-1)
	pp=0x7fffffff;
	bool flag=1;
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&a,&b,&c);
		if(a!=1&&b!=1)
		flag=0;
		z[i]=c;
		f[++tot]=(ss){head[a],b,c};head[a]=tot;
		f[++tot]=(ss){head[b],a,c};head[b]=tot;
		if(m==n-1)
		pp=min(c,pp);
	}
	if(m==n-1)
	{
		printf("%d",pp);
		return 0;	
	}
	if(m==1)
	{
		dfs(1,1);
		printf("%d",pp);
		return 0;
	}
	if(flag)
	{
		int t=0;
		for(int i=head[1];i;i=f[i].next)
		ans[++t]=f[i].val;
		sort(ans+1,ans+1+t);
		int l=0,r=1e9;
		while(l<r)
		{
			memset(used,0,sizeof(used));
			sum=0;
			mid=(l+r)>>1;
			if(gg(t))l=mid+1,pp=max(pp,mid);
			else r=mid-1;
		}
		printf("%d",pp);
		return 0;
	}
	int l=0,r=1e9;
	sort(z+1,z+n);
	while(l<r)
	{
		sum=0;
		mid=(l+r)>>1;
		int ddd=0;
		for(int i=1;i<=n;i++)
		{
			ddd+=z[i];
			if(ddd>=mid);
			sum++,ddd=0;
		}
		if(sum>=m)l=mid+1,pp=max(mid,pp);
		else r=mid-1;
	}
	printf("%d",pp);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
