#include<bits/stdc++.h>
using namespace std;
int n,ans=0;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	int last=0,a;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a);
		if(a>last)
		ans+=(a-last);
		last=a;
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
