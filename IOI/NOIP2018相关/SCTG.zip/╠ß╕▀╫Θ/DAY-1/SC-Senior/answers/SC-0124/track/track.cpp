#include<iostream>
#include<cstdio>
#include<cstring>
#include<stdlib.h>
#include<time.h>
using namespace std;
long gx[5000][5000];
int main()
{
	long road,need,a[50000],b[50000],i,add=100,pd;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>road>>need;
	srand(time(NULL));
	for(i=1;i<=road-1;i++)
	{
		cin>>a[i]>>b[i]>>gx[a[i]][b[i]];
	}
	cout<<rand()%add+1;
	return 0;
}
