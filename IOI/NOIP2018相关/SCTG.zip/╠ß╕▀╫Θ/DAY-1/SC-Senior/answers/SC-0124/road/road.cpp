#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
long enter[100001];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long n,i,j,k,l=0,m=0,ans=0;
	cin>>n;
	memset(enter,0,sizeof(enter));
	for(i=0;i<n;i++)
	{
		cin>>enter[i];
	}
	l=enter[0];
	for(i=0;i<n-1;i++)
	{
		j=enter[i];
		k=enter[i+1];
		if(j<k) l=k-m;
		else if(j>k)
		{
			ans+=l;
			l=0;
			m=k;
		}
		if(i==n-2)
		{
			ans+=l;
		}
	}
	cout<<ans;
	return 0;
}
