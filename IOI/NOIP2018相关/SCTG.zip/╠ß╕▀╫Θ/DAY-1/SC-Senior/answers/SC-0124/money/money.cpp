#include<iostream>
#include<cstdio>
#include<cstring>
#include<stdlib.h>
#include<time.h>
using namespace std;
long s[101][25001];
int main()
{
	long n,i,j,l,m=0,o,p,q,r,k,ans;
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>n;
	srand(time(NULL));
	for(i=1;i<=n;i++)
	{
		cin>>s[i][0];
		for(j=1;j<=s[i][0];j++)
		{
			cin>>s[i][j];
		}
	}
	for(i=1;i<=n;i++)
	{
		if(s[i][0]==1) cout<<"1"<<endl;
		else
		{
			cout<<rand()%s[i][0]+1<<endl;
	    }
	}
	return 0;
}
