#include <iostream>
#include <vector>
#include <cstdio>
#include <queue>
using namespace std;
int n,m;
int nm[50020];
struct name 
{
	int end;
	int w;
};
struct node
{
	long long  d;
	int x;
	friend bool operator <(const node a,const node b)
	{
		return a.d<b.d;
	}
};
priority_queue<struct node> q;
vector <struct name> v[50020];
long long  dis[50020];
long long ans;
bool vis[50020];
long long sum;
const int INF=0x3f3f3f3f;
void dijistra(int s)
{
	for(int i=1;i<=n;i++) dis[i]=-0x3f3f3f3f,vis[i]=false;
	dis[s]=0;
	while(!q.empty())
	{
		q.pop();
	} 
	struct node now;
	now.x=s;
	now.d=0;
	q.push(now);
	while(!q.empty())
	{
		now=q.top();
		q.pop();
		int xx=now.x;
		if(vis[xx]) continue;
		vis[xx]=true;
		for(int i=0;i<v[xx].size();i++)
		{
			int ee=v[xx][i].end;
			int ww=v[xx][i].w;
			if(!vis[ee]&&dis[ee]<dis[xx]+ww)
			{
				dis[ee]=dis[xx]+ww;
				struct node next;
				next.x=ee;
				next.d=dis[ee];
				q.push(next);
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		ans=ans<dis[i]?dis[i]:ans;
		//cout<<dis[i]<<endl;
	}
	return ;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout); 
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		sum+=z;
		struct name now;
		now.end=y,now.w=z;
		v[x].push_back(now);
		now.end=x,now.w=z;
		v[y].push_back(now);
		nm[x]++;
		nm[y]++;
	}
	if(m==1)//�· 
	{
		for(int i=1;i<=n;i++)
		{
			if(nm[i]==1)//��Ҷ�ӽڵ���һ�������ֵ 
			{
			//	cout<<"i    "<<i<<endl;
				dijistra(i); 
			}
		}
		cout<<ans<<endl;
		return 0;
	}
	else 
	{
		long long maybe=sum/m;//�� 
		cout<<maybe-1<<endl;
		return 0;
	} 
	return 0;
}
