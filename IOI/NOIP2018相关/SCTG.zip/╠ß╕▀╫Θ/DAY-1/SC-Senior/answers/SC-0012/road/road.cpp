#include <iostream>
#include <vector>
#include <queue>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int d[100020];
long long ans,sum;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&d[i]);
	}
	for(int i=1;i<=n;i++)
	{
		if(d[i]>=d[i-1])
		{
			sum=d[i];
		}
		else 
		{
			ans+=sum-d[i];
			sum=d[i];
		}
	}
	ans+=sum;
	cout<<ans<<endl;
	return 0;
}
