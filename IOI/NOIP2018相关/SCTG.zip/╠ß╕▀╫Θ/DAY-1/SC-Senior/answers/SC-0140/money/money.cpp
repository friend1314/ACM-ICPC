#include <stack>
#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;
const int inf = 0x3f3f3f3f;
const int maxn = 110;
const int maxm = 25010;
int T,n,a[maxn];
int b[maxm];
bool d[maxm];
int same,mx;
void dfs(int i,int val,int cnt)
{
	if(a[i+1]==mx) return;//mx
	if(val>mx) return;
	int bei=0;
	while(true){
		if(bei==0){
			if(cnt>1){
				d[val]=1; 
			}
			dfs(i+1,val,cnt);
		}
		else if(bei==1){
			if(cnt>1)
				d[val+a[i+1]]=1;
			dfs(i+1,val+a[i+1],cnt+1);
		}
		else{
			if(a[i+1]*bei>mx) return;
			int tmp=a[i+1]*bei;
			d[tmp]=1;
			if(val+tmp>mx) return;
			d[tmp+val]=1;
			dfs(i+1,val+tmp,cnt+bei);
		}
		bei++;
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--) {//ȥ����Ч���� 
		memset(b,0,sizeof b);
		memset(d,0,sizeof d);
		mx=same=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++) {
			scanf("%d",&a[i]);
			if(a[i]>mx) mx=a[i];//
			if(b[a[i]]) same++;
			b[a[i]]++;//ȥ�� 
		}
		//ȥ�������
		if(b[1]) {
			printf("1\n");
			continue;
		}
		sort(a+1,a+n+1);
		dfs(0,0,0); 
		for(int i=1;i<=n;i++){
			if(d[a[i]]&&b[a[i]]==1)
			same++;
		}
		printf("%d\n",n-same);
	}
	return 0;
}
