#include <stack>
#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define size siz
using namespace std;
typedef long long ll;
const int inf = 0x3f3f3f3f;
const int maxn = 50010;
struct node {
	int v,w,nxt;
}edge[maxn<<1]; 
int n,m,k,head[maxn];
inline void add(int u,int v,int w){
	edge[k]=(node){v,w,head[u]};
	head[u]=k++;
}
ll dist[maxn];
bool vis[maxn];
bool used[maxn<<1];
int root;
inline void bfs(int s) {
	queue<int> q;
	memset(vis,0,sizeof vis);
	q.push(s);
	dist[s]=0;
	vis[s]=1;
	while(!q.empty()) {
		int u=q.front(); q.pop();
		for(int i=head[u],v;~i;i=edge[i].nxt){
			v=edge[i].v;
			if(vis[v]) continue;
			vis[v]=1;
			dist[v]=dist[u]+edge[i].w;
			q.push(v);
		}
	}
}
int top[maxn],son[maxn],size[maxn],dep[maxn],pos[maxn],tid[maxn],fa[maxn],t;
void dfs1(int u,int dad) {
	fa[u]=dad;
	dep[u]=dep[dad]+1;
	size[u]=1;
	for(int i=head[u],v;~i;i=edge[i].nxt) {
		v=edge[i].v;
		if(v==dad) continue;
		dfs1(v,u);
		size[u]+=size[v];
		if(size[v]>size[son[u]]) son[u]=v;
	}
}
void dfs2(int u,int tp) {
	top[u]=tp;
	pos[u]=++t;
	tid[t]=u;
	if(!son[u]) return;
	dfs2(son[u],tp);
	for(int i=head[u],v;~i;i=edge[i].nxt) {
		v=edge[i].v;
		if(v==fa[u]||v==son[u]) continue;
		dfs2(v,v);
	}
}
inline int LCA(int x,int y) {
	while(top[x]^top[y]) {
		if(dep[top[x]]<dep[top[y]]) swap(x,y);
		x=fa[top[x]];
	}
	if(dep[x]>dep[y]) swap(x,y);
	return x;
}
int pre[maxn];
inline void Pre(int s){
	memset(pre,0,sizeof pre);
	memset(vis,0,sizeof vis);
	queue<int> q;
	q.push(s);
	vis[s]=1;
	while(!q.empty()) {
		int u=q.front(); q.pop();
		for(int i=head[u],v;i;i=edge[i].nxt) {
			v=edge[i].v;
			if(vis[v]) continue;
			vis[v]=1;
			pre[v]=u;
			q.push(v);
		}
	}
}
inline bool Check(int s){
	queue<int> q;
	q.push(s);
	while(!q.empty()) {
		int u=q.front(); q.pop();
		for(int i=head[u],v;i;i=edge[i].nxt){
			v=edge[i].v;
			if(pre[v]==u){
				if(used[i]) return 0;
				q.push(v);
			}
		}
	}
	return 1;
}
inline void book(int s){
	queue<int> q;
	q.push(s);
	while(!q.empty()) {
		int u=q.front(); q.pop();
		for(int i=head[u],v;i;i=edge[i].nxt){
			v=edge[i].v;
			if(pre[v]==u){
				used[i]=used[i^1]=1;
				q.push(v);
			}
		}
	}
}
inline bool check(int lim) {
	int sum=0;
	int lca;
	memset(used,0,sizeof used);
	for(int i =1;i<=n;i++) {
		for(int j=i+1;i<=n;i++) {
			lca=LCA(i,j);
			if(dist[i]+dist[j]-dist[lca]-dist[lca]>=lim){
				Pre(lca);
				if(Check(i)&&Check(j)){
					sum++;
					if(sum>=m) return 1;
					book(i),book(j);
				}
			}
		}
	} 
	if(sum>=m) return 1;
	else return 0;
}
bool chain=1;
bool chaincheck(int lim) {
	int sum=0;
	int last=1;
	for(int i=2;i<=n;i++) {
		if(dist[i]-dist[last]>=lim){
			if(sum>=m) return 1;
			sum++;
			last=i;
		}
	}
	if(sum>=m) return 1;
	else return 0;
}
bool root1=1;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	//���ִ� 
	scanf("%d%d",&n,&m);
	memset(head,-1,sizeof head);
	int u,v,w;
	ll l=inf,r=0;
	for(int i=1;i<n;i++) {
		scanf("%d%d%d",&u,&v,&w);
		if(v!=u+1) chain=0;
		if(u!=1) root1=0;
		if(w<l) l=w;
		add(u,v,w);
		add(v,u,w);
	}
	if(chain) {
		bfs(1);
		r=dist[n];
		while(l<=r){
			int mid=(l+r)>>1;
			if(!chaincheck(mid)) r=mid-1;
			else l=mid+1;
		}
		printf("%lld\n",r);
		return 0;
	}
	if(root1){
		bfs(1);
		sort(dist+1,dist+n+1);
		reverse(dist+1,dist+n+1);
		printf("%lld\n",dist[m]);
		return 0;
	}
	bfs(1);
	for(int i=1;i<=n;i++) {
		if(dist[i]>r){
			r=dist[i];
			root=i;
		}
	}
	bfs(root);
	for(int i=1;i<=n;i++) {
		if(dist[i]>r){
			r=dist[i];
		}
	}//�ұ߽�:ֱ�� 
	if(m==1){
		printf("%lld\n",r);
		return 0;
	}
	else {
		dfs1(root,0);
		dfs2(root,root);
		while(l<=r){
			int mid=(l+r)>>1;
			if(!check(mid)) r=mid-1;
			else l=mid+1;
		}
		printf("%lld\n",r);
	}
	return 0;
}
