#include <stack>
#include <queue>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

using namespace std;
const int inf = 0x3f3f3f3f;
const int maxn = 100010;
int n,d[maxn];
long long ans;
int last=0;
bool up=1;
inline int check()
{
	for(register int i=last;i<=n;i++){
		if(d[i]) return i;
	}
	return 0;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	register int i;
	for( i=1;i<=n;i++)
	{
		scanf("%d",&d[i]);
		if(d[i]<d[i-1]) up=0;
	}
	if(up){
		printf("%d\n",d[n]);
		return 0; 
	}
	int l,r,mn;
	while(true)
	{
		l=check();
		if(!l) break;
		last=l;//���仯 
		r=l;
		mn=d[l];
		for(i=l+1;i<=n;i++){
			if(!d[i]) break;
			r=i;
			if(d[i]<mn) mn=d[i];
		}
		for(i=l;i<=r;i++) d[i]-=mn;
		ans+=mn;
	}
	printf("%lld\n",ans);
	return 0;
}
