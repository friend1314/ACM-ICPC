#include<bits/stdc++.h>
using namespace std;
void read(int &x)
{
	x=0;int f=0;char ch=getchar();
	while(!isdigit(ch))f|=(ch=='-'),ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	f?x=-x:x;
}
inline int womax(int a,int b)
{
	return a>b?a:b;
}
inline int womin(int a,int b)
{
	return a<b?a:b;
}
int vis[50200],a[50200];
int MAXAI=0,MINAI=25001;
int fen(int X)
{
	for(int i=0;i<X;++i)
	{
		if(vis[i]&&vis[X-i])return 0;
	}
	return 1;
}
void jie(int X)
{
	for(int i=1;i<=MAXAI;++i)
	{
		if(vis[i]&&(!vis[i+X]))
		{
			for(int ji=i+X;ji<=MAXAI;ji+=X)
			{
				vis[ji]=1;
			}
		}
	}
	for(int i=X;i<=MAXAI;i+=X)
	{
		vis[i]=1;
	}
	
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	read(T);
	while(T--)
	{
		memset(vis,0,sizeof vis);
		int ans=0,n;
		read(n);
		for(int i=1;i<=n;++i)
		{
			read(a[i]);
			MAXAI=womax(MAXAI,a[i]);MINAI=womin(MINAI,a[i]);
		}
		if(2*MINAI>MAXAI)
		{
			printf("%d\n",n);
			continue;
		}
		sort(a+1,a+n+1);
		if(a[1]==1)
		{
			printf("1\n");
			continue;
		}
		for(int i=1;i<=n;++i)
		{
			int fla=fen(a[i]);
			if(!fla)ans++;
			else
			{
				jie(a[i]);
			}
		}
		printf("%d\n",n-ans);
//		for(int i=0;i<=40;++i)
//		{
//			cout<<"i "<<i<<" "<<vis[i]<<"\n";
//		}
	}
	return 0;
}
