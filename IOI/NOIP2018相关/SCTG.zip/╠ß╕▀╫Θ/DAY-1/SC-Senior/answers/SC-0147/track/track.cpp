#include<bits/stdc++.h>
using namespace std;
void read(int &x)
{
	x=0;int f=0;char ch=getchar();
	while(!isdigit(ch))f|=(ch=='-'),ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	f?x=-x:x;
}
inline int womax(int a,int b)
{
	return a>b?a:b;
}
inline int womin(int a,int b)
{
	return a<b?a:b;
}
#define MAXN 55000
#define MAXM 120000
struct II{
	int NE,TO,WI;
}bian[MAXM];
bool PPQ(II a,II b)
{
	return a.WI>b.WI;
}
int Head[MAXN],ccnt=0;
void add(int U,int V,int W)
{
	ccnt++;
	bian[ccnt].NE=Head[U],bian[ccnt].TO=V,bian[ccnt].WI=W;
	Head[U]=ccnt;
}
int n,m;
bool che(int X)
{
	int jishu=0;int ans=0;
	for(int i=1;i<=ccnt;i+=2)
	{
		jishu+=bian[i].WI;
		if(jishu>=X)ans++,jishu=0;
	}
	if(ans<m)return 0;
	return 1;
}
int dis[MAXN],maxjin=0;
int dfs_zhi(int U,int F)
{
	int zui=0,ci=0;
	for(int i=Head[U];i;i=bian[i].NE)
	{
		int V=bian[i].TO;
		if(V==F)continue;
		int an=dfs_zhi(V,U)+bian[i].WI;
		if(zui<=an)
		{
			ci=zui;zui=an;
		}
		else if(ci<an)
		{
			ci=an;
		}
	}
	maxjin=womax(maxjin,zui+ci);
	return zui;
}
int B[MAXM];
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);
	if(m==1)
	{
		int a,b,l;
		for(int i=1;i<n;++i)
		{
			read(a);read(b);read(l);
			add(a,b,l);add(b,a,l);
		}
		int ww=dfs_zhi(1,0);
		printf("%d",maxjin);
		return 0;
	}
	int a,b,l;
	int fla=1,flaa=1;
	for(int i=1;i<n;++i)
	{
		read(a);read(b);read(l);
		if(b!=a+1)fla=2;if(a!=1)flaa=2;
		add(a,b,l);add(b,a,l);
	}
	if(fla==1)// lian
	{
		int L=0,R=500000000,mid,daan;
		while(L<R)
		{
			mid=((L+R+1)>>1);
			if(che(mid))
			{
				daan=mid;L=mid;
			}
			else
			{
				R=mid-1;
			}
		}
		printf("%d",daan);
		return 0;
	}
	if(flaa==1)
	{
		int minans=500000000;
		sort(bian+1,bian+ccnt+1,PPQ);
		int jj=1;
		for(int i=1;i<=ccnt;++i)
		{
			B[jj]=bian[i].WI;i++;jj++;
		}
//		for(int i=1;i<=jj;++i)cout<<B[i]<<" ";
		int j=1,mm=m,nn=n;
		if(n-1<2*m)
		{
			while(mm*2>nn-1)
			{
				minans=womin(minans,B[j]);
				j++;
				mm--,nn--;
			}
		}
//		cout<<"MM "<<mm<<" NN "<<nn<<"\n";
		int L,R;
//		cout<<"j "<<j<<" "<<j+2*mm<<"\n";
		for(L=j,R=j+2*mm-1;L<R;L++,R--)
		{
//			cout<<"L "<<L<<" R "<<R<<" "<<minans<<"\n";
			minans=womin(minans,B[L]+B[R]);
		}
		if(L==R)minans=womin(minans,B[L]);
		printf("%d",minans);
	}
	return 0;
}




