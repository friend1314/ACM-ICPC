#include<bits/stdc++.h>
using namespace std;
void read(int &x)
{
	x=0;int f=0;char ch=getchar();
	while(!isdigit(ch))f|=(ch=='-'),ch=getchar();
	while(isdigit(ch))x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
	f?x=-x:x;
}
int n,a[101000],d[101000];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long long ans=0;
	read(n);
	for(int i=1;i<=n;++i)
	{
		read(a[i]);d[i]=a[i]-a[i-1];
	}
	for(int i=1;i<=n;++i)
	{
		if(d[i]>0)ans+=(long long)d[i];
	}
	printf("%lld",ans);
	return 0;
}
