#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
using namespace std;
int n,d[100100],t[100100],day,f,mark;
struct node{
	int num,val;
};

void go(int l,int r,int &floor){
	if(l==r||r==0){
		day+=d[l];
		return;
	}	
	node MIN;MIN.val=INF;
	for(int i=l;i<=r;i++){
		if(d[i]==0){
			mark++;
			f++;
			break;
		}
		if(d[i]<MIN.val)
			MIN.val=d[i],MIN.num=i;
	}
	if(f){
		f=0;
		for(int i=l;i<=MIN.num;i++)
			d[i]-=MIN.val;
		floor++;
	}
	else
		for(int i=l;i<=r;i++)
			d[i]-=MIN.val;
		day+=MIN.val;
	//
	/*for(int i=1;i<=n;i++)
		printf("%d ",d[i]);
	printf("\n NOW:L=%d R=%d FLOOR=%d DAY=%d\n",l,r,floor,day);*/
	go(l,MIN.num,floor);
	go(MIN.num+1,r,floor);
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	int floor=1;
	int j=1;
	for(int i=1;i<=n;i++){
		scanf("%d",&d[i]);
		if(i!=1)
			if(d[i]!=d[i-1])
				j=0;
	}
	if(j){
		cout<<d[1];
		return 0;
	}
	go(1,n,floor);
	cout<<day;
	return 0;
}
