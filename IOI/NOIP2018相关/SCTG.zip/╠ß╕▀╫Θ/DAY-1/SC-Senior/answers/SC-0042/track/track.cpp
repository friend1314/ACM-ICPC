#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
using namespace std;

int n,m,MAX=-1;
int g[1010][1010];
int vis[1010],dis[1010];

void spfa(int start){
	dis[start]=0;
	vis[start]=1;
	queue <int> q;
	q.push(start);
	while(!q.empty()){
		int t=q.front();q.pop();
		vis[t]=0;
		for(int i=1;i<=n;i++){
			if(dis[i]>(dis[t]+g[t][i])){
				dis[i]=dis[t]+g[t][i];
				if(!vis[i])
					q.push(i),vis[t]=1;
			}
		}
	}
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			g[i][j]=INF;
	int x,y,z;
	for(int i=1;i<=n;i++){
		scanf("%d%d%d",&x,&y,&z);
		g[x][y]=g[y][x]=z;
	}
	spfa(1);
	for(int i=1;i<=n;i++)
		MAX=max(dis[i],MAX);
	cout<<MAX;
	return 0;
}
