#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
    long long int time,ans[25];
	cin>>time;
	for(int what=1;what<=time;what++){
		long long int a[105],n,tpoint=0;
		cin>>n;
		for(int i=1;i<=n;i++){
		    cin>>a[i];
			if(a[i]==1){tpoint=i;break;}
		}
		if(tpoint!=0)ans[what]=1;
		else{
		    ans[what]=n;
			for(int i=1;i<n;i++)
			    for(int j=i+1;j<=n;j++)
			        if(a[j]%a[i]==0){ans[what]--;a[j]=-1;}
			if(ans[what]!=1||ans[what]!=2){
				long long int b[105],oh=1;
				
			    for(int i=1;i<=n;i++)
			    	if(a[oh]!=-1){b[i]=a[oh];oh++;}
			    	
			    for(int i=1;i<ans[what]-1;i++)
			        for(int j=i+1;j<=ans[what]-1;j++)
			            for(int k=j+1;k<=ans[what];k++)
			                if(a[i]!=-1&&a[j]!=-1&&a[k]!=-1)
			            	    if(a[k]>(a[i]*a[j])-a[i]-a[j]){ans[what]--;a[k]=-1;}
		    }
		}
	}
	for(int i=1;i<=time;i++)cout<<ans[i]<<endl;
	return 0;
}
