#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
long long int num,l,ans;
long long int deep[100005];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>num;
	for(int i=1;i<=num;i++){
	    cin>>deep[i];
		if(deep[i]>l)l=deep[i];
	}
	l=0;ans=0;deep[0]=0;
	for(int i=1;i<=l;i++){
		for(int j=1;j<=num;j++){
			if(deep[j-1]>0&&deep[j]==0&&j<num)ans++;
			if(((deep[j-1]>0)||(deep[j]>0))&&j==num)ans++;
		}
		for(int j=1;j<=num;j++)if(deep[j]>0)deep[j]--;
	}
	cout<<ans;
	return 0;
}

