#include <cstdio>
#include <iostream>
#define Debug(x) std::cerr<<#x<<" = "<<x<<std::endl

int read() {
	int x = 0, ch = getchar(), f = 0;
	for (; ch < '0' || ch > '9'; ch = getchar()) if (ch == '-') f = 1;
	for (; ch >='0' && ch <='9'; ch = getchar()) 
		x = (x << 1) + (x << 3) + (ch ^ 48);
	return f ? -x : x;
}
typedef long long ll;
#define rep(i, s, t) for (int i = (int)(s); i <= (int)(t); ++ i)

const int maxn = 100010;

int a[maxn << 1], n, mx = 0;

int max(const int &x, const int &y) {
	return x > y ? x : y;
}

int min(const int &x, const int &y) {
	return x < y ? x : y;
}

int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n = read();
	for (int i = 1; i <= n; ++ i) a[i] = read(), mx = max(a[i], mx);
	ll ans = 0;
	while (1) {
		int mn = 0x3f3f3f3f, res = 0, l = 0, r = 0;
		for (int i = 1; i <= n + 1; ++ i) {
			if (a[i - 1] == 0 && a[i] >= 1) { l = i; }
			else if (a[i - 1] >= 1 && a[i] == 0) { 
				r = i - 1; 
				rep(j, l, r) {
					a[j] -= mn;
				}
				res += mn;
				mn = 0x3f3f3f3f;
			}
			if (a[i] >= 1) { mn = min(mn, a[i]); }
		}
		ans += res;
		if (res == 0) break;
	}
	printf("%lld\n", ans);
}

