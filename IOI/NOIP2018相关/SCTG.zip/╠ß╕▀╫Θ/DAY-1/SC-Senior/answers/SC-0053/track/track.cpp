#include <iostream>
#include <vector>
#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;

#define Debug(x) cerr<<#x<<" = "<<x<<endl

int read() {
	int x = 0, ch = getchar(), f = 0;
	for (; ch < '0' || ch > '9'; ch = getchar()) if (ch == '-') f = 1;
	for (; ch >='0' && ch <='9'; ch = getchar()) 
		x = (x << 1) + (x << 3) + (ch ^ 48);
	return f ? -x : x;
}
typedef long long ll;
#define rep(i, s, t) for (int i = (int)(s); i <= (int)(t); ++ i)
const int maxn = 50010;

int ver[maxn << 1], head[maxn], edge[maxn << 1], Next[maxn << 1], tot;
int vale[maxn], n, m, c[maxn];
ll d[maxn];
ll sum[maxn];

inline void addline(int x, int y, int z) {
	ver[++tot] = y, edge[tot] = z, Next[tot] = head[x], head[x] = tot;
}

ll ans = 0;

inline void treeDp(int x, int f) {
	for (int i = head[x], y; i; i = Next[i]) {
		if ((y = ver[i]) == f) continue;
		treeDp(y, x);
		ans = max(ans, d[x] + d[y] + edge[i]);
		d[x] = max(d[x], d[y] + edge[i]);
	}
}

int subtask1() {
	ans = 0;
	for (int i = 1; i <= n; ++ i)
		memset(d, 0, sizeof(d)), treeDp(i, i);
	printf("%lld", ans);
	return 0;
}

int subtask2() {
	priority_queue<int, vector<int>, greater<int> > q;
	for (int i = 1; i < n; ++ i) {
		q.push(vale[i]);
	}
	for (int i = 1; i <= n - m - 1; ++ i) {
		int x = q.top(); q.pop();
		int y = q.top(); q.pop();
		q.push(x + y);
	}
	printf("%d", q.top());
	return 0;
}

bool check(int value) {
	int cnt = 0; ll pre = 0;
	for (int i = 1; i <= n; ++ i) {
		if (c[i] - pre >= value) {
			cnt ++;
			pre = c[i];
		}
	}
	return cnt >= m;
}

int subtask3() { // c[x] for val[x][x+1];
	int l = 0, r = 0x3f3f3f3f, mid; ans = 0;
	for (int i = 1; i <= n; ++ i) c[i] += c[i - 1];
	while (l < r) {
		if (check(mid = (l + r + 1) >> 1)) ans = mid, l = mid; else r = mid - 1;
	}
	printf("%lld", ans);
	return 0;
}

int main() {
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n = read(), m = read();
	int x, y, z;
	bool flag1 = true, flag2 = true;
	rep(i, 1, n - 1) {
		x = read(), y = read(), z = read();
		vale[i] = z; if (x != 1) flag1 = false;
		c[x] = z; if (y != x + 1) flag2 = false;
		addline(x, y, z), addline(y, x, z);
	}
	if (flag1) return subtask2();
	if (flag2) return subtask3();
	else if (m == 1) return subtask1();
}

