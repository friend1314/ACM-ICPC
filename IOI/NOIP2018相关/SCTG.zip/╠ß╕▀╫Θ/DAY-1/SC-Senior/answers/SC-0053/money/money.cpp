#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>

#define Debug(x) std::cerr<<#x<<" = "<<x<<std::endl

int read() {
	int x = 0, ch = getchar(), f = 0;
	for (; ch < '0' || ch > '9'; ch = getchar()) if (ch == '-') f = 1;
	for (; ch >='0' && ch <='9'; ch = getchar()) 
		x = (x << 1) + (x << 3) + (ch ^ 48);
	return f ? -x : x;
}

#define rep(i, s, t) for (int i = (int)(s); i <= (int)(t); ++ i)

const int maxn = 110, maxm = 25010;
int n, a[maxn], mx;
bool ok[maxn], has[maxm];

inline void swap(int &x, int &y) {
	int t = x; x = y; y = t;
}

int max(const int &x, const int &y) {
	return x > y ? x : y;
}

int gcd(int x, int y) {
	if (y == 0) return x;
	return gcd(y, x%y);
}

int work() {
	std::memset(ok, 0, sizeof(ok));
	std::memset(has, 0, sizeof(has));
	n = read(); mx = 0;
	rep(i, 1, n) a[i] = read(), mx = max(a[i], mx);
	std::sort(a + 1, a + n + 1);
	has[0] = 1;
	rep(i, 1, n) {
		if (has[a[i]]) {
			ok[i] = true;
			continue;
		}
		for (int j = 0; j + a[i] < mx + 10; ++ j) {
			if (has[j]) has[j + a[i]] = 1;
		}
	}
	int ans = 0;
	rep(i, 1, n) if (!ok[i]) ++ ans;
	printf("%d\n", ans);
	return 1;
}

int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T = read();
	while (T --) work();
}

