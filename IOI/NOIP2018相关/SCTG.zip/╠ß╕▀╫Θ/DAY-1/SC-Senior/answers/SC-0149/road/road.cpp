//freopen("","",std);
#include <cmath> 
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
int sideL,sideR,minn=9999999;
int len,depth[100010];
long long answer=0,counter=0,all=0;
inline int read()
{
	int x=0;
	char c=getchar();
	while (c<48||c>57)
		c=getchar();
	while (c>=48&&c<=57)
	{x=x*10+c-48;c=getchar();}	
	return x;
} 
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>len;
	for(int i=0;i<len;i++)
	    {depth[i]=read(),all+=depth[i];}   
	while (counter<all)
	{
		minn=999999;
		for(int i=0;i<len;i++)
		{
			if(depth[i]<=0) continue;
			sideL=i;break;
		}
		for(int i=sideL;i<len;i++)
		{
			sideR=i;
			if(depth[i]>0) minn=min(minn,depth[i]);
			if(depth[i]<=0) 
			{sideR--;break;}
		}
		answer+=minn;
		for(int i=sideL;i<=sideR;i++)
			depth[i]-=minn,counter+=minn;
	} 
	cout<<answer<<endl;
	return 0;
}
















