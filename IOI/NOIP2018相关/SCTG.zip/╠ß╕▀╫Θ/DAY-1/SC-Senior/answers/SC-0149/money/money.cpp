//freopen("","",std);
#include <cmath> 
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
int T,nummoney,money[105],a,b,c;
int answer[20],cache,minn=9999999999;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>T;
	for(int v=0;v<T;v++)
	{
		memset(money,0,sizeof(money));
		minn=9999999999;
		cin>>nummoney;cache=nummoney;
		for(int i=0;i<nummoney;i++)
		{
			cin>>money[i];
			if(money[i]==1) 
			    {answer[v]=1;goto g;}
	    }
	    if(nummoney==1){answer[v]=1;goto g;}
		for(int i=0;i<nummoney-1;i++)
			for(int j=i+1;j<nummoney;j++)
			{
				if(money[j]!=0&&money[i]!=0)
				{
					if(money[j]%money[i]==0) money[j]=0,cache--;
				    else if(money[i]%money[j]==0) money[i]=0,cache--;
				}
			}
		for(int i=0;i<nummoney-1;i++)
		{
				for(int j=i+1;j<nummoney;j++)
				if(money[j]!=0&&money[i]!=0)
					 minn=min(minn,money[i]*money[j]-money[i]-money[j]);
		}	    		    
		for(int i=0;i<nummoney;i++)
			if(money[i]!=0&&money[i]>minn) 
			{cache--;money[i]=0;}
			for(int i=0;i<nummoney-1;i++)
			    for(int j=i+1;j<nummoney;j++)
			    	if(money[j]!=0&&money[i]!=0)
			    	{
			    		c=money[j]*money[i]-money[i]-money[j];
			    		a=c/money[i],b=c/money[j];
			    		for(int n=1;n<=a;n++)        //n:i
			    		    for(int m=1;m<=b;m++)    //m:j
			    		    	if(money[i]*n+money[j]*m<=c)
			    		    		for(int x=0;x<nummoney;x++)
			    		    			if(money[x]==money[i]*n+money[j]*m)
			    		    				{cache--;money[x]=0;}
			    	}
		if(cache==1) cache++;	
		answer[v]=cache;
	    g:;
	}
	for(int i=0;i<T;i++)
	    cout<<answer[i]<<endl;
	return 0;	 
}
