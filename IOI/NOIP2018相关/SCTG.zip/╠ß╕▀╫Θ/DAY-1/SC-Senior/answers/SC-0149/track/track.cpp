#include <cmath> 
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
int numpoi,numway,a,b,len;
int way[1010][1010],maxx=0,ans=0;
int used[1010][1010];
inline void find(int point)
{
	maxx=max(maxx,ans); 
	for(int i=0;i<numpoi;i++)
	{
		if(used[i][point]==0&&way[i][point]!=0)
		{
			used[i][point]=1;
			used[point][i]=1;
			ans+=way[i][point];
			find(i);
			ans-=way[i][point];
			used[i][point]=0;
			used[point][i]=0;
		}
	}
	return;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>numpoi>>numway;
	for(int i=0;i<numpoi-1;i++)
	{
		cin>>a>>b>>len;
		a--,b--;
		way[a][b]=len;
		way[b][a]=len;
	}
	for(int i=0;i<numpoi;i++)
	    find(i);
	cout<<maxx;    
    return 0;    
    
}
