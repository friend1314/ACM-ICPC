#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=100000+10;
int n,a[maxn],stack[maxn],top=0,ans=0,pre=1;

void dfs(int x)
{
	int minn=0x7f7f7f7f;
	for(int i=pre+1;i<=stack[x];i++) if(a[i]>0) minn=min(minn,a[i]);
	for(int i=pre+1;i<=stack[x];i++)
	{
		if(a[i]==minn) stack[++top]=i;
		a[i]-=minn;
	}
	ans+=minn;
}
void dfss()
{
	bool flag=false; top=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=0) stack[++top]=i,flag=true;
		else if(flag) break;
	}
	if(!flag) return;
	int minn=0x7f7f7f7f;
	for(int i=1;i<=top;i++) minn=min(minn,a[stack[i]]);
	for(int i=1;i<=top;i++) a[stack[i]]-=minn;
	ans+=minn;
	dfss();
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	/*if(n<=1000)
	{*/
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		dfss();
		printf("%d",ans);
	/*}
	else
	{
		int minn=0x7f7f7f7f; stack[0]=n;
		for(int i=1;i<=n;i++) scanf("%d",&a[i]),minn=min(minn,a[i]);
		for(int i=1;i<=n;i++) if(a[i]==minn) stack[++top]=i;
		ans+=minn; int tmp=top;
		for(int i=1;i<=tmp;i++) dfs(i),pre=i; dfs(0);
		while(tmp!=top)
		{
			int tp=tmp; tmp=top; pre=0;
			for(int i=tp;i<=tmp;i++) dfs(i),pre=i;
		}
		printf("%d",ans);
	}*/
	return 0;
}
