#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;

const int maxn=50000+10;
int n,m,u,v,w[maxn],k=1,head[maxn],dis[maxn],ans=0;
bool vis[maxn],flag1=true,flag2=true;
struct node
{
	int to,nxt,w;
} edge[maxn*2];
priority_queue< pair<int,int> > q;

void add(int u,int v,int w)
{
	edge[k].to=v;
	edge[k].nxt=head[u];
	edge[k].w=w;
	head[u]=k++;
}
void dijkstra(int s)
{
	memset(dis,0,sizeof(dis));
	memset(vis,false,sizeof(vis));
	dis[s]=0; q.push(make_pair(0,s));
	while(!q.empty())
	{
		int x=q.top().second; q.pop(); ans=max(ans,dis[x]);
		if(vis[x]) continue; vis[x]=true;
		for(int i=head[x];i;i=edge[i].nxt)
		{
			if(dis[edge[i].to]<dis[x]+edge[i].w && !vis[edge[i].to])
			{
				dis[edge[i].to]=dis[x]+edge[i].w;
				q.push(make_pair(-dis[edge[i].to],edge[i].to));
			}
		}
	}
}
void sol_1()
{
	for(int i=1;i<=n;i++) dijkstra(i); //for(int j=1;j<=n;j++) ans=max(ans,dis[j]); //for(int j=1;j<=n;j++) printf("%d ",dis[j]);printf("\n");
	printf("%d",ans);
}
void sol_2()
{
	for(int i=1;i<n;i++) for(int j=1;j<n;j++) if(i!=j) ans=max(ans,w[i]+w[j]);
	printf("%d",ans);
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&u,&v,&w[i]),add(u,v,w[i]),add(v,u,w[i]);
		if(u!=1) flag1=false;
		if(v!=u+1) flag2=false;
	}
	sort(w+1,w+n);
	if(m==1)
	{
		if(n<=1000) sol_1();
		else if(flag1) printf("%d",w[n-1]+w[n-2]);
	}
	else
	{
		if(flag1) sol_2();
		//else if(flag2) sol_3()
	}
	return 0;
}
