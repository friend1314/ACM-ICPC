#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=50000+10;
int T,n,a[maxn];

void sol_1()
{
	if(a[1]%a[2]==0 || a[2]%a[1]==0) printf("1\n");
	else printf("2\n");
}
void sol_2()
{
	sort(a+1,a+n+1); //for(int i=1;i<=n;i++) printf("%d ",a[i]);
	if(a[3]%a[1]==0 && a[2]%a[1]==0) printf("1\n");
	else if(a[2]%a[1]==0 || a[3]%a[1]==0 || a[3]%a[2]==0) printf("2\n");
	else
	{
		int tmp=a[3]/a[1]; bool flag=false; //printf("%d",tmp);
		for(int i=1;i<=tmp;i++)
		{
			int res=a[3]-a[1]*i;
			if(res%a[2]==0)
			{
				printf("2\n"),flag=true;
				break;
			}
		}
		if(!flag) printf("3\n");
	}
}
void sol_3()
{
	sort(a+1,a+n+1);
	if(a[3]%a[1]==0 && a[2]%a[1]==0) printf("1\n");
	else if(a[2]%a[1]==0 || a[3]%a[1]==0 || a[3]%a[2]==0) printf("2\n");
	else
	{
		int tmp=a[3]/a[1]; bool flag=false;
		for(int i=1;i<=tmp;i++)
		{
			if((a[3]%(a[1]*tmp))%a[2]==0)
			{
				printf("2\n"),flag=true;
				break;
			}
		}
		if(!flag) printf("3\n");
	}
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]);
		if(n==2) sol_1();
		if(n==3) sol_2();
		//if(n==4) sol_3();
		//if(n==5) sol_4();
	}
	return 0;
}
