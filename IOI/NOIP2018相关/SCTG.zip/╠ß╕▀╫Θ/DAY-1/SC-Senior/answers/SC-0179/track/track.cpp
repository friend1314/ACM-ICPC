#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define v d[t].to
const int N = 5e4 + 10;
using namespace std;
struct ll{int to,last,dis;}d[N<<1];
struct edge{int from,to,dis;}e[N];
int n,m,flag,num,head[N],f[N];
int read(){
 int k=0,f=0;char c=getchar();for(;c<'0'||c>'9';c=getchar())if(c=='-')f=1;
 for(;c<='9'&&c>='0';c=getchar())k=(k<<3)+(k<<1)+c-'0';return f?-k:k;
}
void init(){
 n = read();m = read();
 flag = 2;int maxn = 0;
 for(int i = 1;i < n;i ++)
 e[i] = (edge){read(),read(),read()};
 for(int i = 1;i < n;i ++){
  maxn = max(maxn,e[i].from);
  if(e[i].from != e[i].to - 1)flag = 0;
 }if(maxn == 1)flag = 1;
}
void add(int a,int b,int c){
 d[++num]=(ll){b,head[a],c};head[a]=num;
 d[++num]=(ll){a,head[b],c};head[b]=num;
}
int dfs(int u,int fa){
 int maxn = 0,f1 = 0,f2 = 0;
 for(int t = head[u]; t;t = d[t].last)
 if(v != fa){
  maxn = max(maxn,dfs(v,u));f[u] = max(f[v] + d[t].dis,f[u]);
  if(f1 < f[v] + d[t].dis)f2 = f1,f1 = f[v] + d[t].dis;
  else if(f2 < f[v] + d[t].dis)f2 = f[v] + d[t].dis;
 }return max(maxn,f1 + f2);
}
void work_D(){
 for(int i = 1;i < n;i ++)
 add(e[i].from,e[i].to,e[i].dis);
 printf("%d\n",dfs(1,-1));
}
bool cmpA(edge a,edge b){return a.dis > b.dis;}
bool cmpB(edge a,edge b){return a.from < b.from;}
void work_A(){
 sort(e+1,e+n,cmpA);int ans = 1e9;
 int p1 = m,p2 = m + 1;
 while(p1 >= 1&& p2 < n){
  e[p1].dis += e[p2].dis;
  p1 --;p2 ++;
 }
 for(int i = 1;i <= m;i ++)
 ans = min(ans,e[i].dis);
 printf("%d\n",ans);
}
bool check(int x){
 int cnt = 0,tot = 0;
 for(int i = 1;i < n;i ++){
  tot += e[i].dis;
  if(tot >= x)cnt++,tot = 0;
 }return cnt >= m;
}
void work_B(){
 sort(e+1,e+n,cmpB);
 int l = 1,r = 1e9,ans = 0;
 while(l <= r){
  int mid = (l + r >> 1);
  if(check(mid))l = (ans = mid) + 1;
  else r = mid - 1;
 }printf("%d\n",ans);
}
int main(){
 freopen("track.in","r",stdin);
 freopen("track.out","w",stdout);
 init();
 if(m == 1){work_D();return 0;}
 if(flag == 1){work_A();return 0;}
 work_B();
 fclose(stdin);
 fclose(stdout);
 return 0;
}
