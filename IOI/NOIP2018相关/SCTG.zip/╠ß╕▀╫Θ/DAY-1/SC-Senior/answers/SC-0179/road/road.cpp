#include<cstdio>
#include<cstring>
#include<iostream>
const int N = 1e5 + 10;
using namespace std;
int n,a[N],len[N],f[N][31],p[N][31];
int read(){
 int k=0,f=0;char c=getchar();for(;c<'0'||c>'9';c=getchar())if(c=='-')f=1;
 for(;c<='9'&&c>='0';c=getchar())k=(k<<3)+(k<<1)+c-'0';return f?-k:k;
}
void ST(){
 for(int i = 1;i <= n;i ++)
 len[i] = len[i - 1] + ((1<<len[i - 1] + 1) == i);
 for(int i = 1;i <= n;i ++)
 f[i][0] = a[p[i][0] = i];
 for(int j = 1;j <= 30;j ++)
 for(int i = 1;i + (1<<j-1)<= n;i ++){
  if(f[i][j - 1] < f[i + (1<<j-1)][j - 1])
  f[i][j] = f[i][j - 1],p[i][j] = p[i][j - 1];
  else f[i][j] = f[i + (1<<j-1)][j - 1],p[i][j] = p[i + (1<<j-1)][j - 1];
 }
 
}
int work(int l,int r,int del){
 if(l < 1 || r > n || l > r)return 0;
 int L = len[r - l + 1],val,pos;
 if(f[l][L] < f[r - (1<<L) + 1][L])
 val = f[l][L],pos = p[l][L];
 else val = f[r - (1<<L) + 1][L],pos = p[r - (1<<L) + 1][L];
 return val - del + work(l,pos - 1,val) + work(pos + 1, r,val);
}
int main(){
 freopen("road.in","r",stdin);
 freopen("road.out","w",stdout);
 n = read();
 for(int i = 1;i <= n;i ++)a[i] = read();
 ST();printf("%d\n",work(1,n,0));
 fclose(stdin);
 fclose(stdout);
 return 0;
}
