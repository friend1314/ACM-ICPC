#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
const int N = 1001;
using namespace std;
int n,T,a[N],ans,maxn;int in[N],used[25001];
int read(){
 int k=0,f=0;char c=getchar();for(;c<'0'||c>'9';c=getchar())if(c=='-')f=1;
 for(;c<='9'&&c>='0';c=getchar())k=(k<<3)+(k<<1)+c-'0';return f?-k:k;
}
void dfs(int now){
 if(now == n + 1){
  int minn = 0;
  for(int i = 1;i <= n;i ++)
  if(in[i] || !used[a[i]])minn ++;
  ans = min(minn,ans);return;
 }
 used[a[now]]++;
 for(int i = 1;i <= maxn - a[now];i ++)
 if(used[i])used[i+a[now]] ++;
 in[now] = 1;dfs(now+1);
 used[a[now]]--;
 for(int i = 1;i <= maxn - a[now];i ++)
 if(used[i])used[i+a[now]] --;
 in[now] = 0;dfs(now+1);
}
void work(){
 ans = 0;
 for(int i = 1;i <= n;i ++)
  if(!used[a[i]]){
   ans ++;used[a[i]] = 1;
   for(int j = 1;j <= maxn - a[i];j ++)
   if(used[j])used[j+a[i]] = 1;
  }
}
int main(){
 freopen("money.in","r",stdin);
 freopen("money.out","w",stdout);
 T = read(); while(T --){
  memset(used,0,sizeof(used));
  memset(in,0,sizeof(in));
  maxn = 0;ans = 1e9;
  n = read();
 for(int i = 1;i <= n;i ++)
 a[i] = read(),maxn = max(maxn,a[i]);
 sort(a+1,a+n+1);
  if(n <= 13)dfs(1);
  else work();
 printf("%d\n",ans);
 }
 fclose(stdin);
 fclose(stdout);
 return 0;
}
