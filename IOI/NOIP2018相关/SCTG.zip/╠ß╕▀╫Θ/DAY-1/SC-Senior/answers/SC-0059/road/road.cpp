#include<bits/stdc++.h>
using namespace std;	
int n;
long long ans=0;
int a[100010];
bool f;
inline int read()
{
	char c;
	int fg=1;
	do
	{
		c=getchar();
		if(c=='-')
		fg=-1;
	}while(c<'0'||c>'9');
	int sum=0;
	do
	{
		sum=(sum<<3)+(sum<<1)+c-48;
		c=getchar();
	}while(c>='0'&&c<='9');
	return fg*sum;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
		if(a[i]>a[i-1])
		{
			ans+=a[i]-a[i-1];
			f=0;
		}
		else if(a[i]<a[i-1]&&!f)
		{
			f=1;
		}
	}	
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;

	
}

