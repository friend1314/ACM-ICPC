#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	char c;
	int fg=1;
	do
	{
		c=getchar();
		if(c=='-')
		fg=-1;
	}while(c<'0'||c>'9');
	int sum=0;
	do
	{
		sum=(sum<<3)+(sum<<1)+c-48;
		c=getchar();
	}while(c>='0'&&c<='9');
	return sum*fg;
} 
int n,m,t,ans;
int vis[110];
int w[110];
//bool gcd(int x,int y)
//{
//	while(x%y)
//	{
//		int z=x%y;
//		y=z;
//		x=y;
//	}
//	if(y==1) return 1;
//	else return 0;
//}
void check()
{
	for(int num=n;num>2;num--)
	{
		bool s;
		int c=w[num];
		if(!vis[num])
		{
			for(int i=1;i<=n;i++)
			{
				if(vis[num]) break;
				if(!vis[i])
				for(int j=i+1;j<=n;j++)
				{
					if(vis[num]||j==num) break;
					int a=w[i];
					int b=w[j];
					if(!vis[j])
					for(int y=1;y<=c/b;y++)
					{
						if(vis[num]) break;
						if((c-y*b)%a==0)
						{
							ans--;
						//	printf("%d-%d*%d=%d*x %d ",c,y,b,a,w[num]);
							vis[num]=1;
						}
					}
					
				}
		
			}
		
		}
	}
	printf("%d\n",ans);
}
//void check()
//{
//	for(int i=1;i<=n;i++)
//	for(int j=i+1;j<=n;j++)
//	{
//		bool b;
//		if(!nouse[w[i]]&&!nouse[w[j]])
//		for(int k1=1;k1<=25000;k1++)
//		{
//			if(k1*w[i]>w[n]) break;
//			for(int k2=1;k2<=25000;k2++)
//			{
//				if(k1*w[i]+k2*w[j]>w[n]) break;
//				if()
//			}
//		}
//	}
//}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	for(int k=1;k<=t;k++)
	{
		memset(vis,0,sizeof(vis));
		memset(w,0,sizeof(w));
		ans=0;
		n=read();
		if(n==1)
		{
			int x=read();
			printf("1\n");
		}
		else if(n==2)
		{
			int x=read(),y=read();
			if(x<y) swap(x,y);
			if(x%y!=0)
			printf("2\n");
			else
			printf("1\n");
		}
		else
		{
			for(int i=1;i<=n;i++)
			{
				w[i]=read();
			}
			ans=n;
			sort(w+1,w+1+n);
			if(w[1]==1)
			{
				printf("1\n");
				continue;
			}
			for(int i=2;i<=n;i++)
			if(w[i]%w[1]==0) vis[i]=1,ans--;
			int q=2;
			while(vis[q]) q++;
			long long num=w[1]*w[q]-w[1]-w[q];
			for(int i=2;i<=n;i++)
			{
				if(!vis[i]&&w[i]>num&&i!=q) vis[i]=1,ans--;
				if(!vis[i])
				{
					for(int j=i+1;j<=n;j++)
					{
						if(!vis[j]&&w[j]>num&&j!=q) vis[j]=1,ans--;
						if(!vis[j])
						{
							if(w[j]%w[i]==0)
							vis[j]=1,ans--;
						}
					}
				}
			}
			if(ans<3)
			printf("%d\n",ans);
			else
			check();
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
