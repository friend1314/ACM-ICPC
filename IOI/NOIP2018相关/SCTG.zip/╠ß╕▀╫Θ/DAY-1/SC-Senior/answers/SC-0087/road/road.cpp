#include<iostream>
#include<cstdio>
#include<cmath>
 using namespace std;
 int n,i,j,a[100034],k,minn=232425,x,maxx,xx,y;
 void update(int p,int q)
  {
  	for (j=p;j<=q;++j)
  	 if (a[j]!=0)
  	  a[j]-=minn;
  }
 
 bool check()
  { int pp=0;
    for (i=1;i<=n;++i)
     if (a[i]!=0)
      { 
        pp=1;
        break;
      }
   if (pp==1) return false;
   if (pp==0) return true;
  }
   
 long long ans=0;
  int main() 
   { freopen("road.in","r",stdin);
     freopen("road.out","w",stdout);
    scanf("%d",&n);
    
    for (i=1;i<=n;++i)
     { 
      scanf("%d",&a[i]);
       if (a[i]<minn)
        {
          minn=a[i];
		  x=i;	
        }
        
     }
     
     xx=1; y=n;
     update(1,n);
     ans=minn;
     
     while (1>0)
      { 
      
  
	     
 xx=1;
	    
	for (i=1;i<=n;++i)
	 {  
	 
	 if (a[i]==0)
	  {
	  	
	   xx=i+1;
	   	
	   continue;
      }
	   
	   if (a[i]<minn)
	    minn=a[i];
	    
	    
	    
	   if (a[i+1]==0)
	    {  
	     y=i;

     
	 
	 if (xx==y)
	  {ans+=a[xx];
	   
	   a[xx]=0;
	   continue;
	  }
	     if (minn!=232425)
		   ans=minn+ans;
		
		 update(xx,y);
	     
		 minn=232425;
	     
	     
	  
	      
	      
	    }
	     
	 }	  

	   if (check()==true)
	    break;
		 }
	 
    cout<<ans<<endl; 
     
   }
