#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>

 using namespace std;
 int main() 
  {  freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    int n,i,j,s=0,m,a,b,c,minn=9999999;
    
    cin>>n>>m;
    
    for (i=1;i<=n-1;++i)
     {
     	cin>>a>>b>>c;
     	s+=c;
     	if (c<minn)
     	minn=c;
     }
     if (m==1)
      cout<<s;
     
	 else 
	  cout<<c;
  }
