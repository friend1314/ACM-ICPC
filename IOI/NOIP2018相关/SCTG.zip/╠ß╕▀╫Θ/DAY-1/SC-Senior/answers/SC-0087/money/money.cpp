#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
 using namespace std;
 int t,i,j,x,y,k,ans,n,a[134],b[26000];
 bool check()
  {  int sl=0;
   for (j=1;j<=a[1]-1;++j)
    { 
      if (b[j]==0)
        {
          sl=1;
          break;
        }
      
	   
    }
    if (sl==0) return true;
    if (sl==1) return false;
  }
  int main()
   {  
freopen("money.in","r",stdin);
freopen("money.out","w",stdout);
   cin>>t;
   for (int tt=1;tt<=t;++tt)
    { 
     
       cin>>n;
       
	   for (i=1;i<=n;++i)
	    scanf("%d",&a[i]);
		
	 	   sort(a+1,a+n+1);
	 
	   if (n==1)
	    {cout<<1<<endl;
	     continue;
	    }
	   	
	   if (n==2)  //2���� 
	    { int c,d;
		 c=min(a[1],a[2]);
		 d=max(a[1],a[2]);
		 
		 if (d%c==0)
		  cout<<1<<endl;
		 
		 if (d%c!=0)
		  cout<<2<<endl;
		    
	     continue;
	    }
	   

	   
	    
		if (a[1]==1) //���Ϊ1 ȫ���� 
		 {
		  cout<<1<<endl;
		  continue;	 
		 } 
		 
		 
		 
		 if (a[1]-1>n-1)
		  {  int sss=n;
		   
		   for (i=1;i<=n;++i)
		    { 
		    int cf=0;
		     for (j=1;j<=n;++j)
		       if (a[i]%a[j]==0&&i!=j)
		         { 
		           sss-=1;
		           break;
		         }
		    }
		  cout<<sss<<endl;
		  continue;
		  }
		  
		  
	   for (i=1;i<=a[1]-1;++i)  //��ʼ�� 
	      b[i]=0;
	 
	 
		 
	     int p=1;
	    
		for (i=2;i<=n;++i)
	     { 
	      int g;
	      g=a[i]%a[1];
	      if (b[g]==0&&g!=0)
	       { 
	       p++;
	       
	       b[g]=1;
	       }
	       
	       
	       
	     
		   if (check()==true)
	        break;
	       
	     }
	    
	    
				 
       
       cout<<p<<endl;
      
    } 
     
   } 
    
