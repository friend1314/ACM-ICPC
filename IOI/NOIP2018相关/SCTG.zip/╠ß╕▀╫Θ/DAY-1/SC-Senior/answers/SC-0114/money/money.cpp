// SC-0114 fxy
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<queue>
#include<stack>
#include<algorithm>
#define ll long long
#define rg register
#define go(i,x,a) for(rg int i=a;i<x;i++)
#define LDB long double
#define inf 0x3f3f3f3f
#define INF 0x7f7f7f7f
using namespace std;

const int maxn=105;
int n,a[maxn],vis[maxn],ok[25005],cnt;

inline int read(){
	int ret=0,af=1; char gc=getchar();
	while(gc < '0' || gc > '9'){ if(gc=='-')af=-af; gc=getchar(); }
	while(gc >= '0' && gc <= '9') ret=ret*10+gc-'0',gc=getchar();
	return ret*af;
}

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t=read();
	while(t--){
		n=read(); memset(vis,0,sizeof(vis));
		memset(ok,0,sizeof(ok)); ok[0]=1; cnt=0;
		go(i,n+1,1) a[i]=read();
		sort(a+1,a+n+1);
		if(a[1] == 1){
			puts("1"); continue;
		}
		go(i,n+1,1)
			go(j,i,1)
				if(a[i] % a[j] == 0){
					vis[i]=1; break;
				}
		go(i,n+1,1){
			if(ok[a[i]] || vis[i]) continue;
			else cnt++;
			for(rg int j=a[i];j<=25000;j++)	ok[j]=max(ok[j-a[i]],ok[j]);
		}
		printf("%d\n",cnt);
	}
	return 0;
}

