// SC-0114 fxy
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<queue>
#include<stack>
#include<algorithm>
#define ll long long
#define rg register
#define go(i,x,a) for(rg int i=a;i<x;i++)
#define LDB long double
#define inf 0x3f3f3f3f
#define INF 0x7f7f7f7f
using namespace std;

const int maxn=1e5+5;
int n,d[maxn],q[maxn],sz[maxn],tl=0,rt=0;
ll ans=0;
struct edd{
	int l,r,fa;
}t[maxn];

inline int read(){
	int ret=0,af=1; char gc=getchar();
	while(gc < '0' || gc > '9'){ if(gc=='-')af=-af; gc=getchar(); }
	while(gc >= '0' && gc <= '9') ret=ret*10+gc-'0',gc=getchar();
	return ret*af;
}

void make_tree(){
	int x=0;
	q[++tl]=1; t[1].l=0; t[1].r=0; t[1].fa=0; rt=1; sz[1]=1;
	for(rg int i=2;i<=n;i++){
		x=0; sz[i]=1;
		while(d[q[tl]] > d[i]) x=q[tl--];
		t[q[tl]].r=i; t[i].fa=q[tl]; t[x].fa=i;
		t[i].l=x; q[++tl]=i; 
		if(t[i].fa == 0) rt=i;
	}
}

void dfs(int x){
	ans+=d[x]-d[t[x].fa];
	if(t[x].l) dfs(t[x].l);
	if(t[x].r) dfs(t[x].r);
	return ;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	go(i,n+1,1) d[i]=read();
	make_tree();
	dfs(rt);
	printf("%lld",ans);
	return 0;
}

