// SC-0114 fxy
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<queue>
#include<stack>
#include<algorithm>
#define ll long long
#define rg register
#define go(i,x,a) for(rg int i=a;i<x;i++)
#define LDB long double
#define inf 0x3f3f3f3f
#define INF 0x7f7f7f7f
using namespace std;

const int maxn=1e3+5;
int n,m,k,hd[maxn],f[maxn][maxn],sz[maxn],vis[maxn][maxn];
ll mid;
struct edd{
	int nt,v,w;
}e[maxn*2];

inline int read(){
	int ret=0,af=1; char gc=getchar();
	while(gc < '0' || gc > '9'){ if(gc=='-')af=-af; gc=getchar(); }
	while(gc >= '0' && gc <= '9') ret=ret*10+gc-'0',gc=getchar();
	return ret*af;
}

inline void add(int a,int b,int c){
	e[k].v=b; e[k].w=c; e[k].nt=hd[a]; hd[a]=k++;
}

int dfs(int x,int faa){
	int tl=0;
	for(rg int i=hd[x];i!=-1;i=e[i].nt){
		int v=e[i].v,w=e[i].w; 
		if(v == faa) continue;
		f[x][++tl]=dfs(v,x)+w; sz[x]+=sz[v];
	}
	if(tl == 0) return 0;
	sort(f[x]+1,f[x]+tl+1);
	for(rg int i=tl;i>=1;i--){
		if(vis[x][i]) continue;
		if(f[x][i] >= mid){
			vis[x][i]=1; sz[x]++; continue;
		}
		for(rg int j=1;j<i;j++){
			if(vis[x][j] || vis[x][i]) continue;
			if(f[x][i]+f[x][j] >= mid){
				vis[x][i]=vis[x][j]=1; sz[x]++;
				break;
			}
		} 
	} int bs=0;
	for(rg int i=tl;i>=1;i--){
		if(vis[x][i] == 0) bs=max(bs,f[x][i]);
	}
	return bs;
}

int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(hd,-1,sizeof(hd));
	n=read(); m=read(); int a,b,c;
	if(n > 2000){
		return 0;
	}
	go(i,n,1){
		a=read(); b=read(); c=read();
		add(a,b,c); add(b,a,c);
	}
	ll l=0,r=100000000;
	while(l < r){
		memset(vis,0,sizeof(vis));
		memset(sz,0,sizeof(sz));
		mid=(l+r+1)/2; dfs(1,0);
		if(sz[1] < m) r=mid-1;
		else l=mid;
	}
	printf("%lld",l);
	return 0;
}

