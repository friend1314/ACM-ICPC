// La Lune
//80' Violence Program
//Failed
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long ln;
const int N = 1e2 + 5, M = 3e4 + 5;
int n, a[N], v[M];
int main(){
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int T; scanf("%d", &T);
	while(T--){
		memset(v, 0, sizeof(v));
		scanf("%d", &n); int mx = 0;
		for(int i = 1; i <= n; i++){
			scanf("%d", &a[i]); v[a[i]] = 2;
			mx = max(mx, a[i]);
		}
		sort(a + 1, a + n + 1);
		for(int i = 2; i <= mx; i++){
			for(int j = 1; j <= n && i * a[j] <= mx; j++){
				v[i * a[j]] = 1;
				if(i % a[j] == 0) break;
			}
		}
		if(mx < 10000){
			for(int i = 1; i <= mx; i++){
				for(int j = 1; i + j <= mx; j++){
					if(v[i] && v[j]) v[i + j] = 1;
				}
			}
			int ans = 0;
			for(int i = 1; i <= n; i++){
				if(v[a[i]] == 2) ans++;
			}
			printf("%d\n", ans);
		}
		else if(n == 2){
			int lg = max(a[1], a[2]), sm = min(a[1], a[2]);
			if(lg % sm == 0) printf("1\n");
			else printf("2\n");
		}
		else if(n == 3){
			for(int i = 0; i * a[3] <= mx; i++){
				for(int j = 0; i * a[3] + j * a[2] <= mx; j++){
					for(int k = 0; i * a[3] + j * a[2] + k * a[1] <= mx; k++){
						if(i == 1 && j == 0 && k == 0) continue;
						if(i == 0 && j == 1 && k == 0) continue;
						if(i == 0 && j == 0 && k == 1) continue;
						v[i * a[3] + j * a[2] + k * a[1]] = 1;
					}
				}
			}
			int ans = 0;
			for(int i = 1; i <= 3; i++) if(v[a[i]] == 2) ans++;
			printf("%d\n", ans);
		}
		else if(n == 4){
			for(int i = 0; i * a[4] <= mx; i++){
				for(int j = 0; i * a[4] + j * a[3] <= mx; j++){
					for(int k = 0; i * a[4] + j * a[3] + k * a[2] <= mx; k++){
						for(int l = 0; i * a[4] + j * a[3] + k * a[2] + l * a[1] <= mx; l++){
							if(i == 1 && j == 0 && k == 0 && l == 0) continue;
							if(i == 0 && j == 1 && k == 0 && l == 0) continue;
							if(i == 0 && j == 0 && k == 1 && l == 0) continue;
							if(i == 0 && j == 0 && k == 0 && l == 1) continue;
							v[i * a[4] + j * a[3] + k * a[2] + l * a[1]] = 1;	
						}
					}
				}
			}
			int ans = 0;
			for(int i = 1; i <= 4; i++) if(v[a[i]] == 2) ans++;
			printf("%d\n", ans);
		}
		else if(n == 5){
			for(int i = 0; i * a[5] <= mx; i++){
				for(int j = 0; i * a[5] + j * a[4] <= mx; j++){
					for(int k = 0; i * a[5] + j * a[4] + k * a[3] <= mx; k++){
						for(int l = 0; i * a[5] + j * a[4] + k * a[3] + l * a[2] <= mx; l++){
							for(int r = 0; i * a[5] + j * a[4] + k * a[3] + l * a[2] + r * a[1] <= mx; r++){
								if(i == 1 && j == 0 && k == 0 && l == 0 && r == 0) continue;
								if(i == 0 && j == 1 && k == 0 && l == 0 && r == 0) continue;
								if(i == 0 && j == 0 && k == 1 && l == 0 && r == 0) continue;
								if(i == 0 && j == 0 && k == 0 && l == 1 && r == 0) continue;
								if(i == 0 && j == 0 && k == 0 && l == 0 && r == 1) continue;
								v[i * a[5] + j * a[4] + k * a[3] + l * a[2] + r * a[1]] = 1;
							}
						}
					}
				}
			}
			int ans = 0;
			for(int i = 1; i <= 5; i++) if(v[a[i]] == 2) ans++;
			printf("%d\n", ans);
		}
		else printf("0\n");
	}
	return 0;
}
