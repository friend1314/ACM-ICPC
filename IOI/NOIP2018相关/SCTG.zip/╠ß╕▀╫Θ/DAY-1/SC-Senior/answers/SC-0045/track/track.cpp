// La Lune
// ���߳�ŷ��ͼ?
// ��һ�����������Թ��� 
#include<queue>
#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
typedef long long ln;
const int N = 5e4 + 5;
struct edge{
	int v, next;
	int w;
} e[N << 1];
int n, m, head[N], k = 1, in[N], a[N];
int ans = 0;
void adde(int u, int v, int w){
	e[k] = (edge){v, head[u], w};
	head[u] = k++;
}
void dfs(int u, int f, int sum){
	ans = max(ans, sum);
	for(int i = head[u]; i != -1; i = e[i]. next){
		int v = e[i]. v;
		if(v == f) continue;
		dfs(v, u, sum + e[i]. w);
	}
}
bool ctrl(int x){
	int sum = 0, res = 0;
	for(int i = 1; i < n; i++){
		if(sum + a[i] > x){
			res++;
			sum = a[i];
		}
		sum += a[i];
	}
	return res <= m;
}
int main(){
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	priority_queue <int, vector<int>, greater<int> > q;
	memset(head, -1, sizeof(head));
	scanf("%d %d", &n, &m); int f1 = 1, mx = 0, mn = 1e9, f2 = 1;
	for(int i = 1; i < n; i++){
		int u, v, w;
		scanf("%d %d %d", &u, &v, &w);
		if(v != u + 1) f1 = 0;
		if(u != 1) f2 = 0;
		if(f1) a[u] = w;
		adde(u, v, w); adde(v, u, w);
		in[u]++, in[v]++;
		mx = max(mx, w);
		mn = min(mn, w);
		q. push(w);
	}
	if(m == n - 1){
		printf("%d", mn);
	}
	else if(m == 1){
		for(int i = 1; i <= n; i++)
		if(in[i] == 1){
			dfs(i, 0, 0);
			printf("%d", ans);
			return 0;
		}
	}
	else if(f2){
		while(m < n - 1){
			int x = q. top(); q. pop();
			int y = q. top(); q. pop();
			q. push(x + y);
			m++;
		}
		printf("%d", q. top());
	}
	else if(f1){
		int l = mx, r = 5e8, ans = 0;
		while(l <= r){
			int mid = l + r >> 1;
			if(ctrl(mid)) ans = mid, r = mid - 1;
			else l = mid + 1;
		}
		printf("%d", ans);
	}
	return 0;
}
