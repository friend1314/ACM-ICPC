// La Lune
#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
typedef long long ln;
const int N = 1e5 + 5;
int n, a[N], cf[N];
int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d", &a[i]);
		cf[i] = a[i] - a[i - 1];
	}
	int ans = 0;
	for(int i = 1; i <= n; i++){
		if(cf[i] > 0) ans += cf[i];
	}
	printf("%d", ans);
	return 0;
}
