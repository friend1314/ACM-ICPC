#include<cstdio>
#include<cmath>
#include<algorithm>
#include<iomanip>
#include<iostream>
#include<cctype>
#include<vector>
#include<cstdlib>
#include<map>
#include<list>
#include<queue>
using namespace std;
int a[10001],n,t,m=0,tot[10001];
void find(int x,int y,int z)
{
    if(m==1)return;
	for(int i=y;i>=1;i--)if(a[i]<=x&&a[i]<z){
	int h=x-a[i];
	   if(h==0){
	    m=1;	
	   break;
	    }
		 if(h>=a[1])find(h,i,x);
		}
		return ;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		memset(a,0,sizeof(a));
		scanf("%d",&n);
		tot[i]=n;
		for(int j=1;j<=n;j++)
		scanf("%d",&a[j]);
		sort(a+1,a+n+1);
		for(int k=n;k>=1;k--)
		{
			find(a[k],k,a[k]);
			if(m==1){
				tot[i]--;
				m=0;
			}
		}
		
	}
	for(int i=1;i<=t;i++)
	cout<<tot[i]<<endl;
	return 0;
}
