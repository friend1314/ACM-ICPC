#include<cstdio>
#include<cmath>
#include<algorithm>
#include<iomanip>
#include<iostream>
#include<cctype>
#include<vector>
#include<cstdlib>
#include<map>
#include<list>
#include<queue>
using namespace std;
struct lyw{
	long long ma,mi;
}a[1000005];
long long n,t=0,k=0;
long long b[1000005];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld",&n);
	a[k].ma=0;a[k].mi=0;
	for(int i=1;i<=n;i++)
	{
	  scanf("%lld",&b[i]);
	  if(b[i]>a[k].mi)
	  {
		k++;
		a[k].ma=b[i];
		t+=a[k].ma-a[k-1].mi;
		a[k].mi=b[i];
	  }
	  else if(b[i]<=a[k].mi)
	  {
	  	a[k].mi=b[i];
	  }
	
	}
    printf("%lld",t);
    return 0;
}
