#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 105
using namespace std;

int a[N],n,m;
bool f[25005];

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') ans=(ans<<1)+(ans<<3)+(c^48),c=getchar();
	return ans*f;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t=read();
	while(t--)
	{
		m=n=read();
		memset(f,0,sizeof f);
		f[0]=1;
		for(int i=1;i<=n;++i) a[i]=read();
		sort(a+1,a+1+n);
		for(int i=1;i<=n;++i)
		{
			if(f[a[i]]) {m--;continue;}
			for(int j=a[i];j<=a[n];++j)
				f[j]|=f[j-a[i]];
		}
		printf("%d\n",m);
	}
	return 0;
}
