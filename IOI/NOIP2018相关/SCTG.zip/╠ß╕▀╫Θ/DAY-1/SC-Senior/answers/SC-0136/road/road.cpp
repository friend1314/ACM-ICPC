#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#define N 100005
#define ll long long
using namespace std;

ll q[N],top,a,n,ans;

inline ll read()
{
	ll ans=0,f=1;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') ans=(ans<<1)+(ans<<3)+(c^48),c=getchar();
	return ans*f;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(ll i=1;i<=n;++i)
	{
		a=read();
		ll now=q[top];
		while(a<=q[top]&&top) top--;
		q[++top]=a;
		if(a<now) ans+=now-a;
	}
	printf("%lld",ans+q[top]);
	return 0;
}
/*
6
4 3 2 5 3 5
*/
