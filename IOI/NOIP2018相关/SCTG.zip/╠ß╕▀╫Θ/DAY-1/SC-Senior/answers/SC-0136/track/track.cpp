#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
#define N 50005
using namespace std;

int h[N],cnt,d1[N],d2[N],maxx,n,m,dis[N],id[N],st;
struct node{int v,next,w;}e[N<<1];
queue<int>q;

inline int read()
{
	int ans=0,f=1;
	char c=getchar();
	while(c>'9'||c<'0') {if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') ans=(ans<<1)+(ans<<3)+(c^48),c=getchar();
	return ans*f;
}

inline void add(int x,int y,int z){e[++cnt]=(node){y,h[x],z};h[x]=cnt;}

void dfs(int x,int fa)
{
	for(int i=h[x];i;i=e[i].next)
	{
		int v=e[i].v;
		if(v==fa) continue;
		dfs(v,x);
		if(d1[v]+e[i].w>d1[x])
		{
			d2[x]=d1[x];
			d1[x]=d1[v]+e[i].w;
		}
		else if(d1[v]+e[i].w>d2[x]) d2[x]=d1[v]+e[i].w;
	}
	maxx=max(maxx,d1[x]+d2[x]);
}

inline bool check(int mid)
{
	int lst=st,ans=0;
	q.push(st);
	while(!q.empty())
	{
		int x=q.front();q.pop();
		if(dis[x]-dis[lst]>=mid) ans++,lst=x;
		for(int i=h[x];i;i=e[i].next)
		{
			int v=e[i].v;
			if(dis[v]<=dis[x]) continue;
			q.push(v);
		}
	}
	return ans>=m;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	int x,y,z,ans=0x3f3f3f3f;
	for(int i=1;i<n;++i) x=read(),y=read(),z=read(),add(x,y,z),add(y,x,z),ans=min(ans,z);
	if(m==1)
	{
		dfs(1,1);
		printf("%d",maxx);
	}
	else if(m==n-1)
	{
		printf("%d",ans);
	}
	else
	{
		for(int i=1;i<=n;++i)
			for(int j=h[i];j;j=e[j].next) id[i]++;
		for(int i=1;i<=n;++i) if(id[i]==1) {q.push(st=i);break;}
		while(!q.empty())
		{
			int x=q.front();q.pop();
			for(int i=h[x];i;i=e[i].next)
			{
				int v=e[i].v;
				if(!dis[v]&&v!=st) q.push(v),dis[v]=dis[x]+e[i].w;
			}
		}
		int l=0,r=1000000000;
		while(l<r)
		{
			int mid=l+r>>1;
			if(check(mid)) ans=mid,l=mid+1;
			else r=mid;
		}
		printf("%d",ans);
	}
	return 0;
}
