#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int data[10001];

int main(){
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int t;
	scanf("%d", &t);
	for (int k = 1; k <= t; k++){
		int n;
		scanf("%d", &n);
		for (int j = 1; j <= n; j++){
			scanf("%d", &data[j]);
		}
		if (n == 2){
			if (data[1] < data[2]){
				data[1] = data[1]^data[2];
				data[2] = data[1]^data[2];
				data[1] = data[1]^data[2];
			}
			if (data[1] % data[2] == 0)
				printf("%d\n", 1);
			else
				printf("%d\n", 2);
		}else if (n == 3){
			sort(data+1, data+n+1);
			if ((data[3] % data[2] == 0) && (data[2] % data[1] == 0))
				printf("%d\n", 1);
			else if ((data[3] % data[2] == 0) || (data[2] % data[1] == 0) ||
					(data[3] >= (data[1]*data[2]-data[1]-data[2])))
				printf("%d\n", 2);
			else
				printf("%d\n", 3);
		}else{
			printf("%d\n", n);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
