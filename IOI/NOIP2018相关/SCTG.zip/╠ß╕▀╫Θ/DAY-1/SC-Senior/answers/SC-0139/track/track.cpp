#include <iostream>
#include <cstdio>
using namespace std;

struct Edge{
	int v, w, nxt;
}e[100010];

int head[50010], cnt, n, m, vis[50010];

void add(int u, int v, int w){
	e[++cnt].v = v;
	e[cnt].w = w;
	e[cnt].nxt = head[u];
	head[u] = cnt;
}

bool dfs(int x, int tot, int sum){
	if (tot >= sum)
		return true;
	bool flag = false;
	for (int i = head[x]; i; i = e[i].nxt){
		if (!vis[e[i].v]){
			vis[e[i].v] = 1;
			flag = dfs(e[i].v, tot+e[i].w, sum);
			vis[e[i].v] = 0;
			if (flag) return true;
		}
	}
	return false;
}

bool check(int mid){
	int flag = false;
	for (int i = 1; i <= n; i++){
		vis[i] = 1;
		flag = dfs(i, 0, mid);
		vis[i] = 0;
		if (flag) return true;
	}
	return false;
}

int main(){
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	scanf("%d%d", &n, &m);
	int l = 1, r = 0;
	for (int i = 1; i <= n-1; i++){
		int u, v, w;
		scanf("%d%d%d", &u, &v, &w);
		add(u, v, w); add(v, u, w);
		r += w;
	}
	while (l < r){
		int mid = (l+r)/2;
		if (check(mid)) l = mid;
		else r = mid-1;
	}
	cout << l;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
