#include <iostream>
#include <cstdio>
using namespace std;

int data[100010];

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n;
	scanf("%d", &n);
	int maxn = 0, ans = 0;
	for (int i = 1; i <= n; i++){
		scanf("%d", &data[i]);
		maxn = max(maxn, data[i]);
	}
	for (int i = 1; i <= maxn; i++){
		int cnt = 0;
		int j = 1;
		while(j <= n){
			for (; data[j] >= i; j++);
			if (data[j-1] >= i) cnt++;
			j++;
		}
		ans += cnt;
	}
	printf("%d", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
