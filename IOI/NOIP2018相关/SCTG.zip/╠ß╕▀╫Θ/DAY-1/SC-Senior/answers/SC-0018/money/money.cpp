#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int a[105],flag,N,NO[105],no;

bool check(int rt,int pow,int test)
{
	if(rt == 0)	return 0;
	if(test - a[rt] * pow < 0)	return check(rt-1,0,test - a[rt] * (pow - 1));
	if((test - a[rt] * pow) % a[rt] == 0)	return 1;
	return check(rt-1,0,test - a[rt] * pow) || check(rt,pow+1,test);
}

bool solve(int rt)
{
	for(int i = rt+1;i <= N;i++){
		if(check(rt,0,a[i])){
			NO[i] = 1;
			continue ;
		}
		else	return 0;
	}
	return 1;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	
	int T,ans;scanf("%d",&T);
	while(T--){
		no = 0;memset(NO,0,sizeof(NO));
		scanf("%d",&N);
		for(int i = 1;i <= N;i++)	scanf("%d",&a[i]);
		sort(a+1,a+1+N);
		for(ans = 1;ans <= N;ans++){
			if(NO[ans]) {no++;continue ;}
			if(solve(ans))	break ;
		}
		printf("%d\n",ans - no);
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
