#include <iostream>
#include <cstdio>
using namespace std;
int place,a[100005];

int solve(int l,int r,int left)
{
	int f = 0x3f3f3f3f;
	for(int i = l;i <= r;i++){
		if(a[i] < f){
			f = a[i];
			place = i;
		}
	}
	if(l == r)	return f - left;
	if(l > r)	return 0;
	return f + solve(l,place-1,f) + solve(place+1,r,f) - left;
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	int N;scanf("%d",&N);
	for(int i = 1;i <= N;i++)	scanf("%d",&a[i]);
	int ans = solve(1,N,0);
	printf("%d\n",ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
