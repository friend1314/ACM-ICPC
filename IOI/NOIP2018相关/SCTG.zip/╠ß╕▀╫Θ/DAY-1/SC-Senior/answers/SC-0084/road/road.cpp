#include<cstdio>
using namespace std;
int n,a[100001];
long long sum;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
    scanf("%d",&a[i]);
	int now=a[1],leiji=0;
	sum=a[1];

	for(int i=1;i<=n;i++)
	{
		if(a[i]>=a[i+1])
		continue;
		if(a[i]<a[i+1]){
		a[i]-=leiji;	
		leiji+=a[i];
		now=a[i+1]-leiji;
		sum+=now;
		}
	
	}
	printf("%lld",sum);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
