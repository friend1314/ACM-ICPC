#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int a[25001],vis[25001],n,biaoji1[25001],t,tot,b[25001];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
   for(int k=1;k<=t;k++)
	{	memset(a,0,sizeof(a));
			memset(vis,0,sizeof(vis));
			memset(biaoji1,0,sizeof(biaoji1));
		scanf("%d",&n);
		tot=n;
		b[0]=0;
		for(int i=1;i<=n;i++)
		{
		
		scanf("%d",&a[i]);
		vis[a[i]]=1;
		}
	
		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++)
		b[i]=b[i-1]+a[i];
	
		for(int i=1;i<=n;i++)
		for(int j=2;j<=500;j++)
		{
			if(a[i]*j>1000) break;
			if(vis[a[i]*j]==1)
			{
				biaoji1[a[i]*j]=1;
				tot--;
			}
		}
		for(int i=2;i<=n;i++)
		if(vis[b[i]]==1&&biaoji1[b[i]]==0) 
		{
		tot--;
		}
		printf("%d\n",tot); 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
