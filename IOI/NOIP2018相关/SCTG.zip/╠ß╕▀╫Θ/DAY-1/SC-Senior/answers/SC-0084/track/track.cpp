#include<cstdio>
#include<queue>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<iostream>
using namespace std;
int n,m,dep[50001],first[50001],exist[50001];
long long ans,dis[50001];
struct node{
	int next;
	int to;
	int w;
};
node a[50001];
int tot;
queue<int> q;
void lianjie(int x,int y,int z)
{
	tot++;
	a[tot].next=first[x];
	a[tot].to=y;
	a[tot].w=z;
	first[x]=tot;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n-1;i++)
	{
		int x,y,z;
		scanf("%d %d %d",&x,&y,&z);
		lianjie(x,y,z);
		lianjie(y,x,z);
	}
	for(int i=1;i<=n;i++)
	{
		memset(exist,0,sizeof(exist));
		memset(dis,0x3f,sizeof(dis));
		q.push(i);
		exist[i]=1;
		dis[i]=0;
		while(!q.empty())
		{
			//printf("*");
			int x=q.front();
			q.pop();
			exist[x]=0;
			for(int k=first[x];k!=0;k=a[k].next)
			{
				if(dis[a[k].to]>dis[x]+a[k].w)
				{
					dis[a[k].to]=dis[x]+a[k].w;
					if(exist[a[k].to]==0)
					{
						q.push(a[k].to);
						exist[a[k].to]=1;
					}
				}
			}
		}
		for(int i=1;i<=n;i++)
		ans=max(ans,dis[i]);
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
