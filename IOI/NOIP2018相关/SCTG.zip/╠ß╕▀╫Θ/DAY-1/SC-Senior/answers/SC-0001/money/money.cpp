#include<bits/stdc++.h>
using namespace std;
int t,n,a[101],b[101],ans;
bool flag[25001],book=0;
void pd(int u,int wei)
{
	for(int i=wei-1;i>=1;i--)
	{
		if(u-b[i]>=0){	
		if(flag[u-b[i]]==true)
		{
			pd(u-b[i],wei);
		}
		if(flag[u-b[i]]==false)
		{
			book=1;
		}}
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
    cin>>t;
	for(int i=1;i<=t;i++)
	{
		cin>>n;
		memset(flag,true,sizeof(flag));
		for(int j=1;j<=n;j++) 
		{
			cin>>a[j];
			if(flag[a[j]]==true)
			{
				for(int k=2;a[j]*k<=25000;k++)
				{
					int u=a[j]*k;
					flag[u]=false;
				}
			}
		}
		int tot=0;
		for(int j=1;j<=n;j++)
		{
			if(flag[a[j]]==true) 
			{
				b[++tot]=a[j];
				flag[b[tot]]=false;
			}
		}
		ans=tot;
		sort(b+1,b+tot+1);
		for(int j=3;j<=tot;j++)
		{
			book=0;
			pd(b[j],j);
			if(book==1) ans--;
		}
		cout<<ans<<endl;
	}
	return 0;
}
