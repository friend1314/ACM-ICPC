#include<bits/stdc++.h>
using namespace std;
int n,deep[100001],ans=0;
void search(int l,int r)
{
	if(l==r) ans+=deep[l];
	else if(r>l)
	{
		int minn=99999999,mid=0;
		for(int i=l;i<=r;i++)
		{
			if(deep[i]<minn&&deep[i]!=0)
			{
				minn=deep[i];
				mid=i;
			}
		}
		ans+=deep[mid];
		int u=deep[mid];
		for(int i=l;i<=r;i++) 
		{
			deep[i]-=u;
		}
		int x=l;
		for(int i=l;i<=r;i++)
		{
			if(deep[i]==0)
			{
				search(x,i-1);
				x=i+1;
			}
		}
		search(x,r);
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>deep[i];
	search(1,n);
	cout<<ans;
	return 0;
}
