#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c,fir[50001],next[50001],to[50001],road[50001],cont[50001],tot=0;
int s,ans=0,maxn=0,minn=0;
void addedge(int x,int y,int z)
{
	to[++tot]=y;
	road[tot]=z;
	next[tot]=fir[x];
	fir[x]=tot;
}
void search(int u,int father)
{
	for(int i=fir[u];i;i=next[i])
	{
		int v=to[i];
		if(v!=father)
		{
			ans+=road[i];
			if(ans>minn) 
			{
				minn=ans;
				s=v;
			}
			search(v,u);
			ans-=road[i];
		}
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n-1;i++)
	{
		cin>>a>>b>>c;
		if(c>=maxn) maxn=c;
		addedge(a,b,c);
		addedge(b,a,c);	
	}
	if(m==1)
	{
		search(1,0);
		ans=0;
		minn=0;
		search(s,0);
		cout<<minn;
	}
	if(m==n-1) cout<<maxn;
	return 0;
}
