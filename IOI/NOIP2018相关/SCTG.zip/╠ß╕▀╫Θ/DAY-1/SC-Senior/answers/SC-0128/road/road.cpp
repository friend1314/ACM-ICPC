#include<bits/stdc++.h>
#define FE "road"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-')p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
const int LEN=1000005;
int n;
vector<int>pos[LEN];
bool ext[LEN];
long long ans=0,cur=0;
inline void work(int d){
	for(int i=0;i<pos[d].size();++i){
		int p=pos[d][i];
		ext[p]=1;
		++cur;
		if(ext[p-1])--cur;
		if(ext[p+1])--cur;
	}
	ans+=cur;
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	n=getint();
	for(int i=1;i<=n;++i){
		pos[getint()].push_back(i);
	}
	for(int i=0;i<=n+1;++i){
		ext[i]=0;
	}
	for(int i=100000;i>=1;--i){
		work(i);
	}
	cout<<ans<<endl;
	return 0;
}
