#include<bits/stdc++.h>
#define FE "track"
#define pb push_back
#define mp make_pair
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-')p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
int n,m;
vector<pair<int,int> >r[100005];
bool a1=1,ba1=1;
int s,t,dis,ans;
inline void dfs1(int fa,int cur,int &s,int d){
	if(d>dis){
		s=cur;
		dis=d;
	}
	for(int i=0;i<r[cur].size();++i){
		int v=r[cur][i].first;
		if(v==fa)continue;
		dfs1(cur,v,s,d+r[cur][i].second);
	}
}
inline void dfs2(int fa,int cur,int d){
	if(d>ans){
		ans=d;
	}
	for(int i=0;i<r[cur].size();++i){
		int v=r[cur][i].first;
		if(v==fa)continue;
		dfs2(cur,v,d+r[cur][i].second);
	}
}
inline void work1(){
	dis=0;
	dfs1(1,1,s,0);
	dfs2(s,s,0);
	cout<<ans<<endl;
}
multiset<int>val1;
typedef multiset<int>::iterator si;
inline int ck2(int ca){
	for(int i=0;i<r[1].size();++i){
		val1.insert(r[1][i].second);
	}
	int ans=0;
	while(!val1.empty()){
		si p1=val1.begin();
		int x=*p1;
		val1.erase(p1);
		if(x>=ca){
			++ans;
		}
		else{
			si p2=val1.lower_bound(ca-x);
			if(p2!=val1.end()){
				val1.erase(p2);
				++ans;
			}
		}
	}
	return ans;
}
inline void work2(){
	int l=0,r=1000000000;
	while(l<=r){
		int mid=l+r>>1;
		if(ck2(mid)>=m){
			ans=mid;
			l=mid+1;
		}
		else{
			r=mid-1;
		}
	}
	cout<<ans<<endl;
}
inline int ck3(int ca){
//	cout<<ca<<":\n";
	int ans=0,cur=0;
	for(int i=1;i<n;++i){
		int j;
		for(j=0;j<r[i].size();++j)if(r[i][j].first==i+1)break;
		cur+=r[i][j].second;
//		cout<<cur<<endl;
		if(cur>=ca)cur=0,++ans;
	}
//	cout<<ca<<" "<<ans<<endl;
	return ans;
}
inline void work3(){
	int l=0,r=1000000000;
	while(l<=r){
		int mid=l+r>>1;
		if(ck3(mid)>=m){
			ans=mid;
			l=mid+1;
		}
		else{
			r=mid-1;
		}
	}
	cout<<ans<<endl;
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	n=getint(),m=getint();
	for(int i=1;i<n;++i){
		int a=getint(),b=getint(),c=getint();
		r[a].pb(mp(b,c));
		r[b].pb(mp(a,c));
		if(a!=1)a1=0;
		if(b!=a+1)ba1=0;
	}
	if(m==1){
		work1();
	}
	else{
		if(a1){
			work2();
		}
		else{
			if(ba1){
				work3();
			}
		}
	}
	return 0;
}
