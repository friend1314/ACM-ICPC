#include<bits/stdc++.h>
#define FE "money"
using namespace std;
inline int getint(){
	int x=0,p=1;
	char c=getchar();
	while(!isdigit(c)){
		if(c=='-')p=-1;
		c=getchar();
	}
	while(isdigit(c)){
		x=(x<<3)+(x<<1)+(c^'0');
		c=getchar();
	}
	return x*p;
}
const int LEN=50005;
int mo[1005];
bool can[LEN];
inline void work(){
	int n=getint();
	can[0]=1;
	for(int i=1;i<=n;++i){
		mo[i]=getint();
	}
	sort(mo+1,mo+n+1);
	int ans=0;
	for(int i=1;i<=n;++i){
		if(!can[mo[i]]){
			++ans;
			for(int j=0;j<=mo[n]-mo[i];++j){
				if(can[j]){
					can[j+mo[i]]=1;
				}
			}
		}
	}
	memset(can,0,sizeof(can));
	cout<<ans<<'\n';
}
int main(){
	freopen(FE".in","r",stdin);
	freopen(FE".out","w",stdout);
	int T=getint();
	while(T--){
		work();
	}
	return 0;
}
