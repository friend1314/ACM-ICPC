#include<bits/stdc++.h>
#define de printf("~~~\n");
#define ll long long
#define il inline
#define re register
using namespace std;
const int maxn=30005;
//////////////////////INIT///////////////////////////////////////////////
il void read(int &x)
{
	int f=1;x=0;char c=getchar();
	while(c>'9'||c<'0') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

il void print(int x)
{
	if(x<0) {putchar('-');x=-x;}
	if(x>=10) print(x/10);
	putchar(x%10+48);
}
///////////////////KDKS//////////////////////////////////////////////////
struct egde{
	int v,w,nxt;
}e[maxn*3];

int hed[maxn],cnt,d[maxn];

il void add(int x,int y,int w)
{
	cnt++;
	e[cnt].v=y;
	e[cnt].w=w;
	e[cnt].nxt=hed[x];
	hed[x]=cnt;
}
///////////////////STAR//////////////////////////////////////////////////
int maxnd,maxl;
int l[maxn];

il void dfs(int x,int fa,int w)
{
	d[x]=d[fa]+1;
	l[x]=l[fa]+w;
	if(l[x]>maxl)
	{
		maxl=l[x];
		maxnd=x;
	}
	for(re int i=hed[x];i;i=e[i].nxt)
	{
		int v=e[i].v;
		if(v==fa) continue;
		dfs(v,x,e[i].w);
	}
}
///////////////////DFS///////////////////////////////////////////////////
int n,m;
int a,b,w;
///////////////////DEFINE////////////////////////////////////////////////
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);
	for(re int i=1;i<n;++i)
	{
		read(a);read(b);read(w);
		add(a,b,w);add(b,a,w);
	}
	dfs(1,0,0);
	memset(l,0,sizeof l);
	memset(d,0,sizeof d);
	dfs(maxnd,0,0);
	print(maxl);
	return 0;
}
