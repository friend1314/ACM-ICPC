#include<bits/stdc++.h>
#define de printf("~~~\n");
#define ll long long
#define il inline
#define re register
using namespace std;
const int maxn=105;
//////////////////////INIT///////////////////////////////////////////////
il void read(int &x)
{
	int f=1;x=0;char c=getchar();
	while(c>'9'||c<'0') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

il void print(int x)
{
	if(x<0) {putchar('-');x=-x;}
	if(x>=10) print(x/10);
	putchar(x%10+48);
}
///////////////////KDKS//////////////////////////////////////////////////
bool cmp(const int a,const int b)
{
	return a<b;
}
///////////////////CMP///////////////////////////////////////////////////
il int gcd(int a,int b)
{
	return !b?a:gcd(b,a%b);
}
///////////////////GCD///////////////////////////////////////////////////
int t,n;
int a[maxn];
///////////////////DEFINE////////////////////////////////////////////////
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(t);
	while(t--)
	{
		read(n);
		for(re int i=1;i<=n;++i)
		{
			read(a[i]);
		}
		if(n==2)
		{
			if(a[1]==1||a[2]==1)
				printf("1\n");
			else
			{
				int g=gcd(a[1],a[2]);
				if(g==1) {printf("2\n");}
				else
				{
					if(g==a[1]||g==a[2])
					{
						if((g<<1)==a[1]||(g<<1)==a[2]) {printf("1\n");}
						else {printf("2\n");}
					}
					else {printf("2\n");}
				}
			}
		}
		else if(n==3)
		{
			stable_sort(a+1,a+1+n,cmp);
			if(a[1]==1) printf("1\n");
			else
			{
				int g1=gcd(a[1],a[2]),g2=gcd(a[2],a[3]),g3=gcd(a[1],a[3]);
				if(g1==1&&g2==1&&g3==1) printf("3\n");
				//1 pair
				else if(g1!=1&&g2==1&&g3==1)
				{
					if(g1==a[1]&&a[1]*2==a[2]) printf("2\n");
					else printf("3\n");
				}
				else if(g1==1&&g2!=1&&g3==1)
				{
					if(g2==a[2]&&a[2]*2==a[3]) printf("2\n");
					else printf("3\n");
				}
				else if(g1==1&&g2==1&&g3!=1)
				{
					if(g3==a[1]&&a[1]*2==a[3]) printf("2\n");
					else printf("3\n");
				}
				//2 pair
				else if(g1!=1&&g2!=1&&g3==1)
				{
					if(g1==a[1]&&a[1]*2==a[2])
					{
						printf("2\n");
					}
					else if(g2==a[2]&&a[2]*2==a[3])
					{
						printf("2\n");
					}
					else printf("3\n");
				}
				else if(g1==1&&g2!=1&&g3!=1)
				{
					if(g2==a[2]&&a[2]*2==a[3])
					{
						printf("2\n");
					}
					else if(g2==a[2]&&a[2]*2==a[3])
					{
						printf("2\n");
					}
					else printf("3\n");
				}
				else if(g1!=1&&g2==1&&g3!=1)
				{
					if(g1==a[1]&&a[1]*2==a[2])
					{
						printf("2\n");
					}
					else if(g1==a[1]&&a[1]*2==a[3])
					{
						printf("2\n");
					}
					else printf("3\n");
				}
				else printf("3\n");
			}
		}
		else
		{
			print(n);
			putchar('\n');
		}
	}
	return 0;
}
