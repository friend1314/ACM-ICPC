#include<bits/stdc++.h>
#define de printf("~~~\n");
#define ll long long
#define il inline
#define re register
using namespace std;
const int maxn=100005;
//////////////////////INIT///////////////////////////////////////////////
il void read(int &x)
{
	int f=1;x=0;char c=getchar();
	while(c>'9'||c<'0') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}

il void print(int x)
{
	if(x<0) {putchar('-');x=-x;}
	if(x>=10) print(x/10);
	putchar(x%10+48);
}
///////////////////KDKS//////////////////////////////////////////////////
int d[maxn],f[maxn];
int n;
///////////////////DEFINE////////////////////////////////////////////////
int main()//road
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);read(d[1]);
	f[1]=d[1];
	for(re int i=2;i<=n;++i)
	{
		read(d[i]);
		
		if(d[i]<=d[i-1])
			f[i]=f[i-1];
		else
			f[i]=f[i-1]+d[i]-d[i-1];
	}
	print(f[n]);
	return 0;
}
/*
6
4 3 2 5 3 5

9
*/
