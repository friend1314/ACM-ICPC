#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn = 25000+10;
int T,n,a[100+10],ans;
bool in[maxn];
int dfs(int x){
	if(in[x]==true) return 1;
	if(x<a[1]) return 0;
	for(int i=1;i<=n;i++){
		int temp=x-a[i];
		if(in[temp]==true){
			return 1;
		}
		in[x]=dfs(temp);
	}
	return in[x];
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int ke=1;ke<=T;ke++){
		memset(in,false,sizeof(in));ans = 0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++){
			if(in[a[i]]==true){
				continue;
			}
			int j=2; int temp = a[i]*j;
			while(temp<a[n]){
				in[temp]=true; j++;
				temp = a[i]*j;
			}
		}
		for(int i=1;i<=n;i++){
			if(dfs(a[i])) ans++;
		}
		printf("%d\n",n-ans);
	}
	return 0;
}
