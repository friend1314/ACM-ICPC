#include<cstdio>
using namespace std;
const int maxn = 1000+10;
int n,deep[maxn],ans=0;
int min(int a,int b){return a<b?a:b;}
void dfs(int lef,int rig,int sign){
//	printf("l:%d r:%d sign:%d\n",lef,rig,sign);
	if(lef==rig){ ans+=(deep[lef]-sign); return ;}
	if(lef>rig) return;
	int minn = 99999;int id;
	for(int i=lef;i<=rig;i++){
		if(deep[i]-sign==0){
			dfs(lef,i-1,sign);
			dfs(i+1,rig,sign);
			return ;
		}
		if(deep[i]-sign<minn){
			
			minn=deep[i]-sign; id=i;
		}
	}
	ans+=minn;
//	printf("2:ans:%d\n",ans);
	dfs(lef,id-1,minn+sign); dfs(id+1,rig,minn+sign);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&deep[i]);
	}
	dfs(1,n,0);
	printf("%d\n",ans);
	return 0;
}
