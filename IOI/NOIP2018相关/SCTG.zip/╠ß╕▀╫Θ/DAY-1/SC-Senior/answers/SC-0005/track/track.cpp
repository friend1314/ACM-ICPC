#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn = 1000+10;
int n,m,ek=0,ans = 0;
int head[maxn],fa[maxn];
struct Edge{
	int to,from,next,wi;
}edge[maxn*2];
int find(int x){
	if(fa[x]==x) return x;
	fa[x]=find(fa[x]);
	return fa[x];
}
void hebing(int x,int y){
	int fx=find(x); int fy=find(y);
	if(fx!=fy) fa[x]=fy;
}
void add(int from,int to,int vi){
	edge[++ek].to=to; edge[ek].from=from; edge[ek].wi=vi;
	edge[ek].next=head[from];
	head[from]=ek; 
}
bool cmp(Edge a,Edge b){
	return a.wi<b.wi;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	int t1,t2,t3;
	for(int i=1;i<n;i++){
		scanf("%d%d%d",&t1,&t2,&t3);
		add(t1,t2,t3); add(t2,t1,t3);
	}
	sort(edge+1,edge+ek+1,cmp);
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
	int cnt=0;
	for(int i=1;i<=ek;i++){
		int to=edge[i].to; int from=edge[i].from;
		if(find(to)!=find(from)){
			hebing(to,from);
			ans+=edge[i].wi;
			cnt++;	
		}
		if(cnt==n-1) break;
	}
	printf("%d\n",ans);
	return 0;
}
