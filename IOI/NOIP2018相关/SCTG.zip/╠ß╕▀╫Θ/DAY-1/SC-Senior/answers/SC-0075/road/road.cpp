#include<iostream>
#include<cstdio>
#include<cstring>
#define LL long long
using namespace std;
const int N=1e5+10;
int n,pos[N][20];
LL h[N],minn[N][20];
inline LL read(){
	char ch=getchar(); LL x=0, f=1;
	while(ch<'0' || ch>'9'){if(ch=='-') f=-1; ch=getchar();	}
	while(ch>='0' && ch<='9'){x=10*x+ch-'0'; ch=getchar();	}
	return x*f;}
inline LL mi(LL a,LL b){return a<b ? a : b;}
inline void ST()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=1;i+(1<<j-1)<=n;j++)
		{
			if(minn[i][j-1]<minn[i+(1<<j-1)][j-1])
			{
				minn[i][j]=minn[i][j-1];
				pos[i][j]=pos[i][j-1];
			}
			else{
				minn[i][j]=minn[i+(1<<j-1)][j-1];
				pos[i][j]=pos[i+(1<<j-1)][j-1];
			}
		}
	}
}
inline int ask1(int nn,int mm)//pos
{
	int kk=0;
	while((1<<kk+1)+nn<=mm) kk++;
	return minn[nn][kk]<minn[mm-(1<<kk)+1][kk] ? pos[nn][kk] : pos[mm-(1<<kk)+1][kk];
}
inline LL ask2(int nn,int mm)//tt
{
	int kk=0;
	while((1<<kk+1)+nn<=mm) kk++;
	return mi(minn[nn][kk],minn[mm-(1<<kk)+1][kk]);
}
LL dfs(int l,int r,LL de)
{
	if(l==r) return h[l]-de;
	if(l>r) return 0;
	LL tt=ask2(l,r); int pos=ask1(l,r);
	if(!tt) return dfs(l,pos-1,de)+dfs(pos+1,r,de);
	return dfs(l,pos-1,tt)+dfs(pos+1,r,tt)+tt-de;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read(); memset(minn,0x3f,sizeof minn);
	for(int i=1;i<=n;i++) minn[i][0]=h[i]=read(),pos[i][0]=i;
	ST();
	printf("%lld\n",dfs(1,n,0));
	fclose(stdin); fclose(stdout);
	return 0;
}
