#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define LL long long
using namespace std;
const int N=105;
int T,n,cnt,flgg,m,t[N];
LL num[N],a[N];
inline LL read(){
	char ch=getchar(); LL x=0, f=1;
	while(ch<'0' || ch>'9'){if(ch=='-') f=-1; ch=getchar();	}
	while(ch>='0' && ch<='9'){x=10*x+ch-'0'; ch=getchar();	}
	return x*f;}
void dfs(int x,int st,LL sum)
{
	if(flgg==1 || st>cnt) return ;
	for(t[st]=0;sum+num[st]*t[st]<=x && !flgg;t[st]++)
	{
		if(sum+num[st]*t[st]==x) 
		{
			m--; flgg=1;
			return ;
		}
		dfs(x,st+1,sum+num[st]*t[st]);
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--)
	{
		m=n=read();
		for(int i=1;i<=n;i++) a[i]=read();
		sort(a+1,a+1+n);
		if(n==2)
		{
			if(a[2]%a[1]==0) printf("1\n");
			else printf("2\n");
		}
		else if(n==3) {
			if(a[2]%a[1]==0)
			{
				if(a[3]%a[1]==0) printf("1\n");
				else printf("2\n");
			}
			else {
				int flg=0;
				for(int i=0;a[1]*i<=a[3] && !flg;i++)
				{
					for(int j=0;a[1]*i+a[2]*j<=a[3] && !flg;j++)
					{
						if(a[1]*i+a[2]*j==a[3]) flg=1;
					} 
				}
				printf("%d\n",flg ? 2 : 3);
			}
		}
		else {
			cnt=0;
			num[++cnt]=a[1];
			for(int i=2;i<=n;i++)
			{
				memset(t,0,sizeof t); flgg=0;
				dfs(a[i],1,0);
				if(!flgg) num[++cnt]=a[i];
			}
			printf("%d\n",m);
		}
	}
	fclose(stdin); fclose(stdout);
	return 0;
}

