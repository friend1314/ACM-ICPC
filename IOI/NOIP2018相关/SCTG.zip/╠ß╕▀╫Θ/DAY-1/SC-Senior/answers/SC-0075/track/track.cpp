#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
const int N=5e4+10;
struct dabt{
	int next,to,dis;
}e[N<<1];
int n,m,k,head[N],dist[N],minn=2e9,ru[N];
inline void add(int from,int to,int d){e[++k]=(dabt){head[from],to,d}; head[from]=k;}
inline int read(){
	char ch=getchar(); int x=0, f=1;
	while(ch<'0' || ch>'9'){if(ch=='-') f=-1; ch=getchar();	}
	while(ch>='0' && ch<='9'){x=10*x+ch-'0'; ch=getchar();	}
	return x*f;}
inline int mx(int a,int b){return a>b ? a : b;}
inline int mi(int a,int b){return a<b ? a : b;}
void dfs(int st,int fa,int sum)
{
	dist[st]=sum;
	for(int i=head[st];i;i=e[i].next)
	{
		int v=e[i].to;
		if(v==fa) continue;
		dfs(v,st,sum+e[i].dis);
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(); m=read();
	for(int i=1,a,b,c;i<n;i++)
	{
		a=read(); b=read(); c=read();
		add(a,b,c); add(b,a,c); minn=mi(minn,c);
		ru[a]++; ru[b]++;
	}
	if(m==1)
	{
		memset(dist,0,sizeof dist);
		dfs(1,0,0);
		int maxx=0, pos=0; 
		for(int i=1;i<=n;i++) if(dist[i]>maxx) maxx=dist[i], pos=i;
		memset(dist,0,sizeof dist);
		dfs(pos,0,0);
		maxx=0;
		for(int i=1;i<=n;i++) maxx=mx(maxx,dist[i]);
		printf("%d\n",maxx);
	}
	else if(m==n-1) {
		printf("%d\n",minn);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
