#include<bits/stdc++.h>
using namespace std;
const int N=1e5+1;
int a[N];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
	}
	long long ans=0;
	int l=1,r=n;
	while(!a[l]){
		l++;
	}
	while(!a[r]){
		r--;
	}
	while(l<=r){
		int ming=2e9,L=l;
		for(int i=l;i<=r;++i){
			if(!a[i]&&ming<1e9){
				for(int j=L;j<i;++j){
					a[j]-=ming;
				}
				while(!a[i+1]&&i<=n){
					i++;
				}
				L=i+1;
				ans+=ming;
				ming=2e9;
				continue;
			}
			if(a[i]<ming){
				ming=a[i];
			}
		}
		ans+=ming;
		for(int i=L;i<=r;++i){
			a[i]-=ming;
		}
		while(!a[l]&&l<=n){
			l++;
		}
		while(!a[r]&&r>0){
			r--;
		}
	}
	printf("%lld",ans);
	return 0;
}

