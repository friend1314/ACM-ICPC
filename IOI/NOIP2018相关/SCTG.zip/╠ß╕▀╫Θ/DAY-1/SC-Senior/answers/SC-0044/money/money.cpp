#include<bits/stdc++.h>
using namespace std;
const int N=3e4+1,M=101;
int a[M],e;
bool vis[N];
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		for(int i=1;i<=n;++i){
			scanf("%d",&a[i]);
		}
		sort(a+1,a+n+1);
		memset(vis,0,sizeof(vis));
		e=0;
		e++;
		vis[a[1]]=1;
		for(int i=2;i<=a[n]/a[1];++i){
			vis[i*a[1]]=1;
		}
		for(int i=2;i<=n;++i){
			if(vis[a[i]]){
				continue;
			}
			e++;
			vis[a[i]]=1;
			for(int j=a[i]+1;j<=a[n];++j){
				if(!vis[j]&&vis[j-a[i]]){
					vis[j]=1;
				}
			}
		}
		printf("%d\n",e);
	}
	return 0;
}

