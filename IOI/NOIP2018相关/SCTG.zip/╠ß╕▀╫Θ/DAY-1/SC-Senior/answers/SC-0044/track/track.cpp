#include<bits/stdc++.h>
using namespace std;
const int N=5e4+1;
struct node{
	int v,w,nex;
}t[N<<1];
vector<int>ceng[N];
int n,m;
int ful_max;
int dp[N],lon[N];
int len,las[N],dep[N];
int nest[N],nser[N];
int fa[N][18],sum[N][18];
bool kil[N];
inline void add(int u,int v,int w){
	len++;
	t[len].v=v,t[len].w=w;
	t[len].nex=las[u],las[u]=len;
}
inline void bz(){
	for(int i=1;i<=17;++i){
		for(int j=1;j<=n;++j){
			fa[j][i]=fa[fa[j][i-1]][i-1];
			sum[j][i]=sum[fa[j][i-1]][i-1]+sum[j][i-1];
		}
	}
}
inline void build(int rt){
	sum[rt][0]=0;
	memset(dep,0,sizeof(dep));
	queue<int>s;
	s.push(rt);
	dep[rt]=1;
	while(!s.empty()){
		int x=s.front();
		s.pop();
		for(int i=las[x];i;i=t[i].nex){
			int v=t[i].v;
			if(!dep[v]){
				dep[v]=dep[x]+1;
				ful_max=dep[v]; 
				fa[v][0]=x;
				sum[v][0]=t[i].w;
				s.push(v);
			}
		}
	}
}
inline int lcasum(int x,int y){
	if(dep[x]>dep[y]){
		x^=y^=x^=y;
	}
	int ans=0;
	int cha=dep[y]-dep[x];
	for(int i=17;i>=0;--i){
		if(cha>=(1<<i)){
			cha-=(1<<i);
			ans+=sum[y][i];
			y=fa[y][i];
		}
	}
	if(x==y){
		return ans;
	}
	for(int i=17;i>=0;--i){
		if(fa[x][i]!=fa[y][i]){
			ans+=sum[x][i],ans+=sum[y][i];
			x=fa[x][i],y=fa[y][i];
		}
	}
	ans+=sum[x][0],ans+=sum[y][0];
	return ans;
}
inline bool pan(int ep){//���,���Ȳ�С��x���������Ƿ�С��m 
	memset(dp,0,sizeof(dp));
	int now=ful_max-1,tot=0;
	int gg=0;
	while(now){
		int ten=ceng[now].size();
		for(int i=0;i<ten;++i){
			int x=ceng[now][i];
			gg=0;
			for(int j=las[x];j;j=t[j].nex){
				int v=t[j].v;
				if(dep[v]<dep[x]){
					continue;
				}
				lon[++gg]=dp[v]+t[j].w;
			}
			sort(lon+1,lon+gg+1);
			int r=gg;
			for(int j=1;j<=gg;++j){
				if(lon[j]>=ep){
					tot+=gg-j+1;
					r=j-1;
					break;
				}
			}
			for(int j=1;j<=r;++j){
				if(kil[j]){
					continue;
				}
				int L=j+1,R=r,ant=0;
				while(L<=R){
					int mid=(L+R)>>1;
					if(lon[mid]+lon[j]>=ep){
						R=mid-1;
						ant=mid;
						continue;
					}
					L=mid+1;
				}
				if(!ant){
					continue;
				}
				for(int k=ant;k<=r;++k){
					if(!kil[k]){
						kil[j]=1;
						kil[k]=1;
						tot++;
						break;
					}
				}
			}
			for(int j=r;j>=1;--j){
				if(kil[j]){
					continue;
				}
				dp[x]=lon[j];
				break;
			}
			for(int j=1;j<=r;++j){
				kil[j]=0;
			}
		}
		now--;
	}
	return tot>=m;
}
inline bool pan1(int x){
	int tot=0,sut=0;
	for(int i=1;i<=n;++i){
		sut+=nest[i];
		if(sut>=x){
			tot++;
			sut=0;
			continue;
		}
	}
	return tot>=m;
}
inline bool pan2(int x){
	int tot=0,r=n;
	for(int i=2;i<=n;++i){
		if(nser[i]>=x){
			tot=n-i+1;
			r=i-1;
			break;
		}
	}
	for(int i=2;i<=r;++i){
		if(r==i){
			break;
		}
		if(nser[i]+nser[r]>=x){
			tot++;
			r--;
		}
	}
	return tot>=m;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int sut=0;
	scanf("%d%d",&n,&m);
	bool flag1=1,flag2=1;
	for(int i=1;i<n;++i){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		if(u>v){
			u^=v^=u^=v;
		}
		if(flag1){
			nser[v]=w;
		}
		if(flag2){
			nest[u]=w;
		}
		if(u!=1){
			flag1=0;
		}
		if(v-u>1){
			flag2=0;
		}
		sut+=w;
		add(u,v,w),add(v,u,w);
	}
	build(1);
	if(m==1){
		bz();
		int maxe=0,root;
		for(int i=2;i<=n;++i){
			int now=lcasum(1,i);
			if(now>maxe){
				maxe=now;
				root=i;
			}
		}
		build(root);
		bz();
		int ans=0;
		for(int i=1;i<=n;++i){
			ans=max(ans,lcasum(root,i));
		}
		printf("%d",ans);
		return 0;
	}
	sut/=m;
	if(flag1){//˫���� 
		sort(nser+1,nser+n+1);
		int l=1,r=sut,ans=1;
		while(l<=r){
			int mid=(l+r)>>1;
			if(pan2(mid)){
				l=mid+1;
				ans=mid;
				continue;
			}
			r=mid-1;
		}
		printf("%d",ans);
		return 0;
	}
	if(flag2){//�� 
		int l=1,r=sut,ans=1;
		while(l<=r){
			int mid=(l+r)>>1;
			if(pan1(mid)){
				l=mid+1;
				ans=mid;
				continue;
			}
			r=mid-1;
		}
		printf("%d",ans);
		return 0;
	}
	for(int i=1;i<=n;++i){
		ceng[dep[i]].push_back(i);
	}
	int l=1,r=sut,ans=1;
	while(l<=r){
		int mid=(l+r)>>1;
		if(pan(mid)){
			l=mid+1;
			ans=mid;
			continue;
		}
		r=mid-1;
	}
	printf("%d",ans);
	return 0;
}

