#include <algorithm>
#include <cstdio>
using namespace std;

typedef pair <int, int> pr;
const int maxn = 1e5 + 10;
int n, ans, a[maxn];
struct sgt {
	#define lson k << 1, s, mid
	#define rson k << 1 | 1, mid + 1, t
	static const int maxk = maxn << 2;
	int val[maxk], pos[maxk], lazy[maxk];
	inline void maintain(int k) {
		if (val[k << 1] < val[k << 1 | 1]) {
			val[k] = val[k << 1], pos[k] = pos[k << 1];
		} else {
			val[k] = val[k << 1 | 1], pos[k] = pos[k << 1 | 1];
		}
	}
	inline void pushlazy(int k, int x) {
		val[k] += x, lazy[k] += x;
	}
	inline void pushdown(int k) {
		if (lazy[k]) {
			pushlazy(k << 1, lazy[k]);
			pushlazy(k << 1 | 1, lazy[k]);
			lazy[k] = 0;
		}
	}
	void build(int k, int s, int t) {
		if (s == t) {
			val[k] = a[s], pos[k] = s;
			return;
		}
		int mid = s + t >> 1;
		build(lson);
		build(rson);
		maintain(k);
	}
	void upd(int k, int s, int t, int l, int r, int x) {
		if (s == l && t == r) {
			pushlazy(k, x); return;
		}
		pushdown(k);
		int mid = s + t >> 1;
		if (r <= mid) {
			upd(lson, l, r, x);
		} else if (l > mid) {
			upd(rson, l, r, x);
		} else {
			upd(lson, l, mid, x), upd(rson, mid + 1, r, x);
		}
		maintain(k);
	}
	pr query(int k, int s, int t, int l, int r) {
		if (s == l && r == t) {
			return pr(val[k], pos[k]);
		}
		pushdown(k);
		int mid = s + t >> 1;
		if (r <= mid) {
			return query(lson, l, r);
		} else if (l > mid) {
			return query(rson, l, r);
		} else {
			return min(query(lson, l, mid), query(rson, mid + 1, r));
		}
	}
	#undef lson
	#undef rson
} tree;

void dfs(int l, int r) {
	if (l > r || l < 1 || r > n) return;
	pr p = tree.query(1, 1, n, l, r);
	tree.upd(1, 1, n, l, r, -p.first), ans += p.first, dfs(l, p.second - 1), dfs(p.second + 1, r);
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", a + i);
	}
	tree.build(1, 1, n);
	dfs(1, n), printf("%d", ans);
	fclose(stdin), fclose(stdout);
	return 0;
}
