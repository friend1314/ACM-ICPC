#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;

#define re register int
const int maxn = 25010, maxm = 110;
int T, n, a[maxm], f[maxn];

int main() {
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		memset(f, 0, sizeof f);
		scanf("%d", &n);
		for (re i = 1; i <= n; i++) {
			scanf("%d", a + i);
		}
		sort(a + 1, a + n + 1);
		const int lim = a[n];
		re ans = 0;
		f[0] = 1;
		for (re i = 1; i <= n; i++) {
			if (!f[a[i]]) {
				ans++;
				for (re j = a[i]; j <= lim; j++) {
					f[j] |= f[j - a[i]];
				}
			}
		}
		printf("%d\n", ans);
	}
	fclose(stdin), fclose(stdout);
	return 0;
}
