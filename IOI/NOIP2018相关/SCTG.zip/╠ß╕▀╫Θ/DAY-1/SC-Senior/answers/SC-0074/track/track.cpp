#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
using namespace std;

#define iter set <int> :: iterator
const int maxn = 5e4 + 10;
int n, m, top, a[maxn], q[maxn], st[maxn], dis[maxn], head[maxn]; bool vis[maxn];
struct edges {
	int nxt, to, w;
} e[maxn << 1];

inline void chkmin(int& x, const int& y) {
	if (x > y) x = y;
}

inline void chkmax(int& x, const int& y) {
	if (x < y) x = y;
}

inline void addline(int u, int v, int w) {
	static int cnt;
	e[++cnt].nxt = head[u], head[u] = cnt, e[cnt].to = v, e[cnt].w = w;
}

inline int bfs(int s) {
	memset(dis, -1, sizeof dis);
	int l = 1, r = 1;
	dis[q[1] = s] = 0;
	while (l <= r) {
		int u = q[l++];
		for (int i = head[u]; i; i = e[i].nxt) {
			int v = e[i].to;
			if (dis[v] == -1) {
				dis[q[++r] = v] = dis[u] + e[i].w;
			}
		}
	}
	int pos = 0;
	for (int i = 1; i <= n; i++) {
		if (dis[pos] < dis[i]) pos = i;
	}
	return pos;
}

inline bool check(int x) {
	int sum = 0, tot = 0;
	for (int i = 1; i <= n; i++) {
		if ((sum += a[i]) >= x) {
			sum = 0, tot++;
		}
	}
	return (tot + (sum >= x)) >= m;
}

inline bool pd(int x) {
	int tot = 0; top = 0;
	for (int i = 1; i < n - 1 << 1; i += 2) {
		if (e[i].w >= x) {
			tot++;
		} else {
			st[++top] = e[i].w;
		}
	}
	memset(vis, 0, sizeof vis);
	sort(st + 1, st + top + 1);
	for (int i = top; i > 1; i--) {
		int lef = 1, rig = i - 1, mid, res;
		while (lef <= rig) {
			mid = lef + rig >> 1;
			if (st[mid] >= x - st[i]) {
				rig = (res = mid) - 1;
			} else {
				lef = mid + 1;
			}
		}
		while (vis[res] && res < i) res++;
		if (!vis[res] && res < i) tot++, vis[res] = 1;
	}
	return tot >= m;
}

inline void subtask1() {
	int s = bfs(1);
	int t = bfs(s);
	printf("%d", dis[t]);
}

inline void subtask2() {
	for (int i = 1; i < n - 1 << 1; i += 2) {
		a[e[i].to - 1] = e[i].w;
	}
	int lef = 0, rig = 0x3f3f3f3f, mid, res;
	while (lef <= rig) {
		check(mid = lef + rig >> 1) ? lef = (res = mid) + 1 : rig = mid - 1;
	}
	printf("%d", res);
}

inline void subtask3() {
	int lef = 0, rig = 0x3f3f3f3f, mid, res;
	while (lef <= rig) {
		pd(mid = lef + rig >> 1) ? lef = (res = mid) + 1 : rig = mid - 1;
	}
	printf("%d", res);
}

inline void subtask4() {
	int val = 0x3f3f3f3f;
	for (int i = 1; i < n - 1 << 1; i += 2) {
		chkmin(val, e[i].w);
	}
	printf("%d", val);
}

int main() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	scanf("%d %d", &n, &m);
	bool flg1 = 1, flg2 = 1;
	for (int i = 1, u, v, w; i < n; i++) {
		scanf("%d %d %d", &u, &v, &w);
		flg1 &= u + 1 == v, flg2 &= u == 1;
		addline(u, v, w), addline(v, u, w);
	}
	if (m == 1) {
		subtask1();
	} else if (flg1) {
		subtask2();
	} else if (flg2) {
		subtask3();
	} else {
		subtask4();
	}
	fclose(stdin), fclose(stdout);
	return 0;
}
