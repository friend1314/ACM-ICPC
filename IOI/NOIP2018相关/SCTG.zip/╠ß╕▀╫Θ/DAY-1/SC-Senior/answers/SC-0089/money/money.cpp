#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>
#include<cstring>

using namespace std;

const int MAXN = 100 + 50;
const int MAXM = 25000 + 10;

inline int read()
{
	int f=1,x=0;
	char ch;
	do
	{
		ch=getchar();
		if(ch=='-') f=-1;
	}while(ch<'0'||ch>'9');
	do
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return f*x;
}

int T;
int n;
int a[MAXN];
bool boo[MAXM];
int b[MAXN],tot=0;

inline bool check(int x,int now)
{
	if(boo[x]) return true;
	for(int i=now+1;i<=tot;i++)
	{
		if(x%b[i]==0)
		{
			boo[x]=1;
			return true;
		} 
	}
	bool bz=false;
	for(int i=now+1;i<=tot;i++)
	{
		for(int j=1;j*b[i]<=x;j++)
		{
			if(bz) return true;
			bz=max(check(x-j*b[i],i),bz);
		}
	}
	return bz;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--)
	{
		memset(boo,0,sizeof(boo));
		memset(b,0,sizeof(b));
		n=read();
		for(int i=1;i<=n;i++) a[i]=read();
		sort(a+1,a+n+1);
		tot=1;b[tot]=a[1];
		boo[a[1]]=1;
		for(int i=2;i<=n;i++)
		{
			if(check(a[i],0)==false)
			{
				tot++;
				b[tot]=a[i];
				boo[a[i]]=1;	
			}
		}

		cout<<tot<<endl;
	}
	return 0;
}
