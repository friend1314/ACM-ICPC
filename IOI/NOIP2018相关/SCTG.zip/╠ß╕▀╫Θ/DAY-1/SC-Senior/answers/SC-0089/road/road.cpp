#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>

using namespace std;

const int MAXN = 100000 + 10;

inline long long read()
{
	long long f=1,x=0;
	char ch;
	do
	{
		ch=getchar();
		if(ch=='-') f=-1;
	}while(ch<'0'||ch>'9');
	do
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return f*x;
}

int n;
long long d[MAXN]; 
long long ans=0,maxi,minn;

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		d[i]=read();
	}	
	maxi=d[1];
	minn=d[1];
	ans+=d[1];
	for(int i=1;i<=n;i++)
	{
		if(d[i]>minn)
		{
			ans+=(d[i]-minn);
		}
		minn=min(ans,d[i]);
	}
	cout<<ans<<endl;
	return 0;
}
