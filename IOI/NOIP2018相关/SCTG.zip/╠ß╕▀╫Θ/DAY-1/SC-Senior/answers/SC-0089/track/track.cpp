#include<iostream>
#include<cstdio>
#include<map>
#include<algorithm>

using namespace std;

const int MAXN = 50000 + 10;

inline int read()
{
	int f=1,x=0;
	char ch;
	do
	{
		ch=getchar();
		if(ch=='-') f=-1;
	}while(ch<'0'||ch>'9');
	do
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return f*x;
}

bool bz1=1,bz2=1,bz3=1;

struct hhd
{
	int id;
	int val;
	friend bool operator < (hhd a1,hhd a2)
	{
		return a1.id<a2.id;
	}
};

int n,m;
int u[MAXN],v[MAXN];
hhd w[MAXN];
long long ans=0;

struct node
{
	int next;
	int to;
	long long val;
}g[MAXN];

int head[MAXN],cnt=0;
long long sum=0;
int fa[MAXN],dep[MAXN];
long long dp[MAXN],cur[MAXN];

inline void addedge(int u,int v,long long w)
{
	++cnt;g[cnt].to=v;g[cnt].next=head[u];g[cnt].val=w;head[u]=cnt;return;
}

inline void dfs(int x,int f)
{
	dp[x]=0;
	for(int i=head[x];i;i=g[i].next)
	{
		int v=g[i].to;
		if(v!=f)
		{
			fa[v]=x;
			dep[v]=dep[x]+g[i].val;
			dfs(v,x);
			dp[x]=max(dp[x],dp[v]+g[i].val);
		}
	}
	return;
}

inline void dp2(int x,int f)
{
	int maxi=0,maxj=0;
	for(int i=head[x];i;i=g[i].next)
	{
		int v=g[i].to;
		if(v!=f)
		{
			dp2(v,x);
			if(maxi<dp[v]+g[i].val)
			{
				maxj=maxi;
				maxi=dp[v]+g[i].val;
			}
			else if(maxj<dp[v])
			{
				maxj=dp[v]+g[i].val;
			}	
		}
	}
	cur[x]=maxi+maxj;
	
}

int bl[MAXN],boo[MAXN];

inline bool check(int x)
{
	int cnt=0,sum=0;
	for(int i=1;i<=n;i++)
	{
		if(sum+w[i].val>=x)
		{
			sum=0;
			cnt++;
		}
		else sum+=w[i].val;
	}
	if(cnt>=m) return true;
	else return false;
}

inline bool dfs2(int x,int f,int val,int num)
{
	bool bz=false;
	if(num==m)
	{
		return true;
	}
	for(int i=head[x];i;i=g[i].next)
	{
		int v=g[i].to;
		if(v!=f&&!boo[v])
		{
			if(bl[num]+g[i].val>=val)
			{
				bl[num]+=g[i].val;
				num++;
				boo[v]=1;
				bz=dfs2(v,x,val,num);
				if(bz) return true;
				num--;
				boo[v]=0;
				bl[num]-=g[i].val;
			}
			else
			{
				bl[num]+=g[i].val;
				boo[v]=1;
				bz=dfs2(v,x,val,num);
				if(bz) return true;
				boo[v]=0;
				bl[num]-=g[i].val;
			}
		}
	}
	return false;
}

inline bool check2(int x)
{
	boo[1]=1;
	if(dfs2(1,0,x,1)) return true;
	else return false;
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;i++)
	{
		 u[i]=read(),v[i]=read(),w[i].val=read();
		 w[i].id=u[i];
		if(v[i]!=u[i]+1) bz2=false;
		if(u[i]!=1) bz1=false;
		addedge(u[i],v[i],w[i].val);
		addedge(v[i],u[i],w[i].val);
		sum+=w[i].val;
	}
	if(bz1==1&&m==1)
	{
		long long maxi=0,
		maxj=0;
		for(int i=1;i<=n;i++)
		{
			if(maxi<w[i].val)
			{
				maxj=maxi;
				maxi=w[i].val;
			}
			else if(maxj<w[i].val)
			{
				maxj=w[i].val;
			}
		}
		cout<<maxi+maxj<<endl;
		return 0;
	}
	dep[0]=0;
	fa[1]=0;
	dfs(1,0);
	if(m==1)
	{
		dp2(1,0);
		for(int i=1;i<=n;i++)
		{
			ans=max(ans,cur[i]);
		}
		cout<<ans<<endl;
		return 0;
	}
	if(bz2==1)
	{
		sort(w+1,w+n);
		long long l=1,r=sum;
		while(l<=r)
		{
			long long mid=(l+r)>>1;
			if(check(mid))
			{
				ans=max(ans,mid);
				l=mid+1;
			}
			else
			{
				r=mid-1;
			}
			
		}
		cout<<ans<<endl;
		return 0;
	}
	else
	{
		long long l=1,r=sum;
		while(l<=r)
		{
			long long mid=(l+r)>>1;
			if(check2(mid))
			{
				ans=max(ans,mid);
				l=mid+1;
			}
			else
			{
				r=mid-1;
			}
			
		}
		cout<<ans<<endl;
	}
	return 0;
}
