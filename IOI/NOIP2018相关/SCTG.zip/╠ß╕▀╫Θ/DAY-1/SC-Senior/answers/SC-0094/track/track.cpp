#include<iostream>
#include<fstream>
#include<math>
using namespace std;

ifstream("track.in");
ofstream("track.out");
int main()
{
	fout<<random()
	return 0;
}
