#include<iostream>
#include<fstream>
#include<algorithm>
using namespace std;

ifstream fin("money.in");
ofstream fout("money.out");

int T,n,a[101],m,b[101];
bool cut=false;

void read()
{
	fin>>n;
	for(int i=1;i<=n;i++)
	{
		a[i]=0;
		b[i]=0;
	}
	m=n;
	for(int k=1;k<=n;k++)
		fin>>a[k];
}

void find()
{
	sort(a+1,a+n+1);
	for(int i=1;i<n;i++)
		for(int k=i;k<=n;k++)
		{
			if(a[k]%a[i]==0)
			{
				b[k]=1;
				cut=true;
			}
		}
	if(cut==true)
		for(int i=1;i<=m;i++)
			if(b[i]==1)
				n--;
}

int main()
{
	fin>>T;
	for(int i=1;i<=T;i++)
	{
		read();
		fout<<n<<endl;
	}
	return 0;
}
