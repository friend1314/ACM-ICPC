#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("road.in");
ofstream fout("road.out");

int len,pit[100001],day=0;

void read()
{
	fin>>len;
	for(int i=1;i<=len;i++)
		fin>>pit[i];
}

void fill(int a,int b)
{
	for(int i=a;i<=b;i++)
		pit[i]--;
	day++;
}

void search()
{
	int start, end;
	bool fillable=true;
	for(int i=1;i<=len;i++)
	{
		start=0;
		if(pit[i]>0)
		{
			start=i;
			break;
		}
		if(start==0&&i==len) return;
	}
	for(int i=start+1;i<=len+1;i++)
	{
		end=0;
		if(i==7) end=len;
		else if(pit[i]==0)
		{
			end=i-1;
			break;
		}
		if(end==0&&i==len) end=i;
	}
	while(fillable==true)
	{
		fill(start,end);
		for(int i=start;i<=end;i++)
		{
			if(pit[i]<=0)
			{
				fillable=false;
				break;
			}
		}
	}
	

	search();
	return;
}
int main()
{
	read();
	search();
	fout<<day;
	return 0;
}
