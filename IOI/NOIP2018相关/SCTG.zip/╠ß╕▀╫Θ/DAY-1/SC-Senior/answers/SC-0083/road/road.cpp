#include<bits/stdc++.h>
#define ll long long
#define ma 100050
#define mo
#define mid (l+r<<1)
using namespace std;
inline ll R()
{
	char c=getchar();ll an=0,kk=1;
	while(c<'0'||c>'9'){if(c=='-')kk=-1;c=getchar();}
	while(c>='0'&&c<='9')an=an*10+c-'0',c=getchar();
	return an*kk;
}
struct node{ll z,bh;}a[ma];bool p[ma];
bool cmp(node x,node y){return x.z<y.z;}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ll n=R(),cnt=1,dep=0,an=0;p[0]=p[n+1]=1;
	for(int i=1;i<=n;i++)a[i].z=R(),a[i].bh=i;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++)
	{
		an+=(a[i].z-dep)*cnt;dep=a[i].z;p[a[i].bh]=1;cnt--;
		if(!p[a[i].bh-1])cnt++;if(!p[a[i].bh+1])cnt++;
	}
	cout<<an;return 0;
}

