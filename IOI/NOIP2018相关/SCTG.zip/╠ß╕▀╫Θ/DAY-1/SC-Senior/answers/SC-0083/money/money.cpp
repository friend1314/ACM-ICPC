#include<bits/stdc++.h>
#define ll long long
#define ma 30050
#define mo
#define mid (l+r<<1)
using namespace std;
inline ll R()
{
	char c=getchar();ll an=0,kk=1;
	while(c<'0'||c>'9'){if(c=='-')kk=-1;c=getchar();}
	while(c>='0'&&c<='9')an=an*10+c-'0',c=getchar();
	return an*kk;
}
int a[ma],p[ma];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int k=R();while(k--)
	{
		int n=R(),an=1;for(int i=1;i<=n;i++)a[i]=R();
		sort(a+1,a+n+1);for(int i=1;i<a[1];i++)p[i]=99999;
		for(int k=2;k<=n;k++)if(a[k]<p[a[k]%a[1]])
		{
			an++;
			for(int i=0;i<a[1];i++)for(int j=1;j<=a[n]/a[k];j++)
				if(p[(i+a[k]*j)%a[1]]>p[i]+a[k]*j)p[(i+a[k]*j)%a[1]]=p[i]+a[k]*j;
										  	 else break;
		}
		cout<<an<<endl;
	}
	return 0;
}

