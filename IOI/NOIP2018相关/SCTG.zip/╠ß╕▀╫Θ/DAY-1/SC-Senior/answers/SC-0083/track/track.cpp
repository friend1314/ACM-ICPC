#include<bits/stdc++.h>
#define ll long long
#define ma 100050
#define mo
#define mid (l+r>>1)
using namespace std;
inline ll R()
{
	char c=getchar();ll an=0,kk=1;
	while(c<'0'||c>'9'){if(c=='-')kk=-1;c=getchar();}
	while(c>='0'&&c<='9')an=an*10+c-'0',c=getchar();
	return an*kk;
}
struct bian{ll to,nxt,z,p;}v[ma];
ll hd[ma],k=1,a[ma],an,d[ma],q[ma],p3;
void add(int x,int y,int z)
{
	v[k].to=y;v[k].z=z;v[k].nxt=hd[x];hd[x]=k++;
	v[k].to=x;v[k].z=z;v[k].nxt=hd[y];hd[y]=k++;
}
void dfs1(int x,int fa)
{
	ll mx=0;
	for(int i=hd[x];i;i=v[i].nxt)if(v[i].to!=fa)
	{
		ll y=v[i].to,z=v[i].z;dfs1(y,x);z+=d[y];
		if(z<=d[x]&&z>mx)mx=z;if(z>d[x])mx=d[x],d[x]=z;
	}an=max(an,d[x]+mx);
}
void dfs2()
{
//	for(int i=1;i<=n;i++)if(q[i]==1)dfs3(i,0);
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	ll n=R(),m=R(),p1=1,p2=1,cnt=0,l=1,r=0;
	for(int i=1;i<n;i++)
	{
		int x=R(),y=R(),z=R();add(x,y,z);
		if(x>1)p1=0;if(x!=y-1)p2=0;q[x]++,q[y]++;
	}
	if(p1)
	{
		for(int i=hd[1];i;i=v[i].nxt)a[++cnt]=v[i].z;
		sort(a+1,a+n);ll k=n-1;cnt=m;an=999999;
		for(;k>2*n-2-2*m;k--)cnt--,an=min(an,a[k]);
		for(int i=k;i>k-cnt;i--)an=min(an,a[i]+a[k-cnt*2+k-i+1]);
		cout<<an;
	}else if(p2)
	{
		ll t=1,sum;
		for(int i=1;i<n;i++)for(int j=hd[t];j;j=v[j].nxt)
			if(v[j].to>t)a[++cnt]=v[j].z,r+=a[cnt],t=v[j].to;
		while(l<r)
		{
			t=0;sum=0;for(int i=1;i<n;i++)
				{sum+=a[i];if(sum>=mid)t++,sum=0;}
			if(t<m)r=mid;else l=mid+1;
		}cout<<l-1;
	}else if(m==1){dfs1(1,0);cout<<an;}else
	{
//		for(int i=1;i<n*2-1;i++)r+=v[i].z;r/=2;
//		p3=0;while(l<r)
//		{
//			dfs2();if()r=mid;else l=mid+1;
//		}cout<<l-1;
	cout<<"while(1)rp++";
	}
	return 0;
}

