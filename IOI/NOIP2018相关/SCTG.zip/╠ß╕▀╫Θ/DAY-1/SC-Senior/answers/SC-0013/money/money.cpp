#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<iostream>
using namespace std;
const int maxn=105;
int init()
{
	char c=getchar();int t=0,type=1;
	while(c>'9'||c<'0')	type=(c=='-')?-1:1,c=getchar();
	while(c>='0'&&c<='9')	t=10*t+c-'0',c=getchar();
	return t*type;
}
int T,n,a[maxn];
int dfs(int x,int pos)
{
	if(pos==0)	return 0;
	for(int i=0;a[pos]*i<=x;i++)
	{
		if(x-a[pos]*i==0)	return 1;
		if(dfs(x-a[pos]*i,pos-1))	return 1;
	}
	return 0;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=init();
	while(T--)
	{
		n=init();int ans=n;
		for(int i=1;i<=n;i++)	a[i]=init();
		sort(a+1,a+n+1);
		for(int i=n;i>=1;i--)	if(dfs(a[i],i-1)) ans--;
		cout<<ans<<endl;
	}
}
