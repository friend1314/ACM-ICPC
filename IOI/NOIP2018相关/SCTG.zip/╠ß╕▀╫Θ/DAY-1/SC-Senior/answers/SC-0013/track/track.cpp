#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<iostream>
using namespace std;
const int maxn=1e5+5;
int init()
{
	char c=getchar();int t=0,type=1;
	while(c>'9'||c<'0')	type=(c=='-')?-1:1,c=getchar();
	while(c>='0'&&c<='9')	t=10*t+c-'0',c=getchar();
	return t*type;
}
struct edge
{
	int next,to,val;
}e[maxn];
int last[maxn],n,m,cnt=1,du[maxn],st[maxn],tot,tag[maxn],vis[maxn],lev[maxn];
int ano[maxn];
void add(int u,int v,int val)
{
	e[++cnt].to=v;
	e[cnt].next=last[u];
	last[u]=cnt;
	e[cnt].val=val;
}

int dfs(int x,int f,int k,int num,int all)
{
//	if(k==0)	return 1;
	for(int i=last[x];i;i=e[i].next)
	{
		int he=e[i].to;if(he==f)	continue;
		if(tag[i])	continue;
		tag[i]=1,tag[i^1]=1;
		if(all+e[i].val>=num)
		{
			if(k==1)	return 1;
			for(int j=1;j<=n;j++)	if(dfs(st[j],0,k-1,num,0))	return 1;
			tag[i]=0,tag[i^1]=0;
		}
		else	
		{
			if(dfs(he,x,k,num,all+e[i].val))	return 1;
			tag[i]=0,tag[i^1]=0;
		}
	}
	return 0;
}
int check(int num,int k)
{
	int can=0;
	for(int i=1;i<=n;i++)	if(dfs(i,0,k,num,0))	can=1;
	return can;
}//k��ʣ���·����num�Ƕ��ֵĴ�
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=init(),m=init();
	for(int i=1;i<=n-1;i++)
	{
		int x=init(),y=init(),v=init();
		add(x,y,v);add(y,x,v);du[x]++,du[y]++;
		ano[i]=v;
	}
	for(int i=1;i<=n;i++)	if(du[i]==1)	st[++tot]=i,lev[i]=1;
	if(tot==n-1&&lev[1]==0&&m==1&&n>=20)
	{
        sort(ano+1,ano+n);
        cout<<ano[n-1]+ano[n-2]<<endl;
		return 0;
	}
//	for(int i=1;i<=tot;i++)	printf("%d ",st[i]);puts("");
	int l=1,r=5e8+5;
	while(l<r)
	{
		for(int i=1;i<=cnt;i++)	tag[i]=0;
	//	printf("%d %d\n",l,r);
		if(r==l+1)	
		{
			if(check(r,m)){l=r;break;}
			else break;
		}
		int mid=(l+r)>>1;
		if(check(mid,m))	l=mid;
		else r=mid-1;
	}
	cout<<l<<endl;
}
/*
6 3
1 2 1000
1 3 100
1 4 81
1 5 20
1 6 1
*/
