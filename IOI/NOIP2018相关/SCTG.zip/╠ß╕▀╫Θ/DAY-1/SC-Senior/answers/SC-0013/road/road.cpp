#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<iostream>
using namespace std;
int init()
{
	char c=getchar();int t=0,type=1;
	while(c>'9'||c<'0')	type=(c=='-')?-1:1,c=getchar();
	while(c>='0'&&c<='9')	t=10*t+c-'0',c=getchar();
	return t*type;
}
const int maxn=1e6+5;
long long ans=0;
int n,a[maxn];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=init();
	for(int i=1;i<=n;i++)	a[i]=init();
	for(int i=1;i<=n;i++)	if(a[i]>a[i-1])	ans=ans+1ll*(a[i]-a[i-1]);
	cout<<ans<<endl;
	return 0;
}
