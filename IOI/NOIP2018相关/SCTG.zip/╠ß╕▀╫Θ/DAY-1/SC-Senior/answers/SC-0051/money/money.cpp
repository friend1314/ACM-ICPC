#include <iostream>
#include <cstdio>
using namespace std;
int n,a[102],h[102],ans;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&n);
		for(int j=1;j<=n;j++)
		scanf("%d",&a[j]);
		ans=n;
		for(int j=1;j<n;j++)
		for(int k=j+1;k<=n;k++)
		if(a[j]%a[k]==0||a[k]%a[j]==0)
		{
			if(h[j]==0||h[k]==0)ans--;
			h[k]=h[j]=1;
		}
		printf("%d\n",ans);
	}
    return 0;
}

