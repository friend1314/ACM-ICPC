#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int cnt,n,d[100010],g[100010],l,sum,ans,t=1,kl,u[100010];
struct node
{
	int num;
	int s;
	int ct;
	int cg[500];
	int siz;
}f[100010];
bool cmp(node x,node y)
{
	return x.s<y.s;
}
int main()
{
	freopen("road.in","r",stdin);
  	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&d[i]);
		if(g[d[i]]==0)
		f[++l].s=d[i],g[d[i]]=l;
		f[g[d[i]]].num++;
	}
	for(int i=1;i<=n;i++)
	{
		if(d[i]<d[i-1]&&d[i]<d[i+1])
		f[g[d[i]]].ct++,kl++;
		u[kl]++,f[g[d[i]]].cg[++f[g[d[i]]].siz]=kl;
	}
	sort(f+1,f+l+1,cmp);
	for(int i=1;i<=l;i++)
	{
		if(f[i].s-cnt==0) continue;
		ans+=(f[i].s-cnt)*t;
	//	cout<<f[i].s<<' '<<f[i].ct<<' '<<t<<" "<<ans<<endl;
		cnt=f[i].s;
		t+=f[i].ct;
		for(int j=1;j<=f[g[d[i]]].siz;j++)
		{
			u[f[g[d[i]]].cg[j]]--;
			if(u[f[g[d[i]]].cg[j]]==0)
			t--;
		//	cout<<f[g[d[i]]].cg[j]<<' '<<u[f[g[d[i]]].cg[j]]<<endl;
		}
	}
	printf("%d",ans);
    return 0;
}

