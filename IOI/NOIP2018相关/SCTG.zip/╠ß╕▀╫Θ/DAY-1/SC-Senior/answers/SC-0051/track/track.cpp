#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <cmath>
#include <queue>
#define N 50000
using namespace std;
int l,head[N],n,m;
int cans[N];
struct node
{
	int v;
	int w;
	int nex;
}e[N];
void adde(int v,int u,int w)
{
	e[++l].v=v;
	e[l].w=w;
	e[l].nex=head[u];
	head[u]=l;
}
int dij(int x)
{
	int dis[50001]={0},vis[50001]={0};
	typedef pair<int ,int >pil;
	priority_queue <pil ,vector <pil>,less <pil > > q;
	dis[x]=0;
	q.push(make_pair(dis[x],x));
	while(!q.empty())
	{
		int u=q.top().second;
		q.pop();
		if(vis[u]) continue;
		vis[u]=1;
//		cout<<'*'<<u<<' '<<dis[u]<<endl;
		for(int i=head[u];i!=-1;i=e[i].nex)
		{
			int v=e[i].v;
			if(dis[v]<dis[u]+e[i].w&&!vis[v])
			{
				dis[v]=dis[u]+e[i].w;
				q.push(make_pair(dis[v],v));
			}
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++)
	if(vis[i])
	ans=max(ans,dis[i]);
	return ans;
}
int main()
{
	freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d%d",&n,&m);
	int a,b,c;
	for(int i=1;i<=n-1;i++)
	scanf("%d%d%d",&a,&b,&c),adde(a,b,c),adde(b,a,c);
	for(int i=1;i<=n;i++)
	cans[i]=dij(i);
	sort(cans+1,cans+n+1);
	printf("%d",cans[n-m+1]);
    return 0;
}
