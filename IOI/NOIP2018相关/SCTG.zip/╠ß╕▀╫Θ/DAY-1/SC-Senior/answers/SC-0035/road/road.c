#include<stdio.h>
#include<string.h>
#include<math.h>
int b[100086];
int main(){
	FILE *fin,*fout;
	fin=fopen("road.in","r");
	fout=fopen("road.out","w");
	int i,j,n;
	long long ans=0;
	fscanf(fin,"%d",&n);
	b[0]=0;
	for(i=1;i<=n;i++){
		fscanf(fin,"%d",&b[i]);
	}
    for(i=1;i<=n;i++){
    	if(b[i]>b[i-1])ans+=b[i]-b[i-1];
    }
	fprintf(fout,"%d",ans);
	fclose(fin);
	fclose(fout);
	return 0;
}
