#include<stdio.h>
#include<string.h>
#include<math.h>
int a[101],z[101];
int main(){
	int i,j,k,t,n,p[101],ans[21],t1;
	FILE *fin,*fout;
	fin=fopen("money.in","r");
	fout=fopen("money.out","w");
	fscanf(fin,"%d",&t);
	for(i=1;i<=t;i++){
		fscanf(fin,"%d",&n);
		ans[i]=n;
		for(j=1;j<=n;j++){
			fscanf(fin,"%d",&a[j]);
		}
//		for(k=1;k<=n;k++){
//			for(j=k+1;j<=n;j++){
//				if(a[k]>a[j]){
//					t1=a[k];
//					a[k]=a[j];
//					a[j]=t1;
//				}
//			}
//		}
//		t=0;
//		for(i=1;i<=n;i++){
//			if(fen(a[i],t1)){
//				ans[i]--;
//			}
//			else {
//				t1++;
//				z[t]=a[i];
//			}
//		}
		ans[i]=n;
	}
	for(i=1;i<=t;i++)fprintf(fout,"%d",ans[i]);
	fclose(fin);
	fclose(fout);
	return 0;
}
