#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int i,j,n,m,n1,n2,d[501][501],k=0,ans;
	FILE *fin,*fout;
	fin=fopen("track.in","r");
	fout=fopen("track.out","w");
		fscanf(fin,"%d%d",&n,&m);
	for(i=1;i<=n;i++){
		fscanf(fin,"%d%d",&n1,&n2);
		fscanf(fin,"%d",&d[n1][n2]);
		if(d[n1][n2]>k){
		k=d[n1][n2];
		ans+=k;
	    }
	}
	fprintf(fout,"%d",ans);
	fclose(fin);
	fclose(fout);
	return 0;
}
