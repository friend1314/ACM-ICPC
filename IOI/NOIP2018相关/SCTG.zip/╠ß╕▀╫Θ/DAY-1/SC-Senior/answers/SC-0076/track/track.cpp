#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cctype>
#include <set>
using namespace std;
typedef long long ll;

inline int read()
{
	int x=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=x*10+c-'0';c=getchar();}
	return x*f;
}

const int maxn = 5e4 + 10;
struct edge
{
	int nxt, to, w;
	edge() {}
	edge(int nxt, int to, int w): nxt(nxt), to(to), w(w) {}
} e[maxn << 1];
int n, m, last[maxn], cnt = 1, fa[maxn], deg[maxn], dep[maxn];
inline void insert(int u, int v, int w) {e[++ cnt] = edge(last[u], v, w); last[u] = cnt;}
inline void addedge(int u, int v, int w) {insert(u, v, w); insert(v, u, w); ++ deg[u]; ++ deg[v];}
inline void dfs(int x)
{
	dep[x] = dep[fa[x]] + 1;
	for(int i = last[x]; i; i = e[i].nxt)
	{
		int v = e[i].to;
		if(v == fa[x]) continue;
		fa[v] = x; dfs(v);
	}
}

ll depth[maxn], mx[maxn], cmx[maxn];
inline void dfs2(int x)
{
	mx[x] = depth[x]; cmx[x] = 0;
	for(int i = last[x]; i; i = e[i].nxt)
	{
		int v = e[i].to;
		if(v == fa[x]) continue;
		depth[v] = depth[x] + e[i].w; dfs2(v);
		if(mx[v] >= mx[x])
		{
			cmx[x] = mx[x];
			mx[x] = mx[v];
		}
		else if(mx[v] > cmx[x])
			cmx[x] = mx[v];
	}
}

inline ll findmx()
{
	dfs2(1); ll ans = 0;
	for(int i = 1; i <= n; i ++)
		ans = max(ans, mx[i] + cmx[i] - depth[i] * 2LL);
	return ans;
}

int buc[maxn], tot;
multiset<int> s;
typedef multiset<int>::iterator iter;
inline bool juhua_check(int now)
{
	s.clear(); int res = 0;
	for(int i = 1; i <= tot; i ++)
		s.insert(buc[i]);
	while(s.size())
	{
		iter it = s.end(); -- it;
		int cur = *it;
		s.erase(it);
		if(cur >= now)
		{
			++ res;
			continue;
		}
		int ano = now - cur;
		iter it2 = s.lower_bound(ano);
		if(it2 == s.end()) break;
		s.erase(it2);
		++ res;
		if(res >= m) return 1;
	}
	return res >= m;
}

inline void juhua()
{
	tot = 0; int L = 0, R = 0, res = 0;
	for(int i = last[1]; i; i = e[i].nxt)
		buc[++ tot] = e[i].w;
	sort(buc + 1, buc + 1 + tot);
	if(tot == 1) {printf("%d\n", buc[1]); return;}
	R = buc[tot] + buc[tot - 1];
	while(L <= R)
	{
		int MID = (L + R) >> 1;
		if(juhua_check(MID))
			res = MID, L = MID + 1;
		else R = MID - 1;
	}
	printf("%d\n", res);
}

inline bool chain_check(ll now)
{
	int res = 0;
	for(int i = 1, j; i <= tot; i = j + 1)
	{
		j = i; ll cur = buc[i];
		while(j <= tot)
		{
			if(cur >= now || j == tot)
				break;
			cur += buc[++ j];
		}
		if(cur >= now)
			++ res;
	}
	return res >= m;
}

inline void chain()
{
	tot = 0;
	for(int i = 1; i < n; i ++)
	{
		for(int j = last[i]; j; j = e[j].nxt)
		{
			if(e[j].to > i)
				buc[++ tot] = e[j].w;
		}
	}
	ll L = 0, R = 0, res = 0;
	for(int i = 1; i <= tot; i ++)
		R += buc[i];
	R /= m;
	while(L <= R)
	{
		ll MID = (L + R) >> 1;
		if(chain_check(MID))
			res = MID, L = MID + 1;
		else R = MID - 1;
	}
	printf("%lld\n", res);
}

ll f[1005][1005];
int sz[1005];

inline void Dp(int x, ll nMid)
{
	sz[x] = 0; f[x][0] = 0;
	for(int i = last[x]; i; i = e[i].nxt)
	{
		int v = e[i].to; if(v == fa[x]) continue;
		Dp(v, nMid); int w = e[i].w;
		int up1 = min(m, sz[x]);
		int up2 = min(m, sz[v]);
		for(int i = up1; i >= 0; i --) if(~f[x][i])
		{
			for(int j = up2; j >= 0; j --) if(~f[v][j])
			{
				ll now = f[v][j] + w;
				int nxt = min(i + j + 1, m);
				if(now >= nMid)
					f[x][nxt] = max(f[x][nxt], f[x][i]);
				else if((now + f[x][i]) >= nMid)
					f[x][nxt] = max(f[x][nxt], 0LL);
				nxt = min(i + j, m);
				f[x][nxt] = max(f[x][nxt], max(f[x][i], now));
			}
		}
//		if(x == 1)
//		{
//			cerr << "v: " << v << endl;
//			for(int j = 0; j <= m; j ++)
//				cerr << f[x][j] << " ";
//			cerr << endl;
//		}
		sz[x] += sz[v] + 1;
	}
}

int son[5], up[5], we[5];
inline bool check(ll MID)
{
	memset(f, -1, sizeof f); Dp(1, MID);
	return f[1][m] >= 0;
}

int main()
{
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	n = read(), m = read();
	for(int i = 1; i < n; i ++)
	{
		int u = read(), v = read(), w = read();
		addedge(u, v, w);
	}
	dfs(1);
	if(m == 1) {printf("%lld\n", findmx()); return 0;}
	if(deg[1] == n - 1) {juhua(); return 0;}
	bool ischain = 1;
	for(int i = 2; i <= n; i ++)
		if(fa[i] != i - 1) {ischain = 0; break;}
	if(ischain) {chain(); return 0;}
	ll L = 0, R = 0, ans = 0;
	for(int x = 1; x <= n; x ++)
		for(int i = last[x]; i; i = e[i].nxt)
		{
			int v = e[i].to;
			if(v == fa[x]) continue;
			R += e[i].w;
		}
	R /= m;
	while(L <= R)
	{
		ll MID = (L + R) >> 1;
		if(check(MID))
			ans = MID, L = MID + 1;
		else R = MID - 1;
	}
	printf("%lld\n", ans);
	return 0;
}
