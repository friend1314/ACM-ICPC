#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cctype>
using namespace std;
typedef long long ll;
inline int read()
{
	int x=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=x*10+c-'0';c=getchar();}
	return x*f;
}

const int maxn = 1e5 + 10;

struct node
{
	int l, r, w;
	node() {}
	node(int l, int r, int w): l(l), r(r), w(w) {}
} b[maxn];
int n, a[maxn], tot = 0, mn[maxn << 2]; ll ans = 0;
#define ls (x << 1)
#define rs (x << 1 | 1)
inline void update(int x) {if(a[mn[ls]] > a[mn[rs]]) mn[x] = mn[rs]; else mn[x] = mn[ls];}
inline void build(int x, int l, int r)
{
	if(l == r) {mn[x] = l; return;}
	int mid = (l + r) >> 1;
	build(ls, l, mid);
	build(rs, mid + 1, r);
	update(x);
}
inline int query(int x, int l, int r, int lx, int rx)
{
	if(l > r || lx > rx) return 0;
	if(l >= lx && r <= rx) return mn[x];
	int mid = (l + r) >> 1, res = 0;
	if(lx <= mid) res = query(ls, l, mid, lx, rx);
	if(rx > mid)
	{
		int tmp = query(rs, mid + 1, r, lx, rx);
		if(!res || a[res] > a[tmp])
			res = tmp;
	}
	return res;
}
int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	n = read();
	for(int i = 1; i <= n; i ++)
		a[i] = read();
	build(1, 1, n);
	b[++ tot] = node(1, n, 0);
	while(tot)
	{
		node now = b[tot --];
		if(now.l > now.r) continue;
		int pos = query(1, 1, n, now.l, now.r);
		if(a[pos] == now.w)
		{
			b[++ tot] = node(now.l, pos - 1, now.w);
			b[++ tot] = node(pos + 1, now.r, now.w);
			continue;
		}
		ans += a[pos] - now.w;
		b[++ tot] = node(now.l, pos - 1, a[pos]);
		b[++ tot] = node(pos + 1, now.r, a[pos]);
	}
	printf("%lld\n", ans);
	return 0;
}
