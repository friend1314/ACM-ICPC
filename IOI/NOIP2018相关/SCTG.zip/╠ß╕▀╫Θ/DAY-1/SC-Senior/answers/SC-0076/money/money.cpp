#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cctype>
using namespace std;
typedef long long ll;

inline int read()
{
	int x=0,f=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=x*10+c-'0';c=getchar();}
	return x*f;
}

const int maxn = 105;
const int maxm = 25000 + 10;
int n, a[maxn], ans = 0;
bool f[maxm];

int main()
{
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	int T = read();
	while(T --)
	{
		ans = 0;
		memset(f, 0, sizeof f);
		n = read();
		for(int i = 1; i <= n; i ++)
			a[i] = read();
		sort(a + 1, a + 1 + n);
		f[0] = 1;
		for(int i = 1; i <= n; i ++)
		{
			if(!f[a[i]])
			{
				++ ans;
				for(int j = a[i]; j <= 25000; j ++)
					if(!f[j] && f[j - a[i]])
						f[j] = 1;
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
