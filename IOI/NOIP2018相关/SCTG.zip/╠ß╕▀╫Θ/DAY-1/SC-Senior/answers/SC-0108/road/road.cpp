#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=200000;
int read(){
	bool flag=0;int res=0;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
	if(ch=='-'){flag=1,ch=getchar();}
	while(ch>='0'&&ch<='9'){res=res*10+ch-'0';ch=getchar();}  
	return flag?-res:res;
}
int n,a[N];
int min(int a,int b){return a<b?a:b;}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)a[i]=read();
	long long ans=0;int minn=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]==0){minn=0;continue;}
		if(a[i]<=minn)
		{
			minn=min(minn,a[i]);
			continue;
		}
		if(a[i]>minn)
		{
			ans+=a[i]-minn;
			minn=a[i];
		}
	}
	printf("%lld\n",ans);
	return 0;
}
