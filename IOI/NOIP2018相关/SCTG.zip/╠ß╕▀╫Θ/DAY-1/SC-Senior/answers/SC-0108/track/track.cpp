#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=500000+500;
int read()
{
	bool flag=0;int res=0;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
	if(ch=='-'){flag=1,ch=getchar();}
	while(ch>='0'&&ch<='9'){res=res*10+ch-'0';ch=getchar();
	}  return flag?-res:res;
}
int head[N],k=0;
int ans=0;
struct node
{
	int to,next,w;
}edg[N*4];
void build(int x,int y,int w)
{
	edg[++k].to=y;edg[k].w=w;edg[k].next=head[x];head[x]=k;
}
void dfs(int u,int fa,int num)
{
	bool f=0;
	for(int i=head[u];i;i=edg[i].next)
	{
		int v=edg[i].to;
		if(v==fa)continue;
		dfs(v,u,num+edg[i].w);
		f=1;
	}
	if(!f)ans=max(ans,num);
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n=read(),m=read();
	int minn=0x7f7f7f7f;
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read(),w=read();build(x,y,w);build(y,x,w);minn=min(minn,w);
	}
	if(m==n-1)
	{
		printf("%d\n",minn);
		return 0;
	}
	if(m==1)
	{
		for(int i=1;i<=n;i++)
		{
			dfs(i,i,0);
		}
		printf("%d\n",ans);
		return 0;
	}
	
	return 0;
}
