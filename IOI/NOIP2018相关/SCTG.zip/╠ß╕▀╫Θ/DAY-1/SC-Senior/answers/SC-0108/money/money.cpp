#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=150;
int read()
{
	bool flag=0;int res=0;char ch=getchar();
	while((ch<'0'||ch>'9')&&ch!='-')ch=getchar();
	if(ch=='-'){flag=1,ch=getchar();}
	while(ch>='0'&&ch<='9'){res=res*10+ch-'0';ch=getchar();
	}  return flag?-res:res;
}
int t,a[N];bool f=0;
int yz[N];
void dfs(int u,int xz,int hm,int zhi)
{
	if(f)return;
	if(u==hm)
	{
		if(xz==0)f=1;
		return;
	}
	if(yz[u]==0)dfs(u+1,xz,hm,zhi);
	else
	{
		for(int i=0;i<=xz/yz[u];i++)
		{
			int j=xz-i*yz[u];
			dfs(u+1,j,hm,zhi);
		}
	}
	return;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	for(int h=1;h<=t;h++)
	{
		int n=read();
		for(int i=1;i<=n;i++)a[i]=read();
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
		{
			for(int j=i+1;j<=n;j++)
			{
				if(a[j]==0||a[i]==0)continue;
				int x=a[j],y=a[i];
				if(x%y==0)a[j]=0;
			}
		}
		int cnt=0;
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=0){cnt++;yz[cnt]=a[i];}
		}
		sort(yz+1,yz+cnt+1);
		int ans=cnt;
		for(int i=3;i<=cnt;i++)
		{
			f=0;
			dfs(1,yz[i],i,yz[i]);
			if(f)
			{
				yz[i]=0;
				ans--;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
