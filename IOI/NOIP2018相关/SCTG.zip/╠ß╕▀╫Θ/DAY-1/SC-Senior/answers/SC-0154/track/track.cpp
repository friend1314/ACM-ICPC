#include <bits/stdc++.h>
using namespace std;
#define N  60004
int nxt[N],tov[N],head[N],val[N],s,vis[N]={0},dis[N],etot=0,ans=0,n,m,p,a[N],mmp[N];
queue <int> q;
void add(int u,int v,int w)
{
	etot++;
	tov[etot]=v;
	nxt[etot]=head[u];
	val[etot]=w;
	head[u]=etot;
}
void pr()
{
	for(int i=1;i<=p;i++)
	{
		printf("%d ",dis[i]);
	}
}
void spfa()
{
	for(int i=1;i<=p;i++)
	{
		dis[i]=0x3fffffff;
	}
	for(int i=1;i<=p;i++)
	{
		vis[i]=0;
	}
	dis[s]=0;
	vis[s]=1;
	q.push(s);
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		vis[u]=0;
		for(int i=head[u];i;i=nxt[i])
		{
			int v=tov[i];
			if(dis[v]>dis[u]+val[i])
			{
				dis[v]=dis[u]+val[i];
				if(vis[v]==0)
				{
					vis[v]=1;
					q.push(v);
				}
			}
		}
	}
}
void work1()
{
	for(int i=1;i<=n;i++)
	{
		s=i;
		spfa();
		for(int j=1;j<=n;j++)
		{
			ans=max(ans,dis[j]);
		}
	}
}
bool cmp(int a,int b)
{
	return a>b;
}
int main()
{
	int n,m;
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	p=n;
	for(int i=1;i<n;i++)
	{
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		add(u,v,w);
		add(v,u,w);
		a[i]=u;
	}
	if(m==1)
	{
		for(s=1;s<=n;s++)
		{
			spfa();
			for(int i=1;i<=n;i++)
			{
				ans=max(ans,dis[i]);
			}
		}
		printf("%d",ans);
		return 0;
	}
}
