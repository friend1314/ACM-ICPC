#include <bits/stdc++.h>
using namespace std;
int n,d[100000],ans=0,l,r,m,p=0x7f7f7f7f;
bool sol=false,rol=false;
int findmin()
{
	int res=999999999,k;
	for(int i=1;i<=n;i++)
	{
		if(res>d[i]&&d[i]!=0)
		{
			res=d[i];
			k=i;
		}
	}
	return k;
}
int all()
{
		for(int i=1;i<=n;i++)
		{
			if(d[i]!=0)
			{
				return 1;
			}
		}
		return 0;
}
void print()
{
		for(int i=1;i<=n;i++)
		{
			printf("%d ",d[i]);
		}
		cout<<endl;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&d[i]);
	}
	m=findmin();
	for(int i=1;;i++)
	{
		int now,l;
		l=d[m];
		d[m]=0;
	
		for(int j=m+1;j<=n;j++)
		{
			if(d[j]==0)
			{
				break;
			}
			else
			{
				d[j]-=l;
			}
		}
		for(int j=m-1;j>=1;j--)
		{
			if(d[j]==0)
			{
				break;
			}
			else
			{
				d[j]-=l;
			}
		}
		ans+=l;
		now=findmin();
		m=now;
		if(all()==0)
		{
			printf("%d",ans);
			return 0;
		}
		//	print();
	}
	return 0;
}
