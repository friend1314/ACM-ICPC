#include <bits/stdc++.h>
using namespace std;
int n,m,t,a[102][102];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&n);
		for(int j=1;j<=n;j++)
		{
			scanf("%d",&a[i][j]);
		} 
		if(n==2)
		{
			printf("2");
		}
	}
} 
