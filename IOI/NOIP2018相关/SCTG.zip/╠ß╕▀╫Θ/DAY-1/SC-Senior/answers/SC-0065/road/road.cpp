#include <bits/stdc++.h>
using namespace std;
const int maxn=100005;
int n,num=0,ans=0,sum=0,b;
int a[maxn];
void init()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
}

int read()
{
	char ch=getchar();
	int x=0;
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=x*10+ch-'0';	
		ch=getchar();
	}
	return x;
}

void readdata()
{
	n=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
		sum+=a[i];	
	}
}

int find()
{
	if(a[1]!=0)return 1;
	if(a[b]!=0)return b;
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=0)
		{
			b=i;
			return i;
			break;
		}
	}
}

void work()
{
	while(sum!=0)
	{	
		for(int i=find();i<=n;i++)
		{
			if(a[i]!=0)
			{
				a[i]--;
				sum--;
			}
			else
			{
				break;
			}
		}
		ans++;
	}	
	printf("%d",ans);
}

int main()
{
	init();
	readdata();
	work();
	return 0;
}
