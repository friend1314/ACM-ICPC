#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
long long  ans,n,m,last,a[101001],c[10011];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		if(a[i]>last)
		ans+=(a[i]-last);
		last=a[i];
	}
	printf("%lld\n",ans);
	return 0;
}
