#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,m,r,e[10010],a[100101],ans,sum,c[10011];
bool vis[10001],flag,flag2;
void kk(int p,int val)
{
	if(flag2)return ;
	if(val>=p)
	{
		if(val==p)
		{
		flag2=1;
		}
		return ;
	}
	for(int i=1;i<=n;i++)
	{
		if(vis[i]||a[i]==p)continue;
		kk(p,val+a[i]);
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&r);
	while(r--)
	{
		flag=0;
		sum=0;
		memset(vis,0,sizeof(vis));
		memset(a,0,sizeof(a));
		scanf("%d",&n);
		ans=n;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			if(a[i]==1)
			flag=1;
			for(int j=1;j<i;j++)
			{
				if(a[i]%a[j]==0)
				{
					vis[i]=1;
					ans--;
					break;
				}
			}
			if(!vis[i])sum+=a[i];
		}
		if(flag==1)
		{
			printf("1\n");
			continue;
		}
		else 
		{
			for(int i=1;i<=n;i++)
			{
				if(vis[i])continue;
				flag2=0;
				kk(a[i],0);
				if(flag2)
				{
				ans--;
				vis[i]=1;
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
