#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
int n,m,k=1,e[101010],sum,aa[110001],ai,ci,ei,ans,head[100010],c[110011];
bool vis[100011];
struct nope{
	int x,w,v;
}a[200001];
void adde(int u,int v,int w)
{
	a[k].v=v;
	a[k].w=w;
	a[k].x=head[u];
	head[u]=k++;
}
bool check(int q)
{
	int shu,sum=0;
	for(int j=1;j<=n;j++)
	{
	for(int l=head[j];l!=-1;l=a[l].x)
	{
	if(vis[l])continue;
	sum+=a[l].w;
	vis[l]=1;
	if(sum>q)
	{
		sum=0;
		shu++;
		if(shu>=m)return 1;
	}	
	j=a[l].v;
	}
	
	}	
	return 0;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d%d",&ai,&ci,&ei);
		adde(ai,ci,ei);
		sum+=ei;
	}
	int l=1,r=sum,mid;
	while(l<=r)
	{
		mid=l+(r-l)/2;
		if(check(mid))
		{
			ans=mid;
			l=mid+1;
		}
		else r=mid-1;
	}
	printf("%d",ans);
	return 0;	
}
