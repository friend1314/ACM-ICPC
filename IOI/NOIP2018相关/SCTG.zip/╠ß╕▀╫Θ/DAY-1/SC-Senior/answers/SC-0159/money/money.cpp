#include<bits/stdc++.h>
using namespace std;
const int N=105;
int n,a[N];
int used[30010],no[N];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T;scanf("%d",&T);
	while(T--) 
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&a[i]),no[i]=0;
		sort(a+1,a+n+1);
		for(int i=1;i<=a[n];i++) used[i]=0;
		for(int i=1;i<=n;i++) 
		{
			if(used[a[i]]) {no[i]=1;continue;}
			for(int j=a[1];j<=a[n];j++)
			{
				if(j%a[i]==0) {used[j]=1;}
				if(used[j]==1&&j+a[i]<=a[n]) {used[j+a[i]]=1;}			
			}
		}
		int num=0;
		for(int i=1;i<=n;i++) if(no[i]==0) num++;
		printf("%d\n",num);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
