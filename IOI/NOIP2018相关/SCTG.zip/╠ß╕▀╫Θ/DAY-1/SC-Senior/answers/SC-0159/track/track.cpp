#include<bits/stdc++.h>
using namespace std;
const int N=5e4+12;
int n,m;

int head[N],net[N<<1],to[N<<1],ci[N<<1],p;

void build(int a,int b,int c)
{
	to[p]=b;
	net[p]=head[a];
	head[a]=p;
	ci[p++]=c;
}
int val[N],imax1,imax2;

int check1(int mid)
{
	int num=m;
	int l=1,r=n-1;
	while(l<=r)
	{
		if(val[r]>=mid) {num--;r--;}
		else if(val[r]+val[l]>=mid&&l!=r) {num--;l++;r--;}
		else l++;
		
		if(num==0) break;
	}
	if(num==0) return 1;
	else return 0;
}
void work1()
{
	int l=0,r=imax1+imax2,ans=0;
	sort(val+1,val+n);
	while(l<=r) 
	{
		int mid=(l+r)>>1;
		if(check1(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d\n",ans);
}
int tot,first;
int check2(int mid)
{
	int num=m; 
	int add=0,now=first,fa=0;
	int t=0;
	while(num)
	{
	    add=0;
		while(add<mid)
		{
			t=0;int a,b;
			for(int i=head[now];i!=-1;i=net[i])
			{
				int v=to[i];
				if(v==fa) continue;
				t=1;
				add+=ci[i];a=now;b=v;
			}
			fa=a;now=b;
			if(t==0) break;
		}
		if(t==0) break;
		if(add>=mid) num--;
	}
	if(num==0) return 1;
	else return 0;
}
void work2()
{
	for(int i=1;i<=n;i++) 
	{
		int num=0;
		for(int j=head[i];j!=-1;j=net[j]) num++;
		if(num==1) {first=i;break;}
	}
	int l=0,r=tot,ans=0;
	while(l<=r) 
	{
		int mid=(l+r)>>1;
		if(check2(mid)) {ans=mid,l=mid+1;}
		else r=mid-1; 
	}
	printf("%d\n",ans);
}

int mx[N],imax;
void dfs(int now,int fa)
{
	int mx1=0,mx2=0;
	for(int i=head[now];i!=-1;i=net[i])
	{
		int v=to[i];
		if(v==fa) continue;
		dfs(v,now);
		mx[now]=max(mx[now],mx[v]+ci[i]);
		if(mx1<mx[v]+ci[i]) {mx2=mx1;mx1=mx[v]+ci[i];}else if(mx2<mx[v]+ci[i]) mx2=mx[v]+ci[i];
	}
	imax=max(imax,mx1+mx2);
}
void work3()
{
	dfs(1,-1);
	printf("%d\n",imax);
}

int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d%d",&n,&m);
	int type1=1,type2=1;
	int a,b,c;
	int mini=0x3f3f3f3f;
	for(int i=1;i<n;i++) 
	{
		scanf("%d%d%d",&a,&b,&c);
		if(a!=1) type1=0;if(b!=a+1) type2=0;
		
		build(a,b,c);build(b,a,c);
		
		tot+=c;//2
		
		if(imax1<c) imax2=imax1,imax1=c;else if(imax2<c) imax2=c;val[i]=c;
		mini=min(mini,c);
	}
	if(type1) work1();
	else if(type2) work2();
	else if(m==n-1) {printf("%d\n",mini);}
 	else work3();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
