#include<bits/stdc++.h>
using namespace std;
const int N=1e5+12;
const int inf=0x3f3f3f3f;
int n;
int d[N];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&d[i]);
	
	int imax=d[1],cnt=d[1];
	for(int i=2;i<=n;i++) 
	{
		imax=min(imax,d[i]);
		cnt+=d[i]-imax;
		imax=max(imax,d[i]);
	}
	printf("%d\n",cnt);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
