#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
#include<cstdlib>
using namespace std;
const int M = 5e4 + 5;
int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}
int h[M], w[M], tot, n, m, dis[M];
bool check(int k){
	int now=0,cnt=0;
	int l=1,r=n-1;
	while(l<r){
		int now=w[l]+w[r];
		while(now<k&&l+1<r) now+=w[++l];
		if(now>=k)cnt++;
		l++,r--;
	}
	return cnt>=m;
}

bool check2(int k){
	int now=0, cnt=1;
	for(int i=1;i<n;i++){
		if(now>=k){now=w[i];cnt++;}
		else now+=w[i];
	}
	if(now<k)cnt--;
	return cnt>=m;
}
#define ex(i, u) for(int i = h[u]; i; i = G[i].nxt)
struct edge{
	int v, w, nxt;
}G[M<<1];
void add(int u, int v, int w){
	G[++tot].v = v, G[tot].nxt = h[u], G[tot].w = w, h[u] = tot;
}
int ret, root;
void dfs1(int u, int f){
	ex(i, u){
		int v=G[i].v;
		if(v==f)continue;
		dis[v]=dis[u]+G[i].w;
		dfs1(v, u);
	}
	if(dis[u]>dis[root]) root=u;
}
void dfs2(int u, int f){
	ex(i, u){
		int v=G[i].v;
		if(v==f)continue;
		dis[v]=dis[u]+G[i].w;
		dfs2(v, u);
	}
	if(dis[u]>ret) ret=dis[u];
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n = read(), m = read();
	int a1 = 1, a2 = 1;
	for(int i = 1; i < n; i++){
		int u = read(), v = read();
		w[i] = read();
		if(u != 1) a1 = 0;
		if(v != u + 1) a2=0;
		add(u, v, w[i]), add(v, u, w[i]);
	}
	if(m==1){
		dfs1(1, 0);
		memset(dis, 0, sizeof(dis));
		dfs2(root, 0);
		printf("%d\n", ret);
	}
	else if(a1==1){
		int ans=0,sum=0;
		sort(w+1,w+1+n-1);
		for(int i=1;i<n;i++)sum+=w[i];
		int lf=w[1], rg=sum;
		while(lf<=rg){
			int mid=(lf+rg)>>1;
			if(check(mid))ans=mid,lf=mid+1;
			else rg=mid-1;
		}
		printf("%d\n",ans);
	}
	else if(a2==1){
		int ans=0,sum=0;
		for(int i=1;i<n;i++)sum+=w[i];
		int lf=0, rg=sum;
		while(lf<=rg){
			int mid=(lf+rg)>>1;
			if(check2(mid))ans=mid,lf=mid+1;
			else rg=mid-1;
		}
		printf("%d\n",ans);
	}
	
}
