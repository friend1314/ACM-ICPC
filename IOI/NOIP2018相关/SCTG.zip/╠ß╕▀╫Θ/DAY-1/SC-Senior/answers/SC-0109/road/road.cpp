#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
#include<cstdlib>
using namespace std;
const int M = 1e5 + 5, ME = 5e6;
int n, cnt, a[M], INF = 2e9;
int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}


struct Node{
	int v, p;
	Node *ls, *rs;
	void up(){
		if(ls->v < rs->v) v = ls->v, p = ls->p;
		else v = rs->v, p = rs->p;
	}
}pool[M << 2], *root, *tail = pool;

Node *build(int lf = 1, int rg = n){
	Node *nd = ++tail;
	if(lf == rg){
		nd->p = lf, nd->v = a[lf];
	}
	else {
		int mid = (lf + rg) >> 1;
		nd->ls = build(lf, mid);
		nd->rs = build(mid + 1, rg);
		nd->up();
	}
	return nd;
}

#define Ls nd->ls, lf, mid
#define Rs nd->rs, mid+1, rg
int query(int L, int R, Node *nd = root, int lf = 1, int rg = n) {
	if(lf == rg) {
		return lf;
	}
    //nd->down()
	int mid = (lf + rg) >> 1;
	int c = 0, t = 0;
	if(L <= mid) c = query(L, R, Ls);
	if(R > mid) t = query(L, R, Rs);
	if(a[c] > a[t]) return t;
	else return c;
}
struct node{int l, r, d;}q[ME];

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n = read();a[0]=INF;
	for(int i = 1; i <= n; i++) a[i] = read();
	root = build();
	int h=0,t=-1;
	q[++t] = (node){1, n, 0};
	while(h <= t){
		node u=q[h]; h++;
		if(u.l > u.r) continue;
		int p=query(u.l, u.r);
		int dop = a[p];
		if(dop != u.d) cnt+=(dop-u.d);
		q[++t] = (node){u.l, p-1, dop};
		q[++t] = (node){p+1, u.r, dop};	
		//fprintf(stderr, "%d %d %d %d\n", cnt, u.l, u.r, u.d,p);
	}
	printf("%d\n", cnt);
}
