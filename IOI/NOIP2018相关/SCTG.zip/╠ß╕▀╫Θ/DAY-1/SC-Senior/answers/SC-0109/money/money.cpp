#include<cstdio>
#include<algorithm>
#include<cmath>
#include<iostream>
#include<cstring>
#include<queue>
#include<stack>
#include<cstdlib>
using namespace std;
const int M = 105, ME = 2e7 + 3;
#define Rand() (rand() << 15 | rand())
int read(){
	int x=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	return x*f;
}
int now[M], c[M], tot, vis[ME], a[M], n, mx; 
bool dp[10005], ban[M];
#define RG register

inline int bit(int x){return x ? bit(x>>1) + (x&1) : 0;}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int T = read();
	while(T--){
		n = read();
		mx = 0;
		for(int i = 1; i <= n; i++) {
			a[i] = read(); mx = max(mx, a[i]);
		}
		sort(a + 1, a + 1 + n);
		tot = unique(a + 1, a + 1 + n) - a - 1;
		if(tot <= 20){
			int ans = bit( (1<<tot)-1 );
			for(RG int s = 1; s < (1<<tot); s++){
				if(bit(s) > ans) continue;
				int cnt = 0;
				memset(dp, 0, sizeof(dp));
				for(RG int i=0;i<tot;i++) if((1<<i)&s) now[++cnt] = a[i+1];
				dp[0] = 1;
				for(RG int i=1;i<=cnt;i++)
					for(RG int t = 0; t+now[i]<=mx; t++)
					if(dp[t]){
							dp[t+now[i]]=1;
					}
				bool fg=1;
				for(RG int i = 1; i <= tot;i++) if(!dp[a[i]]){fg=0;break;}
				//printf("%d %d\n",s, fg);
				if(fg  && ans > cnt ) ans = cnt;
			}
			printf("%d\n",ans);
			
		}
		else if(mx <= 40){
			int idc = 0, ans = tot;
			while(idc <= 1e6){
				idc++;
				int s=Rand() % (1<<tot)+1;
				if(vis[s] == T|| bit(s) > ans)continue;
				vis[s] = T;
				for(RG int s = 1; s < (1<<tot); s++){
					if(bit(s) > ans) continue;
					int cnt = 0;
					for(RG  int i=1;i<=mx;i++)dp[i]=0;
					for(RG int i=0;i<tot;i++) if((1<<i)&s) now[++cnt] = a[i+1];
					dp[0] = 1;
					for(RG int i=1;i<=cnt;i++)
						for(RG int t = 0; t+now[i]<=mx; t++)
						if(dp[t]){
								dp[t+now[i]]=1;
						}
					bool fg=1;
					for(RG int i = 1; i <= tot;i++) if(!dp[a[i]]){fg=0;break;}
					//printf("%d %d\n",s, fg);
					if(fg  && ans > cnt ) ans = cnt;
				}
			}
			printf("%d\n",ans);
			
			
		}
	}
}
