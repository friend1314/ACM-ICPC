#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("road.in.txt","r",stdin);
	freopen("road.out","w",stdout);
	int n,now,ans=0,x;
	cin>>n;
	cin>>now;
	ans=now;
	for(int i=2;i<=n;i++)
	{
		cin>>x;
		if(x<=now)
		now=x;
		else
		{
			ans+=x-now;
			now=x;
		}
	}
	cout<<ans;
	return 0;
}
