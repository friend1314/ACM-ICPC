#include<bits/stdc++.h>
using namespace std;
int a[110],b[110],c[110],d[110];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t;
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		int n;
		cin>>n;
		for(int j=1;j<=n;j++)
		cin>>a[j];
		sort(a+1,a+n+1);
		b[0]=1;
		b[1]=a[1];
		for(int j=2;j<=n;j++)
		{
			bool e=1;
			for(int k=1;k<=b[0];k++)
			if(a[j]%b[k]==0)
			{
				e=0;
				break;
			}
			if(e)
			b[++b[0]]=a[j];
		}
		if(b[0]==2||b[0]==1)
		cout<<b[0]<<endl;
		else
		{
			c[0]=2;
			c[1]=b[1];
			c[2]=b[2];
			int x=(c[1]-1)*(c[2]-1)-1;
			for(int j=3;j<=b[0];j++)
			{
				if(b[j]<=x)
				c[++c[0]]=b[j];
			}
			if(c[0]==2)
			cout<<c[0]<<endl;
			else
			{
				d[0]=1;
				d[1]=c[1];
				for(int j=2;j<=c[0];j++)
				{
					int o=c[j];
					bool b1=1;
					for(int k=1;k<=d[0];k++)
					{
						while(o>d[1])
						{
							o-=d[k];
							for(int l=1;l<=d[0];l++)
							if(o%d[l]==0)
							{
								b1=0;
								break;
							}
							if(!b1)
							break;
						}
						if(b1)
						break;
					}
					if(b1)
					d[++d[0]]=c[j];
				}
				cout<<d[0]<<endl;
			}
		}
	}
	return 0;
}
