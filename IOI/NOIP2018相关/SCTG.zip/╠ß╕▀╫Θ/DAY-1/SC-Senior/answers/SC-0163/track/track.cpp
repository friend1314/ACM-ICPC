#include<bits/stdc++.h>
using namespace std;
int a[1100][1100],c[1100][5];
bool b[1100][1100];
int ans=0,sum=0;
void w(int t)
{
	ans=max(ans,sum);
	for(int i=1;i<=c[t][0];i++)
	if(b[t][c[t][i]])
	{
		sum+=a[t][c[t][i]];
		b[t][c[t][i]]=0;
		b[c[t][i]][t]=0;
		w(c[t][i]);
		sum-=a[t][c[t][i]];
		b[t][c[t][i]]=1;
		b[c[t][i]][t]=0;
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n,m;
	cin>>n>>m;
	for(int i=1;i<n;i++)
	{
		int x,y,l;
		cin>>x>>y>>l;
		a[x][y]=l;
		b[x][y]=true;
		b[y][x]=true;
		c[x][++c[x][0]]=y;
	}
	for(int i=1;i<n;i++)
	{
		sum=0;
		w(i);
		ans=max(ans,sum);
	}
	cout<<ans;
	return 0;
}
