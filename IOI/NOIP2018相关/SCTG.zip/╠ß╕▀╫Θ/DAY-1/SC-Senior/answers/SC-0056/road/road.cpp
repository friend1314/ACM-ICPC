#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cctype>
#include <cstring>
using namespace std;
inline int readint()
{
	int x=0;
	char c=getchar();
	while(!isdigit(c))
		c=getchar();
	while(isdigit(c))
	{
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
} 
struct data
{
	int x,pos;
}tree[400005];
int n,ans=0,d[100005];
void buil(int cur,int l,int r)
{
	if(l==r)
	{
		tree[cur].x=d[l];
		tree[cur].pos=l;
		return;
	}
	int mid=(l+r)>>1;
	buil(cur<<1,l,mid);
	buil(cur<<1|1,mid+1,r);
	if(tree[cur<<1].x>tree[cur<<1|1].x)
	{
		tree[cur].x=tree[cur<<1|1].x;
		tree[cur].pos=tree[cur<<1|1].pos;
	}
	else
	{
		tree[cur].x=tree[cur<<1].x;
		tree[cur].pos=tree[cur<<1].pos;
	}
	return;
}
int quer(int cur,int l,int r,int s,int e)
{
	if(s<=l&&e>=r) return tree[cur].pos;
	int mid=(l+r)>>1,ans=0x3f3f3f3f,p,temp;
	if(e<=mid) 
		p=quer(cur<<1,l,mid,s,e);
	else if(s>mid)
		p=quer(cur<<1|1,mid+1,r,s,e);
	else
	{
		if(s<=mid)
		{
			temp=quer(cur<<1,l,mid,s,e);
			if(ans>d[temp])
			{
				ans=d[temp];
				p=temp;
			}
		}
		if(r>=mid+1)
		{
			temp=quer(cur<<1|1,mid+1,r,s,e);
			if(ans>d[temp])
			{
				ans=d[temp];
				p=temp;
			}
		}
	}
	return p;
}
void solv(int l,int r,int cur)
{
	if(l>r) return;
	if(l==r) 
	{
		ans+=d[l]-cur;
		return;
	}
	int temp=quer(1,1,n,l,r);
	ans+=d[temp]-cur;
	solv(l,temp-1,d[temp]);
	solv(temp+1,r,d[temp]);
	return;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=readint();
	for(int i=1;i<=n;i++)
		d[i]=readint();
	buil(1,1,n);
	solv(1,n,0);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
