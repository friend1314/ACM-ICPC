#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cctype>
#include <cstring>
using namespace std;
int readint()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c))
	{
		if(c=='-') f=-1;
		c=getchar();
	}
	while(isdigit(c))
	{
		x=x*10+c-'0';
		c=getchar();
	}
	return x*f;
} 
int m,n,v[100005],w[100005],nxt[100005],firs[50005],a,b,c;
int bok[50005];
int dfs(int cur,int rot,int sum)
{
	int mx=0;
	for(int k=firs[cur];k;k=nxt[k])
	{
		if(!bok[v[k]])
		{
			bok[v[k]]=1;
			if(cur==rot) mx+=dfs(v[k],rot,w[k]);
			else mx=max(mx,dfs(v[k],rot,w[k]));
		}
	}
	return mx+sum;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=readint();
	m=readint();
	if(m==1)
	{
		memset(bok,0,sizeof(bok));
		memset(nxt,0,sizeof(nxt));
		memset(firs,0,sizeof(firs));
		for(int i=1;i<=2*n-2;i+=2)
		{
			a=readint();
			b=readint();
			c=readint();
			v[i]=b;
			w[i]=c;
			nxt[i]=firs[a];
			firs[a]=i;
			v[i+1]=a;
			w[i+1]=c;
			nxt[i+1]=firs[b];
			firs[b]=i+1;
		}
		bok[1]=1;
		printf("%d",dfs(1,1,0));
	}
//	else if(n<=200)
//	{
//		memset(map,0,sizeof(map));
//		for(int i=1;i<n;i++)
//		{
//			a=readint();
//			b=readint();
//			c=readint();
//			map[a][b]=map[b][a]=c;
//		}
//		for(int k=1;k<=n;k++)
//			for(int i=1;i<=n;i++)
//				for(int j=1;j<=n;j++)	
//					if(map[i][j]<map[i][k]+map[k][j])
//						map[i][j]=map[i][k]+map[k][j];
//		
//	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
