#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cctype>
#include <cstring>
using namespace std;
inline int readint()
{
	int x=0;
	char c=getchar();
	while(!isdigit(c))
		c=getchar();
	while(isdigit(c))
	{
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
} 
int t,n,a[105],f,c;
bool bok[25005],abl[25005];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=readint();
	while(t--)
	{
		n=readint();
		f=0;
		c=0;
		memset(bok,false,sizeof(bok));
		memset(abl,false,sizeof(abl));
		for(int i=1;i<=n;i++)
		{
			a[i]=readint();
			bok[a[i]]=true;
			abl[a[i]]=true;
			if(a[i]==1) f=1;
		}
		if(f)
		{
			printf("1\n");
			continue;
		}
		sort(a+1,a+n+1);
		for(int i=1;i<=n;i++)
		{
			if(!bok[a[i]]) continue;
			for(int j=i+1;j<=n;j++)
			{
				if(a[j]%a[i]==0) bok[a[j]]=false;
				else
				{
					int temp=a[j]-a[i];
					while(temp>0)
					{
						if(abl[temp])
						{
							bok[a[j]]=false;
							break;
						}
						temp-=a[i];
					}
				}
			}
			c++;
		}
		printf("%d\n",c);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
