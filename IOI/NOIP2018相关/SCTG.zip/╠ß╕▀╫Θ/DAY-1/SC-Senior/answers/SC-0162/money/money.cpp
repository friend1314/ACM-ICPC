#include<bits/stdc++.h>
using namespace std;
inline void R(int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch =='-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch ^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int T;
int n;
int a[105];
int b[105];
int tot;
int geshu;
int now;
int ma;
int ans;
bool vis[25005];
int c[105];
int topc;
int main (){
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	R(T);
	for(int o = 1;o <= T;++o) {
		R(n);
		topc = 0;
		ma = 0;
		ans = 0;
		for(register int i = 1; i <= n; ++i) {
			R(a[i]);
			ma = max(ma, a[i]);
		}
		for(register int j = 1; j <= ma; ++j) vis[j] = 0;
		sort(a + 1, a + n + 1);
		int temp;
		int tm;
		vis[0] = 1;
		for(register int i = 1; i <= n; ++i) {
			if(!vis[a[i]]) {
				temp = a[i];
				++ans;
				tm = ma - temp;
				for(register int j = 0;j <= tm; ++j) {
					vis[j + temp] = (vis[j] || vis[j + temp]);
				}
			}
		}
		printf("%d\n", ans);	

	}
	return 0 ;
}
