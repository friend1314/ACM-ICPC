#include<bits/stdc++.h>
using namespace std;
inline void R(int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch =='-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch ^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
int n;
struct node {
	int zhi, pos;
}a[200005];
int b[200005];
int tot;
int geshu;
int now;
int ma;
int ans;
inline bool cmp(const node &a,const  node &b) {
	return a.zhi < b.zhi;
}
int main (){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	R(n);
	for(int i = 1; i <= n; ++i) {
		R(a[i].zhi);
		b[i] = 1;
		a[i].pos = i;
		ma = max(ma, a[i].zhi);
	//	tot += a[i];
	} 
	b[0] = 0;
	b[n + 1] = 0;
	sort(a + 1, a + n + 1, cmp);
	int blo = 1;
	a[n + 1].zhi = INT_MAX;
	int temp = 0;
	int mi = 0;
	for(int i = 1; i <= n; ++i) {
	//	printf("a[%d].zhi = %d, a[%d].pos = %d\n", i, a[i].zhi, i, a[i].pos);
		if(b[a[i].pos - 1] != 0 && b[a[i].pos + 1] != 0) ++temp;
		if(b[a[i].pos - 1] == 0 && b[a[i].pos + 1] == 0) -- temp;
		b[a[i].pos] = 0;
		if(a[i + 1].zhi != a[i].zhi) {
			ans += blo * (a[i].zhi - mi);
	//		printf(" mi = %d, bl = %d, ans = %d\n", mi, blo,ans);

			mi = a[i].zhi;
			blo += temp;
			temp = 0;
		}
	}
	cout << ans << '\n';
	return 0;
}
