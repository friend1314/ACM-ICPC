#include<bits/stdc++.h>
using namespace std;
inline void R(int &v) {
	static char ch;
	v = 0;
	bool p = 0;
	do {
		ch = getchar();
		if(ch =='-') p = 1;
	} while(!isdigit(ch));
	while(isdigit(ch)) {
		v = (v + (v << 2) << 1) + (ch ^'0');
		ch = getchar();
	}
	if(p) v = -v;
}
struct node {
	int to, length, id;
	node (int to, int length,int id):to(to), length(length),id(id){
	}
	node(){
	}
};
struct bian2 {
	int x, y, yun, length;
	bian2(int x, int y, int length):x(x),y(y),length(length){
	}
	bian2(){
	}
}bian[50005];
vector<node>q[50005];
int n;
int zong;
inline void create(int x, int y, int z) {
	q[x].push_back(node (y, z, ++zong));
	q[y].push_back(node	(x, z, zong));
}
int dis[50005], dep[50005];
int rt, ma;
inline void dfs(int x, int fa) {
	node *p;
	for(int i = 0; i < q[x].size(); ++i) {
		p = &q[x][i];
		if(p->to != fa) {
			dis[p->to] = dis[x] + p->length;
		//	dep[p->to] = dep[x] + 1;
			dfs(p->to, x);
		}
	}
	if(dis[x] > dis[rt]) rt = x, ma = dis[x];
}
inline void dfs1(int x, int fa) {
	node *p;
	for(int i = 0; i < q[x].size(); ++i) {
		p = &q[x][i];
		if(p->to != fa) {
			dep[p->to] = dep[x] + 1;
			dfs1(p->to, x);
		}
	}
}
int m;
bool kind1, kind2;
int b[50005],c[50005];
inline bool check(int mid) {
	int geshu = 0;
	int tou = 1, wei = n - 1;
	while(tou < wei) {
		if(b[tou] + b[wei] >= mid) {
			++geshu;
			--wei;
		}
		++tou;
	}
	return geshu >= m;
}
inline bool check2(int mid) {
	int l = 1, now = 0, geshu = 0;
	for(int i = 1; i < n; ++i) {
		now += c[i];
		if(now >= mid) {
			now = 0;
			++geshu;
			l = i + 1;
		}
	}
	return geshu >= m;
}
int chou[50005];
bool zou1[50005], zou2[50005];
int te;
int rt1;
int fa[50005];
inline void dfs3(int x, int fa) {
	node *p;
	if(dis[x] > dis[rt]) ma = dis[x], rt1 = x;
}
inline void dfs2(int x, int fa) {
	node *p;
	for(int i = 0; i < q[x].size(); ++i) {
		p = &q[x][i];
		if(p->to != fa && p->to != rt1 && ((bian[p->id].yun == 0))) {
			dis[p->to] = dis[x] + p->length;
			if(bian[p->id].yun == 0)
			dfs2(p->to, x);
	
		//	bian[i].yun = INT_MAX;
		}
	}
	if(dis[x] > dis[rt]) rt = x, ma = dis[x], te = 0, rt1 = 0;
}
int mi;
int main() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	srand((int)('g' + 'l' + 'g' + 'j' + 's' + 's' +'y' + 'q' + 'y' + 'h' + 'f' + 'b' + 'q' + 'z'));
	R(n);
	R(m);
	int x, y, z;
	kind1 = 1, kind2 = 1;
	int tt = INT_MAX;
	for(int i = 1; i < n; ++ i) {
		R(x), R(y), R(z);
		if(x > y) swap(x , y);
		if(x != 1) kind1 = 0;
		if(y != x + 1) kind2 = 0;
		create(x, y, z);
		b[i] = z;
		c[x] = z;
		bian[zong] = bian2(x, y, z);
		tt=min(tt,z);
	}
	rt = 1;
	if(m == n - 1) {
		cout << tt << '\n';
		return 0;
	}
	if(m == 1) {
		memset(dis, 0, sizeof(dis));
		dfs(rt, rt);
		memset(dis, 0, sizeof(dis));
		dfs(rt, rt);
		printf("%d\n", ma);
	} else {
		if(kind1) {
			int l = -1, r = 100005, mid;
			sort(b + 1, b + n);
			while(l < r - 1) {
				mid = l + r >> 1;
//				printf("mid = %d\n",mid);
				if(check(mid)) {
					l = mid;
				} else r = mid;
			}
			printf("%d\n", l);
		} else {
			if(kind2) {
				int l = -1, r = 100005, mid;
				sort(b + 1, b + n);
				while(l < r - 1) {
					mid = l + r >> 1;
//					printf("mid = %d\n",mid);
					if(check2(mid)) {
						l = mid;
					} else r = mid;
				}
				printf("%d\n", l);
			} else {
				dfs1(1, 1);
				int cishu = 15000000 / n;
				int ans = 0;
				while(cishu--) {
			//		printf("cishu = %d\n", cishu);
		//	if(cishu == 1666663) {
		//		puts("233");
		//	} 		
					int tot = 0;
					mi = INT_MAX;
					for(int i = 1; i < n; ++i) {
					chou[i] = i;
					zou1[i] = zou2[i] = 0;
					bian[i].yun = 0;
				}
					ma = 0;
					random_shuffle(chou + 1, chou + n);
					for(int i = 1; i <= m; ++i) {
						if(dep[bian[chou[i]].x] > dep[bian[chou[i]].y])
						bian[chou[i]].yun = bian[chou[i]].x;
						else bian[chou[i]].yun = bian[chou[i]].y;
					}
					for(int i = 1; i <= m; ++i) {
						if(bian[chou[i]].yun == bian[chou[i]].x) {
							rt = bian[chou[i]].x;
							dis[rt] = bian[chou[i]].length;
							zou1[chou[i]] = 1;
							ma = dis[rt];
							dfs2(rt, rt);
							dis[rt] = 0;
							dfs2(rt, rt);
							mi = min(mi, ma);
							++tot;
							if(mi < ans) break;
						}
						if(bian[chou[i]].yun == bian[chou[i]].y) {
							rt = bian[chou[i]].y;
							dis[rt] = bian[chou[i]].length;		
							zou2[chou[i]] = 1;
							ma = dis[rt];
							dfs2(rt, rt);
							dis[rt] = 0;
							dfs2(rt, rt);
							mi = min(mi, ma);
							++tot;
							if(mi < ans) break;
						}
					}
				//	printf("tot = %d\n", tot);
					if(mi != INT_MAX && tot >=m){
						ans = max(ans, mi);
					}
				}
				cout << ans << '\n';
			}
		}
	}	
}
