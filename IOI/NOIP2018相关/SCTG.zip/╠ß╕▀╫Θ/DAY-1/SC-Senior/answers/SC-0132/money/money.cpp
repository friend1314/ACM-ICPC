#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
void read(int &v)
{
	int f;char ch;
	while(!isdigit(ch=getchar())&&ch!='-'); ch=='-'?(f=-1,v=0):(f=1,v=ch-'0');
	while(isdigit(ch=getchar())) v=v*10+ch-'0';v=v*f;
}
const int N=30,M=1e6+5,INF=1e9+7;
int st[N],n,mx,ans;
bool tmp[M],dp[M],gg[N],vis[1<<26];
int gcd(int a,int b) {return !b?a:gcd(b,a%b);}
bool DP(int now)
{
	fill(tmp+1,tmp+1+mx,0);
	tmp[0]=1;
	for(int i=1;i<=n;i++)
	if((now&(1<<(i-1)))){
		for(int j=0;j<=mx;j++) 
		if(tmp[j]&&j+st[i]<=mx) tmp[j+st[i]]=1;
	}
	for(int i=0;i<=mx;i++) if(dp[i]!=tmp[i]) return 0;
	return 1;
}
int get_num(int v)
{
	int num=0;
	while(v){
		if(v&1) num++;
		v=v>>1;
	}
	return num;
}
queue<int> que;
int bfs()
{
	memset(vis,0,sizeof(vis));
	while(!que.empty()) que.pop();
	que.push(0),vis[0]=1;
	while(!que.empty()){
		int now=que.front();que.pop();
		for(int i=1;i<=n;i++)
		if(!(now&(1<<(i-1)))){
			int tmpnow=now|(1<<(i-1));
			if(vis[tmpnow]) continue;
			if(DP(tmpnow)) return get_num(tmpnow);
			if(!vis[tmpnow]) que.push(tmpnow);
		}
	}
}
int main()
{
	freopen("money.in","r",stdin);freopen("money.out","w",stdout);
	int T;
	read(T);
	while(T--){
		mx=INF,ans=0;
		memset(gg,0,sizeof(gg));
		read(n);
		for(int i=1;i<=n;i++) read(st[i]);
		for(int i=1;i<=n;i++) 
		for(int j=i+1;j<=n;j++) if(gcd(st[i],st[j])==1) mx=min(mx,st[i]*st[j]-st[i]-st[j]);
		if(mx==INF){
			for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++){
				int a=st[i],b=st[j];
				if(!(b%a)||!(a%b)) gg[max(a,b)]=1;
			}
			for(int i=1;i<=n;i++) if(!gg[i]) ans++;
			printf("%d\n",ans);continue;
		}
		fill(dp+1,dp+1+mx,0),dp[0]=1;
		for(int i=1;i<=n;i++)
		for(int j=0;j<=mx;j++)
		if(dp[j]&&j+st[i]<=mx) dp[j+st[i]]=1;
		printf("%d\n",bfs());
	}
	return 0;
}
