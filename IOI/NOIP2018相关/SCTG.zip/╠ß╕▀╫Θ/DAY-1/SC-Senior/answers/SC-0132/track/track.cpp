#include<cstdio>
#include<cctype>
#include<algorithm>
#include<cstring>
#include<set>
using namespace std;
void read(int &v)
{
	int f;char ch;
	while(!isdigit(ch=getchar())&&ch!='-'); ch=='-'?(f=-1,v=0):(f=1,v=ch-'0');
	while(isdigit(ch=getchar())) v=v*10+ch-'0';v=v*f;
}
const int N=5e4+5,INF=1e9+7;
struct sd{
	int nxt,to,w;
	sd(){};
	sd(int a,int b,int c){nxt=a,to=b,w=c;}
}edge[N<<1];
int head[N],val[N],line[N],n,m,cnt,sum;
void add_edge(int from,int to,int w)
{
	edge[++cnt]=sd(head[from],to,w),head[from]=cnt;
	edge[++cnt]=sd(head[to],from,w),head[to]=cnt;
}
int goal,mxlen;
void dfs(int v,int ff,int len)
{
	if(mxlen<len) mxlen=len,goal=v;
	for(int i=head[v];i;i=edge[i].nxt){
		int to=edge[i].to;
		if(to==ff) continue;
		dfs(to,v,len+edge[i].w);
	}
}
void tp()
{
	mxlen=0,dfs(1,0,0);int d1=goal;
	mxlen=0,dfs(d1,0,0);
	printf("%d",mxlen);
}
bool check(int w)
{
	int now=0,id=1,num=0;
	for(int i=1;i<n;i++){
		now+=val[id];
		if(now>=w) num++,now=0;
		id++;
	}
	return num>=m;
}
void tp2()
{
	int l=0,r=sum,ans;
	while(l<=r){
		int mid=l+r>>1;
		if(check(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d",ans);
}
set<int> ss;
set<int> ::iterator it,itt;
int time[N];
bool judge(int w)
{
	int num=0;
	memset(time,0,sizeof(time));
	for(int i=1;i<n;i++) ss.insert(line[i]),time[line[i]]++;
	while(!ss.empty()){
		it=ss.end();it--;
		int len=*it;
		time[len]--;
		if(!time[len]) ss.erase(it);
		if(len>=w) {num++;continue;}
		it=ss.lower_bound(w-len);
		if(it==ss.end()) break;
		int llen=*it;
		if(llen+len<w) break;
		num++;
		if(num>=m) break;
		time[llen]--;
		if(!time[llen]) ss.erase(it);
	}
	return num>=m;
}
void tp1()
{
	int l=0,r=sum,ans;
	while(l<=r){
		int mid=l+r>>1;
		if(judge(mid)) ans=mid,l=mid+1;
		else r=mid-1;
	}
	printf("%d",ans);
}
int main()
{
	freopen("track.in","r",stdin);freopen("track.out","w",stdout);
	int x,y,w,mi=INF;
	read(n),read(m);
	bool f1=1,f2=1;
	for(int i=1;i<n;i++){
		read(x),read(y),read(w),add_edge(x,y,w);
		line[i]=w,val[x]=w,sum+=w,mi=min(mi,w);
		if(x!=1) f1=0;
		if(y!=x+1) f2=0;
	}
	if(m==n-1) {printf("%d",mi);return 0;}
	if(m==1) {tp();return 0;}
	if(f1) {tp1();return 0;}
	if(f2) {tp2();return 0;}
	return 0;
}
