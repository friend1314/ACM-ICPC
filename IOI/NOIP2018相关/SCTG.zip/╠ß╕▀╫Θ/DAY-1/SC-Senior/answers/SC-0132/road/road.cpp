#include<cstdio>
#include<cctype>
#include<algorithm>
using namespace std;
void read(int &v)
{
	int f;char ch;
	while(!isdigit(ch=getchar())&&ch!='-'); ch=='-'?(f=-1,v=0):(f=1,v=ch-'0');
	while(isdigit(ch=getchar())) v=v*10+ch-'0';v=v*f;
}
const int N=1e5+5,INF=1e9+7;
struct sd{
	int son[2],mi,tag;bool zero;
}t[N<<1];
int root,cnt,tmp[N],st[N],n,ans;
void update(int v)
{
	int ls=t[v].son[0],rs=t[v].son[1];
	t[v].mi=min(t[ls].mi,t[rs].mi);
	t[v].zero=t[ls].zero|t[rs].zero;
}
void pushdown(int v)
{
	if(t[v].tag){
		int ls=t[v].son[0],rs=t[v].son[1];
		if(ls) t[ls].mi-=t[v].tag,t[ls].tag+=t[v].tag;
		if(rs) t[rs].mi-=t[v].tag,t[rs].tag+=t[v].tag;
		t[v].tag=0;
	}
}
void build(int &v,int l,int r)
{
	v=++cnt;
	if(l==r) {read(t[v].mi);return;}
	int mid=l+r>>1;
	build(t[v].son[0],l,mid);
	build(t[v].son[1],mid+1,r);
	update(v);
}
int query(int v,int l,int r)
{
	pushdown(v);
	if(l==r) {t[v].zero=1,t[v].mi=INF;return l;}
	int mid=l+r>>1,ls=t[v].son[0],rs=t[v].son[1],res;
	if(t[ls].mi<t[rs].mi) res=query(ls,l,mid);
	else res=query(rs,mid+1,r);
	update(v);
	return res;
}
int find(int v,int l,int r,bool way)
{
	pushdown(v);
	if(l==r){
		if(t[v].zero) return l;
		else return -1;
	}
	int mid=l+r>>1,ls=t[v].son[0],rs=t[v].son[1];
	if(!way){
		if(t[ls].zero) return find(ls,l,mid,way);
		else return find(rs,mid+1,r,way);
	}
	else{
		if(t[rs].zero) return find(rs,mid+1,r,way);
		else return find(ls,l,mid,way);
	}
}
int ask(int v,int l,int r,int lx,int rx,bool way)
{
	pushdown(v);
	if(l==lx&&r==rx) return find(v,l,r,way);
	int mid=l+r>>1,ls=t[v].son[0],rs=t[v].son[1];
	if(rx<=mid) return ask(ls,l,mid,lx,rx,way);
	else if(lx>mid) return ask(rs,mid+1,r,lx,rx,way);
	else{
		int lgg=ask(ls,l,mid,lx,mid,way);
		int rgg=ask(rs,mid+1,r,mid+1,rx,way);
		if(lgg==-1&&rgg==-1) return -1;
		if(!way){
			if(lgg==-1) return rgg;
			else return lgg;
		}
		else{
			if(rgg==-1) return lgg;
			else return rgg;
		}
	}
}
void modify(int v,int l,int r,int lx,int rx,int val)
{
	pushdown(v);
	if(l==lx&&r==rx){
		t[v].tag+=val;
		t[v].mi-=val;return;
	}
	int mid=l+r>>1,ls=t[v].son[0],rs=t[v].son[1];
	if(rx<=mid) modify(ls,l,mid,lx,rx,val);
	else if(lx>mid) modify(rs,mid+1,r,lx,rx,val);
	else modify(ls,l,mid,lx,mid,val),modify(rs,mid+1,r,mid+1,rx,val);
	update(v);
}
int main()
{
	freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	int mi=INF,pos=0;
	read(n);
	build(root,1,n);
	for(int i=1;i<=n;i++){
		int now=t[root].mi;
		ans+=now;
		int pos=query(root,1,n),l,r;
		if(pos==1) l=1;
		else l=ask(root,1,n,1,pos-1,1);
		if(pos==n) r=n;
		else r=ask(root,1,n,pos+1,n,0);
		if(l==-1) l=1;
		if(r==-1) r=n;
		modify(root,1,n,l,r,now);
	}
	printf("%d",ans);
	return 0;
}
