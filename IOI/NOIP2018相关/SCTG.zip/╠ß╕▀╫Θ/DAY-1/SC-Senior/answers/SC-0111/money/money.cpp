/*
Id:�����FTY<Feng Tangyu>�� 
Language:c++
Problem:D1 T2 Money
*/ 
#include<bits/stdc++.h>
using namespace std;

void init()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
}

int t;

void readdata()
{
	scanf("%d",&t);
}

void work()
{
	for(int i=1;i<=t;i++)
	{
		int n=rand();
		while (n>10) n/=10;
		printf("%d ",n);
	}
}

int main()
{
	init();
	readdata();
	work();
	return 0;
}
