/*
Id:�����FTY<Feng Tangyu>�� 
Language:c++
Problem:D1 T3 Track
*/ 
#include<bits/stdc++.h>
using namespace std;

void init()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
}

int head[100010],cnt=0;

struct edge
{
	int u,v,w,next;
} e[100100];

void add(int u,int v,int w)
{
	e[cnt].u=u;
	e[cnt].v=v;
	e[cnt].w=w;
	e[cnt].next=head[u];
	head[u]=cnt++;
}

void readdata()
{

}

void spfa()
{
	for(int i=1000;i<1001;i++)
	printf("%d ",rand());
}

int main()
{
	init();
	readdata();
	spfa();
	return 0;
}
