/*
Id:�����FTY<Feng Tangyu>�� 
Language:c++
Problem:D1 T1 Road
*/ 
#include<bits/stdc++.h>
using namespace std;

int n,a[100010],cnt=0;
bool vis[100010];

void read(int &x)
{
	int f=1;x=0;char s=getchar();
	while( s<'0' || s>'9' ){if(s=='-') f=-1;s=getchar();}
	while( s>='0' && s<='9' ){x=x*10+s-'0';s=getchar();}
	x*=f;
}

void init()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
}

void readdata()
{
	read(n);
	for(int i=1;i<=n;i++)
	{
		read(a[i]);
	}
}

void dfs(int l,int r)
{
	for(int k=1;k<=n;k++)
	{
		if (a[k]!=0) continue;
	}
	for(int i=l;i<=r;i++)
	{
		if(a[i]==0)
		{
			for(int j=l;j<i-1;j++)
			{
				a[j]++;
			}
			dfs(l,i-1);
			dfs(i+1,r);
		}
		if(a[i]!=0)
		{
			a[i]--;
		}
	}
	for(int i=l;i<=r;i++)
	{
		if(a[i]!=0)
		{
			cnt++;
			dfs(l,r);
		}
	 	else 
	 	{
	 		continue;
	 	}
	}
} 

int main()
{
	init();
	readdata();
	dfs(1,n); 
	printf("%d",cnt-1);
	return 0;
}
