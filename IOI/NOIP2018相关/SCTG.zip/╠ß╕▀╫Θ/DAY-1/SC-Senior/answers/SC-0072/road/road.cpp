#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define N 100010
#define ll long long
ll n,hi[N],ans=0;
inline void read(ll &x){
	char c=getchar();x=0;int f=1;
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-48;c=getchar();}
	x=x*f;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++)
		read(hi[i]);
	for(ll i=1;i<=n;i++){
		if(hi[i]>hi[i-1])
			ans+=hi[i]-hi[i-1];
	}
	cout<<ans;
	return 0;
}
/*
6
4 3 2 5 3 5
*/
