#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int T,n,ans;
int a[105];
inline void read(int &x){
	char c=getchar();x=0;int f=1;
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-48;c=getchar();}
	x=x*f;
}
//case 1 : n<=5
int dp[3100]={},ok[8]={};
//case 2 : a[n]<=40
int dp2[210]={},ok2[30]={};
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		ans=n;int dec=0;
		for(int i=1;i<=n;i++){
			read(a[i]);
		} 
		sort(a+1,a+n+1);
		if(n<=5){
			for(int i=1;i<=n;i++) ok[i]=0;
			for(int i=2;i<=n;i++){
				memset(dp,0,sizeof(dp));
				for(int j=1;j<i;j++){
					if(ok[j]) continue;
					for(int l=a[j];l<=1000;l+=a[j])
						dp[l]=1;
				}
				for(int j=1;j<i;j++){
					if(ok[j]) continue;
					for(int l=1;l<=1000;l++){
						if(dp[l]) dp[l+a[j]]=1;
					}
				}
				if(dp[a[i]]){
					ok[i]=1;
					dec++;
				}
			}
//			for(int i=1;i<=n;i++)
//				if(ok[i]) ans--;
			printf("%d\n",ans-dec);
			continue;
		}
		if(a[n]<=40){
			for(int i=1;i<=n;i++) ok2[i]=0;
			for(int i=2;i<=n;i++){
				for(int j=1;j<=200;j++)
					dp2[j]=0;
				for(int j=1;j<i;j++){
					if(ok2[j]) continue;
					for(int l=a[j];l<=40;l+=a[j])
						dp2[l]=1;
				}
				for(int j=1;j<i;j++){
					if(ok2[j]) continue;
					for(int l=1;l<=40;l++){
						if(dp2[l]) dp2[l+a[j]]=1;
					}
				}
				if(dp2[a[i]]){
					ok2[i]=1;
					dec++;
				}
			}
//			for(int i=1;i<=n;i++) 
//				if(ok2[i]) ans--;
			printf("%d\n",ans-dec);
			continue;
		}
		
	}
	return 0;
}
/*
4
4
3 6 10 19
5
11 13 17 23 29
5
1 2 3 4 5
7 
4 3 9 9 5 8 7

*/
