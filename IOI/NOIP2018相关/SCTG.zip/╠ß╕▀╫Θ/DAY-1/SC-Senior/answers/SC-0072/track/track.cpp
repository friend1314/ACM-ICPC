#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define N 50010
int n,m;
struct edge{
	int u,v,w,nxt;
}e[N*2];
struct node{
	int u,v,w;
}len[N*2];
int cnt=0,first[N*2]={};
bool cmp(node a,node b){
	return a.w<b.w;
}
inline void add(int u,int v,int w){
	e[++cnt]=(edge){u,v,w,first[u]};
	first[u]=cnt;
}
inline void read(int &x){
	char c=getchar();x=0;int f=1;
	while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-48;c=getchar();}
	x=x*f;
}
// case 1: m==1
int dis[N]={};
void dfs1(int u,int fa){
	for(int i=first[u];i;i=e[i].nxt){
		int v=e[i].v,w=e[i].w;
		if(v==fa) continue;
		dis[v]=dis[u]+w;
		dfs1(v,u);
	}
}
// case 2: m>1
// Ӧ������ѡ�񽻲�·��,���ÿ���㶼���� 
// case 2.A: ����
// case 2.B: 1�������е�
int st[N]={},tp=0;
int barbar[N]={};
int res[N]={},ct=0;
// case 2.C: line
int sum[N]={},mn[N]={};
int dp(int tot,int k){
	int res=-1;
	if(k==1) return sum[tot];
	if(tot==k) return mn[tot];
	for(int i=k-1;i<tot;i++){
		int ret=min(dp(i,k-1),sum[tot]-sum[i]);
		res=max(res,ret);
	}
	return res;
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	scanf("%d%d",&n,&m);
	memset(mn,0x3f3f3f3f,sizeof(mn));
	for(int i=1;i<n;i++){
		int a,b,c;
		read(a);read(b);read(c);
		len[i].w=c;
		len[i].v=b;
		len[i].u=a;
		add(a,b,c);add(b,a,c);
	}
	int barfg=1,lian=1;
	for(int i=1;i<n;i++){
		if(len[i].u!=1&&len[i].v!=1){
			barfg=0;
			break;
		}
	}
	for(int i=1;i<n;i++){
		sum[i]=sum[i-1]+len[i].w;
		mn[i]=min(mn[i-1],len[i].w);
		if(abs(len[i].u-len[i].v)!=1){
			lian=0;
			break;
		}
	}
	if(m==n-1){//finish
		sort(len+1,len+n,cmp);
		cout<<len[1].w;
		return 0;
	}
	if(m==1){//finish
		dfs1(1,0);int fg=1;
		dis[1]=0;
		for(int i=1;i<=n;i++)
			if(dis[i]>dis[fg])
				fg=i;
		memset(dis,0,sizeof(dis));
		dfs1(fg,0);
		sort(dis+1,dis+1+n);
		printf("%d",dis[n]);
		return 0;
	}
	if(barfg==1){//finish
		sort(len+1,len+n,cmp);
		for(int i=1;i<=m*2;i++){
			if(i>=n) break;
			st[++tp]=len[n-i].w;
		}
		sort(st+1,st+tp+1);
		if(m*2<=n-1){
			for(int i=1;i<=m;i++){
				res[++ct]=st[i]+st[m*2-i+1];
			}
			sort(res+1,res+ct+1);
			cout<<res[1];
			return 0;
		}
		else{
			for(int i=1;i<=(n-m-1);i++){
				res[++ct]=st[i]+st[(n-m-1)*2-i+1];
			}
			sort(res+1,res+ct+1);
			cout<<min(res[1],st[2*(n-m-1)+1]);
			return 0;
		}
	}
	if(lian==1){
		int ans=dp(n-1,m);
		cout<<ans;
	}
	return 0;
}
/*
m==1
7 1
1 2 10
1 3 5
2 4 9
2 5 8
3 6 6
3 7 7
ans=31

�ջ�
9 6
1 2 9
1 3 4
1 4 3
1 5 7
1 6 4
1 7 5
1 8 12
1 9 10 
ans=7

line
7 3
1 2 3
2 3 4
3 4 2
4 5 1
5 6 5
6 7 6
ans=6 
*/
