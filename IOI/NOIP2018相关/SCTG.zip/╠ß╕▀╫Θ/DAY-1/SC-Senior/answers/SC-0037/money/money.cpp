#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
inline bool h(int x,int y,int r){
	for(int i=0;i<=r;i+=x) if((r-i)%y==0) return true;
	return false;
}
int t,n,a[110],ans;
bool vis[25010],flag;
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(t);
	while(t--){
		memset(vis,0,sizeof(vis));
		read(n);ans=n;
		for(int i=1;i<=n;++i){
			read(a[i]);
			for(int j=a[i]*2;j<=25000;j+=a[i]) vis[j]=1;
		}
		sort(a+1,a+1+n);
		for(int i=1;i<=n;++i)
			for(int j=1;j<i;++j){
				flag=false;
				for(int k=1;k<=j;++k)
					if(h(a[j],a[k],a[i])){--ans;flag=true;break;}
				if(flag) break;
			}
		printf("%d\n",ans);
	}
	return 0;
}
