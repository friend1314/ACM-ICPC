#include<cstdio>
#include<cstring>
using namespace std;
const int MAXN=50010;
#define sv son[i].v
inline int max(int a,int b){return a>b?a:b;}
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
int n,m,head[MAXN],tu,tv,td,cnt=0,hs[MAXN],f[MAXN][3];
struct ed{int u,v,d,pre;}E[MAXN],son[MAXN];
inline void addedge(int u,int v,int d){
	E[++cnt].u=u;E[cnt].v=v;E[cnt].d=d;E[cnt].pre=head[u];E[cnt].d=d;head[u]=cnt;
}
inline void rooty(int id,int fa){
	for(int i=head[id];i;i=E[i].pre)
		if(E[i].v!=fa)
			rooty(E[i].v,id),
			son[++cnt].u=id,son[cnt].v=E[i].v,son[cnt].d=E[i].d,son[cnt].pre=hs[id],hs[id]=cnt;
}
inline int dp(int id){
	for(int i=hs[id];i;i=son[i].pre) dp(sv);
	int max1=0,max2=0;
	for(int i=hs[id];i;i=son[i].pre)
		if(f[sv][0]>f[son[max2].v][0])
			if(f[sv][0]>f[son[max1].v][0]) max2=max1,max1=i;
			else max2=i;
	if(max1==0) max1=hs[id];
	f[id][0]=f[son[max1].v][0]+son[max1].d;
	f[id][1]=f[son[max1].v][0]+son[max1].d+f[son[max2].v][0]+son[max2].d;
}
inline bool check(int len){
	memset(f,0,sizeof(f));dp(1);
	return(f[1][0]+f[1][1]+f[1][2]>=m);
}
int bs(int l,int r){
	if(l==r) return l;
	int mid=l+r>>1;
	if(check(mid+1)) return bs(mid+1,r);
	return bs(l,mid);
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);f[0][0]=-1;
	for(int i=1;i<n;++i)
		read(tu),read(tv),read(td),
		addedge(tu,tv,td),addedge(tv,tu,td);
	rooty(1,cnt=0);
	if(m==1){
		dp(1);
		printf("%d",max(f[1][0],f[1][1]));return 0;
	}
	printf("%d",bs(0,(5e8)/m));
	return 0;
}
