#include<cstdio>
using namespace std;
inline int min(int a,int b){return a<b?a:b;}
inline int max(int a,int b){return a>b?a:b;}
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
int n,d[200010],ans=0,sm;
struct tr{
	int l,r,mn,sum,lazy;
}node[100010*8];
inline void build(int id,int l,int r){
	node[id].l=l;node[id].r=r;node[id].lazy=0;
	if(l==r){node[id].mn=node[id].sum=d[l];return;}
	int mid=l+r>>1;
	build(id<<1,l,mid);build((id<<1)|1,mid+1,r);
	node[id].mn=min(node[id<<1].mn,node[(id<<1)|1].mn);
	node[id].sum=node[id<<1].sum+node[(id<<1)|1].sum;
}
inline void pushdown(int id){
	node[id<<1].mn-=node[id].lazy;
	node[id<<1].sum-=node[id].lazy*(node[id<<1].r-node[id<<1].l+1);
	node[id<<1].lazy+=node[id].lazy;
	node[(id<<1)|1].mn-=node[id].lazy;
	node[(id<<1)|1].sum-=node[id].lazy*(node[(id<<1)|1].r-node[(id<<1)|1].l+1);
	node[(id<<1)|1].lazy+=node[id].lazy;
	node[id].lazy=0;
}
inline void modify(int id,int l,int r){
	if(node[id].l==l&&node[id].r==r){
		++node[id].lazy;--node[id].mn;node[id].sum-=(node[id].r-node[id].l+1);
		return;
	}
	if(node[id].lazy) pushdown(id);
	int mid=node[id].l+node[id].r>>1;
	if(r<=mid) modify(id<<1,l,r);
	else if(mid<l) modify((id<<1)|1,l,r);
	else modify(id<<1,l,mid),modify((id<<1)|1,mid+1,r);
	node[id].mn=min(node[id<<1].mn,node[(id<<1)|1].mn);
	node[id].sum=node[id<<1].sum+node[(id<<1)|1].sum;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	for(int i=1;i<=n;++i) read(d[i]),d[i+n]=d[i],sm+=d[i];
	n*=2;build(1,1,n);
	while(node[1].sum>sm){
		++ans;
		
	}
	printf("9");
	return 0;
}
