#include <bits/stdc++.h>
using namespace std;
int a[30000],n,t;
int work1()
{
	if(a[2]%a[1]==0||a[1]%a[2]==0)
	{
		printf("1\n");
		return 0;
	}else
	{
		printf("2\n");
		return 0;
	}
}
int work2()
{
	if(a[2]%a[1]==0&&a[3]%a[1]==0)
	{
		printf("1\n");
		return 0;
	}else
	if(a[1]%a[2]==0&&a[3]%a[2]==0)
	{
		printf("1\n");
		return 0;
	}else
	if(a[1]%a[3]==0&&a[2]%a[3]==0)
	{
		printf("1\n");
		return 0;
	}else
	if(a[2]%a[1]!=0&&a[3]%a[1]!=0&&a[1]%a[2]!=0&&a[3]%a[2]!=0&&a[1]%a[3]!=0&&a[2]%a[3]!=0)
	{
		printf("3\n");
		return 0;
	}else
	{
		printf("2\n");
		return 0;
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d",&n);
		for(int j=1;j<=n;j++)
		{
			scanf("%d",&a[j]);
		}
		if(n==2)
		{
			work1();
		}
		if(n==3)
		{
			work2();
		}
	}
	return 0;
}
