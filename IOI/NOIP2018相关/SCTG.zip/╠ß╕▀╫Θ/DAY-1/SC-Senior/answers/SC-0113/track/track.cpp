#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int n=rand()%100;
	printf("%d",n);
	return 0;
}
