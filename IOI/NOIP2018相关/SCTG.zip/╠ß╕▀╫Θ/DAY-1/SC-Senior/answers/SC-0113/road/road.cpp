#include <bits/stdc++.h>
using namespace std;
long long n,a[100010],mn=10010,s=0,m=0,t=0;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int j=1;j<=n;j++)
	{
		m=0;
		t=0;
		mn=10010;
		for(int q=1;q<=n;q++)
		{
			if(a[q]<=0)
			{
				continue;
			}
			mn=min(mn,a[q]);
		}
		for(int k=2;k<=n;k++)
		{
			if(a[k]<=0&&a[k-1]>0)
			{
				m++;
			}
			if(k==n&&a[k]>0)
			{
				m++;
			}
		}
		for(int l=1;l<=n;l++)
		{
			a[l]=a[l]-mn;
			if(a[l]<=0)
			{
				a[l]=0;
				t++;
			}
		}
		s=s+mn*m;
		if(t==n)
		{
			break;
		}
	}
	printf("%lld",s);
	return 0;
}
