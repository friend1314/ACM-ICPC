#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>

#define ll long long 
#define dd double
#define mem(a, b)  memset(a, b, sizeof(a))

using namespace std;

const int N = 30000 + 19;
vector<int> q[N];
int tot, tov[N * 2], nxt[N * 2], h[N], w[N * 2], fa[N], f[N], qq[N];
int fz[N], num, pos, m, n, l, r, mid, root, ans, len;

const bool cmp (int a, int b)  {
	return a > b;
} 

void add (int x, int y, int z)  {
	tot++; tov[tot] = y; nxt[tot] = h[x]; h[x] = tot; w[tot] = z;
	tot++; tov[tot] = x; nxt[tot] = h[y]; h[y] = tot; w[tot] = z;
}

int read (int &x)  {
	x = 0; int f = 1; char s = getchar ();
	while (s < '0' || s > '9')  {if (s == '-')  f = -1; s = getchar ();}
	while (s <= '9' && s >= '0')  {x = x * 10 + s - '0'; s = getchar ();}
	x *= f; return x;
}

void init ()  {
	read (n); read (m);
	for (int i = 1; i < n; i++)  {
		int x, y, z;
		read (x); read (y); read (z);
		add (x, y, z);
		r += z;
	}	root = 1;
}

void dfs (int u, int x)  {
	for (int i = h[u]; i; i = nxt[i])  {
		int v = tov[i];
		if (v == fa[u])  {
			f[u] += w[i];
			continue;
		}
		fa[v] = u;
		dfs (v, x);
		if (u != 1)  q[u].push_back (f[v]);
		else  qq[++qq[0]] = f[v];
	}	len = q[u].size();
	mem (fz, 0);
	for (int i = 0; i < len; i++)  {
		fz[i + 1] = q[u][i];
	}	if (u == 1)  len = qq[0];	
	if (u == 1)  for (int i = 1; i <= qq[0]; i++)  fz[i] = qq[i];	
	sort (fz + 1, fz + 1 + len, cmp);
	pos = 1; int t = len;
	for (int i = 1; i <= n; i++)  {
		if (fz[i] >= x)  num++, pos = i, fz[i] = 0;
		else  break;
	}	
	for (int i = pos; i <= len; i++)  {
		bool flag = 0;
		for (int j = len; j > pos; j--)  {
			if (fz[i] + fz[j] >= x)  {
				num++;
				flag = 1;	
				pos = i + 1;			
				fz[i] = fz[j] = 0;
				break;
			}
		}		
	}	for (int i = 1; i <= t; i++)  if (fz[i])  {
		f[u] += fz[i]; 
		break;
	}
	return ;
}

bool check (int x)  {
	num = 0; mem (f, 0); mem (qq, 0);
	for (int i = 1; i <= n; i++)  q[i].clear ();
	dfs (root, x);
	if (f[1] >= x)  num++;
	if (num >= m)  return 1;
	return 0;
}

void solve ()  {
	while (l <= r)  {
		mid = (l + r) >> 1;
		if (check (mid))  l = mid + 1, ans = mid;
		else  r = mid - 1;
	}	
	printf ("%d", ans);
}

int main ()  {
	freopen ("track.in", "r", stdin);
	freopen ("track.out", "w", stdout);
	init ();
	solve ();
}

/*
7 1
1 2 10
1 3 5
2 4 9
2 5 8
3 6 6
3 7 7
*/
