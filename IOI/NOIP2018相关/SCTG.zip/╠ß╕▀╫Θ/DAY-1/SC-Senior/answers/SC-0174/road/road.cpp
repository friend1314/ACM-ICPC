#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>

#define ll long long 
#define dd double
#define mem(a, b)  memset(a, b, sizeof(a))

using namespace std;

const int N = 1e5 + 19;
const int inf = 1e9 + 7;
int n, a[N], lzw, hy;
ll ans;
bool vis[N];

int read (int &x)  {
	x = 0; int f = 1; char s = getchar ();
	while (s < '0' || s > '9')  {if (s == '-')  f = -1; s = getchar ();}
	while (s <= '9' && s >= '0')  {x = x * 10 + s - '0'; s = getchar ();}
	x *= f; return x;
}

struct Node  {
	int minn, id;
}t[N * 4];

Node mmin (Node a, Node b)  {
	Node rt;
	if (a.minn < b.minn)  rt = a;
	else  rt = b;
	return rt;
}

void build (int o, int l, int r)  {
	if (l == r)  {
		t[o].minn = a[l];
		t[o].id = l;
		return ;
	}	int mid = (l + r) >> 1;
	build (o * 2, l, mid);
	build (o * 2 + 1, mid + 1, r);
	t[o] = mmin (t[o * 2], t[o * 2 + 1]);
}

void init () {
	read (n);
	for (int i = 1; i <= n; i++)  {
		read (a[i]); vis[i] = 1;
	}
	build (1, 1, n);
}

void modify (int o, int l, int r, int L, int R, int delta)  {
	if (l >= L && r <= R)  {
		t[o].minn += delta;
		return ;
	}	int mid = (l + r) >> 1;
	if (mid >= L)  modify (o * 2, l, mid, L, R, delta);
	if (mid < R)  modify (o * 2 + 1, mid + 1, r, L, R, delta);
	t[o] = mmin (t[o * 2], t[o * 2 + 1]);
}

void modify1 (int o, int l, int r, int L, int R, int delta)  {
	if (l >= L && r <= R)  {
		t[o].minn = delta;
		return ;
	}	int mid = (l + r) >> 1;
	if (mid >= L)  modify (o * 2, l, mid, L, R, delta);
	if (mid < R)  modify (o * 2 + 1, mid + 1, r, L, R, delta);
	t[o] = mmin (t[o * 2], t[o * 2 + 1]);
}

void solve ()  {
	lzw = 1;
	for (int i = 1; i <= n; i++)  {
		Node now; now = t[1];
		ans += 1ll * lzw * now.minn;
		if (!vis[now.id + 1] && !vis[now.id - 1])  vis[now.id] = 0, lzw--;
		if (!vis[now.id + 1] || !vis[now.id - 1])  vis[now.id] = 0;
		else  vis[now.id] = 0, lzw++;
		hy += now.minn;
		modify1 (1, 1, n, now.id, now.id, inf);
		modify (1, 1, n, 1, n, -hy);
	}	printf ("%lld", ans);
}

int main ()  {
	freopen ("road.in", "r", stdin);
	freopen ("road.out", "w", stdout);
	init ();
	solve ();
}

/*
6 
4 3 2 5 3 5
*/
