#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>

#define ll long long 
#define dd double
#define mem(a, b)  memset(a, b, sizeof(a))

using namespace std;

const int N = 100 + 19;

int a[N], n, ans;
bool f[2500000 + 19], vis[N];

int read (int &x)  {
	x = 0; int f = 1; char s = getchar ();
	while (s < '0' || s > '9')  {if (s == '-')  f = -1; s = getchar();}
	while (s <= '9' && s >= '0')  {x = x * 10 + s - '0'; s = getchar();}
	x *= f; return x;
}

void init ()  {
	read (n);
	for (int i = 1; i <= n; i++)  {
		read (a[i]);
	}
	sort (a + 1, a + n + 1);
}

void solve ()  {
	mem (f, 0); ans = 0; mem (vis, 0);
	f[0] = 1;
	for (int i = a[1]; i <= a[n]; i++)  {
		for (int j = 1; j <= n; j++)  {
			if (a[j] > i)  break;
			if (f[i])  break;
			if (f[i - a[j]])  vis[j] = 1, f[i] = 1;
		}
	}	for (int i = 1; i <= n; i++)  if (vis[i])  ans++; 
	printf ("%d\n", ans);
}

int main ()  {
	freopen ("money.in", "r", stdin);
	freopen ("money.out", "w", stdout);
	int T;
	read (T);
	while (T--)  {
		init ();
		solve ();
	}
}

/*
1
31
17 43 57 26 55 58 41 48 60 51 46 7 21 50 44 42 27 59 15 36 47 22 40 29 25 35 53 34 56 45 52
*/
