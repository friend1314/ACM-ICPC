#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<vector>
#include<cmath>
using namespace std;
void open(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
}
void close(){fclose(stdin);fclose(stdout);}
int n,ans;
int a[105];
int dp[25005];
int main(){
	open();
	int t;scanf("%d",&t);
	while(t--){
		memset(dp,0,sizeof(dp));
		ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
		sort(a+1,a+1+n);
		dp[0]=1;
		for(int i=1;i<=n;i++){
			if(!dp[a[i]])ans++;
			for(int j=a[i];j<=25000;j++)
			dp[j]|=dp[j-a[i]];
		}
		printf("%d\n",ans);
	}
	close();
	return 0;
}
