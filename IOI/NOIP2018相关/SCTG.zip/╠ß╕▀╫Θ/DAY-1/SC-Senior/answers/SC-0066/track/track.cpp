#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<vector>
#include<cmath>
using namespace std;
void open(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
}
void close(){fclose(stdin);fclose(stdout);}
int main(){
	open();
	
	close();
	return 0;
}
