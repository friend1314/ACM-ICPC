#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<vector>
using namespace std;
void open(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
}
void close(){fclose(stdin);fclose(stdout);}
int n;
int a[100005];
int ans=0;
int work(int l,int r){
	if(l==r)return a[l];
	int m=(r+l)/2;
	int cnt=min(a[m],a[m+1]);
	int sum=work(l,m)+work(m+1,r)-cnt;
	return sum;
}
int main(){
	open();
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	printf("%d\n",work(1,n));
	close();
	return 0;
}
