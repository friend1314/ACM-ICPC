#include<bits/stdc++.h>
using namespace std;
int fcv[ 105 ];
int dp[ 600000 ];
int ans[25];
int n,i;

void work()
{
	cin>>n;
	for( int j = 1 ; j <= n ; j ++ )
	  scanf( "%d" , &fcv[ j ] );
	sort( fcv + 1 , fcv + n + 1 );
	ans[ i ]=n;
	if( n == 1 )
	{
		ans[ i ]=1;
		return;
	}
	for( int j = 1 ; j <= 500000 ; j ++ )
	  dp[ j ]=0;//������ʼ�� 
	for( int j = 1 ; j <= n ; j ++ )//ö����ֵ
	{
	    int flag=true;
		for( int k = 1 ; k <= 500000 ; k ++ )//ö�����п��ܱ���ʾ�����Ľ�� 
          if( k - fcv[ j ] >= 0 && dp[ k - fcv[ j ] ] == 1 && dp[ k ] == 0 )
          {
              dp[ k ]=1;
              flag=false;//ֻҪö�ٳ�һ���µĽ�˵��������ֵ��Ч 
          }
        if( flag )//��Ч 
          ans[ i ]--;
	}
}

void print( int T )
{
	for( int j = 1 ; j <= T - 1 ; j ++ )
	  printf( "%d\n" , ans[ j ] );
	printf( "%d" , ans[ T ] );
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	dp[ 0 ]=1;
	int T;
	cin>>T;
	for( i = 1 ; i <= T ; i ++ )
	  work();
	print( T );
	return 0;
}
