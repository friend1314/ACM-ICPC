#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<cctype>
#include<iostream>
#include<algorithm>
#include<fstream>
#include<queue>
#include<stack>
using namespace std;

typedef long long ll;
int n;
int deep[100086];
int cha[100086];
ll ans;

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i = 1;i <= n; i++)
	   scanf("%d",&deep[i]);
	for(int i = 1;i <= n + 1; i++){
	   cha[i] = deep[i] - deep[i - 1];
	   if(cha[i] < 0) cha[i] = 0 - cha[i]; 
    }
    int l = 1;
	int r = n + 1;
    while(l <= r){
    	if(!cha[l]) l++;
    	if(!cha[r]) r--;
    	if(cha[l] <= cha[r]){
    		ans += cha[l];
    		cha[r] -= cha[l];
    		cha[l] = 0;
    	}
    	else {
    		ans += cha[r];
    		cha[l] -= cha[r];
    		cha[r] = 0;
    	}
    }
    cout<<ans<<endl;
	return 0;
}
