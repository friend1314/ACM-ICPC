#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<cctype>
#include<iostream>
#include<algorithm>
#include<fstream>
#include<queue>
#include<stack>
using namespace std;

typedef long long ll;
int T;
int n,a[105];
int ans;

int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>T;
	while(T--){
	   cin>>n;
	   ans = n;
	   for(int i = 1;i <= n; i++)
	      scanf("%d",&a[i]);
	   sort(a + 1,a+ n +1);
	   int cnt = 2;
	   bool flag = 1;
	   while(flag){
	   	  if(a[cnt]%a[1] == 0){
	   	    ans--;
	   	    cnt++;
	        }
	      else flag = 0;
	   }
	   if(cnt > n){
	   	 ans = 1;
	   }
	   else {
	       ll res = a[1]*a[cnt] - a[1] - a[cnt] + 1;
	       for(int i = cnt + 1;i <= n; i++){
	   	      if(!a[i]%a[1]||!a[i]%a[cnt]) ans--;
	   	      if(a[i] >= res) ans--;
	   	      else continue;
	       }	
       }
	   cout<<ans<<endl;
	}
	return 0;
}
