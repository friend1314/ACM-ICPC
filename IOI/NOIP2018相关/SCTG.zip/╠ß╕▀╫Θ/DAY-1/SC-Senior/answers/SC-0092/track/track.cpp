#include <bits/stdc++.h>
using namespace std;
typedef pair <int,int> pii;

const int RLEN=1<<18|1;
inline char nc() {
	static char ibuf[RLEN],*ib,*ob;
	(ib==ob) && (ob=(ib=ibuf)+fread(ibuf,1,RLEN,stdin));
	return (ib==ob) ? -1 : *ib++;
}
inline int rd() {
	char ch=nc(); int i=0,f=1;
	while(!isdigit(ch)) {if(ch=='-')f=-1; ch=nc();}
	while(isdigit(ch)) {i=(i<<1)+(i<<3)+ch-'0'; ch=nc();}
	return i*f;
}

const int N=1e5+50;
int n,k,g[N],nt[N],vt[N],w[N],ec;
inline void add(int x,int y,int ww) {nt[++ec]=g[x]; g[x]=ec; vt[ec]=y; w[ec]=ww;}

int lim; pii f[N];
typedef multiset <int> :: iterator it_s;
inline void dfs(int x,int fa) {
	multiset <int> cont;
	f[x]=pii(0,0);
	for(int e=g[x];e;e=nt[e]) if(vt[e]^fa) {
		dfs(vt[e],x); 
		f[x].first+=f[vt[e]].first;
		if(f[vt[e]].second+w[e]>=lim) ++f[x].first;
		else cont.insert(f[vt[e]].second+w[e]);
	}
	int mx=0;
	while(cont.size()) {
		int u=*cont.begin();
		cont.erase(cont.begin());
		it_s it=cont.lower_bound(lim-u);
		if(it==cont.end()) mx=max(mx,u);
		else {
			++f[x].first;
			cont.erase(it);
		}
	}
	f[x].second=mx; return;
}
inline bool check(int li) {
	lim=li;
	return dfs(1,0), f[1].first>=k;
}
int main() {
	freopen("track.in","r",stdin);	
	freopen("track.out","w",stdout);	
	n=rd(), k=rd();
	for(int i=1;i<n;i++) {
		int x=rd(), y=rd(), ww=rd();
		add(x,y,ww), add(y,x,ww);
	} 
	int l=0, r=5e8, ans=0;
	while(l<=r) {
		int mid=(l+r)>>1;
		if(check(mid)) ans=mid, l=mid+1;
		else r=mid-1;
	} cout<<ans<<'\n';
}
