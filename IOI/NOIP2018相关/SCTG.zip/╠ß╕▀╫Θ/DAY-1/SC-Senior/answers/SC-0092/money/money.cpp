#include <bits/stdc++.h>
using namespace std;

const int RLEN=1<<18|1;
inline char nc() {
	static char ibuf[RLEN],*ib,*ob;
	(ib==ob) && (ob=(ib=ibuf)+fread(ibuf,1,RLEN,stdin));
	return (ib==ob) ? -1 : *ib++;
}
inline int rd() {
	char ch=nc(); int i=0, f=1;
	while(!isdigit(ch)) {if(ch=='-')f=-1; ch=nc();}
	while(isdigit(ch)) {i=(i<<1)+(i<<3)+ch-'0'; ch=nc();}
	return i*f;
}

const int N=3e4+50;
int n,a[N],mx;
bool g[N];

inline void solve() {
	n=rd();
	for(int i=1;i<=n;i++) a[i]=rd();
	sort(a+1,a+n+1); mx=a[n];
	memset(g,0,sizeof(g));
	
	int m=0; g[0]=1;
	for(int i=1;i<=n;i++) {
		if(g[a[i]]) continue; ++m;
		for(int j=a[i];j<=mx;j++) g[j]|=g[j-a[i]];
	}
	cout<<m<<'\n';
}

int main() {
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	for(int T=rd();T;T--) solve();	
}
