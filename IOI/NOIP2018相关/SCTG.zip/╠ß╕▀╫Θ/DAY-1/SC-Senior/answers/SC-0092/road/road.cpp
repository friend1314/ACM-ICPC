#include <bits/stdc++.h>
using namespace std;

const int RLEN=1<<18|1;
inline char nc() {
	static char ibuf[RLEN],*ib,*ob;
	(ib==ob) && (ob=(ib=ibuf)+fread(ibuf,1,RLEN,stdin));
	return (ib==ob) ? -1 : *ib++;
}
inline int rd() {
	char ch=nc(); int i=0,f=1;
	while(!isdigit(ch)) {if(ch=='-')f=-1; ch=nc();}
	while(isdigit(ch)) {i=(i<<1)+(i<<3)+ch-'0'; ch=nc();}
	return i*f;
}

const int N=1e5+50;
int n,a[N],ans;
int main() {
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=rd();
	for(int i=1;i<=n;i++) a[i]=rd();
	int res=0;
	for(int i=1;i<=n;i++) {
		if(res>=a[i]) res=a[i];
		else ans+=a[i]-res, res=a[i];
	} cout<<ans<<'\n';
}
