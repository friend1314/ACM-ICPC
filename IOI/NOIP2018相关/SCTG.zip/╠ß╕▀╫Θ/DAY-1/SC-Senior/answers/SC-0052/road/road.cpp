#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

typedef long long LL;
typedef pair<int,int> PII;
const int INF = 0x7fffffff,SINF = 0x3f3f3f3f;

int _v,_c,_f;
inline void read(){_v = _f = 0,_c = getchar();while(_c > '9' || _c < '0'){if(_c == '-'){_f = 1;}_c = getchar();}while(_c >= '0' && _c <= '9'){_v = (_v << 3) + (_v << 1) + (_c ^ 48);_c = getchar();}if(_f){_v = -_v;}}

#define RD (read(),_v)
#define PB push_back
#define MP make_pair
#define OPEN(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout)

const int MAXN = 100005,MOD = 1e9+7;

int num,val[MAXN],ans;

int main(){
	OPEN("road");
	num = RD;
	for(int i = 0;i < num;i++){
		val[i] = RD;
		if(!i){
			ans += val[i];
		}else if(val[i] > val[i-1]){
			ans += val[i] - val[i-1];
		}
	}
	printf("%d\n",ans);
	return 0;
}
