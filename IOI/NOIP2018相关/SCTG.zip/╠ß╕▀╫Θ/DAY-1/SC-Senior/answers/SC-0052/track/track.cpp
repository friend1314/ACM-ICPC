#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;							

typedef long long LL;
typedef pair<int,int> PII;
const int INF = 0x7fffffff,SINF = 0x3f3f3f3f;

int _v,_c,_f;
inline void read(){_v = _f = 0,_c = getchar();while(_c > '9' || _c < '0'){if(_c == '-'){_f = 1;}_c = getchar();}while(_c >= '0' && _c <= '9'){_v = (_v << 3) + (_v << 1) + (_c ^ 48);_c = getchar();}if(_f){_v = -_v;}}

#define RD (read(),_v)
#define PB push_back
#define MP make_pair
#define OPEN(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout)

const int MAXN = 50005,MOD = 1e9+7;

struct Edge{
	int t,n,l;
}edge[MAXN * 2];

int head[MAXN],en;

void add_e(int f,int t,int l){
	edge[en].t = t,edge[en].n = head[f],edge[en].l = l,head[f] = en++;
}

int num,lim;

int cnt[MAXN],remain[MAXN];
vector<int> subs[MAXN];

void update(int cur,int mid){
	sort(subs[cur].begin(),subs[cur].end());
	int rt = subs[cur].size() - 1;
	while(rt >= 0 && subs[cur][rt] >= mid){
		subs[cur][rt--] = 0;
		cnt[cur]++;
	}
	int l = 0,r = rt,mxcnt = 0;
	while(l < r){
		if(subs[cur][l] + subs[cur][r] >= mid){
			mxcnt++;
			l++,r--;
		}else{
			l++;
		}
	}
	cnt[cur] += mxcnt;
	int ll = 0,rr = rt,a = -1;
	while(ll <= rr){
		int m = (ll + rr) >> 1;
		int l = 0,r = rt,ccnt = 0;
		while(l < r){
			if(l == m){
				l++;
			}else if(r == m){
				r--;
			}else if(subs[cur][l] + subs[cur][r] >= mid){
				ccnt++,l++,r--;
			}else{
				l++;
			}
		}
		if(ccnt == mxcnt){
			a = m,ll = m + 1;
		}else{
			rr = m - 1;
		}
	}
	remain[cur] = a == -1 ? 0 : subs[cur][a];
}

void dp_work(int mid,int cur = 0,int last = -1){
	cnt[cur] = remain[cur] = 0;
	subs[cur].clear();
	for(int i = head[cur];~i;i = edge[i].n){
		if(edge[i].t != last){
			dp_work(mid,edge[i].t,cur);
			subs[cur].PB(edge[i].l + remain[edge[i].t]);
			cnt[cur] += cnt[edge[i].t];
		}
	}
	update(cur,mid);
}

bool check(int mid){
	dp_work(mid);
	return cnt[0] >= lim;
}

int main(){
	OPEN("track");
	memset(head,-1,sizeof(head));
	num = RD,lim = RD;
	int sum = 0;
	for(int i = 1;i < num;i++){
		int f = RD - 1,t = RD - 1,l = RD;
		add_e(f,t,l),add_e(t,f,l);
		sum += l;
	}
	int l = 1,r = sum / lim,a = 1;
	while(l <= r){
		int mid = (l + r) >> 1;
		if(check(mid)){
			l = mid + 1,a = mid;
		}else{
			r = mid - 1;
		}
	}
	printf("%d\n",a);
	return 0;
}
