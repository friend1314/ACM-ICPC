#include <stdio.h>
int r[100010],id[100010];
int main()
{
	FILE *fin,*fout;
	fin=fopen("road.in","r");
	fout=fopen("road.ans","w");
	int n,f,i,j,k,l,st,cnt,day=0;
	fscanf(fin,"%d",&n);
	for(i=1;i<=n;i++)
		fscanf(fin,"%d",&r[i]);
	cnt=l=i=j=k=0;
	id[0]=0;
	st=1;
	while(cnt<n){
		for(i=1;i<=n;i++){
			if(r[i]!=0){
				st=i;
				break;
			}
		}
		for(i=st;r[i]!=0;i++){
			r[i]--;
			if(r[i]==0){cnt++;}
		}
		day++;
	}
	fprintf(fout,"%d",day);
	fclose(fin);
	fclose(fout); 
	return 0;
}
