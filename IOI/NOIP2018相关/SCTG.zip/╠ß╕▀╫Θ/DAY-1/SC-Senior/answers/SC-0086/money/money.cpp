#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<vector>
#include<cstdio>
#include<queue>
#include<cmath>

#define ll long long
#define lid (id<<1)
#define rid (id<<1|1)
#define mid ((l+r)>>1)
#define fo1(i,a,b) for(register int i= (a);i<=(b);i++)
#define FILE "money"

template<typename T>inline void read(T &x){
	x= 0;
	char ch= getchar();
	bool t= 0;
	for(;!isdigit(ch);ch= getchar())
		if(ch=='-') t= 1;
	for(;isdigit(ch);ch= getchar())
		x= (x<<1)+(x<<3) + ch - 48;
	if(t) x= -x;
}

template<typename T>void write(T x){
	if(x<0) putchar('-'),x= -x;
	if(x>=10) write(x/10);
	putchar(x%10 + 48);
}

template<typename T>inline void outspace(T x){
	write(x), putchar(' ');
}

template<typename T>inline void out10(T x){
	write(x),putchar(10);
}

template<typename T>T gcd(T x,T y){
	return y==0 ? x : gcd(y,x%y);
}

using namespace std;

const int maxn= 111;

int n,a[maxn],b[maxn],c[maxn],cnt;
bool vis[maxn],vh[25052];

inline void build(int t){
	memset(c,0,sizeof c);
	int num= 0,tem= 0;
	for(int i=1;i<=cnt;i++)
		if(b[i]%t==0) c[++num]= b[i]/t;
	for(int i=1;i<=num;i++)
		for(int j=i+1;j<=num;j++){
			if(!vh[c[i]*t] && !vh[c[j]*t]){
				if(tem && c[j]>tem) vh[c[j]*t]= 1; 
				else if(c[j]%a[i]==0) vh[c[j]*t]= 1;
				else if(!tem && gcd(c[i],c[j])==1) tem= c[i]*c[j]-c[i]-c[j];
			}
		}
	
}

inline void solve(){
	sort(a+1,a+n+1);
	int tem= 0;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++){
			if(!vis[i] && !vis[j]){
				if(tem && a[j]>tem) vis[j]= 1; 
				else if(a[j]%a[i]==0) vis[j]= 1;
				else if(!tem && gcd(a[i],a[j])==1) tem= a[i]*a[j]-a[i]-a[j];
			}
		}
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(!vis[i] && !vis[j])
				if(tem && a[j]>tem) vis[j]= 1; 
	for(int i=1;i<=n;i++)
		if(!vis[i]) b[++cnt]= a[i];
		
		
	for(int i=1;i<=cnt;i++)
		for(int j=i+1;j<=cnt;j++){
			tem= gcd(b[i],b[j]);
			if(tem!=1) build(tem);
		}
		
	
	for(int i=1;i<=cnt;i++)
		for(int j=i+1;j<=cnt;j++){
			if(!vh[b[i]] && !vh[b[j]] ){
				tem= b[j]-b[i];
				for(int k=1;k<=cnt;k++){
					if(k==i||k==j) continue;
					if(tem%b[k]==0) vh[b[k]]= 1;
				}
			}
		}
	
	int ans_cnt= 0,ans[maxn];
	for(int i=1;i<=cnt;i++)
		if(!vh[b[i]]) ans[++ans_cnt]= b[i];
	
	out10(ans_cnt);
	
	//fo1(i,1,ans_cnt) outspace(ans[i]);putchar(10);
	
}

inline void init(){
	n= cnt= 0;
	memset(a,0,sizeof a);
	memset(b,0,sizeof b);
	memset(c,0,sizeof c);
	memset(vis,0,sizeof vis);
	memset(vh,0,sizeof vh);
}

int main(){
	freopen(FILE".in","r",stdin);
	freopen(FILE".out","w",stdout);
	
	int T;
	read(T);
	while(T--){
		init();
		
		read(n);
		fo1(i,1,n) read(a[i]);
		solve();
	}
	
	
	return 0;
}
