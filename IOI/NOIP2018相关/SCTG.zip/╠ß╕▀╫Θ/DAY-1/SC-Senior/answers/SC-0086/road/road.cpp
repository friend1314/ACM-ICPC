#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<vector>
#include<cstdio>
#include<queue>
#include<cmath>

#define ll long long
#define lid (id<<1)
#define rid (id<<1|1)
#define mid ((l+r)>>1)
#define fo1(i,a,b) for(register int i= (a);i<=(b);i++)
#define FILE "road"

template<typename T>inline void read(T &x){
	x= 0;
	char ch= getchar();
	bool t= 0;
	for(;!isdigit(ch);ch= getchar())
		if(ch=='-') t= 1;
	for(;isdigit(ch);ch= getchar())
		x= (x<<1)+(x<<3) + ch - 48;
	if(t) x= -x;
}

template<typename T>void write(T x){
	if(x<0) putchar('-'),x= -x;
	if(x>=10) write(x/10);
	putchar(x%10 + 48);
}

using namespace std;

const int maxn= 1e5+7;

int n,pre,ans;
int a[maxn];

inline void init(){
	ans= 0;
}

int main(){
	freopen(FILE".in","r",stdin);
	freopen(FILE".out","w",stdout);
	
	init();
		
	read(n);
	fo1(i,1,n){
		read(a[i]);
		if(pre<a[i]) pre= a[i];
		else if(pre>a[i]) ans+= (pre-a[i]), pre= a[i];
	}
	ans+= pre;
	
	write(ans);
	
	
	return 0;
}
