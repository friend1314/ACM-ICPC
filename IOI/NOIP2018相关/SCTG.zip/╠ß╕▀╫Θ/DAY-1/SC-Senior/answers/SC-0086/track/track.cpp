#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<vector>
#include<cstdio>
#include<queue>
#include<cmath>

#define ll long long
#define lid (id<<1)
#define rid (id<<1|1)
#define mid ((l+r)>>1)
#define fo1(i,a,b) for(register int i= (a);i<=(b);i++)
#define FILE "track"

template<typename T>inline void read(T &x){
	x= 0;
	char ch= getchar();
	bool t= 0;
	for(;!isdigit(ch);ch= getchar())
		if(ch=='-') t= 1;
	for(;isdigit(ch);ch= getchar())
		x= (x<<1)+(x<<3) + ch - 48;
	if(t) x= -x;
}

template<typename T>void write(T x){
	if(x<0) putchar('-'),x= -x;
	if(x>=10) write(x/10);
	putchar(x%10 + 48);
}

template<typename T>inline void outspace(T x){
	write(x), putchar(' ');
}

template<typename T>inline void out10(T x){
	write(x),putchar(10);
}

using namespace std;

const int maxn= 50011;

int n,m,mi,opt;
vector<int> e[maxn],dis[maxn];

inline void add_edge(int from,int to,int d){
	e[from].push_back(to);
	dis[from].push_back(d);
}

int fa[maxn],dep[maxn];

void dfs(int x){
	for(register int i=0;i<e[x].size();i++){
		register int v= e[x][i];
		if(!fa[v]) fa[v]= x, dfs(v), dep[x]= max(dep[x],dep[v]+dis[x][i]);
	}
}

inline void solve1(){
	fa[1]= 1;
	dfs(1);
	int second= 0;
	for(register int i=0;i<e[1].size();i++){
		register int v= e[1][i];
		if(dep[v]+dis[1][i] == dep[1]) continue;
		second= max(second,dep[v]+dis[1][i]);
	}
	out10(second+dep[1]);
}

int f[1024][1024],len[maxn];
inline void solve2(){
	fo1(i,2,n)
		f[i][1]= len[i];
	fo1(i,2,n){
		fo1(j,1,min(i-1,m)){
			fo1(k,1,i-1){
				f[i][j]= max(f[i][j], min(f[k][j-1] , len[i]-len[k]) );
			}
		}
	}
	
	out10(f[n][m]);	
}

bool cmp(int x,int y){
	return x>y;
}

int ans[maxn],c[maxn],cnt= 0;
inline void solve3(){
	sort(c+1,c+n+1,cmp);
	for(int i=m+1,j=m;j;i++,j--){
		ans[++cnt]= c[i]+c[j];
	}
	sort(ans+1,ans+cnt+1);
	
	out10(ans[1]);
	
	//for(int i=1;i<=n-1;i++)
	//	outspace(ans[i]);
}

inline void init(){
	mi= 1e9;
	opt= 1;
}

int main(){
	freopen(FILE".in","r",stdin);
	freopen(FILE".out","w",stdout);
	
	read(n),read(m);
	init();
	for(int i=1,a,b,l;i<n;i++){
		read(a),read(b),read(l);
		add_edge(a,b,l);
		add_edge(b,a,l);
		mi= min(mi,l);
		c[i]= l;
		len[i+1]= len[i]+l;
		if(a!=1) opt= 0; 
	}
	
	if(m==n-1) out10(mi);
	else if(opt) solve3();
	else if(m==1) solve1();
	else solve2();
	
	
	
	
	return 0;
}
