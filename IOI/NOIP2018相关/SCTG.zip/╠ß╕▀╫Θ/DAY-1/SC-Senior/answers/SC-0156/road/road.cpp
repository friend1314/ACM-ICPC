#include <cstdio>
#include <algorithm>
using namespace std;
typedef long long ll;

const int MAXN = 1e5 + 100;

struct node
{
	int u, h;
};

node a[MAXN];
int root[MAXN];
int h[MAXN];
int lb[MAXN], rb[MAXN];
int n;
ll ans = 0;

bool operator<( node a, node b )
{
	if ( a.h != b.h )
		return a.h > b.h;
	else
		return a.u < b.u;
}

int find( int u )
{
	if ( u == root[u] )
		return u;
	else
	{
		int rt = find( root[u] );
		rb[rt] = max( rb[rt], rb[u] );
		lb[rt] = min( lb[rt], lb[u] );
		return rt;
	}
}

int main( )
{
	freopen( "road.in", "r", stdin );
	freopen( "road.out", "w", stdout );
	scanf( "%d", &n );
	for ( int i = 1; i <= n; i++ )
	{
		scanf( "%d", &h[i] );
		a[i] = (node){ i, h[i] };
	}
	sort( a + 1, a + n + 1 );

	for ( int i = 1; i <= n; i++ )
		root[i] = lb[i] = rb[i] = i;
	int i = 1;
	while ( i <= n )
	{
		int l = i;
		while ( a[i].h == a[l].h )
			i++;
		int r = i - 1;
		for ( int j = l + 1; j <= r; j++ )
			if ( a[j].h == a[j-1].h 
				&& ( lb[find(a[j].u)] == rb[find(a[j-1].u)] + 1	
				|| rb[find(a[j].u)] == lb[find(a[j-1].u)] - 1 ) )
			{
				root[find(a[j].u)] = find( a[j-1].u );
				find( a[j].u );
			}
		for ( int j = l; j <= r; j++ )
		{
			int tar = max( h[find(lb[find(a[j].u)]-1)],
					h[find(rb[find(a[j].u)]+1)] );
			if ( h[find( a[j].u )] > tar )
			{
				ans += h[find( a[j].u )] - tar;
				h[find( a[j].u )] = tar;
			}
		}
		for ( int j = l; j <= r; j++ )
		{
			if ( h[find( a[j].u )] == h[find(lb[find(a[j].u)]-1)] )
				root[find( a[j].u )] = find(lb[find(a[j].u)]-1);
			if ( h[find( a[j].u )] == h[find(rb[find(a[j].u)]+1)] )
				root[find( a[j].u )] = find(rb[find(a[j].u)]+1);
			find( a[j].u );
		}
	}
	ans += h[find(1)];

	printf( "%lld\n", ans );
	return 0;
}
