#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int MAXN = 15 + 1, P = 5000 + 10;
int a[MAXN];
bool b[P];

int main( )
{
	freopen( "money.in", "r", stdin );
	freopen( "money.out", "w", stdout );
	int T;
	scanf( "%d", &T );
	while ( T-- )
	{
		int n;
		scanf( "%d", &n );
		int maxv = 0;
		for ( int i = 0; i < n; i++ )
		{
			scanf( "%d", &a[i] );
			maxv = max( maxv, a[i] );
		}

		int ans = n;
		for ( int s1 = 0; s1 < 1 << n; s1++ )
		{
			memset( b, 0, sizeof b );
			b[0] = 1;
			int cnt = 0;
			for ( int i = 0; i < n; i++ )
				if ( s1 & 1 << i )
					cnt++;
			for ( int s2 = s1; s2 > 0; s2 = s2 - 1 & s1 )
			{
				int t = 0;
				for ( int i = 0; i < n; i++ )
					if ( s2 & 1 << i )
						t += a[i];
				b[t] = 1;
			}
			for ( int i = 1; i <= maxv; i++ )
				for ( int j = 1; j <= i && i + j <= maxv; j++ )
					if ( b[i] && b[j] )
						b[i+j] = 1;
			for ( int i = 0; i < n; i++ )
				if ( b[a[i]] == 0 )
				{
					cnt = n;
					break;
				}
			ans = min( ans, cnt );
		}

		printf( "%d\n", ans );
	}
	return 0;
}
