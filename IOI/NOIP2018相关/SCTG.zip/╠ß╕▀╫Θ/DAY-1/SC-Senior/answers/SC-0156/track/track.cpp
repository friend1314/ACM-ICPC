#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 5e4 + 10, INF = 1e9 + 7;
struct edge
{ 
	int u, v, ne, l;
};
edge e[MAXN << 1];
int fe[MAXN], eid;
int n, m;

inline void adde( int a, int b, int l )
{
	e[++eid] = (edge) { a, b, fe[a], l }, fe[a] = eid;
}

namespace task1 // m = 1: ��ֱ��
{
	int dis, fur;

	void dfs( int u, int f, int d )
	{
		if ( d > dis )
			dis = d, fur = u;
		for ( int i = fe[u]; i != 0; i = e[i].ne )
		{
			int v = e[i].v, l = e[i].l;
			if ( v == f )
				continue;
			dfs( v, u, d + l );
		}
		return;
	}

	int main( )
	{
		dis = fur = 0;
		dfs( 1, 0, 0 );
		int u = fur;
		dis = fur = 0;
		dfs( u, 0, 0 );
		printf( "%d\n", dis );
		return 0;
	}
}

namespace task2 // �ջ�ͼ: 
{
	bool cmp( edge a, edge b )
	{
		return a.l < b.l;
	}

	int check( int k )
	{
		int len = 0, cnt = 0;
		int N = eid / 2;
		for ( int i = 1; i <= N; i++ )
		{
			int p = i & 1 ? i + 1 >> 1 : N - i / 2 + 1;
			len += e[p].l;
			if ( len >= k )
				len = 0, cnt++;
		}
		return cnt;
	}

	int main( )
	{
		for ( int i = 1; i <= eid; i++ )
			if ( e[i].u != 1 )
				e[i].l = INF;
		sort( e + 1, e + eid + 1, cmp );
		int l = 1, r = INF;
		while ( l < r )
		{
			int mid = l + r + 1 >> 1;
			if ( check( mid ) >= m )
				l = mid;
			else
				r = mid - 1;
		}
		printf( "%d\n", l );
		return 0;
	}
}

namespace task3 // һ����: ���ִ�
{
	bool cmp( edge a, edge b )
	{
		if ( a.u != b.u )
			return a.u < b.u;
		else
			return a.v < b.v;
	}

	int check( int k )
	{
		int cnt = 0, len = 0;
		for ( int i = 1; i <= eid; i++ )
			if ( e[i].v > e[i].u )
			{
				len += e[i].l;
				if ( len >= k )
					cnt++, len = 0;
			}
		return cnt;
	}

	int main( )
	{
		sort( e + 1, e + eid + 1, cmp );
		int l = 1, r = INF;
		while ( l < r )
		{
			int mid = l + r + 1 >> 1;
			if ( check( mid ) >= m )
				l = mid;
			else
				r = mid - 1;
		}
		printf( "%d\n", l );
		return 0;
	}
}

namespace task4 // m > (n-1)/2: ֱ�������ı�
{
	inline int max( int a, int b )
	{
		return a > b ? a : b;
	}

	int main( )
	{
		int ans = 0;
		for ( int i = 1; i <= eid; i += 2 )
			ans = max( ans, e[i].l );
		printf( "%d\n", ans );
		return 0;
	}
}

int main( )
{
	freopen( "track.in", "r", stdin );
	freopen( "track.out", "w", stdout );
	scanf( "%d %d", &n, &m );
	eid = 0;
	bool t2 = 1, t3 = 1;
	for ( int i = 1; i < n; i++ )
	{
		int a, b, l;
		scanf( "%d %d %d", &a, &b, &l );
		adde( a, b, l ), adde( b, a, l );
		if ( a != 1 )
			t2 = 0;
		if ( b != a + 1 )
			t3 = 0;
	}
	if ( m == 1 )
		task1::main( );
	else if ( m * 2 > n - 1 )
		task4::main( );
	else if ( t2 == 1 )
		task2::main( );
	else if ( t3 == 1 )
		task3::main( );
	return 0;
}
