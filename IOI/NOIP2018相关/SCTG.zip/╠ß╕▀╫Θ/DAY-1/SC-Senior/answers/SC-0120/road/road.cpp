#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstdlib>
#define re register
using namespace std;
typedef long long ll;
inline int read()
{
	int f=1,x=0;char c=getchar();
	while(c>'9'||c<'0'){	if(f=='-')f=-1;	   c=getchar();	}
	while(c>='0'&&c<='9'){	x=(x<<1)+(x<<3)+c-'0';	c=getchar();	}
	return f*x;
}
inline int max(int a,int b){return a>b?a:b;}
inline int min(int a,int b){return a<b?a:b;}
int n,d[100001],ans=0,minn=1<<30,maxx=0;
int cx(int lie)
{
	re int res=0;
	for(re int i=1;i<=n;i++)
	{
		if(d[i]<lie&&d[i-1]>=lie)++res;
	}
	if(d[n]>=lie)++res;
	return res;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(re int i=1;i<=n;i++)
		d[i]=read(),minn=min(minn,d[i]),maxx=max(maxx,d[i]);
	ans+=minn;
	re int lie=minn;
	for(re int i=1;i<=maxx-minn;i++)
	{
		lie++;
		int c=cx(lie);
		ans+=c;
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
