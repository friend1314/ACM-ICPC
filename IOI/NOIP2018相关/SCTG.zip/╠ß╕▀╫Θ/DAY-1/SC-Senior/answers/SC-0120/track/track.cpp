#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstdlib>
#define re register
using namespace std;
int n,m,s,head[30001],en,depth[30001],f[30001][18];
int max1=1<<30,max0=1<<30,sum=0;
//priority_queue<int,vector<pair<int,int> >,greater<pair<int,int> > >q;
/*struct Edge
{
	int v,w,next;
}e[60001];*/
/*void add(int u,int v,int w)
{
	en++;
	e[en].v=v;
	e[en].w=w;
	e[en].next=head[u];
	head[u]=en;
}*/
/*void dfs(int u,int fa)
{
	depth[u]=depth[fa]+e[u].w;
	for(int i=1;(1<<i)<=n;i++)
		f[u][i]=f[f[u][i-1]][i-1];
	for(int i=head[u];i!=-1;i=e[i].next)
	{
		int v=e[i].v;
		if(v!=fa)
		{
			dfs(v,u);
		}
	}
}*/
/*int lca(int x,int y)
{
	if(depth[x]<depth[y])swap(x,y);
	for(int i=18;i>=0;i--)
	{
		if(depth[x]>=depth[y])x=f[x][i];
	}
	if(f[x][0]==f[y][0])return f[x][0];
	for(int i=18;i>=0;i--)
	{
		if(f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
	}
	return f[x][0];
}
*/
inline int read()
{
	int f=1,x=0;char c=getchar();
	while(c>'9'||c<'0'){	if(f=='-')f=-1;	   c=getchar();	}
	while(c>='0'&&c<='9'){	x=(x<<1)+(x<<3)+c-'0';	c=getchar();	}
	return f*x;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read();m=read();
	memset(head,-1,sizeof(head));
	for(int i=1;i<=m;i++)
	{
		int u,v,w;
		u=read(),v=read(),w=read();
		sum+=w;
		if(max1>w)
		{
			max0=max1;
			max1=w;
		}
	}
	if(m==n-1){
		printf("%d\n",max1);
	}
	else if(m==1){
		printf("%d\n",sum);
	}
	else{
		printf("%d\n",max1+max0);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
