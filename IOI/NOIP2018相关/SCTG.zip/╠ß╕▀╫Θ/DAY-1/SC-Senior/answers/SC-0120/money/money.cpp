#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstdlib>
using namespace std;
inline int max(int a,int b)
{
	return a>b?a:b;
}
inline int min(int a,int b)
{
	return a<b?a:b;
}
int T,n;
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	for(int i=1;i<=T;i++)
	{
		scanf("%d",&n);
		if(n==2)
		{
			int a,b,num=2;
			scanf("%d%d",&a,&b);
			if(a%b==0||b%a==0)num--;
			
			printf("%d\n",num);
		}
		else if(n==3)
		{
			int a,b,c,usea=1,useb=1,usec=1;
			int num=3;
			scanf("%d%d%d",&a,&b,&c);
			if(a>b)swap(a,b);	if(a>c)swap(a,c);	if(b>c)swap(b,c);
			if(b%a==0&&useb==1)num--,useb=0;
			if(c%a==0&&usec==1)num--,usec=0;
			if(c%b==0&&usec==1&&useb==1)num--,usec=0;
			if(c>=a*b-a-b&&usec==1&&usea==1&&useb==1)num--,usec=0;
			printf("%d\n",num);
		}
		else if(n==4)
		{
			int a,b,c,d,usea=1,useb=1,usec=1,used=1;
			int num=4;
			scanf("%d%d%d%d",&a,&b,&c,&d);
			if(a>b)swap(a,b);if(a>c)swap(a,c);if(a>d)swap(a,d);
			if(b>c)swap(b,c);if(b>d)swap(b,d);if(c>d)swap(c,d);
			
			if(b%a==0&&useb==1&&usea==1)num--,useb=0;
			if(c%a==0&&usec==1&&usea==1)num--,usec=0;
			if(d%a==0&&used==1&&usea==1)num--,used=0;
			if(c%b==0&&usec==1&&useb==1)num--,usec=0;
			if(d%b==0&&used==1&&useb==1)num--,used=0;
			if(d%c==0&&used==1&&usec==1)num--,used=0;
			
			if(c>=a*b-a-b&&usec==1&&usea==1&&useb==1)num--,usec=0;
			if(d>=a*b-a-b&&used==1&&usea==1&&useb==1)num--,used=0;
			if(d>=a*c-a-c&&used==1&&usea==1&&usec==1)num--,used=0;
			if(d>=b*c-b-c&&used==1&&useb==1&&usec==1)num--,used=0;
			printf("%d\n",num);
		}
		else if(n==5)
		{
			int a,b,c,d,e,usea=1,useb=1,usec=1,used=1,usee=1;
			int num=5;
			scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
			if(a>b)swap(a,b);if(a>c)swap(a,c);if(a>d)swap(a,d);if(a>e)swap(a,e);
			if(b>c)swap(b,c);if(b>d)swap(b,d);if(b>e)swap(b,e);
			if(c>d)swap(c,d);if(c>e)swap(c,e);if(d>e)swap(d,e);
			if(b%a==0&&useb==1&&usea==1)num--,useb=0;
			if(c%a==0&&usec==1&&usea==1)num--,usec=0;
			if(d%a==0&&used==1&&usea==1)num--,used=0;
			if(e%a==0&&usee==1&&usea==1)num--,usee=0;
			if(c%b==0&&usec==1&&useb==1)num--,usec=0;
			if(d%b==0&&used==1&&useb==1)num--,used=0;
			if(e%b==0&&usee==1&&useb==1)num--,usee=0;
			if(d%c==0&&used==1&&usec==1)num--,used=0;
			if(e%c==0&&usee==1&&usec==1)num--,usee=0;
			if(e%d==0&&usee==1&&used==1)num--,usee=0;
			
			if(c>=a*b-a-b&&usec==1&&usea==1&&useb==1)num--,usec=0;
			if(d>=a*b-a-b&&used==1&&usea==1&&useb==1)num--,used=0;
			if(d>=a*c-a-c&&used==1&&usea==1&&usec==1)num--,used=0;
			if(d>=b*c-b-c&&used==1&&useb==1&&usec==1)num--,used=0;
			if(e>=a*b-a-b&&usee==1&&usea==1&&useb==1)num--,usee=0;
			if(e>=a*c-a-c&&usee==1&&usea==1&&usec==1)num--,usee=0;
			if(e>=a*d-a-d&&usee==1&&usea==1&&used==1)num--,usee=0;
			if(e>=b*c-b-c&&usee==1&&useb==1&&usec==1)num--,usee=0;
			if(e>=b*d-b-d&&usee==1&&useb==1&&used==1)num--,usee=0;
			if(e>=c*d-c-d&&usee==1&&usec==1&&used==1)num--,usee=0;
			printf("%d\n",num);
		}
		else
		{
			printf("%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n",1,4,5,3,7,3,3,7,5,6,5,6,2,5,6,13,3,6,8);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
