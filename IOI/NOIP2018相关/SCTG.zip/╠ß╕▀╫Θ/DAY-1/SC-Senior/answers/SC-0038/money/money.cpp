#include<bits/stdc++.h>
using namespace std;
int n,T;
long long a[110];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();
	}
	return x*f;
}
int gcd(int x,int y)
{
	if(y==0) return x;
	return gcd(y,x%y);
}
void csr2()
{
	int t=gcd(a[1],a[2]);
	if(t==a[1]||t==a[2])
	{
		printf("1\n");
		return;
	}
	printf("2\n");
}

void csrORZ()
{
	int ans=n;
	for(int i=1;i<n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(a[j]%a[i]==0) 
			{
				ans--;
				break;	
			}
		}
	}
	printf("%d\n",ans);
} 

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	T=read();
	while(T--)
	{
		memset(a,0,sizeof(a));
		n=read();
		for(int i=1;i<=n;i++)
		{
			a[i]=read();
		}
		if(n==2) csr2();
		if(n>2) csrORZ();
	}
	return 0;
}
