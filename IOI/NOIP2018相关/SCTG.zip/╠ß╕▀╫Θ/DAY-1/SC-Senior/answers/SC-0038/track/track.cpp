#include<bits/stdc++.h>
using namespace std;
#define MAXN 50010
int n,m;
int indeg[MAXN],outdeg[MAXN];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();
	}
	return x*f;
}
struct edge
{
	int next,to,v;
}ei[MAXN<<1];
int cnt,head[MAXN];
inline void add(int a,int b,int v)
{
	ei[++cnt].to=b;
	ei[cnt].v=v;
	ei[cnt].next=head[a];
	head[a]=cnt;
	indeg[b]++;
	outdeg[a]++;
}
int trdfs(int u,int fa,int f)
{
	int ans1=0,ans2=0;
	for(int i=head[u];i;i=ei[i].next)
	{
		int to=ei[i].to;
		int v=ei[i].v;
		if(to==fa) continue;
		int dist=trdfs(to,u,f);
		dist+=v;
		if(ans1<dist)
		{
			ans2=ans1;
			ans1=dist;
		}else 
		{
			if(dist>ans2) ans2=dist;
		}
	}
	if(u==f) return ans1+ans2;
	return ans1;
}
void csr1()
{
	int f=0;
	for(int i=1;i<=n;i++)
	{
		if(indeg[i]>1)
		{
			f=i;
			break;
		}
	}
	printf("%d",trdfs(f,0,f));
	return;
}

void csr2()
{
	int ans=0x3f3f3f3f;
	for(register int i=1;i<=cnt;i++)
	{
		ans=min(ans,ei[i].v);
	}
	printf("%d",ans);
	return;
}






int checklian(int x)
{
	int num=0,now=0,mi=0x3f3f3f3f;
	for(int k=1;k<n;k++)
	{
		for(int i=head[k];i;i=ei[i].next)
		{
			int to=ei[i].to;
			int v=ei[i].v;
			if(to<k) continue;
			now+=v;
			if(v>=x)
			{
				num++;
				mi=min(mi,now);
				now=0;
			}
		}
	}
	if(num<m) return 1;
	return 0;
}
void csrlian()
{
	int l=0,r=600000000;
	while(l<r)
	{
		int mid=(l+r)/2;
		if(checklian(mid))
		{
			r=mid;
		}else l=mid+1;
	}
	printf("%d",r-1);
	return;
}
void csrhua()
{
	int ans=0x3f3f3f3f;
	vector<int> vc;
	for(int i=1;i<=cnt;i++)
	{
		int to=ei[i].to;
		if(to==1) continue;
		vc.push_back(ei[i].v);
	}
	sort(vc.begin(),vc.end());
	int l=vc.size();
	while(l>m*2)
	{
		vc.erase(vc.begin());
		l--;
	}
	while(l<m*2)
	{
		ans=min(ans,vc.back());
		vc.erase(vc.end()-1);
		m--;
		l--;
	}
	while(l)
	{
		int a=vc.at(0);
		int b=vc.back();
		vc.erase(vc.begin());
		vc.erase(vc.end()-1);
		a+=b;
		ans=min(ans,a);
		l-=2;
	}
	printf("%d",ans);
	return;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	int a,b,v;
	int lian=1;//�� 
	int hua=1;//�� 
	n=read();m=read();
	for(register int i=1;i<n;i++)
	{
		a=read();b=read();v=read();
		if(b!=a+1) lian=0;
		if(a!=1) hua=0;
		add(a,b,v);
		add(b,a,v);
	}
	if(m==1)
	{
		csr1();
		return 0;
	}
	if(m==n-1)
	{
		csr2();
		return 0;
	} 
	if(lian)
	{
		csrlian();
		return 0;
	}
	if(hua)
	{
		csrhua();
		return 0;
	}
	srand(1000);
	printf("%d",ei[rand()%((n-1)*2)+1].v+ei[rand()%((n-1)*2)+1].v);
	return 0;
}
