#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n;
int a[100001];
bool b[100001]={1};
int dayhe=0;
int main()
{
	cout<<dayhe;
}
