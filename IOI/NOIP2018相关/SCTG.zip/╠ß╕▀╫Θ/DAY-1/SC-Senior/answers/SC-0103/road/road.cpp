#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n;
int a[100001];
bool b[100001];
int dayhe=0;
int c;
void dfs(int x,int y)
{
	for(int j=1;j<=y;j++)
	 {
	   if(a[1]!=0&&a[j]!=0)
	    {
	    a[j]=a[j]-1;
	    dayhe++;
	    dfs(1,y);
		}
	   if(a[j]-1==0)
	     dayhe++;
	     a[j]=a[j]-1;
	     dfs(1,y);
       if(a[j]==0);
       break;
	    
	     
     }

}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
    cin>>a[i];
    dfs(1,n);
	return 0;
}
