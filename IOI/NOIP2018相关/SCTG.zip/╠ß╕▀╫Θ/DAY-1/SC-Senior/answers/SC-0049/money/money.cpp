#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int t,n;
struct mc{
	int v;
}data[105];
int bag[25005]={0};
int dp(const mc &a,const mc &b)
{
	return a.v>b.v;
}
void csh(int x)
{
	bag[0]=1;
	for(int i=1;i<=x;i++)
		bag[i]=0;
}
int search(int star,int m)
{
	for(int k=star;k<=n;k++)
		for(int l=data[k].v;l<=m;l++)
		{
			bag[l]+=bag[l-data[k].v];
			if(bag[data[star-1].v]!=0) return 1;
		}
	return 0;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	for(int T=1;T<=t;T++)
	{
		cin>>n;
		int total=n;
		for(int i=1;i<=n;i++)
			cin>>data[i].v;
		
		sort(data+1,data+n+1,dp);
		
		for(int i=1;i<n;i++)
		{
			csh(data[i].v);
			int m=search(i+1,data[i].v);
			if(m==1) total--;
		}
		cout<<total<<endl;
	}
	return 0;
}

