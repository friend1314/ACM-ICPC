#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int n,ans;
struct mc{
	int high;
}data[100005];
int f=-1;
int j;
int high_max;
int main()
{ 
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>data[i].high;
	data[n+1].high=0;
	for(int i=1;i<=n;i++)
	{

		if(data[i-1].high<=data[i].high&&data[i].high>data[i+1].high)
		{
			if(i==n) f=1;
			high_max=data[i].high;
			ans=ans+high_max-j;
		}
		else if(data[i-1].high>=data[i].high&&data[i].high<=data[i+1].high)
		{
			j=data[i].high;
		}
	}
	cout<<ans;
	return 0;
}

