#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int n,m;
struct mc{
	int u,v,w;
}data[50005];
int dis[50005]={99999999};
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>data[i].u>>data[i].v>>data[i].w;
	dis[1]=0;
	for(int i=1;i<=n-1;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(dis[data[j].v]>dis[data[j].u]+data[j].w) dis[data[j].v]=dis[data[j].u]+data[j].w;
		}
	}
	cout<<dis[n];
	return 0;
}

