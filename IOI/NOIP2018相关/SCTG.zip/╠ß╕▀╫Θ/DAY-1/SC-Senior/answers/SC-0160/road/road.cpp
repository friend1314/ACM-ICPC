#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5;
int read()
{
	int ans=0;bool f=0;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=1;ch=getchar();}
	while(ch>='0' and ch<='9'){ans=(ans<<1)+(ans<<3)+(ch^48);ch=getchar();}
	return f?~ans+1:ans;
}
int t,n,a[maxn],ans;
struct sd{
	int l,r,ls,rs,pos,datamax,datamin,f;
}tr[maxn<<1];
struct node{
	int a,b;
};
int nw(int l,int r)
{
	tr[++t]=(sd){l,r,0,0,0,0,0,0};
	return t;
}
void xf(int o)
{
	if(tr[o].f)
	{
		tr[o].datamax+=tr[o].f;
		tr[o].datamin+=tr[o].f;
		tr[tr[o].ls].f+=tr[o].f;
		tr[tr[o].rs].f+=tr[o].f;
		tr[o].f=0;
	}
}
void gx(int o)
{
	xf(o),xf(tr[o].ls),xf(tr[o].rs);
	tr[o].datamax=max(tr[tr[o].ls].datamax,tr[tr[o].rs].datamax);
	if(tr[tr[o].ls].datamin<=tr[tr[o].rs].datamin)
	tr[o].pos=tr[tr[o].ls].pos;
	else
	tr[o].pos=tr[tr[o].rs].pos;
	tr[o].datamin=min(tr[tr[o].ls].datamin,tr[tr[o].rs].datamin);
}
void build(int o)
{
	if(tr[o].l==tr[o].r)
	{
		tr[o].datamax=tr[o].datamin=a[tr[o].l];
		tr[o].pos=tr[o].l;
		return;
	}
	int mid=tr[o].l+tr[o].r>>1;
	build(tr[o].ls=nw(tr[o].l,mid));
	build(tr[o].rs=nw(mid+1,tr[o].r));
	gx(o);
}
void xg(int o,int l,int r,int c)
{
	xf(o);
	if(tr[o].l==l and tr[o].r==r)
	{
		tr[o].f+=c;
		return;
	}
	int mid=tr[o].l+tr[o].r>>1;
	if(r<=mid)
	xg(tr[o].ls,l,r,c);
	else
	if(l>mid)
	xg(tr[o].rs,l,r,c);
	else
	xg(tr[o].ls,l,mid,c),xg(tr[o].rs,mid+1,r,c);
	gx(o);
}
int cxmax(int o,int l,int r)
{
	xf(o);
	if(tr[o].l==l and tr[o].r==r)
		return tr[o].datamax;
	int mid=tr[o].l+tr[o].r>>1;
	if(r<=mid)
	return cxmax(tr[o].ls,l,r);
	else
	if(l>mid)
	return cxmax(tr[o].rs,l,r);
	else
	return max(cxmax(tr[o].ls,l,mid),cxmax(tr[o].rs,mid+1,r));
}
node cxmin(int o,int l,int r)
{
	xf(o);
	if(tr[o].l==l and tr[o].r==r)
		return (node){tr[o].datamin,tr[o].pos};
	int mid=tr[o].l+tr[o].r>>1,hh1,hh2;
	if(r<=mid)
	return cxmin(tr[o].ls,l,r);
	else
	if(l>mid)
	return cxmin(tr[o].rs,l,r);
	else
	{
		node ans1=cxmin(tr[o].ls,l,mid),ans2=cxmin(tr[o].rs,mid+1,r);
		if(ans1.a<=ans2.a)
			return ans1;
		else
			return ans2;
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();
	for(int i=1;i<=n;++i)
	a[i]=read();
	build(nw(1,n+1));	
	int l=1,r=n+1;
	while(l!=n+1)
	{
		while(l!=r)
		{
			node h=cxmin(1,l,r-1);
			if(h.a>0)
			{
				ans+=h.a;
				xg(1,l,r-1,-h.a);
				
			}
			else
			r=h.b;
		}
		while(cxmax(1,l,l)==0 and l<=n)l++;
		r=n+1;
	}
	cout<<ans;
}
