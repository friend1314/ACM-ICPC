#include<bits/stdc++.h>
#include<vector>
using namespace std;
const int maxn=2e5+100;
int read()
{
	int ans=0;bool f=0;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=1;ch=getchar();}
	while(ch>='0' and ch<='9'){ans=(ans<<1)+(ans<<3)+(ch^48);ch=getchar();}
	return f?~ans+1:ans;
}
int n,m,u,v,w,dis[maxn],maxx,pos;
bool vis[maxn];
struct sd{
	int to,val;
};
vector<sd>g[maxn];
void bfs(int s)
{
	memset(dis,0,sizeof(dis));
	memset(vis,0,sizeof(vis));
	queue<int>q;
	q.push(s);
	vis[s]=1;
	maxx=0,pos=0;
	while(!q.empty())
	{
		int now=q.front();q.pop();
		for(int i=0;i<g[now].size();++i)
		{
			int to=g[now][i].to,val=g[now][i].val;
			if(vis[to])
			continue;
			dis[to]=dis[now]+val;
			if(dis[to]>=maxx)
			maxx=dis[to],pos=to;
			q.push(to);vis[to]=1;
		}
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<n;++i)
	{
		u=read(),v=read(),w=read();
		g[u].push_back((sd){v,w});
		g[v].push_back((sd){u,w});
	}
		bfs(1);bfs(pos);
		cout<<maxx<<endl;
	return 0;
}
