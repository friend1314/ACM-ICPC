#include<bits/stdc++.h>
using namespace std;
const int maxn=200;
const int maxx=25001;
int read()
{
	int ans=0;bool f=0;char ch=getchar();
	while(ch<'0' or ch>'9'){if(ch=='-')f=1;ch=getchar();}
	while(ch>='0' and ch<='9'){ans=(ans<<1)+(ans<<3)+(ch^48);ch=getchar();}
	return f?~ans+1:ans;
}
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
int t,n,a[maxn],minn,ans,b[maxn],cnt;
bool vis[maxx];
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	t=read();
	while(t--)
	{
		ans=0;
		cnt=0;
		n=read();
		minn=maxx;
		memset(vis,0,sizeof(vis));
		vis[0]=1;
		for(int i=1;i<=n;++i)
		a[i]=read();
		sort(a+1,a+1+n);
		for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
		if(gcd(a[i],a[j])==1)
		minn=min(minn,a[i]*a[j]-(a[i]+a[j]));
		for(int i=1;i<=n;++i)
		{
			if(a[i]>minn)
			break;
			if(!vis[a[i]])
			{
				for(int j=1;;++j)
				if(j*a[i]<=minn)
				vis[j*a[i]]=1;
				else
				break;
				b[++cnt]=a[i];
				int hh=cnt;
				for(int j=1;j<=hh;++j)
				for(int k=0;b[j]*k<=minn;++k)
				for(int f=0;f*a[i]+b[j]*k<=minn;++f)
				if(!vis[f*a[i]+b[j]*k])
					vis[f*a[i]+b[j]*k]=1,b[++cnt]=f*a[i]+b[j]*k;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
