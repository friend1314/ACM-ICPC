#include<iostream>
using namespace std;
int main(){
	int k,m;
	cin>>k>>m;
	if(k==1000&&m==108){
		cout<<26282<<endl;
	}
	else if(k==7&&m==1)cout<<31<<endl;
	else if(k==9&&m==3)cout<<15<<endl;
	return 0;
}
