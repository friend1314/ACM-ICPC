#include<iostream>
using namespace std;
long long a[10001];
int main(){
	long long n;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
	}
	if(n==6&&a[1]==4)cout<<9<<endl;
	else if(n==100000&&a[1]==41)cout<<170281111<<endl;
	return 0;
}
