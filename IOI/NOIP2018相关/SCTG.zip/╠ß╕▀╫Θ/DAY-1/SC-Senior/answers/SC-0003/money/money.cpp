#include<cstdio>
#include<iostream>
using namespace std;
int t,n,a[100001,m;
int min()
{
	cin>>t;
	while(t>0)
	{
		cin>>n;
		for(int i=1;i<=n;++i)
		{
			cin>>a[i];
		}
		for(int k=1;k<=n;++k)
		for(int i=1;i<=1000;++i)
		for(int j=2;j<=1000;++j)
		{
			if(i+j==a[k])
		cout<<"2"<<endl;
		if(a[k]%a[k+1]==1)
		cout<<"1"<<endl;
	
		}	
	}
	return 0;
}
