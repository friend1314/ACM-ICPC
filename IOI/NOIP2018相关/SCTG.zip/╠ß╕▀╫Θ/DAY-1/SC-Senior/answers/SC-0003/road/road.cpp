#include<cstdio>
#include<iostream>
using namespace std;
int d[100005],n,ans=0,temp=1;
int add(int l,int r)
{
	int min=100001;
	for(int i=l;i<=r;++i)
		if(d[i]<min)
		min=d[i];
	for(int i=l;i<=r;++i)
		d[i]=d[i]-min;
	ans+=min;
	
	if(temp<=n)
	{
		if(d[temp]==0)
		{
		while(d[temp]==0&&temp<n)
		temp++;
		if(temp<=n)
		add(temp,n);
		else
		return ans;
		}
		else
		{
		for(int i=l;i<=r;++i)
			if(d[i]==0)
		add(temp,i-1);
		}	
	}
}	
int main()
{
//	freopen ("road.in","r",stdin);
//	freopen("road.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;++i)
		cin>>d[i];
	
	cout<<add(temp,n)<<endl;	
	return 0;
}
