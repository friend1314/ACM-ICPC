#include<cstdio>
#include<cstring>
#include<algorithm>
#include<algorithm>
#include<vector>
#define LL long long
using namespace std;
const int maxn = 2e5 + 5;
int n, num[maxn], mx, now, lt;
int blk[maxn];
vector<int > ton[maxn];
LL ans;
void del(int pos) {
	blk[pos] = 1;
	if(blk[pos - 1] ^ blk[pos + 1]) lt = lt;
	else if(blk[pos - 1] == 0) ++lt;
	else --lt;
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d", &n), blk[0] = blk[n + 1] = 1;
	for(register int i = 1; i <= n; ++i) {
		scanf("%d", &num[i]), mx = max(mx, num[i]);
		ton[num[i]].push_back(i);
	}
	lt = 1;
	for(register int i = 0; i <= mx; ++i) {
		//if(!ton[i].size()) continue;
		for(register int j = ton[i].size() - 1; j >= 0; --j) {
			del(ton[i][j]);
		}
		ans += lt;
		//printf("#%d %d:", lt, ans);
		//for(register int i = 1; i <= n; ++i)
			//printf("%d ", blk[i]);
		//putchar('\n');
	}
	printf("%lld", ans);
	return 0;
}
