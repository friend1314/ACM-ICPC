#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn = 1e5 + 5;
struct edge {
	int v, w, next;
} e[maxn << 1];
int head[maxn], cnt, n, m, u, v, w, mx[maxn];
void adde(const int &u, const int &v, const int &w) {
	e[++cnt] = (edge) {v, w, head[u]};
	head[u] = cnt;
}

int stk[maxn], tp;
int check2(int x, int pos, int n) {
	int ret = 0;
	int f = 1, b = n;
	while(1) {
		if(f == pos) {++f; continue;}
		if(b == pos) {--b; continue;}
		if(f == b) return ret;
		if(f > b) return ret; 
		if(stk[f] + stk[b] < x) ++f;
		else ++ret, ++f, --b;
	}
}
int solve2(int l, int r, int x, int exp, int n) {
	while(l < r - 1) {
		int mid = l + r >> 1;
		if(check2(x, mid, n) >= exp) l = mid;
		else r = mid; 
	}
	return l;
}

int work(int u, int p, int x, int & ans) {
	tp = 0;
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(v == p) continue;
		stk[++tp] = mx[v] + e[i].w;
	}
	if(!tp) return 0;
	sort(stk + 1, stk + tp + 1);
	int f = 1, b = tp, mx = 0;
	while(f <= b && stk[b] >= x) ++ans, --b;
	int exp = check2(x, 0, b); ans += exp;
	int nmx = stk[solve2(0, b + 1, x, exp, b)];
	return nmx;
}

void dfs(int u, int p, int x, int & ans) {
	for(register int i = head[u]; i; i = e[i].next) {
		int v = e[i].v;
		if(v == p) continue;
		dfs(v, u, x, ans);
	}
	mx[u] = work(u, p, x, ans);
}

bool check(int x) {
	int ans = 0;
	dfs(1, 0, x, ans);
	return ans >= m;
}

int solve(int l, int r) { // [l, r)
	while(l < r - 1) {
		int mid = l + r >> 1;
		if(check(mid)) l = mid;
		else r = mid;
	}
	return l;
}

int main() {
	freopen("track.in", "r", stdin);
	freopen("track.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(register int i = 1; i < n; ++i) {
		scanf("%d%d%d", &u, &v, &w);
		adde(u, v, w), adde(v, u, w);
	}
	printf("%d", solve(0, 1e9));
	return 0;
}
