#include<cstdio>
#include<bitset>
#include<cstring>
#include<algorithm>
#define For(i, a, b) for(register int i = a; i <= b; ++i)
#define Down(i, a, b) for(register int i = a; i >= b; --i)
using namespace std;
int pre[105][25005], suf[105][25005];
const int maxn = 105;
int n, num[maxn], t, ans, mx;

int query(int x) {
	for(register int i = 0; i <= num[x]; ++i)
		if(pre[x - 1][i] && suf[x + 1][num[x] - i])
			return true;
	return false;
}

int main() {
	freopen("money.in", "r", stdin);
	freopen("money.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		memset(pre, 0, sizeof(pre));
		memset(suf, 0, sizeof(suf));
		scanf("%d", &n), ans = n, mx = 0;
		For(i, 1, n) {
			scanf("%d", &num[i]);
			mx = max(mx, num[i]);
		}
		pre[0][0] = 1;
		For(i, 1, n) {
			For(j, 0, mx) pre[i][j] |= pre[i - 1][j];
			For(j, 0, mx - num[i]) pre[i][j + num[i]] |= pre[i][j];
		}
		suf[n + 1][0] = 1;
		Down(i, n, 1) {
			For(j, 0, mx) suf[i][j] |= suf[i + 1][j];
			For(j, 0, mx - num[i]) suf[i][j + num[i]] |= suf[i][j];
		}
		For(i, 1, n) 
			if(query(i)) 
				--ans;
		printf("%d\n", ans);
	}
	return 0;
}
