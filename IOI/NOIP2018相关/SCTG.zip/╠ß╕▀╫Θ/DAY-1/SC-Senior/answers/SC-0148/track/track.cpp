#include<cstdio>
#include<iostream>
using namespace std;
typedef long long LL;
int read()
{
	int sum = 0 , f = 1;
	char q = getchar();
	while(!(q >= '0' && q <= '9'))
	{
		if(q == '-')
			f = -1;
		q = getchar();
	}
	while(q >= '0' && q <= '9')
	{
		sum = sum * 10 + q - '0';
		q = getchar();
	}
	return sum * f;
}
void print(int x)
{
	if(x < 0)
	{
		putchar('-');
		x = -x;
	}
	if(x >= 10)
	{
		print(x / 10);
	}
	putchar(x % 10 + '0');
}
bool r[50001];
int dep[50001] , minl = 1e9 , su[50001];
int n , m , h[50001] , nxt[100001] , to[100001] , sum[100001] , cnt , cnt1 , dis[50001][17] , f[50001][17];
void add(int x , int y , int z)
{
	cnt++;
	nxt[cnt] = h[x];
	h[x] = cnt;
	to[cnt] = y;
	sum[cnt] = z;
}
void pre(int x , int fa)
{
	dep[x] = dep[fa] + 1;
	f[x][0] = fa;
	for(int i = 0 ; i <= 15 ; i = i + 1)
		f[x][i + 1] = f[f[x][i]][i];
	for(int i = 0 ; i <= 15 ; i = i + 1)
		dis[x][i + 1] = dis[x][i] + dis[f[x][i]][i];
	for(int i = h[x] ; i ; i = nxt[i])
	{
		int t = to[i];
		if(t != fa)
		{
			r[x] = 1;
			dis[t][0] = sum[i];
			pre(t , x);
		}
	}
}
int LCA(int x , int y)
{
	if(dep[x] < dep[y])
		swap(x , y);
	for(int i = 16 ; i >= 0 ; i = i - 1)
	{
		if(dep[f[x][i]] >= dep[y])
			x = f[x][i];
		if(x == y)
			return x;
	}
	for(int i = 16 ; i >= 0 ; i = i - 1)
	{
		if(f[x][i] != f[y][i])
		{
			x = f[x][i];
			y = f[y][i];
		}
	}
	return f[x][0];
}
int get(int num , int pos)
{
	int ans = 1e9;
	for(int i = pos + 1 ; i < n ; i = i + 1)
	{
		ans = min(ans , get(num - 1 , i) + su[i]);
	}
	return ans;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	n = read();
	m = read();
	int a , b , c;
	for(int i = 1 ; i < n ; i = i + 1)
	{
		a = read();
		b = read();
		c = read();
		add(a , b , c);
		add(b , a , c);
		su[i] = c;
		minl = min(minl , c);
	}
	if(m == 1)
	{
		int sum = 0 , pos = 0;
		pre(1 , 0);
		for(int i = 1 ; i <= n ; i = i + 1)
		{
			if(!r[i])
			{
				for(int j = i + 1 ; j <= n ; j = j + 1)
				{
					if(!r[j])
					{
						int t = LCA(i , j);
						if(t == 1)
							sum = max(sum , dis[i][16] + dis[j][16]);
					}
				}
			}
		}
		print(sum);
	}
	else if(m == n - 1)
	{
		print(minl);
	}
	else
	{
		int q = (n - 1) / m;
		if(m * q == n - 1)
		{
			print(get(m , 1) + su[1]);
		}
		else
		{
			print(get((n - 1) % m , 1) + su[1]);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

