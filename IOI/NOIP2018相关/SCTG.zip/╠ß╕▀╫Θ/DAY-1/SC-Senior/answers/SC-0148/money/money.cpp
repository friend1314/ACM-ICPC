#include<cstdio>
#include<algorithm>
using namespace std;
typedef long long LL;
int read()
{
	int sum = 0 , f = 1;
	char q = getchar();
	while(!(q >= '0' && q <= '9'))
	{
		if(q == '-')
			f = -1;
		q = getchar();
	}
	while(q >= '0' && q <= '9')
	{
		sum = sum * 10 + q - '0';
		q = getchar();
	}
	return sum * f;
}
void print(int x)
{
	if(x < 0)
	{
		putchar('-');
		x = -x;
	}
	if(x >= 10)
	{
		print(x / 10);
	}
	putchar(x % 10 + '0');
}
int a[1001];
bool pd(int x , int pos)
{
	if(x == 0)
		return 1;
	for(int i = 1 ; i < pos ; i = i + 1)
	{
		if(x % a[i] == 0)
			return 1;
		for(int j = 1 ; j <= x / a[i] ; j = j + 1)
		{
			if(pd(x - j * a[i] , i))
				return 1;
		}
	}
	return 0;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	int t = read();
	while(t--)
	{
		int n = read();
		int ans = n;
		for(int i = 1 ; i <= n ; i = i + 1)
			a[i] = read();
		sort(a + 1 , a + n + 1);
		if(a[1] == 1)
		{
			print(1);
			putchar('\n');
		}
		else
		{
			for(int i = 2 ; i <= n  ; i = i + 1)
			{
				if(pd(a[i] , i))
					ans--;
			}
			print(ans);
			putchar('\n');
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

