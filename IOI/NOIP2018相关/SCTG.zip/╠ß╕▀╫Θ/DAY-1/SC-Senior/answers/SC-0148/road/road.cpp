#include<cstdio>
#include<iostream>
using namespace std;
typedef long long LL;
int read()
{
	int sum = 0 , f = 1;
	char q = getchar();
	while(!(q >= '0' && q <= '9'))
	{
		if(q == '-')
			f = -1;
		q = getchar();
	}
	while(q >= '0' && q <= '9')
	{
		sum = sum * 10 + q - '0';
		q = getchar();
	}
	return sum * f;
}
void print(int x)
{
	if(x < 0)
	{
		putchar('-');
		x = -x;
	}
	if(x >= 10)
	{
		print(x / 10);
	}
	putchar(x % 10 + '0');
}
int n , a[100001];
bool vis[100001];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n = read();
	for(int i = 1 ; i <= n ; i = i + 1)
	{
		a[i] = read();
	}
	int minn , pos = 0 , ans = 0;
	while(1)
	{
		minn = 1e9;
		for(int i = 1 ; i <= n ; i = i + 1)
		{
			if(a[i] <= 0 || a[i] > minn)
				continue;
            minn = a[i];
            pos = i;
		}
		if(minn == 1e9)
			break;
		ans += minn;
		for(int i = pos ; i >= 1 ; i = i - 1)
		{
			if(a[i] == 0)
				break;
			a[i] -= minn;
		}
		for(int i = pos + 1 ; i <= n ; i = i + 1)
		{
			if(a[i] == 0)
				break;
			a[i] -= minn;
		}
	}
	print(ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

