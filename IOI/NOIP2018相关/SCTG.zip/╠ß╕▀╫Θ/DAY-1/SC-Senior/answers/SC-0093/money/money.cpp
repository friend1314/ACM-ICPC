#include<cstdio>
#include<cstring>
#include<algorithm>
template<typename _Tp>
inline void read(_Tp& x){
	int f=1;x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	x*=f;
}

int buf[45];
template<typename _Tp>
inline void print(_Tp x){
	if(!x) return static_cast<void>(putchar('0'));
	if(x<0) putchar('-'),x=-x;
	while(x) buf[++buf[0]]=x%10,x/=10;
	while(buf[0]) putchar(buf[buf[0]--]+'0');
}

template<typename _Tp>
inline void println(_Tp x){
	print(x),putchar('\n');
}

#define TEST(x) freopen(x".in","r",stdin),freopen(x".out","w",stdout)

/*
�ڶ�����ѧ�Ҵ�
��Ȼ��������Ļ���ϵͳ�����һ�ֻ����ܹ��������ֻ��ұ�ʾ��,
��ô��ö���Ҿ���Ȼûʲô��,����ɾ����
�������֮���޷���ʾ,��ֻ��ȫ�̸����� 
*/

template<typename _Tp>
_Tp gcd(_Tp m,_Tp n){
	while (n){
		_Tp t=m%n;
		m=n;
		n=t;
	}
	return m;
}

template<typename _Tp>
_Tp lcm(_Tp m,_Tp n){
	return (m*n)/gcd(m,n);
}

const int maxn=105;

int a[maxn];

int ans_ton[25607];

int del[25607];

int total_ans,max_val;

int n;

int T;

int main(){
	TEST("money");
//	freopen("write.out","w",stdout);
	read(T);
	while(T--){
		memset(ans_ton,0,sizeof ans_ton);
		memset(del,0,sizeof del);
		memset(a,0,sizeof a);
		read(n);
		total_ans=0;
		max_val=0;
		for(int i=1;i<=n;i++) read(a[i]),max_val=std::max(max_val,a[i]);
		std::sort(a+1,a+n+1);
	//	for(int i=1;i<=n;i++){
	//		if(del[a[i]]) continue;
	//		for(int j=1;j<=n;j++){
	//			if(i!=j && !del[a[i]] && !(a[j]%a[i])){
	//				del[a[i]]=1,total_ans--;
	//				break;
	//			}
	//		}
	//		if(!del[a[i]]) max_val=std::max(max_val,a[i]);
	//	}
	
//		printf("%d\n",max_val);
		
		
		for(int i=1;i<=n;i++){
//			printf("\nnow check %d\n",a[i]);
//			for(int i=1;i<=max_val;i++) printf("del[%d]=%d ",i,del[i]);
//			puts("");
			for(int j=2;a[i]*j<=max_val;j++) {
				del[a[i]*j]=1;
//				printf("dd[%d] ",a[i]*j);
			}
			for(int j=1;j<=max_val;j++){
//				if(!del[j]) continue;
				if(del[j] && gcd(a[i],j)==1){
					for(int k=1;j+(k*a[i])<=max_val;k++){
						del[k*a[i]+j]=1;
//						printf("dd:%d(del[%d]=%d)+%d*%d=[%d] ",j,j,del[j],k,a[i],k*a[i]+j);
					}
				}
			}
			for(int j=1;j<=n;j++){
				if(i!=j && !del[a[j]]){
					for(int k=1;a[j]+(k*a[i])<=max_val;k++){
						del[k*a[i]+a[j]]=1;
//						printf("dd:%d(del[%d]=%d)+%d*%d=[%d] ",j,j,del[j],k,a[i],k*a[i]+j);
					}
				}
			}
		}
//		for(int i=1;i<=n;i++){
//			for(int j=2;a[i]*j<=max_val;j++) del[a[i]*j]=1;
//			for(int j=1;j<=max_val;j++){
//				if(del[j] && gcd(a[i],j)==1){
//					for(int k=1;j+(k*a[i])<=max_val;j++) del[k*a[i]+j]=1;
//				}
//			}
//		}
		for(int i=1;i<=n;i++){
			if(!del[a[i]]){
//				print(a[i]),putchar(' ');
				total_ans++;
			}
		}
		println(total_ans);		
	}

	return 0;
}
