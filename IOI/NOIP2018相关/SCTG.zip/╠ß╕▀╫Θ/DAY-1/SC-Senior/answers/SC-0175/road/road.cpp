#include<bits/stdc++.h>
using namespace std;
int c[100000]={0};
int main()
{
	int a,b,d,e,g,i;
	long long f;
	cin>>g;
	cin>>c[i];
	b=c[0]>c[1]?c[1]:c[0];
	a=c[0]>c[1]?1:0;
	for(int i=0;i<g;i++)
	{
	  b=b>c[i]?c[i]:b;
	  a=b>c[i]?i:a;
  	}
	f=b;
	d=c[0]>c[1]?c[0]:c[1];
	for(int i=0;0<i<=a;i++)
	  d=d>c[i]?d:c[i];
	f=f+(d-b);
    e=c[a+1]>c[a+2];
	for(int i=a+1;a<i<g;i++)
	  e=e>c[i]?e:c[i];
	f=f+(e-b);
	cout<<f<<endl;
	return 0;
}
