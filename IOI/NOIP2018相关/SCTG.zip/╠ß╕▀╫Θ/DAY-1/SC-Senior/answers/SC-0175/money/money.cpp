#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n;
	cin>>a;
	cin>>b;
    cin>>c>>d>>e>>f;
    cin>>g;
    cin>>h>>i>>j>>k>>l;
    if(b==4)
      m=2;
    if(g==5)
      n=5;
    cout<<m<<endl;
    cout<<n<<endl;
	return 0;
}
