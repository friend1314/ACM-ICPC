#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u;
	cin>>a>>b;
	cin>>c>>d>>e;
	cin>>f>>g>>h;
	cin>>i>>j>>k;
	cin>>l>>m>>n;
	cin>>o>>p>>q;
	cin>>r>>s>>t;
	if(a==7)
	  u=31;
	cout<<u<<endl;
	return 0;
}
