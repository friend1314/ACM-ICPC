#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>
#include <map>
#include <vector>
#define re register int
#define ll long long
using namespace std;
inline void read(int &x)
{
	x=0;int f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}
inline void print(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
int a[100010],n;
int ans;
inline void dfs(int st,int ed,int tmp)
{
	if(st>ed) return;
	if(st==ed){
		ans+=a[st];
		return;
	}
	int minn1=9999999,minn2=9999999;
	int k1,k2;
	for(re i=st;i<tmp;i++){
		if(a[i]<minn1){
			minn1=a[i];k1=i;
		}
	}
	for(re i=tmp+1;i<=ed;++i){
		if(a[i]<minn2){
			minn2=a[i];k2=i;
		}
	}
	for(re i=st;i<tmp;i++)	a[i]-=minn1;
	for(re i=tmp+1;i<=ed;++i) a[i]-=minn2;
	if(minn1==9999999&&minn2!=9999999) ans+=minn2;
	else if(minn1!=9999999&&minn2==9999999) ans+=minn1;
	else if(minn1!=9999999&&minn2!=9999999) ans+=(minn1+minn2); 
	dfs(st,tmp-1,k1);
	dfs(tmp+1,ed,k2);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	read(n);
	int minn=999999,tmp;
	for(re i=1;i<=n;++i){
		read(a[i]);
		if(a[i]<minn){
			minn=a[i];tmp=i;
		}
	}
	for(re i=1;i<=n;++i) a[i]-=minn;
	ans=minn;
	dfs(1,n,tmp);
	print(ans);
	return 0;
}
