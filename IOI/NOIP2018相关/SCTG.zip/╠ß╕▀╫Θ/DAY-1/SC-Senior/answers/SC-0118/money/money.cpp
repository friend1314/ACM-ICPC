#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>
#include <map>
#include <vector>
#define re register int
#define ll long long
using namespace std;
inline void read(int &x)
{
	x=0;int f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}
inline void print(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
const int inf=999999;
int T,n,cnt=0,tot;
int a[200],b[200];
inline void delet()
{
	bool flag=0;
	cnt++;
	b[cnt]=a[1];
	for(re i=2;i<=n;++i){
		for(re j=1;j<=cnt;++j){
			if(a[i]%b[j]==0){
				tot--;a[i]=inf;
				flag=1;
			}
		}
		if(!flag){
			cnt++;b[cnt]=a[i];
		}
	}
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n);tot=n;
		bool ok=0;
		for(re i=1;i<=n;++i){
			read(a[i]);
			if(a[i]==1) ok=1;
		}
		if(ok==1){
			puts("1");continue;
		}
		if(n==1)
		{
			puts("1");continue;
		}
		if(n==2){
			if(a[1]%a[2]==0||a[2]%a[1]==0){
				puts("1");continue;
			}
		}
		stable_sort(a+1,a+n+1);
		delet();
		print(tot);
		puts("");
	}
	return 0;
}
