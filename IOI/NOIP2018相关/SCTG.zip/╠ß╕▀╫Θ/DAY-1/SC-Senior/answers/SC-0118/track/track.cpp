#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>
#include <map>
#include <vector>
#define re register int
#define ll long long
using namespace std;
inline void read(int &x)
{
	x=0;int f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9'){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=f;
}
inline void print(int x)
{
	if(x<0){x=-x;putchar('-');}
	if(x>9) print(x/10);
	putchar(x%10+'0');
}
struct dl{
	int ed;
	int next;
	int v;
}e[100000];
int head[100000],cnt=0;
inline void add(int a,int b,int x)
{
	cnt++;
	e[cnt].ed=b;
	e[cnt].v=x;
	e[cnt].next=head[a];
	head[a]=cnt;
}
int n,m;
int maxn=0,kk;
inline void dfs(int x,int fa,int path)
{
	if(path>maxn){
		maxn=path;kk=x;
	}
	for(re i=head[x];i;i=e[i].next)
	{
		int to=e[i].ed;
		if(to==fa) continue;
		dfs(to,x,path+e[i].v);
	}
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	read(n);read(m);
	int a,b,x;
	for(re i=1;i<n;++i){
		read(a);read(b);read(x);
		add(a,b,x);add(b,a,x);
	}
	dfs(1,-1,0);
	dfs(kk,-1,0);
	print(maxn);
	return 0;
}
