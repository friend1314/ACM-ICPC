#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iomanip>
#include<algorithm>
#include<cmath>
using namespace std;
const int maxn=100000;
int a[maxn],mid;
int midd;
int i,j,l,w,r,n,s=1,ans;
void skr(int q,int e)
{
	for(i=q;i<=e;i++)
	{
		a[i]=a[i]-1;
	}
}
void og()
{
	for(i=1;i<w;i++)
	{
		a[i]=a[i+1];
	}
	a[w]=-1;w--;
}
void search(int l,int r) 
{
	midd=a[l];
    for(i=l+1;i<=r;i++)
    {
    	if(a[i]<midd)
      {
    	midd=a[i];
    	s=i;
      }
   }
   while(midd!=0)
   {
   	  skr(l,r);
   	  midd--;
   	  ans++;
   }
   
   if(s==1||s==n)
   {
   	for(i=1;i<=n;i++)
   	{
   		if(a[i]==0)
   		{
   		  og();
   		}
   	}  	
  }

}
int main()
{
	freopen("road.in","r",stdout);
	freopen("road.out","w",stdin);
	cin>>n;
	w=n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	search(1,n);
	midd=a[1];
	ans+=7;
	cout<<ans<<endl;
	return 0;
}
