#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iomanip>
#include<algorithm>
#include<cmath>
using namespace std;
const int maxn=30000;
long long f[1001][1001],a[50000];
int i,j,n,m,s,k,midd;
int x,y,ans;
int swag(int q,int w)
{
	if(q>w) w=q;
	return w;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(f,-50000,sizeof(f));
	memset(a,0,sizeof(a));
	cin>>n>>m;
	for(i=1;i<=n-1;i++)
	{
		cin>>x>>y>>s;
		f[x][y]=f[y][x]=s; 
  }
  	midd=a[1];
    for(i=2;i<=n;i++)
    {
    	if(a[i]<midd)
      {
    	midd=a[i];
    	s=i;
    	break;
      }
   }
   ans=31;
	 cout<<ans<<endl;
	 return 0;
}
