#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iomanip>
#include<algorithm>
#include<cmath>
using namespace std;
const int maxn=100000;
int a[25001],b[25001];
int i,j,n,m,s,t;
int lcd(int x,int y)
{
	int r;
	r=y%x;
	while(r!=0)
    {
      	y=x;
      	x=r;
      	r=y%x;
    } 
    return x;
}
int cmp(int q,int e)
{
	return q>e;
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
    cin>>t;
    for(j=1;j<=t;j++)
    {
    cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+n+1,cmp);
	s=lcd(a[1],a[2]);
	if(s==1)
	{
		m=2;
	}  
     else
    {
		m=1;
	}
	cout<<m<<endl;
	m=1;
    }
	return 0;
}
