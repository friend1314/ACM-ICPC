#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,a[105];
bool cmp(int x,int y)
{
	return x<y;
}
bool pd(int x,int y)
{
	int i=1;
	while(x*i<y)
	{
		if(x*i==y)
		{
			return 1;
		}
		i++;
	}
	return 0;
}
void solve2()
{
	int x=a[1],i=1,y=a[2];
	if(a[1]>a[2])
	{
		x=a[2];
		y=a[1];
	}
	while(x*i<y)
	{
		if(x*i==y)
		{
			printf("1\n");
			return;
		}
		i++;
	}
	printf("2\n");
}
void solve3()
{
	sort(a+1,a+3+1,cmp);
	int x=a[1],y=a[2],z=a[3];
	if(pd(x,y)==1 && pd(x,z)==1)
	{
			printf("1\n");
			return;
	}
}
void solve4()
{
	
}
int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	cin>>t;
	while(t--)
	{
		int n;
		scanf("%d",&n);
		memset(a,0,sizeof(a));
		for(int i=1;i<=n;i++)
		{
			cin>>a[i];
		}
		if(n==1) printf("1\n");
		if(n==2) solve2();
		if(n==3) solve3();
		if(n==4) solve4();
	}
}
