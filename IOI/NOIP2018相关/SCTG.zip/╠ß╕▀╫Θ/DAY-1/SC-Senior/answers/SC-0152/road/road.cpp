#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a[100009],n,ans=0,minn=0x7fffff;
void dfs(int l,int r,int cnt,int flag)
{
	if(r<l&&flag==1)
	{
		ans--;
		return;
	}
	if(r<l) return;
	if(a[l]==a[l-1])
	{
		dfs(l+1,r,cnt,2);
		return;
	}
	int x=0;
	for(int i=l;i<=r;i++)
	{
		if(a[i]==cnt)
		{
			x=i;
			break;
		}
	}
	if(x==0)
	{
		ans++;
		dfs(l,r,cnt+1,2);
		return;
	}
	
	ans++;
	dfs(l,x-1,cnt+1,1);
	
	dfs(x+1,r,cnt,2);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		if(a[i]<minn) minn=a[i];
	}
	int y=minn;
	ans=minn;
	dfs(1,n,y,1);
	printf("%d",ans);
}
