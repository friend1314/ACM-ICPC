#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
typedef long long int ll;
int bit[200010];
int n,a[200010];
ll re=0;
int lowbit(int x){
	return x&(-x);	
}
void add(int i,int x){
	while(i<=n){
		bit[i]+=x;
		i+=lowbit(i);
	}
}
ll sum(int i){
	ll s=0;
	while(i>0){
		s+=bit[i];
		i-=lowbit(i);
	}
	return s;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);;
		add(i,a[i]-a[i-1]);
	}
	for(int i=1;i<=n;i++){
	if(sum(i)-sum(i-1)>0) re+=(sum(i)-sum(i-1));
	}
	printf("%lld",re);
	return 0;
}
