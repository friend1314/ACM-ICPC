#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<iostream>
using namespace std;
typedef long long int ll;
const int INF=0x3f;
struct tree{
	int dest,next,val;
}tr[100010];
int n,m,top=0;
ll mx=0;
ll dis[1100][1100];
void floyd(){
	for(int k=1;k<=n;k++){
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(dis[i][k]<INF&&dis[k][j]<INF&&dis[i][j]>dis[i][k]+dis[k][j])
				dis[i][j]=dis[i][k]+dis[k][j];
			}
		}
	}
}
int main(){
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	memset(dis,INF,sizeof(dis));
	scanf("%d%d",&n,&m);
	for(int i=1,u,v,val;i<n;i++){
		scanf("%d%d%d",&u,&v,&val);
		dis[u][v]=dis[v][u]=val;
	}
	floyd();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			mx=max(mx,dis[i][j]);
		}
	}
	cout<<mx;
	return 0;
}
