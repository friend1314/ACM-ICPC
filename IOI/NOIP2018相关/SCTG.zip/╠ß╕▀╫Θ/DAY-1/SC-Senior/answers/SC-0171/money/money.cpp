#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long int ll;
int a[200]={0},dp[210][210],map[36000];
int T,n,big;
void _find(int big){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
				while(dp[i][j]+a[j]<=big){
					dp[i][j]+=a[j];
					map[dp[i][j]]=1;
			}
		}
	}
}
int main(){
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(dp,0,sizeof(dp));
		memset(map,0,sizeof(map));
		memset(a,0,sizeof(a));
		scanf("%d",&n);
		int cnt=n;
		big=0;
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
			big=max(big,a[i]);
		}
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) dp[i][j]=a[i];
		_find(big);
		for(int i=1;i<=n;i++){
			if(map[a[i]]==1){
				cnt--;
				map[a[i]]=0;
			} 
		}
		printf("%d\n",cnt);
	}
	return 0;
}
