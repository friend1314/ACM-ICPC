#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<queue>
#define ll long long
#define MAXN 100100
using namespace std;
inline ll re()
{
    ll x=0,f=1;char ch=getchar();
    while(ch>'9'||ch<'0')
    {
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=(x<<3)+(x<<1)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void wr(ll x)
{
    if(x<0) x=-x,putchar('-');
    if(x>9) wr(x/10);
    putchar(x%10+'0');
}
ll n,a[MAXN];
struct mwy{
    ll l,r,minl,loc;
}e[MAXN*5];
ll lch[MAXN*5],rch[MAXN*5],tot=1;
void pushup(ll x)
{
    if(e[lch[x]].minl<e[rch[x]].minl)
    {
        e[x].minl=e[lch[x]].minl;
        e[x].loc=e[lch[x]].loc;
    }
    else
    {
        e[x].minl=e[rch[x]].minl;
        e[x].loc=e[rch[x]].loc;
    }
    return;
}
void build(ll x,ll l,ll r)
{
    e[x].l=l;e[x].r=r;
    if(l==r)
    {
        e[x].minl=a[l];
        e[x].loc=l;
        return;
    }
    ll mid=(l+r)>>1;
    lch[x]=++tot;
    build(lch[x],l,mid);
    rch[x]=++tot;
    build(rch[x],mid+1,r);
    pushup(x);
}
ll flag,res=(1ll<<60ll);
ll ask(ll x,ll l,ll r)
{
    if(e[x].l>=l&&e[x].r<=r)
    {
        if(e[x].minl<res)
        {
            res=e[x].minl;
            flag=e[x].loc;
        }
        return e[x].minl;
    }
    if(e[x].l>r||e[x].r<l) return (1ll<<60ll);
    return min(ask(lch[x],l,r),ask(rch[x],l,r));
}
ll ans;
void dfs(ll v,ll l,ll r)
{
    if(l>r) return;
    res=(1ll<<60ll);
    ll minn=ask(1,l,r);
    ans+=minn-v;
    dfs(minn,l,flag-1);
    dfs(minn,flag+1,r);
}
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    n=re();
    for(int i=1;i<=n;i++) a[i]=re();
    build(1,1,n);
    dfs(0,1,n);
    wr(ans);
    return 0;
}
