#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<queue>
#include<algorithm>
#define MAXN 510000
using namespace std;
inline int re()
{
    int x=0,f=1;char ch=getchar();
    while(ch>'9'||ch<'0')
    {
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=(x<<3)+(x<<1)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void wr(int x)
{
    if(x<0) x=-x,putchar('-');
    if(x>9) wr(x/10);
    putchar(x%10+'0');
}
struct mwy{
    int from,to,val;
}e[MAXN];
bool cmp(mwy a,mwy b)
{
    return a.val>b.val;
}
int n,m,flag1,flag2;
int head[MAXN],to[MAXN*2],nxt[MAXN*2],cst[MAXN*2],cnt1;
void ins(int u,int v,int w)
{
    to[++cnt1]=v;
    cst[cnt1]=w;
    nxt[cnt1]=head[u];
    head[u]=cnt1;
}
int dis[MAXN],fa[MAXN],ans;
queue<int>q;
int bfs(int x)
{
    memset(fa,0,sizeof(fa));
    memset(dis,0,sizeof(dis));
    dis[x]=0;
    q.push(x);
    while(!q.empty())
    {
        int k=q.front();q.pop();
        for(int i=head[k];i;i=nxt[i])
        {
            int j=to[i];
            if(fa[k]!=j)
            {
                fa[j]=k;
                dis[j]=dis[k]+cst[i];
                q.push(j);
            }
        }
    }
    int maxl=0,maxn;
    for(int i=1;i<=n;i++)
    {
        if(maxl<dis[i]) maxl=dis[i],maxn=i;
    }
    return maxn;
}
void dfs(int last,int now,int wy,int minl)
{
    if(now==wy-1)
    {
        minl=min(minl,dis[n]-dis[last]);
        ans=max(minl,ans);
        return;
    }
    for(int i=last+1;(dis[i]-dis[last])*(wy-1)<=dis[n]&&i<=n;i++)
    {
        int yy=min(minl,dis[i]-dis[last]);
        dfs(i,now+1,wy,yy);
    }
}
int main()
{
    freopen("track.in","r",stdin);
    freopen("track.out","w",stdout);
    n=re();m=re();
    for(int i=1;i<n;i++)
    {
        int x=re(),y=re(),z=re();
        e[i].from=x;e[i].to=y;e[i].val=z;
        ins(x,y,z);ins(y,x,z);
        if(x!=1) flag1=1;
        if(y!=x+1) flag2=1;
    }
    if(m==1)
    {
        int st=bfs(1);
        int ed=bfs(st);
        wr(dis[ed]);
        return 0;
    }
    if(!flag1||m==n-1)
    {
        sort(e+1,e+1+n,cmp);
        wr(e[m].val);
        return 0;
    }
    if(!flag2)
    {
        int k=bfs(1);
        for(int i=1;dis[i]*(m-1)<=dis[n]&&i<=n;i++)
        {
            dfs(i,1,m,dis[i]-dis[1]);
        }
        wr(ans);
        return 0;
    }
    int k=bfs(1);
    wr(dis[k]);
    return 0;
}
