#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<queue>
#include<algorithm>
#define MAXN 301000
using namespace std;
inline int re()
{
    int x=0,f=1;char ch=getchar();
    while(ch>'9'||ch<'0')
    {
        if(ch=='-') f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9')
    {
        x=(x<<3)+(x<<1)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
inline void wr(int x)
{
    if(x<0) x=-x,putchar('-');
    if(x>9) wr(x/10);
    putchar(x%10+'0');
}
int T,n,a[MAXN],vst[MAXN],p[MAXN],ans,m;
int main()
{
    freopen("money.in","r",stdin);
    freopen("money.out","w",stdout);
    T=re();
    while(T--)
    {
        memset(vst,0,sizeof(vst));
        memset(p,0,sizeof(p));
        ans=0;m=0;
        n=re();
        for(int i=1;i<=n;i++) a[i]=re();
        sort(a+1,a+1+n);
        int maxl=a[n];
        for(int i=1;i<=n;i++)
        {
            if(!vst[a[i]]) ans++;
            for(int j=1;j*a[i]<=maxl;j++)
            {
                if(!vst[a[i]*j]) vst[a[i]*j]=1,p[++m]=a[i]*j;
            }
            for(int k=1;k*a[i]<=maxl;k++)
            {
                int wy=k*a[i];
                for(int j=1;j<=m;j++)
                {
                    if(p[j]+wy>maxl) continue;
                    if(!vst[p[j]+wy]) vst[p[j]+wy]=1,p[++m]=p[j]+wy;
                }
            }
        }
        wr(ans);puts("");
    }
    return 0;
}
