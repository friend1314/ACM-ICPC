#include<iostream>
#include<cmath>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std;

long long t,n;
long long num[1050];
int book[250050];
long long maxn;//������
long long num_book[1050];//ѡ1����� 

void dfs(long long step,long long sum)
{
	if(step>n)
	{
		long long flag=0;
		for(int i=1;i<=n;i++)
		{
			flag+=num_book[i];
		}
		if(flag==1) return;
		book[sum]=1;
		return;
	}
	for(int i=0;i<=maxn;i++)
	{
		sum+=num[step]*i;
		if(sum>maxn) continue;
		num_book[step]+=i;//ѡһ���Լ�
		dfs(step+1,sum);
		num_book[step]-=i;//��ȥһ�� 
		sum-=num[step]*i;
	}
}

void clean()
{
	memset(book,0,sizeof(book));
	maxn=-1;
}

bool cmp(long a,long b)
{
	return a>b;
}

int main()
{
	freopen("money.in","r",stdin);
	freopen("money.out","w",stdout);
//	ios::sync_with_stdio(false);
	cin>>t;
	while(t--)
	{
		clean();
		cin>>n;
		long long ans=n;
		for(int i=1;i<=n;i++)
		{
			cin>>num[i];
			maxn=max(maxn,num[i]);
		}
		
		sort(num+1,num+n+1,cmp);//��С����ɸ�ӿ��ٶ�
		
		dfs(1,0);
			
		for(int i=1;i<=n;i++)
		{
			if(book[num[i]]==1) ans--;
		}
			
		cout<<ans<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}



