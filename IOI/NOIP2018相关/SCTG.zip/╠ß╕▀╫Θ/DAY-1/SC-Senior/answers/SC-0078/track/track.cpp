#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>

using namespace std;

int p[100];

struct make_edge
{
	int a;
	int b;
	int w;
};

make_edge edge[1000];

void clean()
{
	for(int i=1;i<=99;i++)
	{
		p[i]=i;
	}
}

int find_father(int v)
{
	if(p[v]==v) return v;
	else 
	{
		p[v]=find_father(p[v]);
		return p[v];
	}
}

void mer(int a,int b)
{
	int a_f=find_father(a);
	int b_f=find_father(b);
	if(a_f!=b_f)
	{
		p[b_f]=a_f;
	}
}

int n,m;

bool cmp(make_edge p,make_edge q)
{
	return p.w<q.w;
}
int main()
{
	freopen("track.in","r",stdin);
	freopen("track.out","w",stdout);
	cin>>n>>m;
	clean();
	int max_ans=-1;
	for(int i=1;i<=n-1;i++)
	{
		cin>>edge[i].a>>edge[i].b>>edge[i].w;
	}
	sort(edge+1,edge+n-1+1,cmp);
	int sum=0;
	int flag=0;
	for(int i=1;i<=n-1;i++)
	{
		if(find_father(edge[i].a)!=find_father(edge[i].b))
		{
			mer(edge[i].a,edge[i].b);
			sum+=edge[i].w;
			flag++;		
		}
		if(flag==n-1) break;
	}
	cout<<sum<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
















