#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<cstdlib>
using namespace std;

const int maxn=100100;
long long a[maxn];
long long ans;

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	long long n;
	cin>>n;
	for(long long i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(long long i=1;i<=n;i++)
	{
		if(a[i]-a[i-1]>=0)
		{
			ans+=a[i]-a[i-1];
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
