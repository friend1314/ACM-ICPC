from random import *
from sys import *
from os import *

N = int(argv[1])
C = int(argv[2])
M = int(argv[3])
if M == 0:	M = randint(1, N)
P1 = int(argv[4])
CS = int(argv[5])
if P1 == -1:	P1 = M
else:	P1 = randint(1, N)

print N
print " ".join([str(randint(1, C)) for i in xrange(N)])
print M, P1, randint(1, CS), randint(1, CS)