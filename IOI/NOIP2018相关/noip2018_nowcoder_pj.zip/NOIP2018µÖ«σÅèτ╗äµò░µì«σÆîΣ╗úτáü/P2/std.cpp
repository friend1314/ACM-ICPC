#include <cstdio>
long long c[1000005];
int main() {
    int n; scanf("%d", &n);
    for(int i = 1; i <= n; ++i) scanf("%lld", c + i);
    long long m, p1, s1, s2;
    scanf("%lld%lld%lld%lld", &m, &p1, &s1, &s2);
    c[p1] += s1;
    long long sum = 0;
    for(int i = 1; i <= n; ++i) sum += (long long) (m - i) * c[i];
    long long ans = 1ll << 62;
    int pos = -1;
    for(int i = 1; i <= n; ++i) {
        sum += (long long) (m - i) * s2;
        if((sum > 0 ? sum : -sum) < ans) { ans = (sum > 0 ? sum : -sum); pos = i; }
        sum -= (long long) (m - i) * s2;
    }
    printf("%d\n", pos);
}