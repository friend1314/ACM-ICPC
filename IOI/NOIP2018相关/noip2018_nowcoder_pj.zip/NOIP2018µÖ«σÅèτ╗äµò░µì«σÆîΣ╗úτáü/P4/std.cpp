#include <cstdio>
const int MAX_N = 1000005;
int v[MAX_N], ch[MAX_N][2], c[MAX_N];
int ans;

bool same(int a, int b) {
	if(a == b) return 1; if(!a || !b) return 0;
	return v[a] == v[b] && same(ch[a][0], ch[b][1]) && same(ch[a][1], ch[b][0]);
}

void dfs(int i) {
	if(!i) return;
	dfs(ch[i][0]); dfs(ch[i][1]);
	c[i] = 1 + c[ch[i][0]] + c[ch[i][1]];
	v[i] = v[i] + v[ch[i][0]] + v[ch[i][1]];
	if(ans < c[i] && same(ch[i][0], ch[i][1])) ans = c[i];
}

int main() {
	int n; scanf("%d", &n);
	for(int i = 1; i <= n; ++i) scanf("%d", v + i);
	v[0] = 1005;
	for(int i = 1; i <= n; ++i) for(int k = 0; k < 2; ++k) {scanf("%d", ch[i] + k); if(ch[i][k] == -1) ch[i][k] = 0;}
	dfs(1);
	printf("%d\n", ans);
}