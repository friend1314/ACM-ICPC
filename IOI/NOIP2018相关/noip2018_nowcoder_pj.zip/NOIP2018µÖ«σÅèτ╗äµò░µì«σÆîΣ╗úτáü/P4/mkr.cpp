#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cassert>
using namespace std;
const int MAX_N = 1000005;
int ch[MAX_N][2], pts, C, siz[MAX_N];

int randint(int l, int r) {return rand() % (r - l + 1) + l;}

int copy(int q) {
	if(q == 0) return 0;
	int p = ++pts;
	ch[p][0] = copy(ch[q][1]);
	ch[p][1] = copy(ch[q][0]);
	return p;
}

int make(int n) {
	if(n == 0) return 0;
	int p = ++pts;
	if((n & 1) && rand() % 2 == 0) {
		ch[p][0] = make(n / 2);
		ch[p][1] = copy(ch[p][0]);
	} else {
		int l = -1;
		switch(randint(1, 3)) {
			case 1: l = randint(0, n - 1); break;
			case 2: l = randint(0, min(n - 1, 3)); break;
			case 3: l = randint(max(0, n - 4), n - 1); break;
		}
		ch[p][0] = make(l);
		ch[p][1] = make(n - 1 - l);
	}
	return p;
}

bool same(int a, int b) {
	if(a == b) return 1;
	if(!a || !b) return 0;
	return same(ch[a][0], ch[b][1]) && same(ch[a][1], ch[b][0]);
}
int v[MAX_N];

bool f;
void assign(int q, int p) {
	if(!q) {assert(!p); return;}
	v[p] = v[q];
	if(f && !ch[p][0] && !ch[p][1] && randint(0, 3))
		{v[p] = randint(1, C); f = randint(0, 1); }
	assign(ch[q][0], ch[p][1]);
	assign(ch[q][1], ch[p][0]);
}

void pre(int i) {
	if(!i) return;
	siz[i] = 1;
	pre(ch[i][0]);
	pre(ch[i][1]);
	siz[i] = 1 + siz[ch[i][0]] + siz[ch[i][1]];
}

void dfs(int i) {
	if(!i) return;
	v[i] = randint(1, C);
	if(same(ch[i][0], ch[i][1]) && siz[i] <= pts / 5) {
		f = rand() % 2;
		dfs(ch[i][0]);
		assign(ch[i][0], ch[i][1]);
	} else {
		dfs(ch[i][0]);
		dfs(ch[i][1]);
	}
}

int makechain(int l, int k) {
	if(!l) return 0;
	int p = ++pts;
	ch[p][!k] = 0;
	ch[p][k] = makechain(l - 1, k);
	return p;
}

int main(int argc, char **argv) {
	int n = atoi(argv[1]);
	C = atoi(argv[2]);
	int t = atoi(argv[3]);

	int *x = new int;
	srand((size_t) x);
	delete x;

	if(t == 1) {
		for(int i = 1; i <= n; ++i) 
			for(int k = 0; k < 2; ++k) {
				ch[i][k] = i << 1 | k;
				if(ch[i][k] > n) ch[i][k] = 0;
			}
	} else if(t == 2) {
		pts = 1;
		int l = randint(0, n - 1);
		if(n % 2 == 1 && randint(0, 2)) l = n / 2;
		ch[1][0] = makechain(l, 0);
		ch[1][1] = makechain(n - 1 - l, 1);
		assert(pts == n);
	} else {
		make(n);
		assert(pts == n);
	}
	pts = n;

	pre(1);
	dfs(1);

	printf("%d\n", n);
	for(int i = 1; i <= n; ++i) printf("%d%c", v[i], " \n"[i == n]);
	for(int i = 1; i <= n; ++i) printf("%d %d\n",ch[i][0]?ch[i][0]:-1,ch[i][1]?ch[i][1]:-1);
}