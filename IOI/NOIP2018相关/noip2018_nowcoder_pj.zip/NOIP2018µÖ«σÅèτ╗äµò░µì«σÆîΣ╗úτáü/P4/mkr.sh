for((i=9;i<=9;++i));do run mkr 16383 1000 1 > tree$i.in;  done
for((i=10;i<=10;++i));do run mkr 32767 1000 1 > tree$i.in;  done
for((i=11;i<=12;++i));do run mkr 65535 1000 1 > tree$i.in;  done
for((i=13;i<=16;++i));do run mkr 100000 1000 1 > tree$i.in;  done
for((i=17;i<=20;++i));do run mkr 100000 1 0 > tree$i.in;  done
for((i=21;i<=25;++i));do run mkr 1000000 1000 0 > tree$i.in;  done