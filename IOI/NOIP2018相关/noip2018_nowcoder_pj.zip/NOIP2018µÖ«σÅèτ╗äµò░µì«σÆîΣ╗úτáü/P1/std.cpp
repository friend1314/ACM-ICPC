#include <cstdio>
int main() {
	int ans = 0;
	char ch;
	while(ch = getchar(), ch != '\n') ans += (ch != ' ');
	printf("%d\n", ans);
}