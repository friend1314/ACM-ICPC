from random import *
from sys import *
from os import *

A = "                                    0987654321qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM"

print "".join([A[randint(0, len(A) - 1)] for i in xrange(randint(1, 5))])