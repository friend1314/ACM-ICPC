#include <cstdio>
#include <algorithm>
int t[505], p[1005 * 105];
long long f[1005 * 105], g[505][105];
int main() {
	int n, m, P = 0; scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++i) {
		scanf("%d", t + i); 
		for(int k = 0; k <= m; ++k) p[++P] = t[i] + k;
	}
	std::sort(t + 1, t + n + 1);
	std::sort(p + 1, p + P + 1); P = std::unique(p + 1, p + P + 1) - p - 1;
	t[0] = -4e6;
	int ans = 2017011328;
	for(int i = 1, k = 0, pi; i <= P; ++i) {
		f[i] = ans; pi = p[i];
		while(k < n && t[k + 1] <= pi) {
			++k;
			for(int i = 0; i <= m; ++i) g[k][i] = 2017011328;
		}
		for(int j = k, c = 0; j >= 1; --j) {
			c += pi - t[j];
			if(t[j - 1] != t[j] && pi - t[j - 1] >= m) f[i] = std::min(f[i], c + g[j - 1][std::min(m, pi - m - t[j - 1])]);
		}
		if(g[k][std::min(m, pi - t[k])] > f[i]) g[k][std::min(m, pi - t[k])] = f[i];
		for(int j = 1; j <= m; ++j) g[k][j] = std::min(g[k][j], g[k][j - 1]);
	}
	printf("%lld\n", g[n][m]);
}