from random import *
from sys import *
from os import *

N = int(argv[1])
M = int(argv[2])
T = int(argv[3])

def make_spl(N, M, Force = False, AllowZero = False):
	# print "make_spl", N, M, Force, AllowZero
	if AllowZero:
		# print "rec call"
		R = map(lambda x : x - 1, make_spl(N + M, M, Force, False))
		R = filter(lambda x : x > 0, R)
		while len(R) < M:	R.append(0)
		assert sum(R) == N
		assert len(R) == M
		return R
		
	R = []
	assert 1 <= M <= N
	if Force or M >= N - 20:
		S = set([N])
		while(len(S) < M):
			S.add(randint(1, N))
		l = 0
		for r in sorted(list(S)):
			R.append(r - l)
			l = r
	else:
		pa = randint(1, min(10, N))
		S = randint(pa, N - M + pa)
		R = make_spl(S, pa, Force = True) + make_spl(N - S, M - pa, Force = True)
		shuffle(R)
	assert sum(R) == N
	assert len(R) == M
	return R

def presum(A):
	s = 0
	for i in xrange(len(A)):
		A[i] += s
		s = A[i]
	return [0] + A


print N, M


K = randint(5, min(min(T, N), 100))
SN = make_spl(N, K)
ST = presum(make_spl(T, K))

A = []
for k in xrange(K):
	s = SN[k]
	for i in xrange(s):
		A.append(randint(ST[k] + 1, ST[k + 1]))


#A = sorted(A)
#for i in xrange(1, N):	print A[i] - A[i - 1]

shuffle(A)
print " ".join(map(str, A))